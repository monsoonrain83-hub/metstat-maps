/* =====================================================================
   چیدمان تازهٔ صفحه‌ها: یک کادر نقشه در هر صفحه، انتخاب نوع نقشه زیر آن،
   تنظیمات همان نقشه، سپس تنظیمات کل صفحه؛ ذخیره/اشتراک، مرزبندی، گزارش، پرسش‌ها و آدرس هر صفحه
   ===================================================================== */
const VPAGES={
  main:{wrap:"app", cards:"grid", status:"status", empty:"empty", keepAside:["tplPanel"], rep:true},
  ds:{wrap:"dsApp", cards:"dsCards", status:"dsStatus", empty:"dsEmpty", rep:true},
  cv:{wrap:"cvApp", cards:"cvCards", status:"cvStatus", empty:"cvEmpty", rep:true},
  lt:{wrap:"ltApp", cards:"ltCards", status:"ltStatus", empty:"ltEmpty", rep:false},
  wn:{wrap:"wnApp", cards:"wnCards", status:"wnStatus", empty:"wnEmpty", rep:true}
};
const ROUTES={wb:"weatherbell", wu:"weatherus", wm:"weathermodels", cu:"anymap", ds:"elevation-correction", cv:"convection", lt:"lightning", wn:"alertmaps", cqc:"statistical-operations", ca:"climate-atlas", on:"online-maps", ci:"climate-indices"};
const PAGE_SUB={ds:"دمای مدل با آهنگ کاهش دما و بارش مدل با ضریب ارتفاعی روی توپوگرافی دقیق (DEM) ریزمقیاس می‌شود — کاملاً آفلاین، روی همین دستگاه",
  cv:"احتمال و شدت همرفت از ترکیب نقشه‌های ناپایداری، چینش باد، رطوبت و بازتاب — کاملاً آفلاین، روی همین دستگاه",
  lt:"چگالی، زمان و مسیر حرکت توده‌های تندری از تصاویر رعدوبرق — کاملاً آفلاین، روی همین دستگاه",
  wn:"نقشه‌ها و متن هشدار رنگی (قرمز، نارنجی، زرد) از نقشه‌های پیش‌بینی — کاملاً آفلاین، روی همین دستگاه",
  cqc:"کنترل کیفیت، ترمیم، خروجی‌های آماری، پهنه‌بندی و شاخص‌های اقلیمی بر روی داده‌های هواشناسی"};
const PAGE_NAME={ci:"شاخص‌های اقلیمی (آنلاین)", on:"تحلیل نقشه‌های آنلاین", wb:"نقشه‌های WeatherBELL", wm:"نقشه‌های weathermodels", wu:"نقشه‌های weather.us", cu:"نقشه از هر سایت", ds:"اصلاح نقشه‌های بارش و دما با توجه به ارتفاع", cv:"همرفت: احتمال وقوع و شدت", lt:"رعدوبرق", wn:"هشدارهای جوی", cqc:"عملیات آماری بر روی داده‌های هواشناسی", ca:"اطلس اقلیمی ایستگاه‌ها"};
const V={pages:{}, cur:null, off:(()=>{ try{ return localStorage.getItem("v.off")==="1"; }catch(e){ return false; } })()}; // v.off=1: چیدمان کلاسیک (برای آزمون‌های خودکار)
// نقشهٔ بوم (canvas) هر تصویر کارت، برای ساخت نسخهٔ پرجزئیات (اندازهٔ لایهٔ مرز همان منطقه)
// کلید کوتاه به‌جای نگه‌داشتن رشتهٔ چند‌مگابایتی base64 (مصرف حافظهٔ زیاد و خطای «Aw, Snap»)
const vKey=s=>{ const n=s.length; let h=n; for(let i=0;i<64;i++){ const j=Math.floor(n*(i+0.5)/64); h=(Math.imul(h,31)+s.charCodeAt(j))|0; } return n+":"+h+":"+s.slice(n>>1,(n>>1)+24); };
const CANVAS_OF=new Map();
{ const orig=HTMLCanvasElement.prototype.toDataURL;
  HTMLCanvasElement.prototype.toDataURL=function(...a){ const s=orig.apply(this,a); if(this.__re||this.__lt){ const k=vKey(s); CANVAS_OF.delete(k); CANVAS_OF.set(k,this); if(CANVAS_OF.size>14){ const o=CANVAS_OF.keys().next().value; CANVAS_OF.delete(o); } } return s; }; }
const svgIc=p=>`<svg viewBox="0 0 24 24" aria-hidden="true" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
function vPageKey(){ for(const [k,c] of Object.entries(VPAGES)) if(!$(c.wrap).hidden) return k; return null; }
function vBuild(key){
  const c=VPAGES[key], wrap=$(c.wrap), main=wrap.querySelector("main"), aside=wrap.querySelector("aside"), cards=$(c.cards);
  const pg={key, c, cards, sel:null, moved:[], hiCache:new WeakMap()};
  const stage=document.createElement("section"); stage.className="stage"; stage.hidden=true;
  stage.innerHTML=`<div class="stbar"><button class="icbtn exp" type="button" title="ذخیرهٔ نقشه" aria-label="ذخیرهٔ نقشه">${svgIc('<path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/>')}<span>ذخیره</span></button><button class="icbtn shr" type="button" title="اشتراک‌گذاری نقشه" aria-label="اشتراک‌گذاری نقشه">${svgIc('<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>')}<span>اشتراک‌گذاری</span></button>
    <label class="brdl"><span>مرزبندی</span><select class="brdMode"><option value="metstat">تفکیک با مرز MetStat</option><option value="src">تفکیک با مرز weather.us</option><option value="none">بدون مرز</option></select></label>
    <label class="brdl"><span>نقاط</span><select class="seatSel"><option value="0">بدون نقاط</option><option value="1">مراکز شهرستان‌ها</option></select></label>
    <label class="brdl ttzl" hidden><span>زوم کن</span><select class="ttZoom"><option value="me">زوم خاورمیانه</option><option value="iran">زوم کن روی ایران</option></select></label>
    <span class="zoneSlot"></span></div>
    <div class="svis"></div><div class="sinfo"><button class="infob" type="button" title="این نقشه چیست؟" aria-label="راهنمای این نقشه">i</button></div><div class="scap"></div>
    <button class="repbtn" type="button" hidden>تولید گزارش و تحلیل</button>`;
  const tabs=document.createElement("nav"); tabs.className="mtabs"; tabs.setAttribute("aria-label","انتخاب نوع نقشه"); tabs.hidden=true;
  const mset=document.createElement("section"); mset.className="panel mset"; mset.hidden=true; mset.innerHTML=`<h2>تنظیمات این نقشه</h2><div class="msbody"></div>`;
  const notes=document.createElement("div"); notes.className="vnotes";
  const pset=document.createElement("section"); pset.className="pset"; pset.innerHTML=`<h2 class="psh">تنظیمات کل صفحه (برای همهٔ نقشه‌ها)</h2>`;
  const status=$(c.status);
  status.after(stage); stage.after(tabs); tabs.after(mset); mset.after(notes); notes.after(pset);
  // پنل‌های تنظیمات کنار صفحه به پایین منتقل می‌شوند؛ پنل افزودن نقشه (اولی) و قالب نقشه در کنار می‌مانند
  const panels=[...aside.querySelectorAll(":scope > section.panel")];
  panels.forEach((p,i)=>{ if(i===0 || (c.keepAside||[]).includes(p.id)) return; pset.append(p); });
  // مرزبندی زوم: کادر قدیمی به نوار بالای نقشه می‌رود
  const wz=wrap.querySelector("[data-wuz]"); if(wz){ stage.querySelector(".zoneSlot").append(wz); wz.classList.add("inbar"); }
  cards.classList.add("vhide");
  pg.stage=stage; pg.tabs=tabs; pg.mset=mset; pg.msb=mset.querySelector(".msbody"); pg.notes=notes; pg.pset=pset;
  stage.querySelector(".exp").onclick=()=>vExport(pg,"save");
  stage.querySelector(".shr").onclick=()=>vExport(pg,"share");
  const bm=stage.querySelector(".brdMode"); bm.value=brdMode(); bm.onchange=()=>setBrdMode(bm.value);
  const ss=stage.querySelector(".seatSel"); ss.value=store.get("seats.on",false)?"1":"0"; ss.onchange=()=>setSeats(ss.value==="1");
  const tz=stage.querySelector(".ttZoom"); tz.value=store.get("tt.zoom","me"); tz.onchange=()=>setTTZoom(tz.value);
  stage.querySelector(".repbtn").onclick=()=>vReport(pg);
  stage.querySelector(".infob").onclick=()=>vInfo(pg);
  new MutationObserver(()=>vSchedule(pg)).observe(cards,{childList:true});
  V.pages[key]=pg; return pg;
}
function vSchedule(pg){ clearTimeout(pg.t); pg.t=setTimeout(()=>vSync(pg),60); }
const vTitle=card=>{ const h=card.querySelector(":scope > header h3, header h3"); return h?h.textContent.trim():"نقشه"; };
// نقشه‌ها اول، نمودارها و جدول‌ها آخر
const vIsChart=c=>/نمودار|chart|مطلوبیت|Favourab/i.test(vTitle(c));
function vEntries(pg){ const a=[...pg.cards.children].filter(e=>e.tagName==="ARTICLE" && !e.classList.contains("cvrep")); return a.filter(c=>!vIsChart(c)).concat(a.filter(vIsChart)); }
function vSync(pg){
  const ents=vEntries(pg), extra=[...pg.cards.children].filter(e=>e.tagName!=="ARTICLE");
  // پیام‌ها و هشدارهای متنی زیر کادر
  pg.notes.replaceChildren(...extra.filter(e=>e.classList.contains("hint")));
  pg.extra=extra.filter(e=>!e.classList.contains("hint"));
  pg.stage.hidden=!ents.length; pg.tabs.hidden=ents.length<1; pg.mset.hidden=!ents.length;
  { const isTT=pg.key==="main" && P && P.custom && P.T && P.T.tt && P.T.tt.geo; pg.stage.querySelector(".ttzl").hidden=!isTT; const bmo=pg.stage.querySelector('.brdMode option[value="src"]'); if(bmo) bmo.textContent = isTT ? "مرز tropicaltidbits" : (P&&P.key==="wb" ? "مرز WeatherBELL" : P&&P.custom ? "مرز نقشهٔ ورودی" : "تفکیک با مرز weather.us"); }
  if(!ents.length){ vRestore(pg); pg.sel=null; pg.tabs.replaceChildren(); pg.stage.querySelector(".repbtn").hidden=true; return; }
  if(!pg.sel || !ents.includes(pg.sel)) pg.sel=ents[0];
  const rep=pg.c.rep && (pg.key==="main" ? !!(pg.sel && Object.values(state.cards).some(c=>c.card===pg.sel && c.data)) : vReportSource(pg)); pg.stage.querySelector(".repbtn").hidden=!rep;
  pg.tabs.replaceChildren(...ents.map(card=>{ const b=document.createElement("button"); b.type="button"; b.className="mtab"; b.textContent=vTitle(card); if(card.dataset.icon){ const im=new Image(); im.src=card.dataset.icon; im.className="hzic"; im.alt=""; b.prepend(im); }
    b.setAttribute("aria-pressed", card===pg.sel); b.onclick=()=>{ pg.sel=card; vShow(pg); pg.stage.querySelector(".repbtn").hidden=!(pg.c.rep && (pg.key==="main" ? !!(pg.sel && Object.values(state.cards).some(c=>c.card===pg.sel && c.data)) : vReportSource(pg))); pg.tabs.querySelectorAll(".mtab").forEach(x=>x.setAttribute("aria-pressed", x===b)); }; return b; }));
  vShow(pg);
}
// بازگرداندن اجزای کارت قبلی سر جای خودشان
function vRestore(pg){ if(pg.zimg){ pg.zimg.style.transform=""; pg.zimg.style.transformOrigin=""; pg.zimg=null; } for(const [el,ph] of pg.moved){ if(ph.parentNode) ph.replaceWith(el); } pg.moved=[]; }
function vMove(pg, el, dest){ const ph=document.createComment("v"); el.replaceWith(ph); pg.moved.push([el,ph]); dest.append(el); }
function vShow(pg){
  vRestore(pg);
  const card=pg.sel, vis=pg.stage.querySelector(".svis"), cap=pg.stage.querySelector(".scap"); vis.replaceChildren(); cap.replaceChildren(); pg.msb.replaceChildren();
  if(!card) return;
  const img=card.querySelector("img"), sub=card.querySelector("header .sub");
  if(!img){ vMove(pg, card, vis); return; }
  // نما (کنترل‌های تعویض نما مثل نمای «ورودی/ضریب») کنار نقشه
  const host=img.parentElement; const view=host && host.querySelector(":scope > .dsview"); if(view) vMove(pg, view, vis);
  vMove(pg, img, vis);
  try{ vZoomAttach(pg, img, vis); }catch(e){ console.warn("zoom",e); }
  const st=card.querySelector(".stats"); if(sub && sub.textContent.trim()){ const s=document.createElement("p"); s.className="ssub"; s.textContent=sub.textContent; cap.append(s); }
  if(st) vMove(pg, st, cap);
  // تنظیمات همین نقشه: هر چه در کارت باقی مانده (به‌جز سربرگ، تصویر، آمار و دکمه‌های دانلود)
  const skip=e=>e.tagName==="HEADER" || e.classList.contains("dl") || e.classList.contains("stats");
  for(const ch of [...card.children]){ if(skip(ch)) continue;
    if(ch.contains(img) || ch.querySelector && ch.querySelector(".svis")){ continue; }
    if(ch.classList.contains("split")){ for(const g of [...ch.children]){ if(g.querySelector(".dl")&&!g.querySelector("input,select,canvas,table")) continue; if(!skip(g)) vMove(pg, g, pg.msb); } continue; }
    vMove(pg, ch, pg.msb); }
  // تب‌های مدل (همرفت) هم تنظیمات این نقشه‌اند
  if(pg.extra && pg.extra.length) for(const e of pg.extra){ if(e.isConnected && !pg.msb.contains(e)) vMove(pg, e, pg.msb); }
  pg.mset.hidden=!pg.msb.children.length;
  vHiRes(pg, img);
  if(!pg.imgObs){ pg.imgObs=new MutationObserver(()=>{ if(pg.sel && pg.stage.contains(pg.imgObs.target)) vHiRes(pg, pg.imgObs.target); }); }
  pg.imgObs.disconnect(); pg.imgObs.target=img; pg.imgObs.observe(img,{attributes:true, attributeFilter:["src"]});
}
// نمایش نقشه در اندازهٔ لایهٔ مرز همان منطقه (weather.us: ۴ برابر) تا مرزها و نام‌ها روی نقشهٔ بزرگ‌شده بیفتند
async function vHiRes(pg, img){
  if(window.MS_SAFE) return;
  const src=img.getAttribute("src"); if(!src || src.startsWith("blob:")) return;
  const cv=CANVAS_OF.get(vKey(src)); if(!cv) return;
  const re=cv.__re; if(!(cv.__lt || (re && PROFILES[re.prof] && PROFILES[re.prof].W===760 && PROFILES[re.prof].H===760))) return;
  if(state.busy || wn.busy || cv.busy || ds.busy) return;
  let u=pg.hiCache.get(cv);
  try{ if(!u){ const blob=await exportPNG(cv); u=URL.createObjectURL(blob); pg.hiCache.set(cv,u); if(pg.hiCache.size>4){ const k0=pg.hiCache.keys().next().value; const u0=pg.hiCache.get(k0); pg.hiCache.delete(k0); setTimeout(()=>{ try{ if(![...document.images].some(i=>i.src===u0)) URL.revokeObjectURL(u0); }catch(e){} },3000); } }
    if(img.getAttribute("src")===src){ img.dataset.lo=src; img.src=u; } }catch(e){ console.warn("hires",e); }
}
// ---- مرزبندی: حالت (MetStat / weather.us / بدون مرز) ----
function brdMode(){ return store.get("brd.mode","metstat"); }
function setBrdMode(v){
  store.set("brd.mode", v);
  store.set("wuz.on", v==="metstat");
  for(const id of ["showBorders","cvBorders","wnBorders"]){ const e=$(id); if(e){ e.checked = v!=="none"; store.set(id, e.checked); } }
  if($("borders")){ $("borders").value = v==="src" ? "orig" : "bold"; store.set("wb.borders", $("borders").value); }
  document.querySelectorAll(".brdMode").forEach(s=>s.value=v);
  try{ wuzSync(); }catch(e){}
  const k=vPageKey(); if(k==="main"){ try{ schedule(); }catch(e){} } else try{ wuzRefresh(); }catch(e){}
  if(k==="wn" && wn.res) wnSchedule(50); if(k==="cv" && cv.res) cvSchedule(50);
}
