// ================= خوانش صوتی گزارش‌ها (فارسی / انگلیسی) =================
// موتور: Web Speech API مرورگر (بدون ارسال متن به سرور MetStat). پیش از خوانش، متن برای گوینده «نرمال‌سازی» می‌شود:
// اعداد فارسی به حروف (با «دهم/صدم» برای اعشار)، بازه‌ها، علامت منفی، درصد، واحدها، نمادهای ریاضی و کوته‌نوشت‌های لاتین.
const TTS={ q:[], i:0, playing:false, paused:false, dlg:null, segs:[], ka:null, lang:"fa", voices:[] };
// ---------- عدد به حروف فارسی ----------
const TTS_ONE=["صفر","یک","دو","سه","چهار","پنج","شش","هفت","هشت","نه"], TTS_TEEN=["ده","یازده","دوازده","سیزده","چهارده","پانزده","شانزده","هفده","هجده","نوزده"],
  TTS_TEN=["","","بیست","سی","چهل","پنجاه","شصت","هفتاد","هشتاد","نود"], TTS_HUN=["","صد","دویست","سیصد","چهارصد","پانصد","ششصد","هفتصد","هشتصد","نهصد"];
function ttsInt3(n){ const h=Math.floor(n/100), r=n%100, t=Math.floor(r/10), o=r%10, a=[]; if(h) a.push(TTS_HUN[h]);
  if(r>=10&&r<20) a.push(TTS_TEEN[r-10]); else { if(t) a.push(TTS_TEN[t]); if(o) a.push(TTS_ONE[o]); } return a.join(" و "); }
function ttsIntFa(n){ if(n===0) return "صفر"; if(n<0) return "منفی "+ttsIntFa(-n); if(n>=1e15) return String(n).split("").map(d=>TTS_ONE[+d]).join(" ");
  const sc=["","هزار","میلیون","میلیارد","هزار میلیارد"], parts=[]; let k=0;
  while(n>0){ const c=n%1000; if(c){ let s=ttsInt3(c); if(k===1&&c===1) s="هزار"; else if(k) s+=" "+sc[k]; parts.unshift(s); } n=Math.floor(n/1000); k++; }
  return parts.join(" و "); }
function ttsNumFa(str){ // str: رقم لاتین با نقطهٔ اعشار
  let neg=false; if(str[0]==="-"){ neg=true; str=str.slice(1); }
  const [a,b]=str.split("."); let s=ttsIntFa(parseInt(a||"0",10));
  if(b && /[1-9]/.test(b)){ const d=b.replace(/0+$/,""); if(d.length<=3){ const w=ttsIntFa(parseInt(d,10))+" "+["","دهم","صدم","هزارم"][d.length]; s = (parseInt(a||"0",10)===0) ? w : s+" و "+w; }
    else s+=" ممیز "+d.split("").map(x=>TTS_ONE[+x]).join(" "); }
  return (neg?"منفی ":"")+s; }
const TTS_LET={A:"اِی",B:"بی",C:"سی",D:"دی",E:"ای",F:"اِف",G:"جی",H:"اِچ",I:"آی",J:"جِی",K:"کِی",L:"اِل",M:"اِم",N:"اِن",O:"اُ",P:"پی",Q:"کیو",R:"آر",S:"اِس",T:"تی",U:"یو",V:"وی",W:"دبلیو",X:"ایکس",Y:"وای",Z:"زِد"};
const TTS_DICT_FA=[[/NINO\s*3[./]4/gi,"نینو سه چهار"],[/NINO\s*(\d)/gi,"نینو $1"],[/\bENSO\b/g,"اِنسو"],[/\bNINO\b/gi,"نینو"],[/WeatherBELL/gi,"وِدِربِل"],[/weather\.us/gi,"وِدِر یو اِس"],[/weathermodels(\.com)?/gi,"وِدِر مادِلز"],
  [/MetStat/g,"مِت‌استت"],[/Meteosat/gi,"مِتِئوسَت"],[/meteologix/gi,"مِتِئولاجیکس"],[/tropicaltidbits/gi,"تروپیکال تید بیتس"],[/Windy/g,"ویندی"],[/\bICON\b/g,"آیکون"],[/\bLeave[\s‑-]*One[\s‑-]*Out\b/gi,"حذف یک نقطه"],
  [/\bkriging\b/gi,"کریجینگ"],[/\bspline\b/gi,"اسپلاین"],[/\bSen\b/g,"سِن"],[/Mann[\s–-]*Kendall/gi,"مَن کندال"],[/Pettitt/gi,"پتیت"],[/Welch/gi,"وِلش"],[/Gumbel/gi,"گامبل"],[/Weibull/gi,"ویبول"],[/Hosking/gi,"هاسکینگ"],
  [/R²/g,"آر دو"],[/r²/g,"آر دو"],[/β/g,"بتا"],[/σ/g,"سیگما"],[/Σ/g,"مجموع"],[/α/g,"آلفا"],[/√/g,"رادیکالِ "],[/\bvs\.?\b/gi,"در برابر"],[/\bp\s*≈/g,"پی تقریباً"]];
function ttsNormFa(t){
  t=String(t).replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u2066-\u2069\u200E\u200F️‍]/gu," ").replace(/[▪•▸►◆]/g," ").replace(/[«»"“”]/g,"");
  t=t.replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/[٠-٩]/g,d=>"٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/(\d)٫(\d)/g,"$1.$2").replace(/(\d)[٬,](\d{3})(?!\d)/g,"$1$2");
  for(const [re,s] of TTS_DICT_FA) t=t.replace(re,s);
  t=t.replace(/°\s*C\b/g," درجهٔ سلسیوس").replace(/(\d)\s*°\s*N\b/g,"$1 درجهٔ شمالی").replace(/(\d)\s*°\s*E\b/g,"$1 درجهٔ شرقی").replace(/°/g," درجه")
     .replace(/(\d)\s*mm\b/gi,"$1 میلی‌متر").replace(/(\d)\s*km\b/gi,"$1 کیلومتر").replace(/(\d)\s*hPa\b/gi,"$1 هکتوپاسکال").replace(/(\d)\s*m\b/g,"$1 متر").replace(/(\d)\s*h\b/g,"$1 ساعت")
     .replace(/\/\s*(decade|دهه)/gi," در دهه");
  // بازه و منفی
  t=t.replace(/(\d)\s*[–—]\s*(?=[\d−-])/g,"$1 تا ").replace(/(\d)\s+-\s+(?=\d)/g,"$1 تا ").replace(/(^|[\s(=:،,؛])[−-]\s?(?=\d)/g,"$1منفی ").replace(/[−]/g," منهای ");
  t=t.replace(/(\d(?:\.\d+)?)\s*[٪%]/g,"$1 درصد").replace(/[٪%]/g," درصد");
  t=t.replace(/≥/g," بزرگ‌تر یا مساوی ").replace(/≤/g," کوچک‌تر یا مساوی ").replace(/±/g," مثبت و منفی ").replace(/×/g," ضرب در ").replace(/÷/g," تقسیم بر ").replace(/≈/g," تقریباً ")
     .replace(/\s=\s|=/g," برابر ").replace(/</g," کمتر از ").replace(/>/g," بیشتر از ").replace(/\+(?=\s?\d)/g,"مثبت ").replace(/\+/g," به‌اضافهٔ ");
  // کوته‌نوشت‌ها و حروف تنهای لاتین → نام حروف
  t=t.replace(/\b([A-Z]{2,6})(\d*)\b/g,(m,a,d)=>a.split("").map(c=>TTS_LET[c]).join(" ")+(d?" "+d:"")).replace(/\b([a-zA-Z])\b/g,(m,c)=>TTS_LET[c.toUpperCase()]);
  t=t.replace(/(\d+(?:\.\d+)?)/g,(m)=>" "+ttsNumFa(m)+" ");
  t=t.replace(/[()[\]{}]/g,"، ").replace(/[\/|·—–]/g,"، ").replace(/\s*،\s*(،\s*)+/g,"، ").replace(/\s+/g," ").replace(/\s+([،.؛:؟!])/g,"$1").replace(/،\s*([:.؛])/g,"$1").trim();
  return t; }
function ttsNormEn(t){
  t=String(t).replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u2066-\u2069\u200E\u200F️‍]/gu," ").replace(/[▪•▸►◆]/g," ").replace(/[«»“”"]/g,"");
  t=t.replace(/°\s*C\b/g," degrees Celsius").replace(/(\d)\s*°\s*N\b/g,"$1 degrees north").replace(/(\d)\s*°\s*E\b/g,"$1 degrees east").replace(/°/g," degrees")
     .replace(/(\d)\s*mm\b/g,"$1 millimetres").replace(/(\d)\s*km\b/g,"$1 kilometres").replace(/(\d)\s*hPa\b/g,"$1 hectopascals").replace(/\/decade/g," per decade")
     .replace(/(\d)\s*[–—]\s*(?=\d)/g,"$1 to ").replace(/(^|[\s(=:,;])[−-]\s?(?=\d)/g,"$1minus ").replace(/−/g," minus ")
     .replace(/R²/g,"R squared").replace(/r²/g,"r squared").replace(/≥/g," greater than or equal to ").replace(/≤/g," less than or equal to ").replace(/±/g," plus or minus ").replace(/≈/g," approximately ")
     .replace(/×/g," times ").replace(/÷/g," divided by ").replace(/</g," less than ").replace(/>/g," greater than ").replace(/\s=\s|=/g," equals ").replace(/β/g,"beta").replace(/σ/g,"sigma").replace(/Σ/g,"sum of ").replace(/√/g,"square root of ")
     .replace(/MetStat/g,"Met Stat").replace(/\bvs\.?/g,"versus").replace(/[·|]/g,", ").replace(/[()]/g,", ").replace(/\s+/g," ").replace(/\s+([,.;:?!])/g,"$1").trim();
  return t; }
function ttsNorm(t,lang){ return lang==="en"?ttsNormEn(t):ttsNormFa(t); }
// جمله‌بندی: تکه‌های کوتاه (کروم متن‌های طولانی را نیمه‌کاره قطع می‌کند)
function ttsChunks(t){ const out=[]; for(const s of t.split(/(?<=[.!?؟؛])\s+|\n+/)){ let x=s.trim(); if(!x) continue;
    while(x.length>220){ let k=Math.max(x.lastIndexOf("، ",200),x.lastIndexOf(", ",200),x.lastIndexOf("; ",200)); if(k<60) k=x.lastIndexOf(" ",200); if(k<60) k=200; out.push(x.slice(0,k+1).trim()); x=x.slice(k+1).trim(); }
    if(x) out.push(x); } return out; }
// ---------- صداها ----------
function ttsVoices(lang){ if(!("speechSynthesis" in window)) return []; const all=speechSynthesis.getVoices()||[];
  const vs=all.filter(v=>(v.lang||"").toLowerCase().replace("_","-").startsWith(lang==="en"?"en":"fa"));
  const score=v=>{ const n=v.name||""; let s=0; if(/Natural|Neural|Online/i.test(n)) s+=10; if(/Dilara|Farid|Aria|Jenny|Guy|Sonia|Ryan/i.test(n)) s+=5; if(/Google/i.test(n)) s+=4; if(lang==="en"&&/en-(US|GB)/i.test(v.lang)) s+=2; if(v.localService) s+=1; return s; };
  return vs.sort((a,b)=>score(b)-score(a)); }
const PIPER_ID="__piper";
const ttsUsePiper=lang=>lang==="fa" && PIPER.ok && store.get("tts.voice.fa",PIPER_ID)===PIPER_ID;
const ttsCan=lang=>ttsUsePiper(lang) || (("speechSynthesis" in window) && !!ttsVoice(lang));
function ttsVoice(lang){ const vs=ttsVoices(lang), want=store.get("tts.voice."+lang,""); return vs.find(v=>v.name===want)||vs[0]||null; }
if("speechSynthesis" in window){ try{ speechSynthesis.getVoices(); speechSynthesis.addEventListener("voiceschanged",()=>{ document.querySelectorAll(".ttsBar").forEach(b=>b.__fill&&b.__fill()); }); }catch(e){} }

// ---------- گویندهٔ فارسی عصبی و رایگان (Piper، داخل خود مرورگر؛ بدون سرور و بدون تحریم) ----------
// فایل‌های مدل روی هاست خودتان: tts/fa.onnx و tts/fa.onnx.json (مثلاً صدای fa_IR-gyro-medium از پروژهٔ Piper، مجوز آزاد)
// کتابخانه‌ها: onnxruntime-web (اجرای مدل) و phonemizer (eSpeak NG به WebAssembly برای آوانویسی فارسی)؛
// اگر نسخهٔ محلی در tts/lib نباشد از jsDelivr گرفته می‌شوند. مدل یک بار دانلود و در حافظهٔ مرورگر نگه داشته می‌شود.
const PIPER={ok:null, cfg:null, sess:null, phon:null, loading:null, ctx:null, aud:null, src:null, err:"", prog:0, base:"tts/"};
const PIPER_LIB={ ort:["tts/lib/ort.min.js","https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/dist/ort.min.js"],
  ortWasm:["tts/lib/","https://cdn.jsdelivr.net/npm/onnxruntime-web@1.18.0/dist/"],
  phon:["tts/lib/phonemizer.js","https://cdn.jsdelivr.net/npm/phonemizer@1.2.1/+esm"] };
async function piperProbe(){
  if(PIPER.ok!==null) return PIPER.ok;
  if(location.protocol==="file:"){ PIPER.ok=false; return false; }
  try{ const r=await fetch(PIPER.base+"fa.onnx.json",{cache:"no-cache"}); if(!r.ok) throw 0; PIPER.cfg=await r.json(); PIPER.ok=!!(PIPER.cfg && PIPER.cfg.phoneme_id_map); }
  catch(e){ PIPER.ok=false; }
  return PIPER.ok;
}
async function piperHas(url){ try{ const r=await fetch(url,{method:"HEAD"}); return r.ok; }catch(e){ return false; } }
function piperScript(src){ return new Promise((ok,bad)=>{ const s=document.createElement("script"); s.src=src; s.onload=ok; s.onerror=()=>bad(new Error("load "+src)); document.head.append(s); }); }
async function piperModel(url, onp){
  const C="metstat-tts-v1";
  try{ const c=await caches.open(C), hit=await c.match(url); if(hit) return await hit.arrayBuffer(); }catch(e){}
  const r=await fetch(url); if(!r.ok) throw new Error("model HTTP "+r.status);
  const tot=+r.headers.get("content-length")||0, rd=r.body.getReader(), parts=[]; let n=0;
  for(;;){ const {done,value}=await rd.read(); if(done) break; parts.push(value); n+=value.length; if(tot&&onp) onp(n/tot); }
  const buf=new Uint8Array(n); let o=0; for(const p of parts){ buf.set(p,o); o+=p.length; }
  try{ const c=await caches.open(C); await c.put(url, new Response(buf,{headers:{"Content-Type":"application/octet-stream"}})); }catch(e){}
  return buf.buffer;
}
function piperLoad(onp){
  if(PIPER.sess) return Promise.resolve();
  if(PIPER.loading) return PIPER.loading;
  PIPER.loading=(async()=>{
    const localOrt=await piperHas(PIPER_LIB.ort[0]);
    if(!window.ort) await piperScript(localOrt?PIPER_LIB.ort[0]:PIPER_LIB.ort[1]);
    ort.env.wasm.wasmPaths=localOrt?PIPER_LIB.ortWasm[0]:PIPER_LIB.ortWasm[1]; ort.env.wasm.numThreads=1;
    const localPh=await piperHas(PIPER_LIB.phon[0]);
    PIPER.phon=await import(localPh?new URL(PIPER_LIB.phon[0],location.href).href:PIPER_LIB.phon[1]);
    const buf=await piperModel(PIPER.base+"fa.onnx", onp);
    PIPER.sess=await ort.InferenceSession.create(buf,{executionProviders:["wasm"],graphOptimizationLevel:"all"});
  })().catch(e=>{ PIPER.loading=null; PIPER.err=String(e&&e.message||e); throw e; });
  return PIPER.loading;
}
async function piperSynth(text, rate){
  const cfg=PIPER.cfg, map=cfg.phoneme_id_map, voice=(cfg.espeak&&cfg.espeak.voice)||"fa";
  let ph=await PIPER.phon.phonemize(text, voice); if(Array.isArray(ph)) ph=ph.join(", ");
  ph=String(ph).trim(); if(!/[.!?؟]$/.test(ph)) ph+=".";
  const ids=[...(map["^"]||[1])], pad=map["_"]||[0];
  for(const ch of Array.from(ph.normalize("NFD"))){ const id=map[ch]; if(!id) continue; ids.push(...id, ...pad); }
  ids.push(...(map["$"]||[2]));
  const inf=cfg.inference||{}, feeds={
    input:new ort.Tensor("int64", BigInt64Array.from(ids.map(BigInt)), [1,ids.length]),
    input_lengths:new ort.Tensor("int64", BigInt64Array.from([BigInt(ids.length)]), [1]),
    scales:new ort.Tensor("float32", Float32Array.from([inf.noise_scale??0.667, (inf.length_scale??1)/(rate||1), inf.noise_w??0.8]), [3]) };
  if((cfg.num_speakers||1)>1) feeds.sid=new ort.Tensor("int64", BigInt64Array.from([0n]), [1]);
  const out=await PIPER.sess.run(feeds); return out[PIPER.sess.outputNames[0]].data;
}
// WAV درون‌حافظه + عنصر <audio> (روی موبایل و iOS پایدارتر از WebAudio است؛ onended همیشه فراخوانی می‌شود)
function ttsWav(f32, sr){
  const n=f32.length, buf=new ArrayBuffer(44+n*2), v=new DataView(buf), w=(o,t)=>{ for(let i=0;i<t.length;i++) v.setUint8(o+i,t.charCodeAt(i)); };
  w(0,"RIFF"); v.setUint32(4,36+n*2,true); w(8,"WAVE"); w(12,"fmt "); v.setUint32(16,16,true); v.setUint16(20,1,true); v.setUint16(22,1,true);
  v.setUint32(24,sr,true); v.setUint32(28,sr*2,true); v.setUint16(32,2,true); v.setUint16(34,16,true); w(36,"data"); v.setUint32(40,n*2,true);
  for(let i=0;i<n;i++){ const x=Math.max(-1,Math.min(1,f32[i])); v.setInt16(44+i*2, x<0?x*0x8000:x*0x7fff, true); }
  return URL.createObjectURL(new Blob([buf],{type:"audio/wav"}));
}
const TTS_SIL="data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAIA+AAACABAAZGF0YQAAAAA=";
function ttsUnlock(){   // باید داخل رویدادِ کلیک صدا زده شود
  if(!PIPER.aud){ PIPER.aud=new Audio(); PIPER.aud.preload="auto"; PIPER.aud.playsInline=true; }
  try{ PIPER.aud.src=TTS_SIL; const p=PIPER.aud.play(); if(p&&p.catch) p.catch(()=>{}); }catch(e){}
  try{ if(!PIPER.ctx) PIPER.ctx=new (window.AudioContext||window.webkitAudioContext)(); PIPER.ctx.resume&&PIPER.ctx.resume(); }catch(e){}
}
function ttsPlayUrl(url){
  return new Promise((res,rej)=>{ const a=PIPER.aud; let done=false;
    const fin=e=>{ if(done) return; done=true; a.onended=a.onerror=null; PIPER.src=null; e?rej(e):res(); };
    a.onended=()=>fin(); a.onerror=()=>fin(new Error("audio element error")); PIPER.src={stop:()=>fin()};
    a.src=url; const p=a.play(); if(p&&p.catch) p.catch(e=>fin(e)); });
}
async function piperPlayQueue(){
  const sr=(PIPER.cfg.audio&&PIPER.cfg.audio.sample_rate)||22050;
  if(!PIPER.aud) ttsUnlock();
  let next=null, made=0, firstErr=null;
  const synth=k=> k<TTS.q.length ? piperSynth(TTS.q[k].t, +store.get("tts.rate",1)||1).catch(e=>{ console.warn("piper",e); if(!firstErr) firstErr=e; return null; }) : Promise.resolve(null);
  next=synth(TTS.i);
  while(TTS.playing && TTS.engine==="piper" && TTS.i<TTS.q.length){
    const a=await next; if(!TTS.playing) break; next=synth(TTS.i+1);   // جملهٔ بعدی هم‌زمان ساخته می‌شود
    if(a && a.length){ made++; ttsMark(TTS.i);
      const url=ttsWav(a instanceof Float32Array?a:Float32Array.from(a), sr);
      try{ await ttsPlayUrl(url); } finally{ URL.revokeObjectURL(url); } }
    TTS.i++; }
  if(!made && TTS.playing) throw (firstErr||new Error("هیچ صدایی ساخته نشد"));
  if(TTS.playing && TTS.engine==="piper") ttsStop();
}
const ttsOn=()=>!!store.get("tts.on",true);
// ---------- پخش ----------
function ttsStop(){ TTS.playing=false; TTS.paused=false; clearInterval(TTS.ka); TTS.ka=null; try{ speechSynthesis.cancel(); }catch(e){} try{ if(PIPER.src){ PIPER.src.stop(); PIPER.src=null; } if(PIPER.aud) PIPER.aud.pause(); }catch(e){} ttsMark(-1); ttsUi(); }
function ttsMark(k){ for(const s of TTS.segs) s.el&&s.el.classList.remove("ttsNow"); const s=TTS.q[k]; if(s && s.el){ s.el.classList.add("ttsNow"); try{ s.el.scrollIntoView({block:"nearest",behavior:"smooth"}); }catch(e){} } }
function ttsNext(){
  if(!TTS.playing) return; if(TTS.i>=TTS.q.length){ ttsStop(); return; }
  const it=TTS.q[TTS.i], u=new SpeechSynthesisUtterance(it.t), v=ttsVoice(TTS.lang);
  if(v){ u.voice=v; u.lang=v.lang; } else u.lang=TTS.lang==="en"?"en-US":"fa-IR";
  u.rate=+store.get("tts.rate",1)||1; u.pitch=1; u.volume=1;
  u.onstart=()=>ttsMark(TTS.i); u.onend=()=>{ if(!TTS.playing) return; TTS.i++; ttsNext(); };
  u.onerror=e=>{ if(e.error==="interrupted"||e.error==="canceled") return; console.warn("tts",e.error); TTS.i++; ttsNext(); };
  speechSynthesis.speak(u);
}
function ttsPlay(){
  TTS.note="";
  if(TTS.playing && !TTS.paused){ if(TTS.engine==="piper"){ PIPER.aud&&PIPER.aud.pause(); } else speechSynthesis.pause(); TTS.paused=true; ttsUi(); return; }
  if(TTS.playing && TTS.paused){ if(TTS.engine==="piper"){ PIPER.aud&&PIPER.aud.play().catch(()=>{}); } else speechSynthesis.resume(); TTS.paused=false; ttsUi(); return; }
  if(ttsUsePiper(TTS.lang)){
    TTS.q=[]; for(const s of TTS.segs) for(const c of ttsChunks(ttsNorm(s.t,TTS.lang))) TTS.q.push({t:c, el:s.el});
    TTS.i=0; TTS.playing=true; TTS.paused=false; TTS.engine="piper";
    ttsUnlock();   // در همان لحظهٔ کلیک (سیاست پخش خودکار مرورگر)
    ttsUi();
    piperLoad(f=>{ PIPER.prog=f; ttsUi(); }).then(()=>{ PIPER.prog=1; ttsUi(); return piperPlayQueue(); })
      .catch(e=>{ console.warn(e); const blocked=e&&e.name==="NotAllowedError"; TTS.playing=false; TTS.engine=""; ttsMark(-1);
        if(blocked){ TTS.note=TTS.lang==="en"?"The browser blocked auto-play; press ▶ to listen.":"مرورگر پخش خودکار را مسدود کرد؛ دکمهٔ ▶ را بزنید."; ttsUi(); return; }
        PIPER.err=String(e&&e.message||e); PIPER.ok=false; ttsUi(); document.querySelectorAll(".ttsBar").forEach(b=>b.__fill&&b.__fill());
        if(("speechSynthesis" in window) && ttsVoice(TTS.lang)) ttsPlay(); });
    return; }
  if(!("speechSynthesis" in window)) return;
  if(!ttsVoice(TTS.lang)){ ttsUi(); return; }
  TTS.engine="web";
  speechSynthesis.cancel(); TTS.q=[]; for(const s of TTS.segs) for(const c of ttsChunks(ttsNorm(s.t,TTS.lang))) TTS.q.push({t:c, el:s.el});
  TTS.i=0; TTS.playing=true; TTS.paused=false; ttsUi(); ttsNext();
  // کروم دسکتاپ با صداهای Google پس از ~۱۵ ثانیه متوقف می‌شود؛ مکث/ادامهٔ دوره‌ای جلوی آن را می‌گیرد
  const v=ttsVoice(TTS.lang); clearInterval(TTS.ka);
  if(v && /Google/i.test(v.name) && !/Android/i.test(navigator.userAgent)) TTS.ka=setInterval(()=>{ if(TTS.playing && !TTS.paused && speechSynthesis.speaking){ speechSynthesis.pause(); speechSynthesis.resume(); } },10000);
}
function ttsUi(){ document.querySelectorAll(".ttsBar").forEach(b=>b.__ui&&b.__ui()); }
// ---------- نوار کنترل ----------
function ttsAttach(dlg, body, lang){
  ttsStop(); TTS.dlg=dlg; TTS.lang=lang;
  TTS.segs=[...body.querySelectorAll("h2,h3,p,li,.rsub")].map(el=>{ let t; if(el.tagName==="LI"){ const c=el.cloneNode(true); c.querySelectorAll(".rsub").forEach(x=>x.remove()); t=c.textContent; } else t=el.textContent; return {el,t:t.trim()}; }).filter(s=>s.t);
  // عنوان گزارش هم خوانده می‌شود
  const h=dlg.querySelector("h3"); if(h && h.textContent.trim()) TTS.segs.unshift({el:h, t:h.textContent.trim()});
  let bar=dlg.querySelector(".ttsBar"); if(bar) bar.remove();
  bar=document.createElement("div"); bar.className="ttsBar"; bar.setAttribute("data-noi18n",""); bar.dir=lang==="en"?"ltr":"rtl";
  const en=lang==="en", L=(fa,e)=>en?e:fa;
  bar.innerHTML=`<button type="button" class="tPlay" title="${L("خوانش صوتی گزارش","Read the report aloud")}"></button><button type="button" class="tStop" title="${L("توقف","Stop")}">⏹</button>
    <button type="button" class="tMute"></button>
    <label class="tRate">${L("سرعت","Speed")} <select><option value="0.8">۰٫۸×</option><option value="0.9">۰٫۹×</option><option value="1">۱×</option><option value="1.1">۱٫۱×</option><option value="1.25">۱٫۲۵×</option><option value="1.5">۱٫۵×</option></select></label>
    <label class="tVoice">${L("گوینده","Voice")} <select></select></label><span class="tMsg"></span>`;
  if(en) bar.querySelectorAll(".tRate option").forEach(o=>o.textContent=o.value+"×");
  const sel=bar.querySelector(".tVoice select"), rate=bar.querySelector(".tRate select"), msg=bar.querySelector(".tMsg");
  rate.value=String(store.get("tts.rate",1)); if(!rate.value) rate.value="1";
  rate.onchange=()=>store.set("tts.rate",+rate.value);   // از جملهٔ بعدی اعمال می‌شود
  bar.__fill=()=>{ const vs=ttsVoices(lang), cur=ttsVoice(lang), opts=vs.map(v=>{ const o=document.createElement("option"); o.value=v.name; o.textContent=v.name.replace(/^Microsoft\s+/,"").replace(/\s*-\s*Persian.*$/i,"").replace(/\s*\(Natural\)/," ✦"); return o; });
    if(lang==="fa" && PIPER.ok){ const o=document.createElement("option"); o.value=PIPER_ID; o.textContent="MetStat فارسی (عصبی، آفلاین) ✦"; opts.unshift(o); }
    sel.replaceChildren(...opts);
    if(ttsUsePiper(lang)) sel.value=PIPER_ID; else if(cur) sel.value=cur.name; bar.querySelector(".tVoice").hidden=opts.length<2; bar.__ui(); };
  sel.onchange=()=>{ store.set("tts.voice."+lang, sel.value); if(TTS.playing){ ttsStop(); ttsPlay(); } };
  bar.__ui=()=>{ const has=ttsCan(lang), on=ttsOn(), pb=bar.querySelector(".tPlay"), mb=bar.querySelector(".tMute");
    pb.textContent = !TTS.playing ? L("▶ خوانش صوتی","▶ Listen") : TTS.paused ? L("▶ ادامه","▶ Resume") : L("⏸ مکث","⏸ Pause");
    pb.disabled=!has; bar.querySelector(".tStop").disabled=!TTS.playing;
    mb.textContent = on ? L("🔊 صدا روشن","🔊 Sound on") : L("🔇 صدا خاموش","🔇 Sound off"); mb.setAttribute("aria-pressed", on);
    mb.title = on ? L("گزارش‌ها هنگام باز شدن خودکار خوانده می‌شوند؛ برای خاموش کردن بزنید","Reports are read automatically when opened; click to turn off") : L("خوانش خودکار خاموش است؛ برای روشن کردن بزنید","Automatic reading is off; click to turn on");
    const loadingP=TTS.playing && TTS.engine==="piper" && !PIPER.sess;
    msg.textContent = TTS.note && !TTS.playing ? TTS.note : loadingP ? L(`بارگیری گویندهٔ فارسی${PIPER.prog>0&&PIPER.prog<1?` ${FA(Math.round(PIPER.prog*100))}٪`:"…"} (فقط بار اول؛ پس از آن آفلاین)`,"Loading the Persian voice… (first time only)")
      : PIPER.err && lang==="fa" && !has ? L("گویندهٔ فارسی MetStat بارگیری نشد: ","Persian voice failed: ")+PIPER.err
      : has ? "" : !("speechSynthesis" in window) ? L("این مرورگر از خوانش صوتی پشتیبانی نمی‌کند.","This browser has no speech synthesis.") : L("گویندهٔ فارسی هنوز روی سایت فعال نشده است (پوشهٔ tts روی هاست).","No voice for this language is available in this browser/device.");
    msg.hidden=!msg.textContent; };
  bar.querySelector(".tPlay").onclick=()=>{ if(!ttsOn()) store.set("tts.on",true); ttsPlay(); };
  bar.querySelector(".tStop").onclick=()=>ttsStop();
  bar.querySelector(".tMute").onclick=()=>{ const on=!ttsOn(); store.set("tts.on",on); if(!on) ttsStop(); else if(!TTS.playing) ttsPlay(); ttsUi(); };
  body.before(bar); bar.__fill();
  if(lang==="fa" && PIPER.ok===null) piperProbe().then(()=>{ bar.__fill(); if(dlg.open) ttsAuto(dlg); });
  if(!dlg.__ttsClose){ dlg.__ttsClose=1; dlg.addEventListener("close",()=>{ if(TTS.dlg===dlg) ttsStop(); }); }
}
function ttsAuto(dlg){ if(!ttsOn() || TTS.dlg!==dlg) return; setTimeout(()=>{ if(dlg.open && !TTS.playing && ttsCan(TTS.lang)) ttsPlay(); },350); }
