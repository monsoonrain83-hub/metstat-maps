/* ===== خوانندهٔ آفلاین اکسل (xlsx و xls قدیمی) — جایگزین SheetJS وقتی CDN در دسترس نیست =====
   خروجی سازگار با بخشی از API کتابخانهٔ XLSX که صفحهٔ «عملیات آماری» به کار می‌برد:
   read(buf) → {SheetNames, Sheets}، utils.sheet_to_json(ws,{header:1})، utils.aoa_to_sheet/book_new/book_append_sheet، writeFile */
const MSXL=(()=>{
  const u8=b=>b instanceof Uint8Array?b:new Uint8Array(b.buffer?b.buffer:b);
  const td=new TextDecoder("utf-8"), td16=new TextDecoder("utf-16le");
  // ---- ZIP (xlsx)
  function unzip(b){ const d=new DataView(b.buffer,b.byteOffset,b.byteLength); let e=b.length-22; while(e>=0 && d.getUint32(e,true)!==0x06054b50) e--; if(e<0) throw new Error("zip: end record not found");
    const n=d.getUint16(e+10,true); let o=d.getUint32(e+16,true); const F={};
    for(let k=0;k<n;k++){ const m=d.getUint16(o+10,true), cs=d.getUint32(o+20,true), nl=d.getUint16(o+28,true), xl=d.getUint16(o+30,true), cl=d.getUint16(o+32,true), lo=d.getUint32(o+42,true), name=td.decode(b.subarray(o+46,o+46+nl));
      F[name]={m,cs,lo}; o+=46+nl+xl+cl; }
    return name=>{ const f=F[name]||F[Object.keys(F).find(k=>k.toLowerCase()===String(name).toLowerCase())]; if(!f) return null; const lo=f.lo, nl=d.getUint16(lo+26,true), xl=d.getUint16(lo+28,true), s=lo+30+nl+xl, raw=b.subarray(s,s+f.cs);
      if(f.m===0) return raw; if(f.m===8){ const z=new Uint8Array(raw.length+2); z[0]=0x78; z[1]=0x9c; z.set(raw,2); return jsInflate(z); } throw new Error("zip: method "+f.m); };
  }
  const xmlOf=bytes=>bytes?new DOMParser().parseFromString(td.decode(bytes),"application/xml"):null;
  const tagAll=(x,t)=>x?[...x.getElementsByTagNameNS("*",t)]:[];
  function colIdx(ref){ let c=0,i=0; while(i<ref.length && /[A-Z]/i.test(ref[i])){ c=c*26+(ref.charCodeAt(i)&31); i++; } return [c-1, +ref.slice(i)-1]; }
  function readXlsx(b){
    const get=unzip(b), wb=xmlOf(get("xl/workbook.xml")), rels=xmlOf(get("xl/_rels/workbook.xml.rels"));
    const rmap={}; tagAll(rels,"Relationship").forEach(r=>rmap[r.getAttribute("Id")]=r.getAttribute("Target"));
    const sst=tagAll(xmlOf(get("xl/sharedStrings.xml")),"si").map(si=>tagAll(si,"t").map(t=>t.textContent).join(""));
    const out={SheetNames:[], Sheets:{}};
    for(const s of tagAll(wb,"sheet")){ const name=s.getAttribute("name"), rid=s.getAttribute("r:id")||s.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id");
      let tg=rmap[rid]||""; tg=tg.replace(/^\//,""); if(!tg.startsWith("xl/")) tg="xl/"+tg;
      const x=xmlOf(get(tg)), A=[];
      for(const c of tagAll(x,"c")){ const [ci,ri]=colIdx(c.getAttribute("r")||"A1"), t=c.getAttribute("t"), v=tagAll(c,"v")[0];
        let val; if(t==="s") val=sst[+(v&&v.textContent)]; else if(t==="inlineStr") val=tagAll(c,"t").map(q=>q.textContent).join(""); else if(t==="str"||t==="e") val=v?v.textContent:""; else if(t==="b") val=v&&v.textContent==="1"; else val=v?+v.textContent:undefined;
        if(val===undefined) continue; (A[ri]=A[ri]||[])[ci]=val; }
      out.SheetNames.push(name); out.Sheets[name]={aoa:A}; }
    return out;
  }
  // ---- CFB + BIFF8 (xls)
  function cfbStream(b, want){
    const d=new DataView(b.buffer,b.byteOffset,b.byteLength); if(d.getUint32(0,true)!==0xE011CFD0) throw new Error("not an OLE file");
    const ss=1<<d.getUint16(30,true), mss=1<<d.getUint16(32,true), nFat=d.getUint32(44,true), dir0=d.getUint32(48,true), cutoff=d.getUint32(56,true), mfat0=d.getUint32(60,true), difat0=d.getUint32(68,true), nDifat=d.getUint32(72,true);
    const sec=i=>512+i*ss; const fatSecs=[]; for(let k=0;k<109&&fatSecs.length<nFat;k++) fatSecs.push(d.getUint32(76+4*k,true));
    let dfs=difat0; for(let q=0;q<nDifat && fatSecs.length<nFat;q++){ for(let k=0;k<ss/4-1&&fatSecs.length<nFat;k++) fatSecs.push(d.getUint32(sec(dfs)+4*k,true)); dfs=d.getUint32(sec(dfs)+ss-4,true); }
    const FAT=new Uint32Array(fatSecs.length*ss/4); fatSecs.forEach((s,k)=>{ for(let j=0;j<ss/4;j++) FAT[k*ss/4+j]=d.getUint32(sec(s)+4*j,true); });
    const chain=(s,fat)=>{ const a=[]; let g=0; while(s<0xFFFFFFFA && g++<1e6){ a.push(s); s=fat[s]; } return a; };
    const readChain=(s,size)=>{ const c=chain(s,FAT), o=new Uint8Array(c.length*ss); c.forEach((q,k)=>o.set(b.subarray(sec(q),sec(q)+ss),k*ss)); return size!=null?o.subarray(0,size):o; };
    const dir=readChain(dir0), dv=new DataView(dir.buffer), ents=[];
    for(let o=0;o+128<=dir.length;o+=128){ const nl=dv.getUint16(o+64,true); if(!nl) { ents.push(null); continue; } ents.push({name:td16.decode(dir.subarray(o,o+nl-2)), type:dir[o+66], start:dv.getUint32(o+116,true), size:dv.getUint32(o+120,true)}); }
    const root=ents[0], e=ents.find(x=>x && want.includes(x.name)); if(!e) throw new Error("Workbook stream not found");
    if(e.size>=cutoff) return readChain(e.start,e.size);
    const ms=readChain(root.start), mf=chain(mfat0,FAT), MFAT=new Uint32Array(mf.length*ss/4); mf.forEach((s,k)=>{ for(let j=0;j<ss/4;j++) MFAT[k*ss/4+j]=d.getUint32(sec(s)+4*j,true); });
    const c=chain(e.start,MFAT), o=new Uint8Array(c.length*mss); c.forEach((q,k)=>o.set(ms.subarray(q*mss,q*mss+mss),k*mss)); return o.subarray(0,e.size);
  }
  function readXls(b){
    const w=cfbStream(b,["Workbook","Book"]), d=new DataView(w.buffer,w.byteOffset,w.byteLength);
    const recs=[]; for(let o=0;o+4<=w.length;){ const id=d.getUint16(o,true), len=d.getUint16(o+2,true); recs.push({id, o:o+4, len}); o+=4+len; }
    const sheets=[]; let sst=[], cp=1256; const dec1252=new TextDecoder("windows-1256");
    // رشته‌های بایفی: با پرچم فشرده/یونیکد، که در CONTINUE ممکن است عوض شود
    const readStr=(chunks, pos, nch)=>{ // chunks: [{u8}] پیوسته از رکورد SST و CONTINUE ها
      let s="", left=nch; let [ci,off]=pos; let fl=chunks[ci][off++]; const rich=fl&8, ext=fl&4; let rt=0, sz=0;
      if(rich){ rt=chunks[ci][off]|(chunks[ci][off+1]<<8); off+=2; } if(ext){ sz=chunks[ci][off]|(chunks[ci][off+1]<<8)|(chunks[ci][off+2]<<16)|(chunks[ci][off+3]<<24); off+=4; }
      let wide=fl&1;
      while(left>0){ if(off>=chunks[ci].length){ ci++; off=0; wide=chunks[ci][off++]&1; }
        const avail=chunks[ci].length-off, take=Math.min(left, wide?avail>>1:avail);
        if(wide){ s+=td16.decode(chunks[ci].subarray(off,off+2*take)); off+=2*take; } else { let t=""; for(let k=0;k<take;k++) t+=String.fromCharCode(chunks[ci][off+k]); s+=t; off+=take; }
        left-=take; }
      let skip=rt*4+sz; while(skip>0){ const av=chunks[ci].length-off; if(skip<=av){ off+=skip; skip=0; } else { skip-=av; ci++; off=0; } }
      if(off>=chunks[ci].length && ci<chunks.length-1){ ci++; off=0; }
      return [s,[ci,off]];
    };
    for(let k=0;k<recs.length;k++){ const r=recs[k];
      if(r.id===0x85){ const pos=d.getUint32(r.o,true), hid=w[r.o+4], typ=w[r.o+5], nl=w[r.o+6], fl=w[r.o+7]; const name= fl&1 ? td16.decode(w.subarray(r.o+8,r.o+8+2*nl)) : String.fromCharCode(...w.subarray(r.o+8,r.o+8+nl)); if(typ===0) sheets.push({name,pos}); }
      else if(r.id===0x42){ cp=d.getUint16(r.o,true); }
      else if(r.id===0xFC){ const chunks=[w.subarray(r.o,r.o+r.len)]; let j=k+1; while(j<recs.length && recs[j].id===0x3C){ chunks.push(w.subarray(recs[j].o,recs[j].o+recs[j].len)); j++; }
        const n=d.getUint32(r.o+4,true); let pos=[0,8]; sst=[]; for(let q=0;q<n;q++){ const c=chunks[pos[0]]; if(!c) break; let nch=c[pos[1]]|(c[pos[1]+1]<<8); pos=[pos[0],pos[1]+2]; if(pos[1]>=c.length){ pos=[pos[0]+1,0]; } const [s,p2]=readStr(chunks,pos,nch); sst.push(s); pos=p2; } }
    }
    const rk=v=>{ let x; if(v&2){ x=v>>2; } else { const bb=new DataView(new ArrayBuffer(8)); bb.setUint32(4,v&0xFFFFFFFC,true); x=bb.getFloat64(0,true); } return v&1 ? x/100 : x; };
    const out={SheetNames:[], Sheets:{}};
    for(const sh of sheets){ const A=[]; let k=recs.findIndex(r=>r.o-4===sh.pos); if(k<0) continue; const put=(r,c,v)=>{ (A[r]=A[r]||[])[c]=v; };
      for(k=k+1;k<recs.length;k++){ const r=recs[k], o=r.o; if(r.id===0x0A) break;
        if(r.id===0xFD) put(d.getUint16(o,true),d.getUint16(o+2,true),sst[d.getUint32(o+6,true)]);
        else if(r.id===0x203) put(d.getUint16(o,true),d.getUint16(o+2,true),d.getFloat64(o+6,true));
        else if(r.id===0x27E) put(d.getUint16(o,true),d.getUint16(o+2,true),rk(d.getInt32(o+6,true)));
        else if(r.id===0xBD){ const row=d.getUint16(o,true), c0=d.getUint16(o+2,true), n=(r.len-6)/6; for(let q=0;q<n;q++) put(row,c0+q,rk(d.getInt32(o+4+6*q+2,true))); }
        else if(r.id===0x204){ const n=d.getUint16(o+6,true), fl=w[o+8]; put(d.getUint16(o,true),d.getUint16(o+2,true), fl&1 ? td16.decode(w.subarray(o+9,o+9+2*n)) : dec1252.decode(w.subarray(o+9,o+9+n))); }
        else if(r.id===0x205){ if(!w[o+7]) put(d.getUint16(o,true),d.getUint16(o+2,true),!!w[o+6]); }
        else if(r.id===0x06){ const row=d.getUint16(o,true), col=d.getUint16(o+2,true);
          if(d.getUint16(o+12,true)===0xFFFF){ const t=w[o+6]; if(t===0 && recs[k+1] && recs[k+1].id===0x207){ const s=recs[k+1], n=d.getUint16(s.o,true), fl=w[s.o+2]; put(row,col, fl&1 ? td16.decode(w.subarray(s.o+3,s.o+3+2*n)) : dec1252.decode(w.subarray(s.o+3,s.o+3+n))); } else if(t===1) put(row,col,!!w[o+8]); }
          else put(row,col,d.getFloat64(o+6,true)); }
      }
      out.SheetNames.push(sh.name); out.Sheets[sh.name]={aoa:A}; }
    return out;
  }
  function read(buf){ const b=u8(buf); if(b[0]===0x50&&b[1]===0x4B) return readXlsx(b); if(b[0]===0xD0&&b[1]===0xCF) return readXls(b);
    const t=td.decode(b); const L=t.split(/\r?\n/).filter(x=>x.trim()); const dl=[",",";","\t"].find(c=>(L[0]||"").includes(c)); return {SheetNames:["Sheet1"], Sheets:{Sheet1:{aoa:L.map(l=>dl?l.split(dl):l.trim().split(/\s+/)).map(r=>r.map(x=>{ const n=+x; return x!==""&&isFinite(n)?n:x; }))}}}; }
  function sheet_to_json(ws, o={}){ const A=ws.aoa||[], defv=o.defval; let W=0; for(let i=0;i<A.length;i++){ const r=A[i]; if(r && r.length>W) W=r.length; }
    const rows=[]; for(let i=0;i<A.length;i++){ const r=A[i]||[]; if(!r.length && defv===undefined){ continue; } const row=[]; for(let j=0;j<W;j++) row.push(r[j]===undefined ? (defv!==undefined?defv:undefined) : r[j]); if(defv===undefined){ while(row.length && row[row.length-1]===undefined) row.pop(); } rows.push(row); }
    if(o.header===1) return rows; const h=rows[0]||[]; return rows.slice(1).map(r=>Object.fromEntries(h.map((k,j)=>[k,r[j]]))); }
  const xmlEsc=s=>String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  const colName=c=>{ let s=""; c++; while(c>0){ const m=(c-1)%26; s=String.fromCharCode(65+m)+s; c=(c-m-1)/26; } return s; };
  function write(wb){ const enc=new TextEncoder(), F=[];
    const sheets=wb.SheetNames.map((n,k)=>{ const A=wb.Sheets[n].aoa||[]; const rows=A.map((r,i)=>`<row r="${i+1}">${(r||[]).map((v,j)=>v==null||v===""?"":(typeof v==="number"&&isFinite(v)?`<c r="${colName(j)}${i+1}"><v>${v}</v></c>`:`<c r="${colName(j)}${i+1}" t="inlineStr"><is><t>${xmlEsc(v)}</t></is></c>`)).join("")}</row>`).join("");
      return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${rows}</sheetData></worksheet>`; });
    F.push(["[Content_Types].xml",`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheets.map((_,k)=>`<Override PartName="/xl/worksheets/sheet${k+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`]);
    F.push(["_rels/.rels",`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`]);
    F.push(["xl/workbook.xml",`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${wb.SheetNames.map((n,k)=>`<sheet name="${xmlEsc(n).slice(0,31)}" sheetId="${k+1}" r:id="rId${k+1}"/>`).join("")}</sheets></workbook>`]);
    F.push(["xl/_rels/workbook.xml.rels",`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_,k)=>`<Relationship Id="rId${k+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${k+1}.xml"/>`).join("")}</Relationships>`]);
    sheets.forEach((x,k)=>F.push([`xl/worksheets/sheet${k+1}.xml`,x]));
    return zipStore(F.map(([n,s])=>[n,enc.encode(s)])); }
  const utils={sheet_to_json, aoa_to_sheet:A=>({aoa:A}), book_new:()=>({SheetNames:[],Sheets:{}}), book_append_sheet:(wb,ws,n)=>{ n=n||"Sheet"+(wb.SheetNames.length+1); wb.SheetNames.push(n); wb.Sheets[n]=ws; }};
  function writeFile(wb, name){ const b=write(wb), a=document.createElement("a"); a.href=URL.createObjectURL(b); a.download=name; document.body.append(a); a.click(); a.remove(); }
  return {read, utils, writeFile, write, __shim:true};
})();
