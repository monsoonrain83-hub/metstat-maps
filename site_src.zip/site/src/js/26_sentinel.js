/* ===== Sentinel: خودمراقبتی نامرئی =====
   ۱) ثبت خطاهای سراسری و بازگردانی خودکار حالت «مشغول» و اسپینرها
   ۲) تشخیص بسته‌شدن ناگهانی تب (Aw Snap) در بار قبل → حالت ایمن (بدون سربار برای کاربر)
   ۳) اسپینر خودکار برای عملیات سنگین (بارگذاری/پردازش) فقط اگر بیش از ۲۵۰ms طول بکشد
   ۴) بررسی پایداری خواندن بوم خروجی نقشه (تشخیص بافت‌های خراب GPU)، بدون کند شدن  */
const Sentinel=(()=>{
  const K_HEAVY="ms.heavy", K_LOG="ms.errlog";
  const ls={ get(k){ try{return localStorage.getItem(k);}catch(e){return null;} }, set(k,v){ try{localStorage.setItem(k,v);}catch(e){} }, del(k){ try{localStorage.removeItem(k);}catch(e){} } };
  const T=(fa,en)=> (typeof LANG!=="undefined"&&LANG==="en")?en:fa;
  const S={ safe:false, depth:0, log:[] };
  // --- ۲) نشانهٔ خروج ناگهانی
  const h=ls.get(K_HEAVY);
  if(h){ const age=Date.now()-(+h.split("|")[0]||0); if(age<30*60*1000){ S.safe=true; S.lastOp=h.split("|")[1]||""; } ls.del(K_HEAVY); }
  window.MS_SAFE=S.safe;
  addEventListener("pagehide",()=>ls.del(K_HEAVY));
  // --- اسپینر
  let ov=null, tmr=null, cnt=0;
  function spinEl(){ if(ov) return ov; ov=document.createElement("div"); ov.id="msSpin"; ov.hidden=true;
    ov.innerHTML='<div class="msSpinBox"><span class="msSpinner"></span><span id="msSpinTxt"></span></div>'; document.body.appendChild(ov); return ov; }
  function spinOn(msg){ cnt++; clearTimeout(tmr); tmr=setTimeout(()=>{ const e=spinEl(); e.querySelector("#msSpinTxt").textContent=msg||T("در حال پردازش…","Processing…"); e.hidden=false; },250); }
  function spinOff(force){ cnt=force?0:Math.max(0,cnt-1); if(cnt===0){ clearTimeout(tmr); if(ov) ov.hidden=true; } }
  // --- toast
  function toast(msg,ms=6000){ let t=document.getElementById("msToast"); if(!t){ t=document.createElement("div"); t.id="msToast"; document.body.appendChild(t); }
    t.textContent=msg; t.hidden=false; clearTimeout(t._t); t._t=setTimeout(()=>t.hidden=true,ms); }
  // --- ۱) بازگردانی حالت مشغول
  function unbusy(){
    try{ if(typeof state!=="undefined"&&state.busy){ state.busy=false; const r=document.getElementById("run"); if(r) r.disabled=false; } }catch(e){}
    try{ if(typeof ds!=="undefined"&&ds.busy){ ds.busy=false; const r=document.getElementById("dsRun"); if(r) r.disabled=false; } }catch(e){}
    try{ if(typeof cv!=="undefined"&&cv.busy){ cv.busy=false; const r=document.getElementById("cvRun"); if(r) r.disabled=false; } }catch(e){}
    spinOff(true); ls.del(K_HEAVY); S.depth=0;
  }
  function record(kind,msg,src){
    const e={t:new Date().toISOString(),k:kind,m:String(msg).slice(0,300),s:String(src||"").slice(0,120)}; S.log.push(e); if(S.log.length>30) S.log.shift();
    ls.set(K_LOG,JSON.stringify(S.log)); try{ console.warn("[Sentinel]",e); }catch(_){}
  }
  addEventListener("error",ev=>{ record("error",ev.message,(ev.filename||"")+":"+ev.lineno); unbusy(); toast(T("خطایی رخ داد و به‌صورت خودکار مهار شد؛ می‌توانید ادامه دهید.","An error occurred and was contained automatically; you can continue.")); });
  addEventListener("unhandledrejection",ev=>{ const r=ev.reason; record("promise",(r&&r.message)||r); unbusy(); toast(T("عملیات ناموفق بود؛ دوباره تلاش کنید.","Operation failed; please try again.")); });
  // --- ۳) پوشش عملیات سنگین
  function guard(name,msg){
    const f=window[name]; if(typeof f!=="function"||f.__g) return;
    const w=async function(...a){
      S.depth++; if(S.depth===1) ls.set(K_HEAVY,Date.now()+"|"+name); spinOn(msg);
      try{ return await f.apply(this,a); }
      catch(e){ record("op:"+name,e&&e.message||e); throw e; }
      finally{ spinOff(); S.depth=Math.max(0,S.depth-1); if(S.depth===0) ls.del(K_HEAVY); }
    }; w.__g=1; window[name]=w;
  }
  // --- ۴) بررسی پایداری بوم
  function checkCanvas(c){
    try{ if(!c||!c.width||!c.height) return true; const x=c.getContext("2d",{willReadFrequently:true}); if(!x) return true;
      const n=4, sz=24; let bad=0;
      for(let i=0;i<n;i++){ const px=Math.floor(Math.random()*Math.max(1,c.width-sz)), py=Math.floor(Math.random()*Math.max(1,c.height-sz));
        const a=x.getImageData(px,py,sz,sz).data, b=x.getImageData(px,py,sz,sz).data; for(let j=0;j<a.length;j+=7) if(a[j]!==b[j]){ bad++; break; } }
      if(bad){ record("canvas","unstable readback x"+bad); return false; } return true; }catch(e){ return true; }
  }
  return Object.assign(S,{spinOn,spinOff,toast,unbusy,guard,checkCanvas,record});
})();
(function(){
  const wrap=()=>{
    [["run",null],["addFiles",null],["ltAddFiles",null],["ltRun",null],["dsAdd",null],["dsRunAll",null],["cvRun",null]].forEach(([n])=>Sentinel.guard(n));
    if(typeof updateCard==="function"&&!updateCard.__g){ const u=updateCard; window.updateCard=function(J,r){ if(r&&r.cv&&!Sentinel.checkCanvas(r.cv)){ try{ r.cv.getContext("2d").getImageData(0,0,1,1); }catch(e){} } return u.apply(this,arguments); }; window.updateCard.__g=1; }
  };
  if(document.readyState==="complete") setTimeout(wrap,0); else addEventListener("load",()=>setTimeout(wrap,0));
  if(Sentinel.safe) setTimeout(()=>Sentinel.toast(T2("بار قبل صفحه به‌علت کمبود حافظه بسته شده بود؛ حالت ایمن فعال شد (پردازش سبک‌تر). برای نقشه‌های بسیار بزرگ تعداد فایل‌ها را کمتر کنید.","The page closed unexpectedly last time (memory); safe mode is on (lighter processing). Use fewer files for very large maps."),9000),800);
  function T2(a,b){ return (typeof LANG!=="undefined"&&LANG==="en")?b:a; }
})();
