/* ---------- اصلاح دما با ارتفاع ----------
   روش: کاهش مقیاس آماری با آهنگ کاهش دمای محلی (lapse-rate downscaling).
   مدل عددی دما را روی «ارتفاع هموارشدهٔ مدل» می‌دهد؛ دمای هر نقطه با ارتفاع واقعی DEM:
       T_fine = T_model + Γ × (z_DEM − z_model)
   Γ (درجه بر کیلومتر) در هر پنجرهٔ محلی با رگرسیون خطی وزنی دمای مدل بر ارتفاع مدل برآورد می‌شود
   (مثل روش‌های PRISM و Dodson & Marks 1997)؛ اگر رابطه ضعیف یا نقاط کم باشد، به آهنگ استاندارد −۶٫۵ درجه بر کیلومتر
   نزدیک می‌شود و به بازهٔ −۱۰ تا +۳ محدود است (وارونگی دما در زمستان و شب ممکن است). */
const DS_GSTD=-6.5;
// آهنگ کاهش دمای پایه بر حسب زمان نقشه و فصل (ماه میلادی از ساعت دستگاه): خودکار = همان −۶٫۵ قبلی
function dsBaseGamma(hc, month){ const summer = month>=5 && month<=9;
  if(hc==="day") return summer ? -9 : -7;
  if(hc==="night") return summer ? -4 : -3;
  return DS_GSTD; }
async function dsProcessTemp(m, cfg, dem, prog){
  await useProfile(m.prof.key);
  const d=m.data, W0=P.W, g=m.geo;
  m.rects = P.invalid(d);
  const cls = classify(d, Infinity, m.rects);
  const nCls=PAL.length, E_=EDGES, low=E_.slice(0,nCls);
  const rep=low.map((lo,c)=>{ const hi=E_[c+1]; if(isFinite(lo)&&isFinite(hi)) return (lo+hi)/2; if(isFinite(lo)) return lo+((c>0&&isFinite(E_[c-1]))?(lo-E_[c-1])/2:1); return hi-((isFinite(E_[c+2]))?(E_[c+2]-hi)/2:1); });
  const vF=new Uint8Array(N), PF=new Float32Array(N);
  for(let i=0;i<N;i++) if(cls[i]>=0){ PF[i]=rep[cls[i]]; vF[i]=1; }
  inpaint(PF, vF);
  const pal = ownPalette(d);
  const st=Math.max(1, Math.ceil(Math.sqrt(N/800000))), GW=Math.ceil(FW/st), GH=Math.ceil(FH/st), GN=GW*GH;
  const T0=new Float32Array(GN);
  if(st===1) T0.set(PF);
  else { const cnt=new Uint16Array(GN); for(let y=0;y<FH;y++){ const gy=Math.floor(y/st); for(let x=0;x<FW;x++){ const k=gy*GW+Math.floor(x/st); T0[k]+=PF[y*FW+x]; cnt[k]++; } } for(let k=0;k<GN;k++) T0[k]/=cnt[k]||1; }
  const cxp=gx=>gx*st+(Math.min(st,FW-gx*st)-1)/2, cyp=gy=>gy*st+(Math.min(st,FH-gy*st)-1)/2;
  const lon=new Float64Array(GW), lat=new Float64Array(GH);
  for(let x=0;x<GW;x++) lon[x]=(cxp(x)+P.fx0-g[0])/g[1]; for(let y=0;y<GH;y++) lat[y]=(cyp(y)+P.fy0-g[2])/g[3];
  const dlon=Math.abs(st/g[1]), dlat=Math.abs(st/g[3]), latm=(lat[0]+lat[GH-1])/2, dxk=dlon*111.32*Math.cos(latm*Math.PI/180), dyk=dlat*110.574;
  prog(0.15, "ارتفاع پیکسل‌ها از DEM"); await tick();
  const Z=new Float64Array(GN); let nIn=0;
  for(let y=0;y<GH;y++){ const fi=(dem.y0-lat[y])/dem.dy; for(let x=0;x<GW;x++){ const fj=(lon[x]-dem.x0)/dem.dx, k=y*GW+x;
    if(fi<0||fj<0||fi>dem.ny-1||fj>dem.nx-1){ Z[k]=NaN; continue; }
    const i0=Math.min(Math.floor(fi),dem.ny-2), j0=Math.min(Math.floor(fj),dem.nx-2), a=fi-i0, b=fj-j0, D=dem.data, n=dem.nx;
    const q=[[D[i0*n+j0],(1-a)*(1-b)],[D[i0*n+j0+1],(1-a)*b],[D[(i0+1)*n+j0],a*(1-b)],[D[(i0+1)*n+j0+1],a*b]].filter(t=>t[0]===t[0]); let s=0,w=0; for(const [v,ww] of q){ s+=v*ww; w+=ww; }
    Z[k]= w>=0.5 ? s/w : NaN; if(Z[k]===Z[k]) nIn++; } }
  if(nIn < 0.02*GN) throw new Error("این نقشه با DEM هم‌پوشانی ندارد (مکان نقشه بیرون از محدودهٔ DEM است)");
  const demOK=new Uint8Array(GN); for(let i=0;i<GN;i++) demOK[i]= Z[i]===Z[i] ? 1 : 0;
  const sE=(cfg.smoothT>=0?cfg.smoothT:cfg.smooth)/2, Zeff = sE>0 ? dsMGauss(Z, demOK, GW, GH, sE/dyk, sE/dxk) : Float64Array.from(Z);
  const effDeg=m.res*cfg.eff, sgX=effDeg/dlon/Math.sqrt(12)*1.25, sgY=effDeg/dlat/Math.sqrt(12)*1.25;
  const Zm = dsMGauss(Z, demOK, GW, GH, sgY, sgX);
  for(let i=0;i<GN;i++) if(!demOK[i]){ Zeff[i]=NaN; Zm[i]=NaN; }
  const dist=dsDistKm(demOK,GW,GH,dxk,dyk);
  prog(0.4, "برآورد آهنگ کاهش دمای محلی (رگرسیون دما–ارتفاع)"); await tick();
  // رگرسیون وزنی دما بر ارتفاع مدل در یک پنجره
  const sub=Math.max(1, Math.round(Math.sqrt(GN/120000)));
  const GS=dsBaseGamma(cfg.hour, new Date().getMonth()+1), cLa0=(lat[0]+lat[GH-1])/2, cLo0=(lon[0]+lon[GW-1])/2, cosL=Math.cos(latm*Math.PI/180);
  // کمترین مربعات وزنی k×k با حذف گاوسی و محور جزئی
  const solveLS=(A,B,k)=>{ const M=[]; for(let i=0;i<k;i++){ M.push([]); for(let j=0;j<k;j++) M[i].push(A[i*4+j]); M[i].push(B[i]); }
    let tr=0; for(let i=0;i<k;i++) tr+=M[i][i]; for(let i=0;i<k;i++) M[i][i]+=1e-9*tr;
    for(let c=0;c<k;c++){ let p=c; for(let r=c+1;r<k;r++) if(Math.abs(M[r][c])>Math.abs(M[p][c])) p=r; if(Math.abs(M[p][c])<1e-14) return null; const tmp=M[c]; M[c]=M[p]; M[p]=tmp;
      for(let r=c+1;r<k;r++){ const q=M[r][c]/M[c][c]; for(let j=c;j<=k;j++) M[r][j]-=q*M[c][j]; } }
    const b=new Array(k); for(let i=k-1;i>=0;i--){ let s=M[i][k]; for(let j=i+1;j<k;j++) s-=M[i][j]*b[j]; b[i]=s/M[i][i]; } return b; };
  // T = a + b·lat + c·lon + G·z در پنجره (اثر شیب افقی دما از آهنگ کاهش جدا می‌شود)؛ r2 = سهم جزئی ارتفاع
  const regress=(lo0, la0, hw)=>{ const A=new Float64Array(16), B=new Float64Array(4), x4=[1,0,0,0], cLa=hw?la0:cLa0, cLo=hw?lo0:cLo0;
    let sw=0,sz=0,szz=0,st_=0,stt=0,n=0;
    for(let y=0;y<GH;y+=sub){ const dy=hw?(lat[y]-la0)/hw:0; if(Math.abs(dy)>1) continue; const wy=hw?Math.cos(dy*Math.PI/2)**2:1;
      for(let x=0;x<GW;x+=sub){ const dx=hw?(lon[x]-lo0)/hw:0; if(Math.abs(dx)>1) continue; const i=y*GW+x; if(!demOK[i]) continue; const z=Zm[i]/1000, t=T0[i]; if(!(z===z && t===t)) continue;
        const w=wy*(hw?Math.cos(dx*Math.PI/2)**2:1); x4[1]=lat[y]-cLa; x4[2]=(lon[x]-cLo)*cosL; x4[3]=z;
        for(let a=0;a<4;a++){ B[a]+=w*x4[a]*t; for(let b=0;b<4;b++) A[a*4+b]+=w*x4[a]*x4[b]; }
        sw+=w; sz+=w*z; szz+=w*z*z; st_+=w*t; stt+=w*t*t; n++; } }
    if(n<30 || sw<=0) return null; const mz=sz/sw, mt=st_/sw, vz=szz/sw-mz*mz;
    if(vz<1e-4) return {G:GS, r2:0, n, relief:0};
    const bF=solveLS(A,B,4), bR=solveLS(A,B,3); if(!bF||!bR) return null;
    let rF=stt, rR=stt; for(let a=0;a<4;a++) rF-=bF[a]*B[a]; for(let a=0;a<3;a++) rR-=bR[a]*B[a];
    const r2=rR>0?Math.max(0,Math.min(1,(rR-rF)/rR)):0;
    return {G:bF[3], r2, n, relief:Math.sqrt(vz)*1000, mz, mt}; };
  const shrink=R=>{ if(!R) return GS; const w=Math.max(0,Math.min(1, R.r2*(R.n/(R.n+200))*Math.min(1,R.relief/250))); return Math.max(-10, Math.min(3, w*R.G+(1-w)*GS)); };
  const RG=regress(0,0,0), Gglob=shrink(RG);
  const acc=new Float64Array(GN), Wt=new Float64Array(GN), tiles=[];
  let ix0=GW, ix1=-1, iy0=GH, iy1=-1; for(let y=0;y<GH;y++) for(let x=0;x<GW;x++) if(demOK[y*GW+x]){ if(x<ix0) ix0=x; if(x>ix1) ix1=x; if(y<iy0) iy0=y; if(y>iy1) iy1=y; }
  const W_=lon[ix0], E2=lon[ix1], N_=lat[iy0], S_=lat[iy1], half=cfg.tile/2, step=cfg.tile/2;
  const add=(lo0, la0, hw, G, scale)=>{ for(let y=0;y<GH;y++){ const dy=(lat[y]-la0)/hw; if(Math.abs(dy)>1) continue; const wy=Math.cos(dy*Math.PI/2)**2;
      for(let x=0;x<GW;x++){ const dx=(lon[x]-lo0)/hw; if(Math.abs(dx)>1) continue; const i=y*GW+x; if(!demOK[i]) continue; const w=scale*wy*Math.cos(dx*Math.PI/2)**2; acc[i]+=w*G; Wt[i]+=w; } } };
  if(cfg.tiles){ for(let lo0=W_+half; lo0<=E2-half+step+1e-9; lo0+=step) for(let la0=S_+half; la0<=N_-half+step+1e-9; la0+=step){ const R=regress(lo0,la0,half), G=R?shrink(R):Gglob; tiles.push({lon0:lo0, lat0:la0, R, G}); add(lo0, la0, half, G, 1); } }
  add((W_+E2)/2, (N_+S_)/2, 1000, Gglob, 1e-3);
  const Gam=new Float32Array(GN), Dl=new Float32Array(GN), Tc=new Float32Array(GN);
  for(let i=0;i<GN;i++){ Gam[i]= Wt[i]>0 ? acc[i]/Wt[i] : Gglob;
    let dT = demOK[i] && Zeff[i]===Zeff[i] && Zm[i]===Zm[i] ? cfg.strength*Gam[i]*(Zeff[i]-Zm[i])/1000 : 0;
    if(cfg.taper>0) dT*=Math.min(dist[i]/cfg.taper,1); Dl[i]=dT; Tc[i]=T0[i]+dT; }
  prog(0.75, "بازسازی نقشه با دمای اصلاح‌شده"); await tick();
  const warns=[];
  if(nIn<0.95*GN) warns.push(`DEM ${FA(Math.round(nIn/GN*100))}٪ کادر نقشه را می‌پوشاند؛ بیرون از آن، نقشه بدون تغییر است.`);
  if(RG && RG.r2<0.15) warns.push("رابطهٔ دما و ارتفاع در کل نقشه ضعیف است (مثلاً به دلیل اثر عرض جغرافیایی یا دریا)؛ آهنگ کاهش دما بیشتر به مقدار استاندارد −۶٫۵ نزدیک شد.");
  const cv=document.createElement("canvas"); cv.width=P.W; cv.height=P.H;
  const cx=cv.getContext("2d"), im=new ImageData(new Uint8ClampedArray(d), P.W, P.H), o=im.data;
  let changed=0; const wuClean = P.key==="wu" || /^dsc_760x760/.test(P.key);
  for(let y=0;y<FH;y++){ const gyf=Math.min(Math.max((y-(st-1)/2)/st,0),GH-1), gy0=Math.min(Math.floor(gyf),Math.max(GH-2,0)), ay=GH>1?gyf-gy0:0;
    for(let x=0;x<FW;x++){ const i=y*FW+x; if(cls[i]<0 && !wuClean) continue;
      const gxf=Math.min(Math.max((x-(st-1)/2)/st,0),GW-1), gx0=Math.min(Math.floor(gxf),Math.max(GW-2,0)), ax=GW>1?gxf-gx0:0;
      let dd; if(st===1) dd=Dl[i]; else { const k=gy0*GW+gx0, k1=Math.min(k+1,GN-1), k2=Math.min(k+GW,GN-1), k3=Math.min(k+GW+1,GN-1); dd=(Dl[k]*(1-ax)+Dl[k1]*ax)*(1-ay)+(Dl[k2]*(1-ax)+Dl[k3]*ax)*ay; }
      const v=PF[i]+dd; let k=0; while(k+1<nCls && low[k+1]<=v) k++;
      if(k!==cls[i]){ const q=((y+P.fy0)*W0+x+P.fx0)*4, c=pal[k]||PAL[k]; o[q]=c[0]; o[q+1]=c[1]; o[q+2]=c[2]; if(cls[i]>=0) changed++; } } }
  cx.putImageData(im,0,0);
  if(wuClean && P.W===760){ const ov=wuOverlay(m.zone); if(ov){ cx.save(); cx.beginPath(); cx.rect(P.fx0,P.fy0,FW,FH); cx.clip(); cx.drawImage(ov,0,0,P.W,P.H); cx.restore(); }
    cx.strokeStyle="#000"; cx.lineWidth=1; cx.strokeRect(P.fx0-0.5,P.fy0-0.5,FW+1,FH+1); cx.fillStyle="#fff"; cx.fillRect(500,722,P.W-500,P.H-722);
    drawBrand(cx, {logoImg:state.logoImg}, 520, 716, P.W-538, 44, {side:true, align:"right", fs:14}); }
  if(cfg.stamp){ const sc=Math.max(1, P.W/900), t_="اصلاح دما با ارتفاع (DEM) · MetStat"; cx.font=`700 ${Math.round(12*sc)}px "Ketab", Tahoma, sans-serif`; cx.direction="rtl";
    const tw=cx.measureText(t_).width, bx=P.fx1-8*sc, by=P.fy0+6*sc; cx.fillStyle="rgba(255,255,255,.88)"; cx.strokeStyle="rgba(90,90,90,.8)"; cx.lineWidth=1;
    cx.beginPath(); cx.rect(bx-tw-10*sc, by, tw+12*sc, 19*sc); cx.fill(); cx.stroke(); cx.fillStyle="#15233b"; cx.textBaseline="middle"; cx.textAlign="right"; cx.fillText(t_, bx-4*sc, by+10*sc); }
  const sum=(arr)=>{ let s=0,n=0,mx=-Infinity,mn=Infinity; for(let i=0;i<GN;i++) if(demOK[i]){ const v=arr[i]; s+=v; n++; if(v>mx) mx=v; if(v<mn) mn=v; } return {mean:n?s/n:NaN, max:mx, min:mn}; };
  const dv=[]; for(let i=0;i<GN;i++) if(demOK[i]) dv.push(Dl[i]);
  const gv=[]; for(let i=0;i<GN;i+=3) if(demOK[i]) gv.push(Gam[i]);
  const res={isTemp:true, m, cfg, lon, lat, dxk, dyk, P0:T0, Pc:Tc, Z, Zeff, Zm, demOK, GW, GH, st, f:Gam, gamma:Gam, delta:Dl, Gglob, RG, tiles, warns, cv, clsFull:cls,
    geo:{W:P.W, H:P.H, fx0:P.fx0, fy0:P.fy0, fx1:P.fx1, fy1:P.fy1, FW, FH, name:m.siteName},
    stats:{before:sum(T0), after:sum(Tc), dP05:dsPct(dv,5), dP95:dsPct(dv,95), gP05:dsPct(gv,5), gP95:dsPct(gv,95), changed, nInside:nIn}};
  return res;
}
function dsChartTemp(r){
  const W=480, H=580, cv=document.createElement("canvas"); cv.width=W*2; cv.height=H*2; const c=cv.getContext("2d"); c.scale(2,2); c.fillStyle="#fff"; c.fillRect(0,0,W,H);
  const ink="#15233b", mut="#6b7686", grid="#e6e9ef";
  const panel=(y0,h,title)=>{ c.fillStyle=ink; c.font='700 15px "Titr","Ketab",Tahoma,sans-serif'; c.direction="rtl"; c.textAlign="right"; c.fillText(title, W-14, y0+18); return {x0:58, x1:W-18, y0:y0+30, y1:y0+h-34}; };
  const axes=(A, xs, ys, xl, yl)=>{ c.strokeStyle=grid; c.lineWidth=1; c.font='12px "Ketab",Tahoma,sans-serif'; c.fillStyle=mut;
    for(const v of xs.t){ const X=xs.f(v); c.beginPath(); c.moveTo(X,A.y0); c.lineTo(X,A.y1); c.stroke(); c.textAlign="center"; c.direction="ltr"; c.fillText(FA(v), X, A.y1+15); }
    for(const v of ys.t){ const Y=ys.f(v); c.beginPath(); c.moveTo(A.x0,Y); c.lineTo(A.x1,Y); c.stroke(); c.textAlign="right"; c.direction="ltr"; c.fillText(FA(+v.toFixed(1)), A.x0-6, Y+4); }
    c.direction="rtl"; c.textAlign="center"; c.fillText(xl, (A.x0+A.x1)/2, A.y1+30); c.save(); c.translate(14,(A.y0+A.y1)/2); c.rotate(-Math.PI/2); c.fillText(yl,0,0); c.restore(); };
  // پنل ۱: پراکنش دمای مدل در برابر ارتفاع مدل + خط آهنگ کاهش کلی
  const A=panel(0,310,"دمای مدل در برابر ارتفاع (آهنگ کاهش دما)"), zs=[], ts=[];
  const stp=Math.max(1,Math.floor(r.P0.length/4000)); for(let i=0;i<r.P0.length;i+=stp) if(r.demOK[i] && r.Zm[i]===r.Zm[i]){ zs.push(r.Zm[i]); ts.push(r.P0[i]); }
  if(zs.length>20){ const z0=Math.max(0,dsPct(zs,0.5)), z1=dsPct(zs,99.5), t0=dsPct(ts,0.5)-1, t1=dsPct(ts,99.5)+1;
    const xs={f:v=>A.x0+(v-z0)/(z1-z0)*(A.x1-A.x0), t:[]}; for(let v=Math.ceil(z0/1000)*1000; v<=z1; v+=1000) xs.t.push(v);
    const sp=t1-t0>30?10:t1-t0>12?5:2, ys={f:v=>A.y1-(v-t0)/(t1-t0)*(A.y1-A.y0), t:[]}; for(let v=Math.ceil(t0/sp)*sp; v<=t1; v+=sp) ys.t.push(v);
    axes(A, xs, ys, "ارتفاع مدل (متر)", "دما (°C)");
    c.save(); c.beginPath(); c.rect(A.x0,A.y0,A.x1-A.x0,A.y1-A.y0); c.clip(); c.fillStyle="rgba(31,111,178,.25)"; zs.forEach((z,k)=>{ c.fillRect(xs.f(z)-1, ys.f(ts[k])-1, 2, 2); });
    if(r.RG){ const mz=r.RG.mz*1000, mt=r.RG.mt; c.strokeStyle="#b5541c"; c.lineWidth=2.4; c.beginPath(); c.moveTo(xs.f(z0), ys.f(mt+r.Gglob*(z0-mz)/1000)); c.lineTo(xs.f(z1), ys.f(mt+r.Gglob*(z1-mz)/1000)); c.stroke(); }
    c.restore(); c.font='700 13px "Ketab",Tahoma,sans-serif'; c.fillStyle="#b5541c"; c.direction="rtl"; c.textAlign="right";
    c.fillText(`آهنگ کاهش کلی ≈ ${FA(r.Gglob.toFixed(1))} °C/km`, A.x1-6, A.y0+16); }
  // پنل ۲: میانگین دما در هر طبقهٔ ارتفاعی DEM پیش و پس از اصلاح
  const B=panel(316,264,"میانگین دما در هر طبقهٔ ارتفاعی DEM"), z2=[], a0=[], a1=[];
  for(let i=0;i<r.P0.length;i++) if(r.demOK[i]){ z2.push(r.Z[i]); a0.push(r.P0[i]); a1.push(r.Pc[i]); }
  if(z2.length>200){ const z0=Math.max(0,dsPct(z2,0.5)), z1=dsPct(z2,99.5), nb=22, s0=new Float64Array(nb), s1=new Float64Array(nb), cn=new Float64Array(nb);
    z2.forEach((z,k)=>{ const b=Math.floor((z-z0)/(z1-z0)*nb); if(b>=0&&b<nb){ s0[b]+=a0[k]; s1[b]+=a1[k]; cn[b]++; } });
    const pts=[]; for(let b=0;b<nb;b++) if(cn[b]>=30) pts.push([z0+(b+0.5)*(z1-z0)/nb, s0[b]/cn[b], s1[b]/cn[b]]);
    if(pts.length>1){ const lo=Math.min(...pts.map(p=>Math.min(p[1],p[2])))-1, hi=Math.max(...pts.map(p=>Math.max(p[1],p[2])))+1;
      const xs={f:v=>B.x0+(v-z0)/(z1-z0)*(B.x1-B.x0), t:[]}; for(let v=Math.ceil(z0/1000)*1000; v<=z1; v+=1000) xs.t.push(v);
      const sp=hi-lo>30?10:hi-lo>12?5:2, ys={f:v=>B.y1-(v-lo)/(hi-lo)*(B.y1-B.y0), t:[]}; for(let v=Math.ceil(lo/sp)*sp; v<=hi; v+=sp) ys.t.push(v);
      axes(B, xs, ys, "ارتفاع DEM (متر)", "°C");
      for(const [k,col] of [[1,"#7a7a7a"],[2,"#c0392b"]]){ c.strokeStyle=col; c.fillStyle=col; c.lineWidth=2; c.beginPath(); pts.forEach((p,j)=>{ const X=xs.f(p[0]), Y=ys.f(p[k]); j?c.lineTo(X,Y):c.moveTo(X,Y); }); c.stroke(); pts.forEach(p=>{ c.beginPath(); c.arc(xs.f(p[0]), ys.f(p[k]), 2.6, 0, 7); c.fill(); }); }
      c.font='12.5px "Ketab",Tahoma,sans-serif'; c.direction="rtl"; c.textAlign="right";
      [["#7a7a7a","نقشهٔ ورودی"],["#c0392b","اصلاح‌شده"]].forEach(([col,t],k)=>{ const y=B.y0+12+k*17; c.fillStyle=col; c.fillRect(B.x1-24,y-8,18,4); c.fillStyle=ink; c.fillText(t,B.x1-30,y); }); } }
  return cv;
}
function dsReportTemp(r){
  const s=r.stats, L=[];
  L.push("Temperature downscaling with elevation (lapse-rate method)");
  L.push(`map: ${r.m.file.name}  model: ${r.m.name}  resolution: ${r.m.res} deg`);
  L.push(`method: T_fine = T_model + Gamma * (z_DEM - z_model); Gamma from local weighted regression of model temperature on model orography (windows ${r.cfg.tile} deg), shrunk toward ${DS_GSTD} C/km when weak, limited to [-10, +3] C/km`);
  L.push(`global lapse rate: ${r.Gglob.toFixed(2)} C/km` + (r.RG?`  (regression ${r.RG.G.toFixed(2)} C/km, R2=${r.RG.r2.toFixed(2)}, n=${r.RG.n})`:""));
  L.push(`local lapse rate 5-95%: ${s.gP05.toFixed(2)} to ${s.gP95.toFixed(2)} C/km`);
  L.push(`temperature change 5-95%: ${s.dP05.toFixed(2)} to ${s.dP95.toFixed(2)} C`);
  L.push(`mean temperature: ${s.before.mean.toFixed(2)} -> ${s.after.mean.toFixed(2)} C; min ${s.before.min.toFixed(1)} -> ${s.after.min.toFixed(1)}; max ${s.before.max.toFixed(1)} -> ${s.after.max.toFixed(1)}`);
  L.push(`pixels changed colour class: ${s.changed}`);
  for(const w of r.warns) L.push("note: "+w);
  return L.join("\n");
}

