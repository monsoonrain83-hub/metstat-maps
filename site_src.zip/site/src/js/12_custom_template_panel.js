/* ---------- حالت آزاد: پنل قالب ---------- */
function uniqueName(n){ let s=n, k=2; while(state.models.some(m=>m.name===s)) s=`${n} ${FA(k++)}`; return s; }
function guessModelName(fn){
  const s=fn.replace(/\.[^.]+$/,""), m=/(cansips|nmme|cfsv2|ecmwf|ifs|gefs|eps|gfs|icon|ukmo|ukmet|gem|cmc|gdps|arpege|access|jma|navgem|cfs|era5|wrf|hrrr|nam)/i.exec(s);
  if(!m) return s.slice(0,24);
  const k=m[1].toUpperCase(); return ({IFS:"ECMWF",UKMET:"UKMO",CMC:"GEM",GDPS:"GEM",CANSIPS:"CanSIPS",CFSV2:"CFSv2",CFS:"CFSv2",EPS:"ECMWF-EPS"})[k]||k;
}
function drawTemplatePanel(){
  const cu=PROFILES.cu, has = !!cu.T && state.models.some(m=>m.ok);
  $("tplEmpty").hidden = has; $("tplBody").hidden = !has;
  if(!has) return;
  const T=cu.T, ref=state.models.find(m=>m.ok);
  // پیش‌نمایش: کادر آبی، نوار رنگ نارنجی
  const pv=$("tplPrev"), sc=Math.min(1, 640/T.W); pv.width=Math.round(T.W*sc); pv.height=Math.round(T.H*sc);
  const pc=pv.getContext("2d"), tmp=document.createElement("canvas"); tmp.width=T.W; tmp.height=T.H;
  tmp.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(ref.data), T.W, T.H), 0, 0);
  pc.drawImage(tmp,0,0,pv.width,pv.height);
  pc.lineWidth=3; pc.strokeStyle="#0a69d8"; pc.strokeRect(T.fx0*sc, T.fy0*sc, (T.fx1-T.fx0+1)*sc, (T.fy1-T.fy0+1)*sc);
  const r=T.bar.rect; pc.strokeStyle="#ff8c14"; pc.strokeRect(r[0]*sc-2, r[1]*sc-2, (r[2]-r[0])*sc+4, (r[3]-r[1])*sc+4);
  // بزرگ‌نمایی نوار رنگ اصلی با برچسب‌هایش
  const h=T.bar.orient==="h", pad=h?[8,22]:[70,8];
  const cx0=Math.max(0,r[0]-pad[0]), cy0=Math.max(0,r[1]-pad[1]), cx1=Math.min(T.W,r[2]+pad[0]), cy1=Math.min(T.H,r[3]+pad[1]);
  const bc=$("tplBar"), bs = h ? Math.min(3, 640/(cx1-cx0)) : Math.min(3, 300/(cy1-cy0));
  bc.width=Math.round((cx1-cx0)*bs); bc.height=Math.round((cy1-cy0)*bs); bc.style.width = h ? "100%" : Math.min(bc.width, 160)+"px"; bc.style.marginInline = h ? "0" : "auto";
  const bctx=bc.getContext("2d"); bctx.imageSmoothingEnabled=false; bctx.drawImage(tmp, cx0, cy0, cx1-cx0, cy1-cy0, 0, 0, bc.width, bc.height);
  // خانه‌های رنگ با حد پایین هر کدام
  const v = parseEdges($("tplEdges").value) || [];
  $("tplSw").replaceChildren(...T.colors.map((c,k)=>{ const s=document.createElement("span"), i=document.createElement("i"); i.style.background=`rgb(${c})`; s.append(i, document.createTextNode(v[k]!==undefined && isFinite(v[k]) ? FA(v[k]) : "؟")); return s; }));
  const st = cu.staticInfo;
  $("tplInfo").textContent = `کادر نقشه ${FA(T.fx1-T.fx0+1)}×${FA(T.fy1-T.fy0+1)} پیکسل (آبی) · نوار رنگ ${h?"افقی":"عمودی"} با ${FA(T.colors.length)} رنگ (نارنجی) · زمینه ${T.bgSep?"جدا از نوار رنگ":"همان رنگ اول نوار"}`
    + (st ? ` · ${FA(st.borders)} پیکسل مرز و ${FA(st.labels)} پیکسل نوشته/لوگوی ثابت` : "") + (state.ttNote ? " · "+state.ttNote : "");
  $("tplEdges").placeholder = `${FA(T.colors.length+1)} عدد، مثلاً 0.1, 1, 2, 5, …, 200, +`;
  $("tplMsg").textContent = cu.edges ? `✓ ${FA(T.colors.length)} رنگ با اعداد جفت شد${guessScale(T.colors,T)?` (شناسایی شد: ${guessScale(T.colors,T).name})`:state.edgeAuto && $("tplEdges").value===state.edgeAuto.txt?" (خودکار از برچسب‌های نوار رنگ خوانده شد — بررسی کنید)":""}` : (cu.edgeMsg || "");
  $("tplMsg").style.color = cu.edges ? "var(--ok)" : "var(--warn)";
  const sel=$("tplPreset"); if(sel.options.length===1) KNOWN_SCALES.forEach((s,k)=>{ const o=document.createElement("option"); o.value=k; o.textContent=`${s.name} (${FA(s.colors.length)} رنگ)`; sel.append(o); });
}
function saveTpl(){ const cu=PROFILES.cu; if(!cu.T) return; store.set("tpl."+cu.T.fp, {edges:$("tplEdges").value, rev:!!cu.rev, geo:["geoW","geoE","geoS","geoN"].map(id=>$(id).value)}); }
function retemplate(){
  const cu=PROFILES.cu; if(!cu.T) return;
  const had = !!cu.edges, oldNC = cu.edges && cu.edges.length;
  applyCustom(cu.T, $("tplEdges").value); saveTpl();
  state.models.forEach(m=>{ m.mm=null; m.hit={}; });
  if(!had && cu.edges) cu.staticDirty = true;
  drawTemplatePanel(); if(cu.edges) schedule(null, 300);
}
$("tplEdges").addEventListener("input", ()=>{ clearTimeout(timers.tpl); timers.tpl=setTimeout(retemplate, 500); });
["geoW","geoE","geoS","geoN"].forEach(id=>$(id).addEventListener("change", retemplate));
$("tplPreset").onchange=e=>{ const s=KNOWN_SCALES[+e.target.value]; if(s){ $("tplEdges").value=s.edges; retemplate(); } e.target.value=""; };
$("tplRev").onclick=()=>{ const cu=PROFILES.cu; if(!cu.T) return; const T=cu.T; T.colors.reverse(); T.segs.reverse(); T.segCenters.reverse(); cu.rev=!cu.rev; cu.staticDirty=true; retemplate(); };
// تبدیل برف: نمایش ردیف، ذخیره و اجرای دوباره (رده‌ها با ضریب جدید)
function snowCmSync(){ const on=$("varSel")&&$("varSel").value==="snowp"; $("snowCmRow").hidden=!on; $("snowCmHint").hidden=!on||!$("snowCm").value; $("snowTRow").hidden=$("snowCm").value!=="T"; }
$("snowCm").value=store.get("snowCm",""); $("snowT").value=store.get("snowT",-2);
for(const id of ["snowCm","snowT"]) $(id).addEventListener("change", async()=>{ store.set(id,$(id).value); snowCmSync(); try{ if(P && !P.custom) await useProfile(P.key); else if(P && P.edges) await useProfile("cu"); state.models.forEach(m=>{ m.mm=null; m.hit={}; }); }catch(e){} schedule(); });
$("varSel").addEventListener("change", ()=>setTimeout(snowCmSync,0)); setTimeout(snowCmSync,0);
$("showBorders").addEventListener("change", ()=>{ store.set("showBorders", $("showBorders").checked); schedule(); });
$("showBorders").checked = store.get("showBorders", true);

/* رویدادها */
const fi=$("files");
fi.onchange=()=>{ addFiles(fi.files); fi.value=""; };
for(const el of [$("drop"), $("empty")]){
  el.addEventListener("dragover", e=>{ e.preventDefault(); el.classList.add("over"); });
  el.addEventListener("dragleave", ()=>el.classList.remove("over"));
  el.addEventListener("drop", e=>{ e.preventDefault(); el.classList.remove("over"); addFiles(e.dataTransfer.files); });
}
$("empty").onclick=()=>fi.click();
$("run").onclick=()=>{ state.models.forEach(m=>m.hit={}); run("all"); };
inputs.forEach(id=>$(id).addEventListener("input", ()=>{ store.set(id, $(id).value); schedule(); }));
$("zoom").onclick=()=>$("zoom").close();

function showLogo(){
  const p=$("logoPrev"); p.innerHTML="";
  if(state.logoImg){ const i=new Image(); i.src=state.logoImg.src; i.alt="لوگو"; p.append(i); }
  else { const s=document.createElement("span"); s.style.cssText='font:26px "Nastaliq",serif;color:var(--accent)'; s.textContent=$("brand").value||"—"; p.append(s); }
}
function loadLogo(src){ const im=new Image(); im.onload=()=>{ state.logoImg=im; showLogo(); schedule(); }; im.src=src; }
$("logoFile").onchange=e=>{ const f=e.target.files[0]; if(!f) return; const r=new FileReader(); r.onload=()=>{ store.set("logo", r.result); loadLogo(r.result); }; r.readAsDataURL(f); };
$("logoClear").onclick=()=>{ state.logoImg=null; store.set("logo", null); showLogo(); schedule(); };
$("brand").addEventListener("input", showLogo);
// لوگوی ثابت سایت (بارگذاری دستی لوگو حذف شد)
$("brand").value="MetStat"; $("handle").value=SITE_URL; loadLogo(LOGO_SRC);

/* =====================================================================
   اصلاح توپوگرافی بارش با DEM — Terrain-Aware Statistical Downscaling
   همان الگوریتم بستهٔ پایتون (GAM با اسپلاین جریمه‌دار + GCV، رابطهٔ محلی،
   ضریب محدود، حفظ میانگین سلول مدل)، اجرا روی شبکهٔ پیکسلی خود نقشه.
   ===================================================================== */
const DEM_META = {"nx": 1260, "ny": 1020, "x0": 43.008211262688, "y0": 40.991788737312, "dx": 0.016666666, "dy": 0.016666666, "name": "Iran DEM 3\u2033 (\u224890 m) aggregated to 1\u2032", "nodata": -32768};
{{BLOB:dem_iran}}
const DS_RES = {ECMWF:0.1, IFS:0.1, GFS:0.125, ICON:0.125, UKMO:0.1, GEM:0.15, CMC:0.15, ARPEGE:0.1, AIFS:0.25, ACCESS:0.117, "ACCESS-G":0.117};
const ds = { maps:[], dem:null, builtin:null, busy:false, pending:false, timer:null, seq:0 };

/* ---------- DEM ---------- */
// بازکردن zlib/deflate به JS خالص (برای مرورگرهایی که DecompressionStream ندارند)
function jsInflate(src){
  let pos=2, bit=0, bb=0; // skip zlib header
  const out=[]; let outBuf=new Uint8Array(1<<20), olen=0;
  const put=b=>{ if(olen>=outBuf.length){ const n=new Uint8Array(outBuf.length*2); n.set(outBuf); outBuf=n; } outBuf[olen++]=b; };
  const getBit=()=>{ if(!bit){ bb=src[pos++]; bit=8; } const v=bb&1; bb>>=1; bit--; return v; };
  const bits=n=>{ let v=0; for(let i=0;i<n;i++) v|=getBit()<<i; return v; };
  const build=(lens)=>{ const cnt=new Uint16Array(16), offs=new Uint16Array(16), sym=new Uint16Array(lens.length);
    for(const l of lens) cnt[l]++; cnt[0]=0; for(let i=1;i<16;i++) offs[i]=offs[i-1]+cnt[i-1];
    for(let i=0;i<lens.length;i++) if(lens[i]) sym[offs[lens[i]]++]=i; return {cnt, sym}; };
  const decode=t=>{ let code=0, first=0, idx=0; for(let l=1;l<16;l++){ code|=getBit(); const c=t.cnt[l]; if(code-c<first) return t.sym[idx+(code-first)]; idx+=c; first+=c; first<<=1; code<<=1; } throw new Error("inflate: bad code"); };
  const LB=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258], LE=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  const DB=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577], DE=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  let fixedL=null, fixedD=null;
  let final=0;
  while(!final){
    final=getBit(); const type=bits(2);
    if(type===0){ bit=0; const len=src[pos]|(src[pos+1]<<8); pos+=4; for(let i=0;i<len;i++) put(src[pos++]); continue; }
    let lt, dt;
    if(type===1){ if(!fixedL){ const l=new Uint8Array(288); l.fill(8,0,144); l.fill(9,144,256); l.fill(7,256,280); l.fill(8,280,288); fixedL=build(l); fixedD=build(new Uint8Array(30).fill(5)); } lt=fixedL; dt=fixedD; }
    else if(type===2){
      const hl=bits(5)+257, hd=bits(5)+1, hc=bits(4)+4, ord=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15], cl=new Uint8Array(19);
      for(let i=0;i<hc;i++) cl[ord[i]]=bits(3);
      const ct=build(cl), L=new Uint8Array(hl+hd); let i=0;
      while(i<hl+hd){ const s=decode(ct); if(s<16) L[i++]=s; else if(s===16){ const p=L[i-1], r=3+bits(2); for(let k=0;k<r;k++) L[i++]=p; } else if(s===17){ i+=3+bits(3); } else { i+=11+bits(7); } }
      lt=build(L.subarray(0,hl)); dt=build(L.subarray(hl));
    } else throw new Error("inflate: bad block");
    for(;;){ const s=decode(lt); if(s<256){ put(s); continue; } if(s===256) break;
      const li=s-257, len=LB[li]+bits(LE[li]), ds=decode(dt), dist=DB[ds]+bits(DE[ds]);
      for(let k=0;k<len;k++) put(outBuf[olen-dist]); }
  }
  return outBuf.slice(0,olen);
}
async function dsInflate(u8){
  if(typeof DecompressionStream!=="undefined"){
    try{ const st = new Blob([u8]).stream().pipeThrough(new DecompressionStream("deflate")); return new Uint8Array(await new Response(st).arrayBuffer()); }catch(e){ console.warn("DecompressionStream failed, using JS inflate", e); }
  }
  return jsInflate(u8);
}
async function dsBuiltinDEM(){
  if(ds.builtin) return ds.builtin;
  const raw = await dsInflate(b64u8(DEM_B64));
  const d16 = new Int16Array(raw.buffer, 0, raw.byteLength>>1);
  const {nx, ny} = DEM_META, out = new Float32Array(nx*ny);
  for(let i=0;i<ny;i++){ let v=0; for(let j=0;j<nx;j++){ const k=i*nx+j; v = j ? ((v + d16[k]) << 16 >> 16) : d16[k]; out[k] = v===-32768 ? NaN : v; } }
  ds.builtin = {...DEM_META, data:out, label:"DEM داخلی ایران (۹۰ متری، تجمیع‌شده به ۱ دقیقه ≈ ۱٫۸ کیلومتر)"};
  // اگر فایل DEM ۳۰ ثانیه‌ای (≈۹۰۰ متر) کنار index.html روی هاست باشد، از آن استفاده می‌شود (برای نقشه‌های استانی دقیق‌تر)
  try{ const hi=await dsHostedDEM(); if(hi) ds.builtin=hi; }catch(e){}
  return ds.builtin;
}
let _hostedDEM;
async function dsHostedDEM(){
  if(_hostedDEM!==undefined) return _hostedDEM; _hostedDEM=null;
  if(!/^https?:/.test(location.protocol) || window.MS_SAFE) return null;
  const r=await fetch("dem_iran_30s.bin",{cache:"force-cache"}); if(!r.ok) return null;
  const u=new Uint8Array(await r.arrayBuffer()); if(String.fromCharCode(...u.subarray(0,6))!=="MSDEM1") return null;
  const hl=u[6]|(u[7]<<8), meta=JSON.parse(new TextDecoder().decode(u.subarray(8,8+hl)));
  const raw=await dsInflate(u.slice(8+hl)), d16=new Int16Array(raw.buffer, raw.byteOffset, raw.byteLength>>1), {nx,ny}=meta, out=new Float32Array(nx*ny);
  for(let i=0;i<ny;i++){ let v=0; for(let j=0;j<nx;j++){ const k=i*nx+j; v = j ? ((v + d16[k]) << 16 >> 16) : d16[k]; out[k]=v; } }
  _hostedDEM={...meta, nodata:-32768, data:out, label:"DEM ایران (۹۰ متری، تجمیع‌شده به ۳۰ ثانیه ≈ ۹۰۰ متر؛ فایل روی هاست)"}; return _hostedDEM;
}
// شیب میانگین (درجه) هر خانهٔ ۱ دقیقه‌ای، محاسبه‌شده از DEM ۹۰ متری (شیب واقعی دامنه‌ها؛ شیبِ DEM درشت آن را کم نشان می‌دهد)
let _demSlope=null;
async function demSlopeLoad(){
  if(_demSlope) return _demSlope;
  const raw=await dsInflate(b64u8(DEM_SLOPE_B64)), {nx,ny}=DEM_META, out=new Float32Array(nx*ny);
  for(let i=0;i<ny;i++){ let v=0; for(let j=0;j<nx;j++){ const k=i*nx+j; v = j ? ((v + raw[k]) & 255) : raw[k]; out[k]=v/2; } }
  _demSlope={...DEM_META, data:out}; return _demSlope;
}
function demSlopeAt(S, lat, lon){ const j=Math.round((lon-S.x0)/S.dx), i=Math.round((S.y0-lat)/S.dy); if(i<0||j<0||i>=S.ny||j>=S.nx) return NaN; return S.data[i*S.nx+j]; }
// GeoTIFF ساده: نوار یا کاشی، بدون فشرده‌سازی یا Deflate، مختصات جغرافیایی (EPSG:4326)
async function dsReadGeoTIFF(file){
  const buf = await file.arrayBuffer(), dv = new DataView(buf);
  const le = dv.getUint16(0)===0x4949, u16=o=>dv.getUint16(o,le), u32=o=>dv.getUint32(o,le);
  if(u16(2)!==42) throw new Error("فقط GeoTIFF معمولی پشتیبانی می‌شود (نه BigTIFF)");
  const TS={1:1,2:1,3:2,4:4,5:8,6:1,8:2,9:4,11:4,12:8,16:8}, ifd=u32(4), n=u16(ifd), T={};
  for(let k=0;k<n;k++){
    const e=ifd+2+k*12, tag=u16(e), type=u16(e+2), cnt=u32(e+4), sz=(TS[type]||1)*cnt, off=sz<=4?e+8:u32(e+8), vals=[];
    if(tag===42113 || type===2){ let s=""; for(let q=0;q<cnt;q++){ const c=dv.getUint8(off+q); if(c) s+=String.fromCharCode(c); } T[tag]=s; continue; }
    for(let q=0;q<cnt;q++){ const o=off+q*(TS[type]||1);
      vals.push(type===3?u16(o):type===4?u32(o):type===8?dv.getInt16(o,le):type===9?dv.getInt32(o,le):type===11?dv.getFloat32(o,le):type===12?dv.getFloat64(o,le):type===16?Number(dv.getBigUint64(o,le)):dv.getUint8(o)); }
    T[tag]=vals;
  }
  const W=T[256][0], H=T[257][0], bits=(T[258]||[8])[0], comp=(T[259]||[1])[0], sf=(T[339]||[1])[0], pred=(T[317]||[1])[0], spp=(T[277]||[1])[0];
  if(spp!==1) throw new Error("DEM باید تک‌باندی باشد");
  if(![1,8,32946].includes(comp)) throw new Error("فشرده‌سازی این GeoTIFF پشتیبانی نمی‌شود؛ آن را بدون فشرده‌سازی یا با Deflate ذخیره کنید");
  if(pred===3) throw new Error("پیش‌بینی‌گر اعشاری (predictor=3) پشتیبانی نمی‌شود؛ بدون آن ذخیره کنید");
  if(!T[33550] || !T[33922]) throw new Error("این TIFF مختصات جغرافیایی ندارد");
  const gk=T[34735]||[]; for(let k=0;k<gk[3];k++){ if(gk[4+4*k]===3072) throw new Error("DEM باید در مختصات جغرافیایی WGS84 (EPSG:4326) باشد؛ ابتدا آن را تبدیل کنید"); }
  let pixIsPoint=false; for(let k=0;k<gk[3];k++) if(gk[4+4*k]===1025 && gk[7+4*k]===2) pixIsPoint=true;
  const bps=bits/8, rd = sf===3 ? (bits===64?(v,o)=>v.getFloat64(o,le):(v,o)=>v.getFloat32(o,le))
    : sf===2 ? (bits===8?(v,o)=>v.getInt8(o):bits===16?(v,o)=>v.getInt16(o,le):(v,o)=>v.getInt32(o,le))
    : (bits===8?(v,o)=>v.getUint8(o):bits===16?(v,o)=>v.getUint16(o,le):(v,o)=>v.getUint32(o,le));
  const out=new Float32Array(W*H), tiled=!!T[322];
  const tw=tiled?T[322][0]:W, th=tiled?T[323][0]:(T[278]||[H])[0], offs=tiled?T[324]:T[273], cnts=tiled?T[325]:T[279];
  const across=Math.ceil(W/tw);
  for(let s=0;s<offs.length;s++){
    let bytes=new Uint8Array(buf, offs[s], cnts[s]);
    if(comp!==1) bytes=await dsInflate(bytes);
    const sv=new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const sx0=tiled?(s%across)*tw:0, sy0=tiled?Math.floor(s/across)*th:s*th, rowW=tw;
    for(let y=0;y<th;y++){ const Y=sy0+y; if(Y>=H) break; let acc=0;
      for(let x=0;x<rowW;x++){ const o=(y*rowW+x)*bps; if(o+bps>bytes.byteLength) break; let v=rd(sv,o);
        if(pred===2){ acc = x ? acc + v : v; v = bits===16 ? (sf===2 ? acc<<16>>16 : acc & 0xffff) : acc; acc=v; }
        const X=sx0+x; if(X<W) out[Y*W+X]=v; } }
  }
  const nod = T[42113]!==undefined && T[42113]!=="" ? parseFloat(T[42113]) : NaN;
  for(let i=0;i<out.length;i++){ const v=out[i]; if(!(v===v) || Math.abs(v)>1e30 || v===nod || v<-1000) out[i]=NaN; }
  const sx=T[33550][0], sy=T[33550][1], tp=T[33922];
  let xe=tp[3]-tp[0]*sx, ye=tp[4]+tp[1]*sy; if(pixIsPoint){ xe-=sx/2; ye+=sy/2; }
  if(Math.abs(xe)>360 || Math.abs(ye)>90) throw new Error("مختصات DEM جغرافیایی نیست؛ DEM را به EPSG:4326 تبدیل کنید");
  return {nx:W, ny:H, x0:xe+sx/2, y0:ye-sy/2, dx:sx, dy:sy, data:out, label:`${file.name} — ${FA(W)}×${FA(H)}، گام ${FA((sx*3600).toFixed(1))} ثانیه`};
}

