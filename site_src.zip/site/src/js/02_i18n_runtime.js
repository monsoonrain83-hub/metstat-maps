
"use strict";
/* =====================================================================
   دوزبانه (English / فارسی) — ترجمهٔ زمان اجرا؛ منطق برنامه فارسی می‌ماند
   ===================================================================== */
let LANG = (()=>{ try{ const v=localStorage.getItem("mmap.lang"); return v ? JSON.parse(v) : "en"; }catch(e){ return "en"; } })();
{{BLOB:data_climqc_i}}
const FA_CH = /[؀-ۿ]/;
const FA_LET = "ء-ي٠-٩پچژکگیۀ۰-۹‌";
const i18nDig = s => s.replace(/[۰-۹]/g, d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/[٠-٩]/g, d=>"٠١٢٣٤٥٦٧٨٩".indexOf(d)).replace(/(\d)٫(\d)/g,"$1.$2").replace(/٫/g,".");
const i18nPunct = s => s.replace(/٪/g,"%").replace(/،\s?/g,", ").replace(/؛\s?/g,"; ").replace(/؟/g,"?").replace(/«/g,"“").replace(/»/g,"”").replace(/‌/g,"");
const i18nNorm = s => i18nDig(s).replace(/ي/g,"ی").replace(/ك/g,"ک").replace(/ۀ/g,"هٔ").replace(/[\s ]+/g," ").trim();
const I18N_EX = new Map(), I18N_PAT = [];
let I18N_PHR = [];
(function(){
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  for(const [fa0,en] of Object.entries(I18N_D)){
    const fa = i18nNorm(fa0);
    if(fa.includes("{}")){
      const lit = fa.split("{}"), litTxt = lit.join("").trim();
      if(!litTxt) continue;
      const re = new RegExp("^" + lit.map(esc).join("(.*?)") + "$", "s");
      const need = lit.reduce((a,b)=>b.length>a.length?b:a, "");
      I18N_PAT.push({re, en, w: litTxt.length, need, semi: /[؛.!؟]\s|\s\|\s/.test(litTxt+" ")});
    } else if(!I18N_EX.has(fa)) I18N_EX.set(fa, en);
  }
  I18N_PAT.sort((a,b)=>b.w-a.w);
  I18N_PHR = [...I18N_EX.entries()].filter(([k])=>FA_CH.test(k) && k.length>=2 && k.length<=60).sort((a,b)=>b[0].length-a[0].length)
    .map(([k,v])=>({k, v, re:new RegExp("(^|[^"+FA_LET+"])"+esc(k)+"(?=$|[^"+FA_LET+"])", "g")}));
})();
const I18N_CACHE = new Map();
function i18nBal(g){ let d=0, q=0; for(const c of g||""){ if(c==="(") d++; else if(c===")"){ if(--d<0) return false; } else if(c==="«") q++; else if(c==="»"){ if(--q<0) return false; } } return d===0 && q===0; }
function lowItems(g){ return g.split(", ").map(x=>/^[A-Z][a-z]/.test(x) ? x.charAt(0).toLowerCase()+x.slice(1) : x).join(", "); }
// ترجمهٔ مستقیم (واژه‌نامه یا الگو)؛ null اگر نبود
function hit(k, depth){
  if(I18N_EX.has(k)) return I18N_EX.get(k);
  for(const p of I18N_PAT){
    if(p.need && !k.includes(p.need)) continue;
    if(p.w < 0.3*k.length && /[.؛!؟]\s|\n/.test(k)) continue;
    const m = p.re.exec(k); if(!m) continue;
    const gs = m.slice(1);
    if(!gs.every(i18nBal)) continue;
    if(!p.semi && gs.some(g=>/[؛.!؟]\s|\s\|\s/.test(g))) continue;
    const fb0 = I18N_FB, tg = gs.map(g=>trCore(g||"", depth+1));
    if(p.w<8 && I18N_FB>fb0){ I18N_FB=fb0; continue; }
    let i=0; return p.en.replace(/\{l?\}/g, ph=>{ const g=tg[i++]||""; return ph==="{l}" ? lowItems(g) : g; });
  }
  return null;
}
function hitV(k, depth){
  if(I18N_EX.has(k)) return I18N_EX.get(k);
  let h, m = /^(.*?)\s*([.:،؛]+)$/s.exec(k);
  if(m && m[1] && FA_CH.test(m[1])){ h = hit(m[1], depth); if(h!==null) return h + i18nPunct(m[2]); }
  h = hit(k, depth); if(h!==null) return h;
  m = /^\((.*)\)([.:]?)$/s.exec(k);
  if(m && FA_CH.test(m[1])){ h = hit(m[1], depth); if(h!==null) return "(" + h + ")" + m[2]; }
  m = /^([✓⚠ⓘ•·—–+\-]+\s*)(.+)$/su.exec(k);
  if(m){ h = hitV(m[2], depth); if(h!==null) return m[1] + h; }
  return null;
}
function trCore(s, depth){
  if(!FA_CH.test(s)) return i18nPunct(i18nDig(s));
  const lead = /^\s*/.exec(s)[0], trail = /\s*$/.exec(s)[0], k = i18nNorm(s);
  const wrap = r => lead + r + trail;
  if(depth>8) return wrap(phr(k));
  let h = hitV(k, depth); if(h!==null) return wrap(h);
  const c0 = /^([^:()]{1,60}):\s+(.+)$/s.exec(k);
  if(c0 && I18N_EX.has(c0[1])) return wrap(I18N_EX.get(c0[1]) + ": " + trCore(c0[2], depth+1));
  const seps = (list) => { for(const sp of list){
    const [a,b] = Array.isArray(sp) ? sp : [sp,sp];
    const src = a==="\n" ? s : k;
    if(src.includes(a)){ const parts=src.split(a); if(parts.length>1) return wrap(parts.map(x=>x.trim()?trCore(x, depth+1):x).join(b).trim()); }
  } return null; };
  let r = seps([["\n","\n"],["  |  ","  |  "]," | "]); if(r!==null) return r;
  // جمله‌ها
  const sent = k.split(/(?<=[.!؟?])\s+(?=\S)/);
  if(sent.length>1) return wrap(sent.map(x=>trCore(x, depth+1)).join(" "));
  const cm = /^([^:]{1,60}):\s+(.+)$/s.exec(k);
  if(cm) return wrap(trCore(cm[1], depth+1) + ": " + trCore(cm[2], depth+1));
  r = seps([["؛ ","; "],[" ؛ ","; "]," · "," — ",["، ",", "],[" ، ",", "],[" و "," and "]]); if(r!==null) return r;
  // پیشوند تا پرانتز بسته که ترجمه دارد: «X (Y) بقیه»
  for(let i=k.length-1;i>0;i--){ if(k[i]!==")") continue; const pre=k.slice(0,i+1), rest=k.slice(i+1); if(!rest.trim()) continue; const hp=hitV(pre, depth); if(hp!==null) return wrap(hp + " " + trCore(rest.trim(), depth+1)); }
  // پرانتز
  const pm = /^(.*?)\s*\(([^()]*)\)(.*)$/s.exec(k);
  if(pm && (pm[1]||pm[3])) return wrap((pm[1]?trCore(pm[1],depth+1)+" ":"") + "(" + trCore(pm[2],depth+1) + ")" + (pm[3]?" "+trCore(pm[3],depth+1).trim():""));
  const sm = /^([✓⚠ⓘ•·—–]+\s*)(.+)$/su.exec(k);
  if(sm) return wrap(sm[1] + trCore(sm[2], depth+1));
  return wrap(phr(k));
}
let I18N_FB=0;
function phr(k){
  I18N_FB++;
  if(self.__I18N_DBG) self.__I18N_DBG.add(k);
  let r = k;
  for(const p of I18N_PHR){ if(r.includes(p.k)) r = r.replace(p.re, (m0,a)=>a+p.v); }
  r = r.replace(new RegExp("(^|[^"+FA_LET+"])و(?=$|[^"+FA_LET+"])","g"), "$1and");
  return i18nPunct(r).replace(/\s{2,}/g," ");
}
function tr(s){
  if(LANG!=="en" || s==null) return s;
  s = String(s);
  if(!FA_CH.test(s)) return /[۰-۹٫٪]/.test(s) ? i18nPunct(i18nDig(s)) : s;
  let r = I18N_CACHE.get(s);
  if(r===undefined){ r = trCore(s, 0); if(I18N_CACHE.size>20000) I18N_CACHE.clear(); I18N_CACHE.set(s, r); }
  return r;
}
const trText = s => LANG==="en" ? String(s).split("\n").map(x=>tr(x)).join("\n") : s;

/* ---- بوم: ترجمهٔ متنِ نقشه‌ها و نمودارها ---- */
(function(){
  const P2 = CanvasRenderingContext2D.prototype, _f=P2.fillText, _s=P2.strokeText, _m=P2.measureText;
  const conv = (ctx,t) => {
    if(LANG!=="en" || t==null) return null;
    const s = String(t); if(!FA_CH.test(s) && !/[۰-۹٫٪]/.test(s)) return null;
    if(/Ocr/.test(ctx.font)) return null;
    const u = tr(s); return u===s ? null : u;
  };
  const draw = (fn) => function(t, x, y, mw){
    let u = conv(this, t);
    if(u===null){ if(LANG!=="en" || t==null || FA_CH.test(String(t)) || this.direction==="ltr" || /Ocr/.test(this.font)) return fn.apply(this, arguments); u=String(t); }
    const d = this.direction, a = this.textAlign, ltr = !FA_CH.test(u);
    if(ltr && d!=="ltr"){
      const rtl = d==="rtl" || (d==="inherit" && getComputedStyle(this.canvas).direction==="rtl" && this.canvas.isConnected);
      if(rtl){ if(a==="start") this.textAlign="right"; else if(a==="end") this.textAlign="left"; }
      this.direction="ltr";
    }
    try{ return mw===undefined ? fn.call(this, u, x, y) : fn.call(this, u, x, y, mw); }
    finally{ this.direction=d; this.textAlign=a; }
  };
  P2.fillText = draw(_f); P2.strokeText = draw(_s);
  P2.measureText = function(t){ const u=conv(this,t); return _m.call(this, u===null ? t : u); };
})();

/* ---- قلم لاتین برای انگلیسی (فقط نویسه‌های لاتین؛ فارسی دست نمی‌خورد) ---- */
const LAT_RANGE = "U+0020-007E,U+00A0-00FF,U+2010-2027,U+2030-203A,U+2190-2195,U+2212,U+2248,U+2260-2265,U+221E,U+00B1";
let LAT_FACES = null;
function latFaces(){
  if(LAT_FACES) return LAT_FACES;
  const b64 = s => { const bin=atob(s), u=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) u[i]=bin.charCodeAt(i); return u.buffer; };
{{BLOB:data_climqc_r_font}}
  const mk = (fam, buf, weight) => new FontFace(fam, buf, {weight, unicodeRange: LAT_RANGE});
  LAT_FACES = [mk("Titr",B,"700"), mk("Ketab",R,"400"), mk("Ketab",M,"500"), mk("Ketab",S,"600"), mk("Ketab",B,"700"), mk("Lalezar",S,"400"), mk("Nastaliq",M,"400")];
  return LAT_FACES;
}
async function latFonts(on){
  try{
    const fs = latFaces();
    for(const f of fs){ if(on){ if(!document.fonts.has(f)) document.fonts.add(f); } else if(document.fonts.has(f)) document.fonts.delete(f); }
    if(on) await Promise.all(fs.map(f=>f.load().catch(()=>{})));
  }catch(e){ console.warn("lat fonts", e); }
}

/* ---- DOM ---- */
const I18N_ATTR = ["placeholder","title","aria-label","alt"];
const I18N_TXT = new WeakMap(), I18N_ATT = new WeakMap();
const i18nSkip = el => { for(let e=el; e && e.nodeType===1; e=e.parentElement){ const t=e.tagName; if(t==="SCRIPT"||t==="STYLE"||t==="TEXTAREA"||e.isContentEditable||e.hasAttribute("data-noi18n")) return true; } return false; };
function i18nText(n){
  const v = n.nodeValue; if(!v || !FA_CH.test(v) && !/[۰-۹٫٪]/.test(v)) return;
  const rec = I18N_TXT.get(n); if(rec && rec.en===v) return;
  if(i18nSkip(n.parentElement)) return;
  const e = tr(v); if(e===v) return;
  I18N_TXT.set(n, {fa:v, en:e}); n.nodeValue = e;
}
function i18nAttr(el, a){
  const v = el.getAttribute(a); if(!v || !FA_CH.test(v)) return;
  let m = I18N_ATT.get(el); if(m && m[a] && m[a].en===v) return;
  if(i18nSkip(el)) return;
  const e = tr(v); if(e===v) return;
  if(!m){ m={}; I18N_ATT.set(el,m); } m[a]={fa:v,en:e}; el.setAttribute(a, e);
}
function i18nWalk(root){
  if(LANG!=="en" || !root) return;
  if(root.nodeType===3) return i18nText(root);
  if(root.nodeType!==1 && root.nodeType!==9 && root.nodeType!==11) return;
  if(root.nodeType===1){ if(i18nSkip(root)) return; I18N_ATTR.forEach(a=>root.hasAttribute(a)&&i18nAttr(root,a)); }
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);
  let n; while((n=w.nextNode())){ if(n.nodeType===3) i18nText(n); else for(const a of I18N_ATTR) if(n.hasAttribute(a)) i18nAttr(n,a); }
}
function i18nRestore(){
  const w = document.createTreeWalker(document.documentElement, NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);
  let n; while((n=w.nextNode())){
    if(n.nodeType===3){ const r=I18N_TXT.get(n); if(r && n.nodeValue===r.en) n.nodeValue=r.fa; I18N_TXT.delete(n); }
    else { const m=I18N_ATT.get(n); if(m){ for(const a in m) if(n.getAttribute(a)===m[a].en) n.setAttribute(a, m[a].fa); I18N_ATT.delete(n); } }
  }
}
const I18N_OBS = new MutationObserver(list=>{
  if(LANG!=="en") return;
  for(const mu of list){
    if(mu.type==="characterData") i18nText(mu.target);
    else if(mu.type==="attributes") i18nAttr(mu.target, mu.attributeName);
    else mu.addedNodes.forEach(n=>i18nWalk(n));
  }
});
const I18N_TITLE = document.title;
function i18nDoc(){
  const en = LANG==="en";
  document.documentElement.lang = en ? "en" : "fa";
  document.documentElement.dir = en ? "ltr" : "rtl";
  document.title = en ? "Meteorological Statistical Maps" : I18N_TITLE;
  const b = document.getElementById("langBtn");
  if(b){ b.textContent = en ? "فارسی" : "English"; b.title = en ? "نمایش فارسی" : "Switch to English"; }
  const hb = document.getElementById("helpBtn"); if(hb) hb.textContent = en ? "Help" : "راهنما";
}
function i18nStart(){
  i18nDoc();
  if(LANG==="en"){ latFonts(true); i18nWalk(document.body); }
  I18N_OBS.observe(document.documentElement, {subtree:true, childList:true, characterData:true, attributes:true, attributeFilter:I18N_ATTR});
}
async function setLang(l){
  if(l===LANG) return;
  LANG = l; try{ localStorage.setItem("mmap.lang", JSON.stringify(l)); }catch(e){}
  I18N_CACHE.clear();
  if(l==="en"){ await latFonts(true); i18nDoc(); i18nWalk(document.body); }
  else { i18nRestore(); await latFonts(false); i18nDoc(); }
  try{ document.dispatchEvent(new CustomEvent("langchange", {detail:l})); }catch(e){}
}

