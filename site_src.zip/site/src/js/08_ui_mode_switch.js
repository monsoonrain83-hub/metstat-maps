/* ---------- انتخاب منبع (دو حالت مستقل) ---------- */
const modeStore = {};
async function switchMode(key){
  if(P) modeStore[P.key] = {models:state.models, w:state.w, lock:state.lock, cards:state.cards, order:state.order};
  await useProfile(key);
  Object.assign(state, modeStore[key] || {models:[], w:{}, lock:{}, cards:{}, order:[]});
  wPanel = null;
  $("grid").replaceChildren(...state.order.map(k=>state.cards[k].card));
  if(state.order.length) buildWeightPanel();
  drawModels();
  const wb = key==="wb", cu = key==="cu";
  $("srcName").textContent = P.name; $("srcBtn").hidden=false;
  $("dropHint").textContent = wb ? "تصاویر ۹۸۴×۸۰۸ WeatherBELL را انتخاب کنید یا اینجا رها کنید"
    : cu ? "نقشه‌های هم‌قالبِ هر سایتی را انتخاب کنید یا اینجا رها کنید (PNG بهتر از JPG)"
    : "تصاویر ۷۶۰×۷۶۰ weather.us را انتخاب کنید یا اینجا رها کنید";
  $("emptyHint").textContent = wb
    ? "ECMWF، GFS، ICON، UKMO، GEM با قالب «Total Precipitation» برش ایران. مرزها پیش از محاسبه کنار گذاشته و پس از آن عیناً روی نقشه برگردانده می‌شوند."
    : cu ? "همهٔ نقشه‌های این بار باید از یک سایت و یک قالب (هم‌اندازه) باشند. هرچه تعداد نقشه‌ها بیشتر باشد، مرزها و نوشته‌ها دقیق‌تر از هم جدا می‌شوند."
    : "ECMWF، GFS، ICON، UKMO، GEM و هر مدل دیگری با همین قالب؛ مرزها و برچسب‌ها کاملاً حذف می‌شوند.";
  $("capRow").hidden = !P.useCap; $("capHint").hidden = !P.useCap; $("barRow").hidden = !wb; $("borderRow").hidden = !wb;
  $("bordersChkRow").hidden = !(wb||cu); $("tplPanel").hidden = !cu;
  ribbon($("ribbon"), cu ? (P.pal && P.pal.length ? [[0,0,0],...P.pal] : WB_PAL) : PAL);
  if(cu) drawTemplatePanel();
  detectVariable(); updateTimeUI();
  $("status").hidden = !state.models.length; if(!state.models.length){ $("stText").textContent=""; $("stBar").style.width="0"; }
  $("landing").hidden = true; $("app").hidden = false; $("dsApp").hidden = true; $("cvApp").hidden = true; $("ltApp").hidden = true; $("wnApp").hidden = true; $("cqcApp").hidden = true; if($("caApp")) $("caApp").hidden = true;
  store.set("mode", key);
}
function showLanding(){ $("landing").hidden=false; $("app").hidden=true; $("dsApp").hidden=true; $("cvApp").hidden=true; $("ltApp").hidden=true; $("wnApp").hidden=true; $("cqcApp").hidden=true; if($("caApp")) $("caApp").hidden=true; window.scrollTo(0,0); }
function openCQC(){ return showLanding();   // صفحهٔ «عملیات آماری» از سایت حذف شد (بایگانی جداگانه)
}
function openCQC_removed(){
  $("landing").hidden=true; $("app").hidden=true; $("dsApp").hidden=true; $("cvApp").hidden=true; $("ltApp").hidden=true; $("wnApp").hidden=true; $("cqcApp").hidden=false; if($("caApp")) $("caApp").hidden=true; $("srcBtn").hidden=true;
  store.set("mode","cqc"); window.scrollTo(0,0);
  cqcLoadLibs();
}
/* کتابخانه‌های خارجی فقط هنگام ورود به صفحهٔ کیفیت داده بارگذاری می‌شوند (نه هنگام شروع سایت) تا کندی یا قطعی CDN سایت را قفل نکند */
const CQC_LIBS=[
  ["XLSX",["https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js","https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"]],
  ["ExcelJS",["https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.4.0/exceljs.min.js","https://cdn.jsdelivr.net/npm/exceljs@4.4.0/dist/exceljs.min.js"]],
  ["JSZip",["https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js","https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js"]],
  ["Chart",["https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js","https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"]],
  ["pdfjsLib",["https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js","https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js"]],
  ["GeoTIFF",["https://cdn.jsdelivr.net/npm/geotiff@2.1.3/dist-browser/geotiff.js","https://unpkg.com/geotiff@2.1.3/dist-browser/geotiff.js"]],
  ["netcdfjs",["https://cdn.jsdelivr.net/npm/netcdfjs@3.0.0/dist/netcdfjs.min.js","https://unpkg.com/netcdfjs@3.0.0/dist/netcdfjs.min.js"]]
];
let _cqcP=null;
function cqcLoadOne(name,urls){
  return new Promise(res=>{
    if(window[name]) return res(true);
    let i=0;
    const next=()=>{ if(i>=urls.length) return res(false);
      const s=document.createElement("script"); s.src=urls[i++]; s.async=true;
      const to=setTimeout(()=>{ s.onload=s.onerror=null; s.remove(); next(); },15000);
      s.onload=()=>{ clearTimeout(to); res(true); }; s.onerror=()=>{ clearTimeout(to); s.remove(); next(); };
      document.head.appendChild(s); };
    next();
  });
}
function cqcLoadLibs(){
  const app=$("cqcApp"); if(!app) return Promise.resolve();
  if(_cqcP) return _cqcP;
  let bar=document.getElementById("cqcLibBar");
  if(!bar){ bar=document.createElement("div"); bar.id="cqcLibBar"; bar.className="libbar"; app.prepend(bar); }
  bar.hidden=false; bar.innerHTML='<span class="spin"></span> '+(typeof LANG!=="undefined"&&LANG==="en"?"Loading spreadsheet/chart libraries…":"در حال بارگذاری کتابخانه‌های اکسل و نمودار…");
  app.style.pointerEvents="none"; app.style.opacity=".6";
  _cqcP=Promise.all(CQC_LIBS.map(([n,u])=>cqcLoadOne(n,u))).then(r=>{
    app.style.pointerEvents=""; app.style.opacity="";
    // اگر SheetJS از اینترنت نیامد، خوانندهٔ داخلی اکسل (xlsx و xls) جایگزین می‌شود تا ورود داده کار کند
    if(!window.XLSX && typeof MSXL!=="undefined"){ window.XLSX=MSXL; r[0]=true; }
    if(r.every(Boolean)) bar.hidden=true;
    else { const bad=CQC_LIBS.filter((_,i)=>!r[i]).map(x=>x[0]).join("، ");
      bar.innerHTML=(typeof LANG!=="undefined"&&LANG==="en"?"Could not load: ":"بارگذاری نشد: ")+bad+" — "+(typeof LANG!=="undefined"&&LANG==="en"?"check internet connection and ":"اینترنت را بررسی کنید و ")+'<button class="btn" onclick="_cqcP=null;cqcLoadLibs()">'+(typeof LANG!=="undefined"&&LANG==="en"?"Retry":"تلاش دوباره")+'</button>'; }
  });
  return _cqcP;
}
document.querySelectorAll(".choice").forEach(b=>b.onclick=()=> b.dataset.mode==="on" ? openON() : b.dataset.mode==="ci" ? openCI() : b.dataset.mode==="cqc" ? openCQC() : b.dataset.mode==="ca" ? openCA() : b.dataset.mode==="ds" ? openDS() : b.dataset.mode==="cv" ? openCV() : b.dataset.mode==="lt" ? openLT() : b.dataset.mode==="wn" ? openWN() : b.dataset.wm ? openWM() : (state.wmPage=false, switchMode(b.dataset.mode)));
// صفحهٔ weathermodels: همان موتور حالت آزاد با قالب ثابت weathermodels (نوار عمودی، زمین‌مرجع و خطوط مرز از پیش برازش‌شده)
async function openWM(){ state.wmPage=true; await switchMode("cu"); store.set("mode","wm"); wmPageLabels(); }
function wmPageLabels(){ if(!state.wmPage || !P || !P.custom) return; const en=typeof LANG!=="undefined"&&LANG==="en";
  $("srcName").textContent="weathermodels";
  $("dropHint").textContent = en ? "Select or drop 1000×750 weathermodels.com maps (total precipitation or 2‑m temperature)" : "نقشه‌های ۱۰۰۰×۷۵۰ سایت weathermodels.com (بارش تجمعی یا دمای ۲ متری) را انتخاب کنید یا اینجا رها کنید";
  $("emptyHint").textContent = en ? "ECMWF, GFS, ICON, GEM, UKMO… with the same template. The vertical colorbar, map frame and geographic position are recognised automatically; the map's own borders are kept (or replaced by MetStat borders from the Borders menu)." : "ECMWF، GFS، ICON، GEM، UKMO و… با همین قالب. نوار رنگ عمودی، کادر نقشه و موقعیت جغرافیایی خودکار شناسایی می‌شود؛ مرزهای خود نقشه حفظ می‌شود (یا از منوی «مرزها» با مرز MetStat جایگزین می‌شود).";
}
$("srcBtn").onclick = showLanding;

function setStatus(t, frac){ $("status").hidden=false; $("stText").textContent=t; if(frac!==undefined) $("stBar").style.width=(frac*100)+"%"; }

const isImg=f=>(f.type||"").startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|avif)$/i.test(f.name||"");
async function readFile(f){
  const bmp = await createImageBitmap(f);
  const cv = document.createElement("canvas"); cv.width=bmp.width; cv.height=bmp.height;
  const cx = cv.getContext("2d", {willReadFrequently:true}); cx.drawImage(bmp,0,0);
  return { file:f, w:bmp.width, h:bmp.height, data:cx.getImageData(0,0,bmp.width,bmp.height).data };
}
async function addFiles(files){
  files = [...files].filter(isImg);
  if(!files.length) return;
  // WeatherBELL/weather.us: نقشه‌ای که نوار رنگش بارش نیست (دما، باد، رطوبت، شاخص‌ها…) با تشخیص خودکار قالب پردازش می‌شود
  if(P && !P.custom && !state.models.some(m=>m.ok)){
    const first=await readFile(files[0]);
    if(first.w===P.W && first.h===P.H && !checkPalette(first.data) && !(P.key==="wu" && wuVariantOf(first.data)) && !(P.key==="wb" && wbVariantOf(first.data))){
      const from=P.name; await switchMode("cu"); state.fromTpl=from;
      setStatus(`نقشهٔ غیربارشیِ ${from} شناسایی شد؛ پارامتر و اعداد نوار رنگ خودکار خوانده می‌شود`, 0.01);
      return addFiles(files); } }
  for(const f of files){
    try{
      const m = await readFile(f);
      if(P.custom){
        const ref = state.models.find(q=>q.ok);
        m.ok = !ref || (m.w===ref.w && m.h===ref.h);
        m.note = m.ok ? "" : `ابعاد ${FA(m.w)}×${FA(m.h)} با بقیه (${FA(ref.w)}×${FA(ref.h)}) فرق دارد؛ همهٔ نقشه‌های یک بار باید هم‌قالب باشند`;
        if(ref && m.ok){ try{ const a=ref.wmT!==undefined?ref.wmT:(ref.wmT=wmDetect(ref)), b=m.wmT=wmDetect(m);
          if(a && b && a.wm.id!==b.wm.id){ m.ok=false; m.note = b.wm.id==="t2m" ? "این نقشهٔ دمای ۲ متری است و نقشه‌های قبلی بارش‌اند؛ جداگانه وارد کنید (یا اول نقشه‌های قبلی را پاک کنید)" : "این نقشهٔ بارش است و نقشه‌های قبلی دما هستند؛ جداگانه وارد کنید"; } }catch(e){} }
        // tropicaltidbits: اعداد نوار رنگ هر نقشه جداگانه خوانده و مقایسه می‌شود (مثلاً CFSv2 هفتگی ±۱۴۰ با ماهانه ±۵۰۰ هم‌رنگ است)
        if(ref){ try{ const Tr=ref.ttT||(ref.ttT=ttDetect(ref)), Tm=m.ttT||(m.ttT=ttDetect(m));
          if(Tr && Tm){ if(!CV_OCR_T) await cvOcrFonts(); if(ref.ttE===undefined){ const r=ttBarEdges(ref,Tr); ref.ttE=r?parseEdges(r.txt):null; }
            const r2=ttBarEdges(m,Tm), e2=r2?parseEdges(r2.txt):null, e1=ref.ttE;
            const fin=a=>a?a.filter(v=>Number.isFinite(v)&&v!==0):null, a1=fin(e1), a2=fin(e2);
            if(a1 && a2 && (a1.length!==a2.length || a1.some((v,k)=>Math.abs(v-a2[k])>1e-6))){ m.ok=false; m.rects=[]; m.name=uniqueName(guessModelName(f.name));
              m.note=`اعداد نوار رنگ این نقشه (${FA(a2[0])} تا ${FA(a2[a2.length-1])}) با نقشهٔ اول (${FA(a1[0])} تا ${FA(a1[a1.length-1])}) فرق دارد؛ جداگانه وارد کنید`;
              state.models.push(m); continue; } } }catch(e){ console.warn("tt compare", e); } }
        if(!m.ok){ let r=null; try{ r=ttWarpTo(m, ref); }catch(e){ console.warn(e); }
          if(r && r.sameBar){ m.orig={w:m.w,h:m.h}; m.data=r.data; m.w=ref.w; m.h=ref.h; m.ok=true; m.note=`tropicaltidbits ${FA(m.orig.w)}×${FA(m.orig.h)} → با مختصات جغرافیایی روی کادر نقشهٔ اول منتقل شد (زوم خاورمیانه)`; }
          else if(r) m.note="نوار رنگ این نقشه با نقشهٔ اول فرق دارد (پارامتر یا مقیاس دیگر)؛ جداگانه وارد کنید"; }
        m.rects = []; { let nm=null; try{ nm=wmModelName(m); }catch(e){} const g=guessModelName(f.name);
          if(!nm && /^[A-Z][A-Za-z0-9-]+$/.test(g) && g.length<=10){ try{ if(wmTitleBits(m)) wmLearnName(m,g); }catch(e){} }
          m.name = uniqueName(nm || g); }
        state.models.push(m); P.dirty = true; continue;
      }
      if(P.key==="wb" && m.w===P.W && m.h===P.H && !state.models.some(q=>q.ok)){
        const v=wbVariantOf(m.data)||"precip"; if(await setWbVariant(v)) state.models.forEach(q=>{ q.mm=null; q.hit={}; }); }
      if(P.key==="wu" && m.w===P.W && m.h===P.H){
        const v=wuVariantOf(m.data);
        if(v && !state.models.some(q=>q.ok) && await setWuVariant(v)) state.models.forEach(q=>{ q.mm=null; q.hit={}; });
      }
      m.ok = m.w===P.W && m.h===P.H;
      if(m.ok && P.key==="wu"){ const v=wuVariantOf(m.data), cur=P.variant||"acc";
        if(v && v!==cur && (v==="h1"||cur==="h1")){ m.ok=false; m.rects=[]; m.name=f.name;
          m.note = v==="h1" ? "این نقشه بارش ۱ ساعته است و نوار رنگش با نقشه‌های قبلی فرق دارد؛ نقشه‌های ۱ ساعته را جداگانه وارد کنید" : "نوار رنگ این نقشه با نقشه‌های ۱ ساعتهٔ قبلی فرق دارد؛ جداگانه وارد کنید";
          state.models.push(m); continue; } }
      const other = Object.values(PROFILES).find(q=>q!==P && q.W===m.w && q.H===m.h);
      m.note = m.ok ? (checkPalette(m.data) ? "" : "نوار رنگ با نقشهٔ بارش این قالب فرق دارد؛ برای دما یا نقشه‌های دیگر از حالت «آزاد» استفاده کنید")
             : (other ? `این نقشهٔ ${other.name} است؛ از بالای صفحه منبع را عوض کنید` : `اندازه ${FA(m.w)}×${FA(m.h)} پشتیبانی نمی‌شود`);
      m.rects = m.ok ? P.invalid(m.data) : [];
      m.name = m.ok ? (recognize(m.data) || f.name.replace(/\.[^.]+$/,"")) : f.name;
      state.models.push(m);
    }catch(e){ console.error(e); }
  }
  for(const m of state.models) if(m.ok && m.times===undefined){ try{ m.times = readTimes(m); }catch(e){ console.error(e); m.times=null; } }
  if(P && P.key==="wu"){ const hs=state.models.filter(m=>m.ok).map(wuHours); P.hours = (P.variant&&P.variant!=="acc" && hs.length && hs.every(h=>h&&h===hs[0])) ? hs[0] : null; }
  syncWeights(true); drawModels(); detectRegion("files"); detectVariable(); updateTimeUI(); schedule();
}
function drawModels(){
  const box=$("models"); box.innerHTML="";
  state.models.forEach((m,idx)=>{
    const row=document.createElement("div"); row.className="m";
    const nm=document.createElement("div"); nm.className="nm";
    const inp=document.createElement("input"); inp.value=m.name; inp.setAttribute("aria-label","نام مدل");
    inp.onchange=()=>{ const old=m.name; m.name=inp.value.trim()||m.name; if(P && P.custom && P.T && P.T.wm) try{ wmLearnName(m, m.name.replace(/\s*\(\d+\)$/,"")); }catch(e){} if(old!==m.name){ state.w[m.name]=state.w[old]; delete state.w[old]; } syncWeights(false); schedule(); };
    const sm=document.createElement("small");
    sm.textContent = m.note || (m.validFrac ? `${FA(Math.round(m.validFrac*100))}٪ پیکسل‌ها داده، بقیه مرز و برچسب` : "آمادهٔ پردازش");
    if(m.note) sm.className="bad";
    nm.append(inp, sm);
    const wt=document.createElement("span"); wt.className="wt";
    wt.textContent = m.ok ? `وزن ${FA(round1(state.w[m.name]??0))}٪` : "";
    const del=document.createElement("button"); del.className="del"; del.type="button"; del.textContent="×"; del.title="حذف "+m.name; del.setAttribute("aria-label","حذف "+m.name);
    del.onclick=()=>{ state.models.splice(idx,1); if(P.custom){ P.dirty=true; const ref=state.models[0]; state.models.forEach(q=>{ q.ok = !!ref && q.w===ref.w && q.h===ref.h; if(q.ok) q.note=""; }); } syncWeights(true); drawModels(); updateTimeUI(); schedule(); };
    row.append(nm, wt, del); box.append(row);
  });
  $("empty").hidden = state.models.length>0;
  try{ mtSync(); }catch(e){ console.warn(e); }
}

/* ---------- وزن‌های درصدی (جمع همیشه ۱۰۰٪) ---------- */
const round1 = v => Math.round((v||0)*10)/10;
const okNames = () => [...new Set(state.models.filter(m=>m.ok).map(m=>m.name))];
function fixSum(names, keep){
  // گرد کردن به یک رقم اعشار و انداختن باقی‌مانده روی بزرگ‌ترین وزن (غیر از وزنی که کاربر دارد تغییر می‌دهد)
  names.forEach(n=>state.w[n]=round1(state.w[n]));
  const diff = round1(100 - names.reduce((a,n)=>a+state.w[n],0));
  if(diff){ const pool=names.filter(n=>n!==keep); const tgt=(pool.length?pool:names).reduce((a,n)=>state.w[n]>state.w[a]?n:a, (pool.length?pool:names)[0]);
    state.w[tgt]=round1(Math.max(0,state.w[tgt]+diff)); }
}
function syncWeights(setChanged){
  const names = okNames(); if(!names.length) return;
  if(setChanged) state.lock = {};
  const known = names.filter(n=>savedW[n]!==undefined || state.w[n]!==undefined);
  if(setChanged && known.length===names.length){
    names.forEach(n=>state.w[n] = state.w[n] ?? savedW[n]);
  } else if(setChanged){
    names.forEach(n=>state.w[n]=100/names.length);
  }
  const s = names.reduce((a,n)=>a+(state.w[n]||0),0);
  if(s<=0) names.forEach(n=>state.w[n]=100/names.length); else names.forEach(n=>state.w[n]=(state.w[n]||0)*100/s);
  fixSum(names);
  names.forEach(n=>savedW[n]=state.w[n]); store.set("wpct", savedW);
  applyWeights(); buildWeightPanel();
}
/* وزن دستی: مدلی که کاربر وزنش را وارد می‌کند «ثابت» می‌شود؛ باقی‌ماندهٔ ۱۰۰٪ فقط بین مدل‌های «خودکار» تقسیم می‌شود.
   اگر همهٔ مدل‌ها ثابت شوند، قدیمی‌ترینِ ویرایش‌شده دوباره خودکار می‌شود تا جمع همیشه ۱۰۰٪ بماند. */
state.lock = {}; let lockSeq = 0;
function autoFill(names){
  const locked = names.filter(n=>state.lock[n]), auto = names.filter(n=>!state.lock[n]);
  const used = locked.reduce((a,n)=>a+state.w[n],0), rest = Math.max(0, 100-used);
  auto.forEach(n=>state.w[n]=rest/auto.length);
  names.forEach(n=>state.w[n]=round1(state.w[n]));
  const diff = round1(100 - names.reduce((a,n)=>a+state.w[n],0));
  if(diff && auto.length){ const last=auto[auto.length-1]; state.w[last]=round1(Math.max(0,state.w[last]+diff)); }
}
function maxFor(name){
  const names=okNames(); if(names.length<2) return 100;
  return round1(100 - names.filter(n=>n!==name && state.lock[n]).reduce((a,n)=>a+state.w[n],0));
}
function setWeight(name, v){
  const names = okNames();
  if(names.length<2){ state.w[name]=100; }
  else {
    state.lock[name] = ++lockSeq;
    const others = names.filter(n=>n!==name);
    if(others.every(n=>state.lock[n])){                     // دست‌کم یک مدل باید خودکار بماند
      const oldest = others.reduce((a,n)=>state.lock[n]<state.lock[a]?n:a, others[0]);
      delete state.lock[oldest];
    }
    state.w[name] = Math.min(maxFor(name), Math.max(0, round1(+v||0)));
    autoFill(names);
  }
  names.forEach(n=>savedW[n]=state.w[n]); store.set("wpct", savedW);
  applyWeights(); refreshWeightPanel(name);
}
function unlock(name){ delete state.lock[name]; const names=okNames(); autoFill(names); names.forEach(n=>savedW[n]=state.w[n]); store.set("wpct",savedW); applyWeights(); refreshWeightPanel(); }
function equalWeights(){ state.lock={}; const names=okNames(); names.forEach(n=>state.w[n]=100/names.length); autoFill(names); names.forEach(n=>savedW[n]=state.w[n]); store.set("wpct",savedW); applyWeights(); refreshWeightPanel(); }
function applyWeights(){ state.models.forEach(m=>m.weight = m.ok ? (state.w[m.name]||0) : 0); }
state.link = store.get("linkW", true);
const linked = () => state.link;

let wPanel = null;
function buildWeightPanel(){
  const names = okNames();
  wPanel = document.createElement("div"); wPanel.className="weights";
  const head = document.createElement("div"); head.className="wh";
  head.innerHTML = `<span>وزن مدل‌ها در میانگین</span><b class="sum"></b>`;
  const eq = document.createElement("button"); eq.type="button"; eq.className="btn sm"; eq.textContent="تقسیم مساوی"; eq.onclick=()=>{ equalWeights(); onWeights(); };
  head.append(eq); wPanel.append(head);
  const hn=document.createElement("p"); hn.className="hint"; hn.style.margin="0";
  hn.textContent="وزن هر مدل را که وارد کنید ثابت می‌ماند؛ باقی‌ماندهٔ ۱۰۰٪ بین مدل‌های «خودکار» تقسیم می‌شود.";
  wPanel.append(hn);
  names.forEach(n=>{
    const r=document.createElement("div"); r.className="wr"; r.dataset.name=n;
    const lb=document.createElement("span"); lb.className="wn"; lb.textContent=n;
    const rg=document.createElement("input"); rg.type="range"; rg.min="0"; rg.max="100"; rg.step="0.5"; rg.setAttribute("aria-label","وزن "+n);
    const nb=document.createElement("input"); nb.type="number"; nb.min="0"; nb.max="100"; nb.step="0.1"; nb.setAttribute("aria-label","درصد وزن "+n);
    const pc=document.createElement("span"); pc.className="pc"; pc.textContent="٪";
    rg.oninput=()=>{ setWeight(n, rg.value); onWeights(); };
    nb.onchange=()=>{ setWeight(n, nb.value); onWeights(); };
    const st=document.createElement("button"); st.type="button"; st.className="lk";
    st.onclick=()=>{ if(state.lock[n]){ unlock(n); onWeights(); } };
    r.append(lb, rg, nb, pc, st); wPanel.append(r);
  });
  const lk=document.createElement("label"); lk.className="wl";
  lk.innerHTML=`<input type="checkbox"> همین وزن‌ها در نقشه‌های توافق هم اعمال شود`;
  wPanel.append(lk);
  const cb=lk.querySelector("input"); cb.checked = state.link;
  cb.onchange=()=>{ state.link=cb.checked; store.set("linkW", cb.checked); schedule(null, 150, "prob"); };
  refreshWeightPanel();
  const c = state.cards.mean; if(c) c.slot.replaceChildren(wPanel);
}
function refreshWeightPanel(skip){
  if(!wPanel) return;
  const many = okNames().length>1;
  wPanel.querySelectorAll(".wr").forEach(r=>{
    const n=r.dataset.name, v=state.w[n]??0, lk=!!state.lock[n];
    const [rg,nb]=r.querySelectorAll("input"), st=r.querySelector(".lk");
    if(n!==skip || document.activeElement!==rg) rg.value=v;
    if(document.activeElement!==nb || n===skip) nb.value=v;
    const mx=maxFor(n); nb.max=mx; rg.style.setProperty("--p", v+"%"); rg.style.setProperty("--m", mx+"%");
    r.classList.toggle("auto", !lk && many);
    st.textContent = !many ? "" : (lk ? "دستی" : "خودکار");
    st.title = lk ? "برگرداندن به خودکار" : "با تغییر مدل‌های دستی، خودکار پر می‌شود";
    st.disabled = !lk;
  });
  const s = okNames().reduce((a,n)=>a+(state.w[n]||0),0);
  wPanel.querySelector(".sum").textContent = `جمع: ${FA(round1(s))}٪`;
  document.querySelectorAll("#models .m").forEach((row,i)=>{ const m=state.models[i]; if(m&&m.ok) row.querySelector(".wt").textContent=`وزن ${FA(round1(state.w[m.name]??0))}٪`; });
}
function onWeights(){ schedule(null, 60, "mean"); if(linked()) schedule(null, 450, "prob"); }

