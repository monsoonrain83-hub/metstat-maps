/* ---------- رابط کاربری ---------- */


/* ---------- رابط کاربری ---------- */
function dsStatus(t, frac){ $("dsStatus").hidden=false; $("dsStText").textContent=t; if(frac!==undefined) $("dsStBar").style.width=(frac*100)+"%"; }
const DS_PROF = {};
// قالب هر نقشه: WeatherBELL، weather.us یا تشخیص خودکار (هر سایت و هر ابعادی)
async function dsTemplateOf(m){
  if(m.w===984 && m.h===808){ await useProfile("wb"); if(checkPalette(m.data)) return {prof:PROFILES.wb, tpl:[PROFILES.wb.ax,PROFILES.wb.bx,PROFILES.wb.ay,PROFILES.wb.by], site:"WeatherBELL"}; }
  if(m.w===760 && m.h===760){ await useProfile("wu"); if(checkPalette(m.data)) return {prof:PROFILES.wu, tpl:[PROFILES.wu.ax,PROFILES.wu.bx,PROFILES.wu.ay,PROFILES.wu.by], site:"weather.us"}; }
  const T=detectTemplate([m]);
  const key=`dsc_${T.W}x${T.H}_${T.fx0}_${T.fy0}_${T.fx1}_${T.fy1}_${T.colors.length}`;
  let prof=DS_PROF[key];
  if(!prof){
    prof={key, name:"آزاد", custom:true, sigs:null, topStrip:false, useCap:false, keepBorders:true, invalid(){ return this.inv||[]; },
      W:T.W, H:T.H, fx0:T.fx0, fx1:T.fx1, fy0:T.fy0, fy1:T.fy1, bg:T.bg, bgSep:T.bgSep, barStart:T.bgSep?1:0, segCenters:T.segCenters, segs:T.segs, bar:T.bar, inv:T.inv, fp:T.fp, tol:T.tol, T,
      pal:(T.bgSep?[T.bg]:[]).concat(T.colors), edges:null, models:[], ax:0, bx:1, ay:0, by:1};
    if(!T.bgSep){ let bi=0, bd=1e9; T.colors.forEach((c,k)=>{ const dd=cdist(c,T.bg); if(dd<bd){ bd=dd; bi=k; } }); prof.bgIdx=bi; } else prof.bgIdx=0;
    const gs=guessScale(T.colors, T); if(gs) dsSetEdges(prof, gs.edges); prof.scaleName=gs?(gs.kind==="temp"?"دما":gs.name):null; if(gs&&gs.kind==="temp") prof.kind="temp";
    DS_PROF[key]=prof; PROFILES[key]=prof;
  }
  prof.models.push(m); prof.staticDirty=true;
  return {prof, tpl:null, site: prof.scaleName ? `قالب آزاد (نوار رنگ ${prof.scaleName})` : "قالب آزاد"};
}
function dsSetEdges(prof, txt){
  const v=parseEdges(txt), K=prof.T.colors.length;
  if(!v || v.length!==K+1 || v.some((x,k)=>k && !(x>v[k-1]))) return `${FA(K+1)} عدد صعودی لازم است: حد پایین هر ${FA(K)} رنگ و در آخر حد بالا (یا +)`;
  prof.edges = prof.T.bgSep ? [0, ...v] : v; prof.edgesTxt=txt; prof.staticDirty=true; return "";
}
function dsDrawList(){
  const box=$("dsList"); box.innerHTML="";
  ds.maps.forEach((m,idx)=>{
    const row=document.createElement("div"); row.className="m";
    const nm=document.createElement("div"); nm.className="nm";
    const inp=document.createElement("input"); inp.value=m.name; inp.setAttribute("aria-label","نام مدل");
    inp.onchange=()=>{ m.name=inp.value.trim()||m.name; if(m.card) m.card.hd.querySelector("h3").textContent=m.name+" — اصلاح توپوگرافی"; };
    const sm=document.createElement("small"); sm.textContent=m.note||""; if(m.bad||m.warn) sm.className="bad";
    nm.append(inp, sm);
    if(m.prof && m.prof.custom && !m.prof.edges){
      const e=document.createElement("input"); e.dir="ltr"; e.placeholder=`${FA(m.prof.T.colors.length+1)} عدد نوار رنگ، مثلاً 0, 1, 2, 5, …, +`; e.value=m.prof.edgesTxt||"";
      e.style.cssText="font:14px var(--body);border:1px solid var(--warn);border-radius:6px;padding:2px 6px;margin-top:4px;text-align:left";
      e.onchange=()=>{ const msg=dsSetEdges(m.prof, e.value); if(msg){ sm.textContent=msg; sm.className="bad"; return; } m.prof.models.forEach(q=>{ q.note=q.siteNote; q.result=null; }); dsDrawList(); dsSchedule(50); };
      nm.append(e);
    }
    const rs=document.createElement("label"); rs.className="dsres"; rs.textContent="°";
    const ri=document.createElement("input"); ri.type="number"; ri.step="0.025"; ri.min="0.02"; ri.max="1"; ri.value=m.res; ri.title="رزولوشن مدل (درجه)"; ri.setAttribute("aria-label","رزولوشن مدل به درجه");
    ri.onchange=()=>{ const v=parseFloat(ri.value); if(v>0){ m.res=v; m.result=null; dsSchedule(100); } };
    // فهرست کوچک رزولوشن مدل‌های رایج (تشخیص خودکار از نام مدل؛ قابل تغییر)
    const rsel=document.createElement("select"); rsel.className="dsresSel"; rsel.title="رزولوشن مدل"; rsel.setAttribute("aria-label","رزولوشن مدل");
    const RES_OPTS=[[0.1,"ECMWF / UKMO / ARPEGE ۰٫۱°"],[0.117,"ACCESS-G ۰٫۱۱۷°"],[0.125,"GFS / ICON ۰٫۱۲۵°"],[0.15,"GEM ۰٫۱۵°"],[0.25,"GFS / AIFS ۰٫۲۵°"],[0.0625,"ICON-EU ۰٫۰۶۲۵°"],[0.025,"مدل منطقه‌ای ۰٫۰۲۵°"]];
    rsel.replaceChildren(...RES_OPTS.map(([v,l])=>{ const o=document.createElement("option"); o.value=v; o.textContent=l; return o; }), Object.assign(document.createElement("option"),{value:"c",textContent:"دلخواه…"}));
    rsel.value = RES_OPTS.some(([v])=>Math.abs(v-m.res)<1e-6) ? String(RES_OPTS.find(([v])=>Math.abs(v-m.res)<1e-6)[0]) : "c"; ri.hidden = rsel.value!=="c";
    rsel.onchange=()=>{ if(rsel.value==="c"){ ri.hidden=false; ri.focus(); return; } ri.hidden=true; ri.value=rsel.value; m.res=parseFloat(rsel.value); m.result=null; dsSchedule(100); };
    rs.prepend(ri); rs.prepend(rsel); if(m.bad) rs.hidden=true;
    const del=document.createElement("button"); del.className="del"; del.type="button"; del.textContent="×"; del.setAttribute("aria-label","حذف "+m.name);
    del.onclick=()=>{ ds.maps.splice(idx,1); if(m.prof && m.prof.models){ m.prof.models=m.prof.models.filter(q=>q!==m); m.prof.staticDirty=true; } if(m.card) m.card.card.remove(); dsDrawList(); };
    row.append(nm, rs, del); box.append(row);
  });
  $("dsEmpty").hidden = ds.maps.length>0;
  if(!ds.maps.length) $("dsStatus").hidden=true;
}
async function dsAdd(files){
  files=[...files].filter(isImg); if(!files.length) return;
  const prev = P ? P.key : null;
  for(const f of files){
    let m;
    try{
      dsStatus(`خواندن ${f.name}…`, 0.02); await tick();
      m=await readFile(f);
      const t=await dsTemplateOf(m);
      m.prof=t.prof; m.tplGeo=t.tpl; m.siteName=t.site;
      if(t.prof.key==="wu" || (m.w===760 && m.h===760)){ try{ if(!CV_OCR_T) await cvOcrFonts(); m.zone = wuZoomOCR({data:m.data, w:m.w, h:m.h, file:f}) || wuSigRegion(m.data) || null; }catch(e){ m.zone=null; } }
      let nm=null; if(t.prof.sigs){ await useProfile(t.prof.key); nm=recognize(m.data); }
      nm = nm || guessModelName(f.name);
      m.name=nm; m.res=DS_RES[(nm||"").toUpperCase()] || 0.25;
      m.kind = t.prof.kind==="temp" ? "temp" : "precip";
      if(m.kind!=="temp" && t.prof.custom){ try{ if(!CV_OCR_T) await cvOcrFonts(); const bt=cvTitleType({...m, prof:t.prof}); if(bt && ((bt.vb&&bt.vb.temp>=0.62) || bt.k==="t500") && !(bt.vb&&bt.vb.precip>=0.66)){ m.kind="temp"; t.prof.kind="temp"; } }catch(e){} }
      const hi=grHintFromName(f.name); m.hint = hi>0 ? {lon:IR_PROV[hi][1], lat:IR_PROV[hi][2], r:1.8, i:hi} : null;
      m.siteNote=`${t.site} · ${FA(m.w)}×${FA(m.h)} · رزولوشن مدل:`;
      m.note = (t.prof.custom && !t.prof.edges) ? "اعداد نوار رنگ را وارد کنید (یک بار برای این قالب)" : m.siteNote;
      try{ const tt=readTimes(m); if(tt && tt.start && tt.end){ const tz=tt.offset===0?" UTC":(LANG==="en"?" Iran time":" به وقت ایران"); m.period=`${persianDT(tt.start,tt.offset)} تا ${persianDT(tt.end,tt.offset)}${tz}`; } }catch(e){}
      ds.maps.push(m);
    }catch(e){ console.error(e); ds.maps.push({file:f, name:f.name, bad:true, note:"قالب نقشه تشخیص داده نشد: "+e.message}); }
  }
  if(prev) await useProfile(prev); else P=undefined;
  dsDrawList(); try{ wuzSync(); }catch(e){} dsSchedule(50);
}
function dsSchedule(delay=500){ clearTimeout(ds.timer); ds.timer=setTimeout(dsRunAll, delay); }
function dsMakeCard(m){
  const card=document.createElement("article"); card.className="card wide";
  const hd=document.createElement("header"); hd.innerHTML=`<h3></h3><div class="sub"></div>`;
  hd.querySelector("h3").textContent=m.name+" — اصلاح توپوگرافی";
  const body=document.createElement("div"); body.className="split";
  const left=document.createElement("div");
  const view=document.createElement("div"); view.className="dsview";
  const img=new Image(); img.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=img.src; d.showModal(); };
  const views=[["out","اصلاح‌شده"],["in","ورودی"],["geo","مکان"],["factor","ضریب اصلاح"],["diff","اختلاف"],["elev","ارتفاع"]];
  const o={card, hd, img, view, srcs:{}, cur:"out", m};
  views.forEach(([k,t])=>{ const b=document.createElement("button"); b.className="btn sm"; b.type="button"; b.textContent=t; b.dataset.v=k; b.setAttribute("aria-pressed", k==="out");
    b.onclick=()=>{ o.cur=k; dsShow(o); }; view.append(b); });
  const sx=document.createElement("div"); sx.className="stats";
  const dl=document.createElement("div"); dl.className="dl";
  left.append(view, img, sx, dl);
  const side=document.createElement("div"); side.className="slot dsside";
  const geo=document.createElement("div"); geo.className="dsgeo";
  const chart=document.createElement("div"), rel=document.createElement("div"); rel.className="dsrel";
  const rep=document.createElement("details"); rep.className="dsrep"; rep.innerHTML="<summary>گزارش کامل پردازش</summary><pre></pre>";
  side.append(geo, rel, chart, rep);
  body.append(left, side); card.append(hd, body);
  Object.assign(o, {sx, dl, chart, rel, rep, geo});
  dsGeoBox(o);
  return o;
}
function dsGeoBox(o){
  const m=o.m, box=o.geo; box.innerHTML="";
  const g=m.geo||m.geoTry, b=g?grBounds(g,m.prof):null;
  const p=document.createElement("div"); p.className="dsrel";
  const where = b ? `طول ${FA(b.W.toFixed(2))} تا ${FA(b.E.toFixed(2))}، عرض ${FA(b.S.toFixed(2))} تا ${FA(b.N.toFixed(2))}` : "";
  p.innerHTML = m.geo ? `مکان نقشه: <b>${m.geoSrc}</b> — ${where}<br><span class="hint" style="margin:0">در نمای «مکان»، مرزهای مرجع (قرمز) باید روی مرزهای خود نقشه بیفتند.</span>`
    : `<span style="color:var(--warn)">${m.geoMsg||"مکان نقشه پیدا نشد"}.</span> استان یا محدودهٔ نقشه را انتخاب کنید یا مختصات کادر را وارد کنید.${b?`<br><span class="hint" style="margin:0">بهترین حدس: ${where}</span>`:""}`;
  box.append(p);
  const row=document.createElement("div"); row.style.cssText="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:6px";
  const sel=document.createElement("select"); sel.className="btn sm"; sel.innerHTML=`<option value="-1">محدودهٔ نقشه…</option>`+IR_PROV.map((p,i)=>`<option value="${i}">${p[0]}</option>`).join("");
  if(m.hint && m.hint.i!==undefined) sel.value=String(m.hint.i);
  sel.onchange=()=>{ const i=+sel.value; m.hint = i>=0 ? {lon:IR_PROV[i][1], lat:IR_PROV[i][2], r:IR_PROV[i][3]||1.8, i} : null; m.manual=null; dsRelocate(m); };
  const again=document.createElement("button"); again.className="btn sm"; again.type="button"; again.textContent="جست‌وجوی دوباره"; again.onclick=()=>{ m.manual=null; dsRelocate(m); };
  row.append(sel, again);
  if(m.geo){ const ok=document.createElement("button"); ok.className="btn sm"; ok.type="button"; ok.textContent="مکان درست است (به خاطر بسپار)";
    ok.onclick=()=>{ grLearn({W:m.w,H:m.h,prof:m.prof,geo:m.geo,sc:m.geoScore}); ok.textContent="ذخیره شد ✓"; ok.disabled=true; }; row.append(ok); }
  box.append(row);
  const det=document.createElement("details"); det.innerHTML=`<summary class="hint">ورود دستی محدودهٔ کادر نقشه (درجه)</summary>`;
  const f=document.createElement("div"); f.className="f"; f.style.marginTop="6px";
  const mk=(id,lab,val)=>`<label>${lab}<input type="number" step="any" data-k="${id}" value="${val!==undefined?(+val).toFixed(3):""}"></label>`;
  f.innerHTML=`<div class="row2">${mk("W","غرب",b&&b.W)}${mk("E","شرق",b&&b.E)}</div><div class="row2">${mk("S","جنوب",b&&b.S)}${mk("N","شمال",b&&b.N)}</div>
    <label class="chk"><input type="checkbox" data-k="ref" checked> پس از آن، تطبیق دقیق خودکار با مرزها</label>`;
  const ap=document.createElement("button"); ap.className="btn sm"; ap.type="button"; ap.textContent="اعمال";
  ap.onclick=()=>{ const v={}; f.querySelectorAll("input[type=number]").forEach(i=>v[i.dataset.k]=parseFloat(i.value));
    if(!(v.E>v.W && v.N>v.S)){ alert("محدوده درست نیست"); return; }
    const pr=m.prof, bx=(pr.fx1-pr.fx0)/(v.E-v.W), by=(pr.fy1-pr.fy0)/(v.S-v.N);
    m.manual=[pr.fx0-bx*v.W, bx, pr.fy0-by*v.N, by]; m.manualRefine=f.querySelector("[data-k=ref]").checked; dsRelocate(m); };
  f.append(ap); det.append(f); box.append(det);
}
function dsRelocate(m){ m.geo=null; m.geoTry=null; m.geoDone=false; m.result=null; dsSchedule(30); }
function dsShow(o){
  const m=o.m, r=o.r;
  if((o.cur==="factor"||o.cur==="diff"||o.cur==="elev"||o.cur==="out") && !r) o.cur = m.geo||m.geoTry ? "geo" : "in";
  if(!o.srcs[o.cur]){
    const cv = o.cur==="out" ? r.cv : o.cur==="in" ? (()=>{ const c=document.createElement("canvas"); c.width=m.w; c.height=m.h; c.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(m.data), m.w, m.h),0,0); return c; })()
      : o.cur==="geo" ? dsGeoView(m) : dsFieldView(r, o.cur);
    o.srcs[o.cur]=cv.toDataURL("image/png"); if(o.cur!=="out") o["cv_"+o.cur]=cv;
  }
  o.img.src=o.srcs[o.cur];
  o.view.querySelectorAll("button").forEach(b=>{ b.setAttribute("aria-pressed", b.dataset.v===o.cur); b.disabled = !r && !["in","geo"].includes(b.dataset.v); });
}
function dsFillPending(o){
  const m=o.m; o.r=null; o.srcs={};
  o.hd.querySelector(".sub").textContent=[m.siteName, m.period].filter(Boolean).join(" · ");
  o.sx.innerHTML=""; o.dl.replaceChildren(); o.rel.innerHTML=""; o.chart.replaceChildren(); o.rep.querySelector("pre").textContent="";
  o.cur = m.geoTry ? "geo" : "in"; dsGeoBox(o); dsShow(o);
}
function dsFill(o, r){
  if(r.isTemp) return dsFillTemp(o, r);
  o.r=r; o.srcs={}; o.cur="out";
  const s=r.stats, rel=r.rel||{};
  o.hd.querySelector("h3").textContent=r.m.name+" — اصلاح توپوگرافی";
  o.hd.querySelector(".sub").textContent=[r.m.siteName, r.m.period].filter(Boolean).join(" · ");
  o.img.alt="نقشهٔ بارش اصلاح‌شده با DEM — "+r.m.name;
  dsGeoBox(o); dsShow(o);
  o.sx.innerHTML=`<span>ضریب (۵ تا ۹۵٪)<b>${fmt(s.fP05,2)} تا ${fmt(s.fP95,2)}</b></span><span>بیشینه<b>${fmt(s.before.max||0)} ← ${fmt(s.after.max||0)} mm</b></span><span>نسبت بارش کل<b>${fmt(s.ratio,3)}</b></span><span>پیکسل‌های تغییرکرده<b>${FA(s.changed)}</b></span>`;
  const zline = rel.key==="peak" ? `ارتفاع بیشینهٔ پاسخ: <b>${FA(Math.round(rel.zmax))} متر</b>` : rel.key==="u" ? `کمینهٔ پاسخ در حدود <b>${FA(Math.round(rel.zmin))} متر</b>؛ بیشینهٔ درونی ندارد` : rel.sig ? "بیشینهٔ درونی ندارد" : "اثر معنادار ارتفاع دیده نشد؛ اصلاح ارتفاعی صفر شد";
  const loc=r.tiles.filter(t=>t.used==="local"), peaks=loc.filter(t=>t.rel.key==="peak").map(t=>t.rel.zmax);
  const pk = peaks.length && LANG==="en" ? (Math.round(Math.min(...peaks))===Math.round(Math.max(...peaks)) ? `; local maximum at <b>${Math.round(peaks[0])} m</b>` : `; local maximum between <b>${Math.round(Math.min(...peaks))} and ${Math.round(Math.max(...peaks))} m</b>`) : peaks.length ? (Math.round(Math.min(...peaks))===Math.round(Math.max(...peaks)) ? `؛ بیشینهٔ محلی در <b>${FA(Math.round(peaks[0]))} متر</b>` : `؛ بیشینهٔ محلی بین <b>${FA(Math.round(Math.min(...peaks)))} تا ${FA(Math.round(Math.max(...peaks)))} متر</b>`) : "";
  o.rel.innerHTML = r.G ? `رابطهٔ کلی: <b>${rel.type}</b><br>${zline}<br>رابطهٔ محلی: ${FA(loc.length)} پنجره با منحنی خودش${pk}<br>شیب و جهت دامنه: ${r.expo.sig ? `دامنه‌های رو به <b>${FA(Math.round(r.expo.facing))}°</b> مرطوب‌ترند` : "اثر معنادار ندارد"}${r.warns.length?`<br><span style="color:var(--warn)">${r.warns.join("<br>")}</span>`:""}`
    : `<span style="color:var(--warn)">${r.warns.join("<br>")}</span>`;
  o.chart.replaceChildren(dsChart(r));
  let AS=null; try{ AS=dsAreaStats(r); }catch(e){ console.warn("dsAreaStats",e); } if(AS) o.rel.insertAdjacentHTML("beforeend", AS.html);
  o.rep.querySelector("pre").textContent=dsReport(r)+(AS?"\n"+AS.txt+"\n":"");
  const base=`${(r.m.name||"model").replace(/[^A-Za-z0-9]+/g,"")||"map"}_dem_corrected`;
  const mk=(label, ext, make)=>{ const b=document.createElement("button"); b.className="btn"; b.type="button"; b.textContent=label;
    b.onclick=async()=>{ b.disabled=true; await tick(); try{ const blob=await make(); const u=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=u; a.download=base+ext; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u), 4000); }catch(e){ console.error(e); } b.disabled=false; };
    return b; };
  const png=cv=>new Promise(res=>cv.toBlob(res,"image/png"));
  o.dl.replaceChildren(
    mk("نقشهٔ اصلاح‌شده PNG", ".png", ()=>png(r.cv)),
    mk("ضریب اصلاح PNG", "_factor.png", ()=>png(o.cv_factor || dsFieldView(r,"factor"))),
    mk("NetCDF", ".nc", ()=>dsNetCDF(r, [["title",`${r.m.name} terrain-corrected precipitation`],["source",r.m.file.name],["method","terrain-aware statistical downscaling: GAM (P-spline, GCV) elevation/exposure response, bounded multiplicative correction, NWP-cell means conserved"],["georeference",`${r.m.geoSrc}; x = ${r.m.geo[0].toFixed(3)} + ${r.m.geo[1].toFixed(4)}*lon, y = ${r.m.geo[2].toFixed(3)} + ${r.m.geo[3].toFixed(4)}*lat`],["dem",ds.dem.label],["relationship",rel.type||""],["disclaimer","statistical downscaling without observations; improvement not verified"],["Conventions","CF-1.8"]])),
    mk("CSV", ".csv", ()=>dsCSV(r)),
    mk("گزارش TXT", "_report.txt", ()=>new Blob([trText(dsReport(r))],{type:"text/plain;charset=utf-8"})),
    mk("نمودار PNG", "_relationship.png", ()=>png(o.chart.querySelector("canvas")))
  );
}
function dsFillTemp(o, r){
  o.r=r; o.srcs={}; o.cur="out"; const s=r.stats;
  o.hd.querySelector("h3").textContent=r.m.name+" — اصلاح دما با ارتفاع";
  o.hd.querySelector(".sub").textContent=[r.m.siteName, r.m.period].filter(Boolean).join(" · ");
  o.img.alt="نقشهٔ دمای اصلاح‌شده با ارتفاع — "+r.m.name;
  o.view.querySelectorAll("button").forEach(b=>{ if(b.dataset.v==="factor") b.textContent="آهنگ کاهش دما"; });
  dsGeoBox(o); dsShow(o);
  o.sx.innerHTML=`<span>آهنگ کاهش کلی<b>${fmt(r.Gglob,1)} °C/km</b></span><span>تغییر دما (۵ تا ۹۵٪)<b>${fmt(s.dP05,1)} تا ${fmt(s.dP95,1)} °C</b></span><span>کمینه<b>${fmt(s.before.min,1)} ← ${fmt(s.after.min,1)} °C</b></span><span>بیشینه<b>${fmt(s.before.max,1)} ← ${fmt(s.after.max,1)} °C</b></span>`;
  o.rel.innerHTML=`روش: <b>آهنگ کاهش دمای محلی</b> — دمای هر نقطه = دمای مدل + آهنگ کاهش × (ارتفاع DEM − ارتفاع هموارشدهٔ مدل)<br>آهنگ کاهش کلی: <b>${fmt(r.Gglob,2)} °C/km</b>${r.RG?` (رگرسیون ${fmt(r.RG.G,2)}، R² = ${fmt(r.RG.r2,2)})`:""}<br>آهنگ کاهش محلی (۵ تا ۹۵٪): <b>${fmt(s.gP05,1)} تا ${fmt(s.gP95,1)} °C/km</b>${r.warns.length?`<br><span style="color:var(--warn)">${r.warns.join("<br>")}</span>`:""}`;
  o.chart.replaceChildren(dsChartTemp(r));
  let AS=null; try{ AS=dsAreaStats(r); }catch(e){ console.warn("dsAreaStats",e); } if(AS) o.rel.insertAdjacentHTML("beforeend", AS.html);
  o.rep.querySelector("pre").textContent=dsReportTemp(r)+(AS?"\n"+AS.txt+"\n":"");
  const base=`${(r.m.name||"model").replace(/[^A-Za-z0-9]+/g,"")||"map"}_temperature_dem`;
  const mk=(label, ext, make)=>{ const b=document.createElement("button"); b.className="btn"; b.type="button"; b.textContent=label;
    b.onclick=async()=>{ b.disabled=true; await tick(); try{ const blob=await make(); const u=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=u; a.download=base+ext; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u), 4000); }catch(e){ console.error(e); } b.disabled=false; };
    return b; };
  const png=cv=>new Promise(res=>cv.toBlob(res,"image/png"));
  o.dl.replaceChildren(mk("نقشهٔ اصلاح‌شده PNG", ".png", ()=>png(r.cv)), mk("NetCDF", ".nc", ()=>dsNetCDF(r, [["title",`${r.m.name} elevation-corrected temperature`],["source",r.m.file.name],["method","lapse-rate downscaling: T = T_model + Gamma*(z_DEM - z_model), local weighted regression lapse rate"],["dem",ds.dem.label],["disclaimer","statistical downscaling without observations"],["Conventions","CF-1.8"]])),
    mk("CSV", ".csv", ()=>dsCSV(r)), mk("گزارش TXT", "_report.txt", ()=>new Blob([dsReportTemp(r)],{type:"text/plain;charset=utf-8"})), mk("نمودار PNG", "_lapse_rate.png", ()=>png(o.chart.querySelector("canvas"))));
}
async function dsLocate(m){
  const extra=ds.maps.filter(q=>q!==m && q.geo && q.w===m.w && q.h===m.h && q.prof===m.prof).map(q=>({g:q.geo, sc:q.geoScore}));
  const L={maps:[m], prof:m.prof, tplGeo:m.tplGeo, W:m.w, H:m.h, hint:m.hint, manual:m.manual, manualRefine:m.manualRefine};
  const r=await grLocate(L, m.prof.pal, extra);
  m.geoDone=true; m.geoScore=r.score; m.geoMsg=r.msg||"";
  if(r.ok){ m.geo=r.g; m.geoTry=null; m.geoSrc=r.src+` · تطابق ${FA(Math.round((1-Math.min(r.score,1))*100))}٪`;
    if(r.score<0.45 && /خودکار/.test(r.src)) grLearn({W:m.w,H:m.h,prof:m.prof,geo:m.geo,sc:r.score}); }
  else { m.geo=null; m.geoTry=r.g||null; }
  return r;
}
async function dsRunAll(){
  if(ds.busy){ ds.pending=true; return; }
  const todo=ds.maps.filter(m=>!m.bad && !m.result && !(m.geoDone && !m.geo)); if(!todo.length) return;
  let cfg; try{ cfg=dsCfg(); }catch(e){ dsStatus("تنظیمات نادرست: "+e.message, 0); return; }
  ds.busy=true; $("dsRun").disabled=true;
  const prev = P ? P.key : null;
  try{
    if(!ds.dem){ dsStatus("بارگذاری DEM…", 0.02); await tick(); ds.dem=await dsBuiltinDEM(); dsDemInfo(); }
    for(let k=0;k<todo.length;k++){
      const m=todo[k];
      const prog=(fr,t)=>dsStatus(`${m.name} (${FA(k+1)} از ${FA(todo.length)}): ${t}…`, (k+fr)/todo.length);
      if(m.prof.custom && !m.prof.edges){ m.note="اعداد نوار رنگ را وارد کنید (یک بار برای این قالب)"; continue; }
      try{
        if(m.prof.custom && m.prof.staticDirty){ prog(0.01,"تشخیص مرزها و نوشته‌های ثابت"); await tick(); await useProfile(m.prof.key); computeStatic(m.prof.models); m.prof.staticDirty=false; }
        if(!m.geoDone){ prog(0.03, "یافتن مکان نقشه با تطبیق مرزها"); await tick(); await dsLocate(m); }
        if(!m.card){ m.card=dsMakeCard(m); $("dsCards").append(m.card.card); }
        if(!m.geo){ dsFillPending(m.card); m.warn=true; m.note="مکان نقشه پیدا نشد؛ در کارت نقشه محدوده را انتخاب کنید"; continue; }
        m.warn=false; m.note=m.siteNote; dsGeoBox(m.card);
        prog(0.08, "رقومی‌سازی نقشه"); await tick();
        const r=await dsProcess(m, cfg, ds.dem, prog);
        m.result=r; dsFill(m.card, r);
      }catch(e){ console.error(e); m.note="خطا: "+e.message; m.warn=true; if(m.card){ m.card.rel.innerHTML=`<span style="color:var(--warn)">خطا در پردازش: ${e.message}</span>`; } }
    }
    const nOK=ds.maps.filter(m=>m.result).length, nWait=ds.maps.filter(m=>!m.bad && !m.result).length;
    dsStatus(`${FA(nOK)} نقشه اصلاح شد`+(nWait?` · ${FA(nWait)} نقشه منتظر تعیین مکان یا اعداد نوار رنگ`:""), 1);
  }catch(e){ console.error(e); dsStatus("خطا: "+e.message, 0); }
  if(prev) await useProfile(prev); else P=undefined;
  dsDrawList();
  ds.busy=false; $("dsRun").disabled=false;
  if(ds.pending){ ds.pending=false; dsRunAll(); }
}
function dsDemInfo(){ $("demInfo").textContent = ds.dem ? ds.dem.label : "DEM داخلی ایران (۹۰ متری، تجمیع‌شده به ۱ دقیقه ≈ ۱٫۸ کیلومتر) — آفلاین داخل همین فایل"; $("demReset").hidden = !ds.dem || ds.dem===ds.builtin; }
function openDS(){
  $("landing").hidden=true; $("app").hidden=true; $("cvApp").hidden=true; $("ltApp").hidden=true; $("wnApp").hidden=true; $("cqcApp").hidden=true; if($("caApp")) $("caApp").hidden=true; $("dsApp").hidden=false;
  $("srcName").textContent="اصلاح نقشه‌های بارش و دما با توجه به ارتفاع"; $("srcBtn").hidden=false;
  ribbon($("ribbon"), WB_PAL); dsDemInfo(); dsDrawList();
  store.set("mode","ds");
}
DS_INPUTS.forEach(id=>{ const v=store.get(id,null); if(v!==null) $(id).value=v; $(id).addEventListener("input", ()=>{ store.set(id,$(id).value); ds.maps.forEach(m=>m.result=null); dsSchedule(900); }); });
DS_CHECKS.forEach(id=>{ const v=store.get(id,null); if(v!==null) $(id).checked=v; $(id).addEventListener("change", ()=>{ store.set(id,$(id).checked); ds.maps.forEach(m=>m.result=null); dsSchedule(300); }); });
$("dsFiles").onchange=()=>{ dsAdd($("dsFiles").files); $("dsFiles").value=""; };
for(const el of [$("dsDrop"), $("dsEmpty")]){
  el.addEventListener("dragover", e=>{ e.preventDefault(); el.classList.add("over"); });
  el.addEventListener("dragleave", ()=>el.classList.remove("over"));
  el.addEventListener("drop", e=>{ e.preventDefault(); el.classList.remove("over"); dsAdd(e.dataTransfer.files); });
}
$("dsEmpty").onclick=()=>$("dsFiles").click();
$("dsRun").onclick=()=>{ ds.maps.forEach(m=>{ if(!m.bad) m.result=null; }); dsRunAll(); };
$("demFile").onchange=async e=>{ const f=e.target.files[0]; e.target.value=""; if(!f) return;
  try{ dsStatus("خواندن DEM…", 0.05); ds.dem=await dsReadGeoTIFF(f); dsDemInfo(); ds.maps.forEach(m=>m.result=null); dsSchedule(50); }
  catch(err){ console.error(err); dsStatus("DEM خوانده نشد: "+err.message, 0); } };
$("demReset").onclick=async()=>{ ds.dem=await dsBuiltinDEM(); dsDemInfo(); ds.maps.forEach(m=>m.result=null); dsSchedule(50); };

