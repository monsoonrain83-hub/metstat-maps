/* ---------- خط لولهٔ اصلی برای یک نقشه ---------- */
async function dsProcess(m, cfg, dem, prog){
  if(m.kind==="temp") return dsProcessTemp(m, cfg, dem, prog);
  await useProfile(m.prof.key);
  const d=m.data, W0=P.W, g=m.geo;
  m.rects = P.invalid(d);
  const cls = classify(d, P.useCap ? 400 : Infinity, m.rects);
  const nCls=PAL.length, low=EDGES.slice(0,nCls);
  const rep=low.map((lo,c)=>{ const hi=EDGES[c+1]; if(c===0) return 0; return hi!==undefined && isFinite(hi) ? (lo+hi)/2 : lo*1.1+1; });
  const vF=new Uint8Array(N), PF=new Float32Array(N);
  for(let i=0;i<N;i++) if(cls[i]>=0){ PF[i]=rep[cls[i]]; vF[i]=1; }
  inpaint(PF, vF);
  const pal = ownPalette(d);
  // شبکهٔ کاری: نقشه‌های بزرگ با گام st کوچک می‌شوند (حداکثر حدود ۶۵۰ هزار خانه)
  const st=Math.max(1, Math.ceil(Math.sqrt(N/800000))), GW=Math.ceil(FW/st), GH=Math.ceil(FH/st), GN=GW*GH;
  const P0=new Float32Array(GN);
  if(st===1) P0.set(PF);
  else { const cnt=new Uint16Array(GN); for(let y=0;y<FH;y++){ const gy=Math.floor(y/st); for(let x=0;x<FW;x++){ const k=gy*GW+Math.floor(x/st); P0[k]+=PF[y*FW+x]; cnt[k]++; } } for(let k=0;k<GN;k++) P0[k]/=cnt[k]||1; }
  const cxp=gx=>gx*st+(Math.min(st,FW-gx*st)-1)/2, cyp=gy=>gy*st+(Math.min(st,FH-gy*st)-1)/2;
  const lon=new Float64Array(GW), lat=new Float64Array(GH);
  for(let x=0;x<GW;x++) lon[x]=(cxp(x)+P.fx0-g[0])/g[1]; for(let y=0;y<GH;y++) lat[y]=(cyp(y)+P.fy0-g[2])/g[3];
  const dlon=Math.abs(st/g[1]), dlat=Math.abs(st/g[3]), latm=(lat[0]+lat[GH-1])/2;
  const dxk=dlon*111.32*Math.cos(latm*Math.PI/180), dyk=dlat*110.574;
  prog(0.15, "ارتفاع پیکسل‌ها از DEM");
  await tick();
  // ارتفاع هر خانه: اگر خانه بزرگ‌تر از DEM است میانگین، وگرنه درون‌یابی دوخطی
  const Z=new Float64Array(GN), hx=dlon/2, hy=dlat/2;
  let nIn=0;
  if(dlon >= dem.dx*0.9){
    const cj=[], ri=[];
    const rng=(c, h, o, step, n, sgn)=>{ let a=Math.ceil((sgn*(c-o)-h)/step-1e-9), b=Math.floor((sgn*(c-o)+h)/step+1e-9);
      if(b<a){ a=b=Math.round(sgn*(c-o)/step); } if(b<0 || a>n-1) return [1,0]; return [Math.max(a,0), Math.min(b,n-1)]; };
    for(let x=0;x<GW;x++) cj.push(rng(lon[x], hx, dem.x0, dem.dx, dem.nx, 1));
    for(let y=0;y<GH;y++) ri.push(rng(lat[y], hy, dem.y0, dem.dy, dem.ny, -1));
    for(let y=0;y<GH;y++){ const [i0,i1]=ri[y]; for(let x=0;x<GW;x++){ const [j0,j1]=cj[x]; let s=0,c=0,t=0;
      for(let i=i0;i<=i1;i++) for(let j=j0;j<=j1;j++){ t++; const v=dem.data[i*dem.nx+j]; if(v===v){ s+=v; c++; } }
      const k=y*GW+x; Z[k] = (t>0 && c*2>=t) ? s/c : NaN; if(Z[k]===Z[k]) nIn++; } }
  } else {
    for(let y=0;y<GH;y++){ const fi=(dem.y0-lat[y])/dem.dy; for(let x=0;x<GW;x++){ const fj=(lon[x]-dem.x0)/dem.dx, k=y*GW+x;
      if(fi<0||fj<0||fi>dem.ny-1||fj>dem.nx-1){ Z[k]=NaN; continue; }
      const i0=Math.min(Math.floor(fi),dem.ny-2), j0=Math.min(Math.floor(fj),dem.nx-2), a=fi-i0, b=fj-j0, D=dem.data, n=dem.nx;
      const v00=D[i0*n+j0], v01=D[i0*n+j0+1], v10=D[(i0+1)*n+j0], v11=D[(i0+1)*n+j0+1];
      if(v00===v00 && v01===v01 && v10===v10 && v11===v11) Z[k]=(v00*(1-b)+v01*b)*(1-a)+(v10*(1-b)+v11*b)*a;
      else { const q=[[v00,(1-a)*(1-b)],[v01,(1-a)*b],[v10,a*(1-b)],[v11,a*b]].filter(t=>t[0]===t[0]); let s=0,w=0; for(const [v,ww] of q){ s+=v*ww; w+=ww; } Z[k]= w>=0.5 ? s/w : NaN; }
      if(Z[k]===Z[k]) nIn++; } }
  }
  if(nIn < 0.02*GN) throw new Error("این نقشه با DEM هم‌پوشانی ندارد (مکان نقشه بیرون از محدودهٔ DEM است)");
  const demOK=new Uint8Array(GN); for(let i=0;i<GN;i++) demOK[i]= Z[i]===Z[i] ? 1 : 0;
  const sE=cfg.smooth/2, Zeff = sE>0 ? dsMGauss(Z, demOK, GW, GH, sE/dyk, sE/dxk) : Float64Array.from(Z);
  const effDeg=m.res*cfg.eff, boxX=effDeg/dlon, boxY=effDeg/dlat, sgX=boxX/Math.sqrt(12)*1.25, sgY=boxY/Math.sqrt(12)*1.25;
  const Zm = dsMGauss(Z, demOK, GW, GH, sgY, sgX);
  const sX=cfg.expoKm/2, Zx = sX>cfg.smooth/2 ? dsMGauss(Z, demOK, GW, GH, sX/dyk, sX/dxk) : Zeff;
  for(let i=0;i<GN;i++) if(!demOK[i]){ Zeff[i]=NaN; Zm[i]=NaN; Zx[i]=NaN; }
  const [gxE,gyE]=dsGrad(Zx,GW,GH,dxk,dyk), [gxM,gyM]=dsGrad(Zm,GW,GH,dxk,dyk);
  const dist=dsDistKm(demOK,GW,GH,dxk,dyk);
  prog(0.35, "برازش مدل غیرخطی بارش–ارتفاع (GAM)");
  await tick();
  const mx=Math.max(1,Math.round(m.res/dlon)), my=Math.max(1,Math.round(m.res/dlat)), BX=Math.floor(GW/mx), BY=Math.floor(GH/my);
  const D={z:[],lon:[],lat:[],gx:[],gy:[],y:[],p:[],bi:[],bj:[]}, allZ=[], allP=[];
  for(let bi=0;bi<BY;bi++) for(let bj=0;bj<BX;bj++){
    let c=0, sp=0, sz=0, sx=0, sy=0, sl=0, sa=0;
    for(let y=bi*my;y<(bi+1)*my;y++) for(let x=bj*mx;x<(bj+1)*mx;x++){ const i=y*GW+x;
      if(demOK[i] && Zm[i]===Zm[i] && gxM[i]===gxM[i]){ c++; sp+=P0[i]; sz+=Zm[i]; sx+=gxM[i]; sy+=gyM[i]; sl+=lon[x]; sa+=lat[y]; } }
    if(c < 0.8*mx*my) continue;
    const pm=sp/c; allZ.push(sz/c); allP.push(pm);
    if(pm>=cfg.thr){ D.z.push(sz/c); D.lon.push(sl/c); D.lat.push(sa/c); D.gx.push(sx/c); D.gy.push(sy/c); D.p.push(pm); D.y.push(Math.log(pm+1)); D.bi.push(bi); D.bj.push(bj); }
  }
  const warns=[], res={m, cfg, lon, lat, dxk, dyk, P0, Z, Zeff, Zm, demOK, D, allZ, allP, warns, tiles:[], GW, GH, st};
  const logf=new Float64Array(GN);
  if(D.y.length < 30){
    warns.push(`فقط ${FA(D.y.length)} سلول بارانی داخل DEM؛ رابطه برآورد نشد و نقشه بدون تغییر ماند.`);
    res.rel={type:"برآورد نشد", sig:false}; res.G=null; res.expo={sig:false};
  } else {
    const G=dsFitGAM(D,cfg); res.G=G;
    const rmap=new Map(); D.y.forEach((v,k)=>rmap.set(D.bi[k]*100000+D.bj[k], v-G.fitted[k]));
    let num=0, den=0;
    for(const [key,r] of rmap){ for(const nk of [key+1, key+100000]){ const q=rmap.get(nk); if(q!==undefined){ num+=r*q; den+=0.5*(r*r+q*q); } } }
    const rho=den>0?Math.min(Math.max(num/den,0),0.95):0, infl=Math.min(Math.max((1+rho)/(1-rho),1),40);
    for(let i=0;i<G.cov.length;i++) G.cov[i]*=infl; G.rho=rho; G.infl=infl;
    res.rel=dsDescribe(G, D.z, cfg.sig);
    let eOK=false, chi2=0;
    if(G.iE>=0){ const a=G.b[G.iE], b=G.b[G.iE+1], c11=G.cov[G.iE*G.p+G.iE], c12=G.cov[G.iE*G.p+G.iE+1], c22=G.cov[(G.iE+1)*G.p+G.iE+1], det=c11*c22-c12*c12;
      if(det>0){ chi2=(a*a*c22-2*a*b*c12+b*b*c11)/det; eOK=chi2>2*cfg.sig*cfg.sig; } }
    const gG=eOK?dsGamma(G):[0,0];
    res.expo={sig:eOK, chi2, facing: (Math.atan2(-gG[0],-gG[1])*180/Math.PI+360)%360};
    const lutG=dsLUT(G, !res.rel.sig);
    prog(0.55, "رابطهٔ محلی هر رشته‌کوه و ضریب اصلاح");
    await tick();
    const acc=new Float64Array(GN), Wt=new Float64Array(GN);
    let ix0=GW, ix1=-1, iy0=GH, iy1=-1; for(let y=0;y<GH;y++) for(let x=0;x<GW;x++) if(demOK[y*GW+x]){ if(x<ix0) ix0=x; if(x>ix1) ix1=x; if(y<iy0) iy0=y; if(y>iy1) iy1=y; }
    const W_=lon[ix0], E_=lon[ix1], N_=lat[iy0], S_=lat[iy1], half=cfg.tile/2, step=cfg.tile/2;
    const add=(lon0, lat0, hw, lut, gam, scale)=>{
      for(let y=0;y<GH;y++){ const dy=(lat[y]-lat0)/hw; if(Math.abs(dy)>1) continue; const wy=Math.cos(dy*Math.PI/2)**2;
        for(let x=0;x<GW;x++){ const dx=(lon[x]-lon0)/hw; if(Math.abs(dx)>1) continue; const i=y*GW+x; if(!demOK[i]) continue;
          const w=scale*wy*Math.cos(dx*Math.PI/2)**2;
          const ze=Math.min(Math.max(Zeff[i],lut.lo),lut.hi), zm=Math.min(Math.max(Zm[i],lut.lo),lut.hi);
          let t=dsInterp(lut,ze)-dsInterp(lut,zm);
          if(gam[0]||gam[1]){ const ex=gxE[i]-gxM[i], ey=gyE[i]-gyM[i]; if(ex===ex && ey===ey) t+=gam[0]*ex+gam[1]*ey; }
          acc[i]+=w*t; Wt[i]+=w; } } };
    if(cfg.tiles){
      for(let lo0=W_+half; lo0<=E_-half+step+1e-9; lo0+=step) for(let la0=S_+half; la0<=N_-half+step+1e-9; la0+=step){
        const idx=[]; for(let k=0;k<D.y.length;k++) if(Math.abs(D.lon[k]-lo0)<=half && Math.abs(D.lat[k]-la0)<=half) idx.push(k);
        let zmn=Infinity, zmx=-Infinity; for(const k of idx){ zmn=Math.min(zmn,D.z[k]); zmx=Math.max(zmx,D.z[k]); }
        let tf={lon0:lo0, lat0:la0, n:idx.length, used:"global", lut:lutG, gam:gG, rel:null};
        if(idx.length>=cfg.minPts && zmx-zmn>=cfg.minRelief){
          const Lc=dsFitLocal(G,D,idx,cfg);
          if(Lc){ for(let i=0;i<Lc.cov.length;i++) Lc.cov[i]*=infl;
            const rel=dsDescribe(Lc, idx.map(k=>D.z[k]), cfg.sig);
            tf={lon0:lo0, lat0:la0, n:idx.length, used:"local", lut:dsLUT(Lc,!rel.sig), gam: eOK?dsGamma(Lc):[0,0], rel, M:Lc}; }
        }
        res.tiles.push(tf); add(lo0, la0, half, tf.lut, tf.gam, 1);
      }
    }
    add((W_+E_)/2, (N_+S_)/2, 1000, lutG, gG, 1e-3);
    for(let i=0;i<GN;i++) logf[i]= Wt[i]>0 ? acc[i]/Wt[i] : 0;
  }
  prog(0.75, "اعمال محدودیت‌ها و بازسازی نقشه");
  await tick();
  const inside=demOK, lmin=Math.log(cfg.minF), lmax=Math.log(cfg.maxF);
  const f=new Float64Array(GN);
  for(let i=0;i<GN;i++){
    if(!inside[i]){ f[i]=1; continue; }
    let l=logf[i]*cfg.strength; const t=Math.min(Math.max((P0[i]-cfg.thr)/(cfg.full-cfg.thr),0),1); l*=t*t*(3-2*t);
    if(cfg.taper>0) l*=Math.min(dist[i]/cfg.taper,1);
    f[i]=Math.exp(Math.min(Math.max(l,lmin),lmax)); }
  const rawF=Float64Array.from(f);
  if(cfg.mass && res.G){
    const wP=Float64Array.from(P0), lf=new Float64Array(GN);
    for(let i=0;i<GN;i++) lf[i]=Math.log(f[i]);
    for(let it=0;it<3;it++){
      const mean=dsMGauss(lf, inside, GW, GH, sgY, sgX, wP);
      for(let i=0;i<GN;i++){ if(!inside[i]){ lf[i]=0; continue; } const mv=mean[i]===mean[i]?mean[i]:0; lf[i]=Math.min(Math.max(lf[i]-mv,lmin),lmax); } }
    for(let i=0;i<GN;i++) f[i]=Math.exp(lf[i]);
    const Pf=new Float64Array(GN); for(let i=0;i<GN;i++) Pf[i]=P0[i]*f[i];
    const g1=dsMGauss(P0, inside, GW, GH, sgY, sgX), g2=dsMGauss(Pf, inside, GW, GH, sgY, sgX);
    for(let i=0;i<GN;i++){ if(!inside[i]){ f[i]=1; continue; } const r=g2[i]>1e-6 && g1[i]===g1[i] ? g1[i]/g2[i] : 1; f[i]=Math.min(Math.max(f[i]*r,cfg.minF),cfg.maxF); }
  }
  const Pin=new Float64Array(GN); for(let i=0;i<GN;i++) Pin[i]=inside[i]?P0[i]:0;
  const capF=dsMaxFilter(Pin, GW, GH, Math.max(1,Math.round(boxY/2)), Math.max(1,Math.round(boxX/2)));
  const Pc=new Float32Array(GN);
  for(let i=0;i<GN;i++){ let v=P0[i]*f[i]; if(inside[i]) v=Math.min(v, cfg.cap*capF[i]); v=Math.max(v,0); Pc[i]=v; f[i]= P0[i]>1e-6 ? v/P0[i] : 1; if(!inside[i]){ f[i]=1; Pc[i]=P0[i]; } }
  res.f=f; res.Pc=Pc;
  // آمار (روی شبکهٔ کاری)
  const sum=(arr,mask)=>{ const v=[]; for(let i=0;i<GN;i++) if(mask[i]) v.push(arr[i]); if(!v.length) return {}; let s=0,mxv=-Infinity,mn=Infinity; for(const q of v){ s+=q; if(q>mxv) mxv=q; if(q<mn) mn=q; }
    const o={mean:s/v.length, max:mxv, min:mn, p95:dsPct(v,95)}; for(const t of [1,5,10,25,50]){ let c=0; for(const q of v) if(q>=t) c++; o["a"+t]=c/v.length; } return o; };
  const fin=[]; for(let i=0;i<GN;i++) if(inside[i] && P0[i]>=cfg.thr) fin.push(f[i]);
  let sa=0, sb=0, sab=0, saa=0, sbb=0, nn=0, art=0, atB=0, nI=0;
  for(let i=0;i<GN;i++) if(inside[i]){ const a=P0[i], b=Pc[i]; sa+=a; sb+=b; sab+=a*b; saa+=a*a; sbb+=b*b; nn++; if(b>=5 && a<cfg.thr) art++; nI++; if(rawF[i]<=cfg.minF+1e-6 || rawF[i]>=cfg.maxF-1e-6) atB++; }
  const corr=(nn*sab-sa*sb)/Math.sqrt(Math.max((nn*saa-sa*sa)*(nn*sbb-sb*sb),1e-12));
  res.stats={before:sum(P0,inside), after:sum(Pc,inside), fMean:fin.length?fin.reduce((a,b)=>a+b,0)/fin.length:1, fMin:fin.length?fin.reduce((a,b)=>a<b?a:b):1, fMax:fin.length?fin.reduce((a,b)=>a>b?a:b):1,
    fP05:fin.length?dsPct(fin,5):1, fP95:fin.length?dsPct(fin,95):1, ratio:sa>0?sb/sa:1, corr, art, atBounds:nI?atB/nI:0, nInside:nI, nOut:GN-nI};
  if(res.stats.atBounds>0.2) warns.push("بیش از ۲۰٪ نقاط به سقف یا کف ضریب رسیده‌اند؛ هموارسازی زمین را بیشتر یا شدت اصلاح را کمتر کنید.");
  if(nIn<0.95*GN) warns.push(`DEM ${FA(Math.round(nIn/GN*100))}٪ کادر نقشه را می‌پوشاند؛ بیرون از آن، نقشه بدون تغییر است.`);
  if(st>1) warns.push(`نقشهٔ بزرگ (${FA(P.W)}×${FA(P.H)}): محاسبه روی شبکهٔ ${FA(GW)}×${FA(GH)} انجام و ضریب با درون‌یابی به همهٔ پیکسل‌ها داده شد.`);
  // بازسازی نقشه با وضوح کامل: ضریب شبکه با درون‌یابی دوخطی به هر پیکسل
  const capCls = P.useCap ? low.findIndex(e=>e>=400)-1 : nCls-1;
  const cv=document.createElement("canvas"); cv.width=P.W; cv.height=P.H;
  const cx=cv.getContext("2d"), im=new ImageData(new Uint8ClampedArray(d), P.W, P.H), o=im.data;
  let changed=0; const wuClean = P.key==="wu";   // weather.us: مرز، نام شهرها و نوشته‌های خود سایت پاک و با مقدار اصلاح‌شده پر می‌شوند
  for(let y=0;y<FH;y++){ const gyf=Math.min(Math.max((y-(st-1)/2)/st,0),GH-1), gy0=Math.min(Math.floor(gyf),Math.max(GH-2,0)), ay=GH>1?gyf-gy0:0, gyn=Math.min(GH-1,Math.floor(y/st));
    for(let x=0;x<FW;x++){ const i=y*FW+x; if(cls[i]<0 && !wuClean) continue;
      const gxf=Math.min(Math.max((x-(st-1)/2)/st,0),GW-1), gx0=Math.min(Math.floor(gxf),Math.max(GW-2,0)), ax=GW>1?gxf-gx0:0, gn=gyn*GW+Math.min(GW-1,Math.floor(x/st));
      let ff;
      if(st===1) ff=f[i];
      else { const k=gy0*GW+gx0, k1=Math.min(k+1,GN-1), k2=Math.min(k+GW,GN-1), k3=Math.min(k+GW+1,GN-1); ff=(f[k]*(1-ax)+f[k1]*ax)*(1-ay)+(f[k2]*(1-ax)+f[k3]*ax)*ay; }
      let v=PF[i]*ff; if(inside[gn]) v=Math.min(v, cfg.cap*capF[gn]); else v=PF[i];
      let k=0; while(k+1<nCls && low[k+1]<=v) k++; if(capCls>=0) k=Math.min(k,capCls);
      if(k!==cls[i]){ const q=((y+P.fy0)*W0+x+P.fx0)*4, c=pal[k]; o[q]=c[0]; o[q+1]=c[1]; o[q+2]=c[2]; if(cls[i]>=0) changed++; } } }
  cx.putImageData(im,0,0);
  if(wuClean){
    // مرزبندی PNG زوم (تشخیص خودکار منطقه) به جای مرزهای weather.us
    const ov=wuOverlay(m.zone); if(ov){ cx.save(); cx.beginPath(); cx.rect(P.fx0,P.fy0,FW,FH); cx.clip(); cx.drawImage(ov,0,0,P.W,P.H); cx.restore(); }
    cx.strokeStyle="#000"; cx.lineWidth=1; cx.strokeRect(P.fx0-0.5,P.fy0-0.5,FW+1,FH+1);
    // لوگوی منبع در پانویس → لوگوی سایت
    cx.fillStyle="#fff"; cx.fillRect(500,722,P.W-500,P.H-722);
    drawBrand(cx, {logoImg:state.logoImg}, 520, 716, P.W-538, 44, {side:true, align:"right", fs:14});
  }
  if(cfg.stamp){
    const sc=Math.max(1, P.W/900), txt="اصلاح توپوگرافی با DEM · MetStat"; cx.font=`700 ${Math.round(12*sc)}px "Ketab", Tahoma, sans-serif`; cx.direction="rtl";
    const tw=cx.measureText(txt).width, bx=P.fx1-8*sc, by=P.fy0+6*sc;
    cx.fillStyle="rgba(255,255,255,.88)"; cx.strokeStyle="rgba(90,90,90,.8)"; cx.lineWidth=1;
    cx.beginPath(); cx.rect(bx-tw-10*sc, by, tw+12*sc, 19*sc); cx.fill(); cx.stroke();
    cx.fillStyle="#15233b"; cx.textBaseline="middle"; cx.textAlign="right"; cx.fillText(txt, bx-4*sc, by+10*sc);
  }
  res.cv=cv; res.stats.changed=changed; res.clsFull=cls;
  res.geo={W:P.W, H:P.H, fx0:P.fx0, fy0:P.fy0, fx1:P.fx1, fy1:P.fy1, FW, FH, name:m.siteName};
  return res;
}

