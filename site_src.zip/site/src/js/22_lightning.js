/* =====================================================================
   رعدوبرق: تبدیل انیمیشن GIF رعدوبرق weather.us به نقشهٔ تجمعی و نقشهٔ تراکم
   ===================================================================== */
// رمزگشای GIF (بدون کتابخانهٔ بیرونی): همهٔ فریم‌ها با اعمال disposal و شفافیت
function gifDecode(buf,onFrame){
  const b=new Uint8Array(buf); let p=0, frameNo=0; const u16=()=>{ const v=b[p]|(b[p+1]<<8); p+=2; return v; };
  const sig=String.fromCharCode(...b.slice(0,6)); if(!/^GIF8[79]a$/.test(sig)) throw new Error("پروندهٔ GIF معتبر نیست");
  p=6; const W=u16(), H=u16(), fl=b[p++]; p++; p++;
  let gct=null; if(fl&0x80){ const n=1<<((fl&7)+1); gct=b.slice(p,p+3*n); p+=3*n; }
  const canvas=new Uint8ClampedArray(W*H*4), frames=onFrame?null:[]; let gce={disp:0, delay:0, tIdx:-1}, prevSnap=null;
  const lzw=(minCode, data, npix)=>{ const out=new Uint8Array(npix); let clear=1<<minCode, eoi=clear+1, size=minCode+1, mask=(1<<size)-1, next=eoi+1;
    const pre=new Int16Array(4096), suf=new Uint8Array(4096), stk=new Uint8Array(4097); for(let i=0;i<clear;i++){ pre[i]=-1; suf[i]=i; }
    let bits=0, cur=0, dp=0, op=0, old=-1, first=0;
    while(op<npix){ while(bits<size && dp<data.length){ cur|=data[dp++]<<bits; bits+=8; } if(bits<size) break;
      let code=cur&mask; cur>>>=size; bits-=size;
      if(code===clear){ size=minCode+1; mask=(1<<size)-1; next=eoi+1; old=-1; continue; } if(code===eoi) break;
      let c=code, sp=0; if(old===-1){ out[op++]=suf[code]; old=code; first=code; continue; }
      if(code>=next){ stk[sp++]=first; c=old; }
      while(c>=clear){ stk[sp++]=suf[c]; c=pre[c]; } stk[sp++]=suf[c]; first=suf[c];
      while(sp && op<npix) out[op++]=stk[--sp];
      if(next<4096){ pre[next]=old; suf[next]=first; next++; if((next&mask)===0 && next<4096){ size++; mask=(1<<size)-1; } }
      old=code; }
    return out; };
  while(p<b.length){ const t=b[p++];
    if(t===0x3B) break;
    if(t===0x21){ const lab=b[p++];
      if(lab===0xF9){ p++; const f=b[p++]; gce={disp:(f>>2)&7, delay:u16()*10, tIdx:(f&1)?b[p]:-1}; p++; p++; }
      else { while(b[p]) p+=b[p]+1; p++; } continue; }
    if(t===0x2C){ const x0=u16(), y0=u16(), w=u16(), h=u16(), f=b[p++]; let lct=null; if(f&0x80){ const n=1<<((f&7)+1); lct=b.slice(p,p+3*n); p+=3*n; }
      const inter=!!(f&0x40), minCode=b[p++]; const chunks=[]; let len=0; while(b[p]){ chunks.push(b.subarray(p+1,p+1+b[p])); len+=b[p]; p+=b[p]+1; } p++;
      const data=new Uint8Array(len); let o=0; for(const c of chunks){ data.set(c,o); o+=c.length; }
      const idx=lzw(minCode, data, w*h), ct=lct||gct;
      if(gce.disp===3) prevSnap=canvas.slice();
      const rows=[]; if(inter){ for(const [s,st] of [[0,8],[4,8],[2,4],[1,2]]) for(let y=s;y<h;y+=st) rows.push(y); } else for(let y=0;y<h;y++) rows.push(y);
      for(let r=0;r<h;r++){ const y=rows[r]; for(let x=0;x<w;x++){ const ci=idx[r*w+x]; if(ci===gce.tIdx) continue; const X=x0+x, Y=y0+y; if(X>=W||Y>=H) continue; const q=(Y*W+X)*4; canvas[q]=ct[ci*3]; canvas[q+1]=ct[ci*3+1]; canvas[q+2]=ct[ci*3+2]; canvas[q+3]=255; } }
      // در حالت callback، همان canvas جاری را می‌دهیم تا برای هر فریم حدود 0.9MB کپی اضافه نسازیم.
      // مصرف‌کننده باید داده را همان لحظه بخواند؛ اگر لازم است نگه دارد، خودش slice() کند.
      if(onFrame) onFrame({data:canvas, delay:gce.delay, index:frameNo++, w:W, h:H});
      else frames.push({data:canvas.slice(), delay:gce.delay});
      if(gce.disp===2){ for(let y=y0;y<Math.min(H,y0+h);y++) for(let x=x0;x<Math.min(W,x0+w);x++){ const q=(y*W+x)*4; canvas[q]=canvas[q+1]=canvas[q+2]=canvas[q+3]=0; } }
      else if(gce.disp===3 && prevSnap) canvas.set(prevSnap);
      gce={disp:0, delay:0, tIdx:-1}; continue; }
    break; }
  return {w:W, h:H, frames};
}
// ---------------------------------------------------------------------------------
// خط لولهٔ فریم‌ها (حافظه‌امن): هر فریم فقط یک بار decode می‌شود؛ از آن فقط «ماسک سفیدِ فشرده» و «زمان» نگه می‌داریم.
// سپس چند GIF/PNG با هم ادغام، به ترتیب زمان مرتب و فریم‌های هم‌زمان (همان تاریخ/ساعت/دقیقه) حذف می‌شوند.
// ---------------------------------------------------------------------------------
function ltBounds(W,H){ const wu=W===760&&H===760; return {fx0:wu?2:0, fy0:wu?2:0, fx1:wu?757:W-1, fy1:wu?614:Math.round(H*0.82)}; }
const ltIsW=(d,q)=>{ const r=d[q],g=d[q+1],b=d[q+2],mn=Math.min(r,g,b); return mn>=228&&Math.max(r,g,b)-mn<=28; };
function ltMake(d,W,B){            // ماسک سفید بیت‌فشرده برای کادر نقشه
  const FW=B.fx1-B.fx0+1, FH=B.fy1-B.fy0+1, m=new Uint8Array((FW*FH+7)>>3); let k=0, nz=0, h=2166136261;
  for(let y=B.fy0;y<=B.fy1;y++){ let q=(y*W+B.fx0)*4; for(let x=0;x<FW;x++,q+=4,k++) if(ltIsW(d,q)){ m[k>>3]|=1<<(k&7); nz++; } }
  for(let i=0;i<m.length;i+=7) h=Math.imul(h^m[i],16777619);
  return {m,nz,h};
}
// زمان فریم: خوانش‌های پرت (OCR) با برازش خطی روی ترتیب فریم جایگزین می‌شوند
function ltFixTimes(ts){
  const ok=[]; ts.forEach((t,k)=>{ if(t!==null) ok.push([k,t]); });
  if(!ok.length) return {t:ts.map(()=>null), step:null, real:false};
  const ds=[]; for(let i=1;i<ok.length;i++){ const d=(ok[i][1]-ok[i-1][1])/(ok[i][0]-ok[i-1][0]); if(d>0) ds.push(d); }
  ds.sort((a,b)=>a-b); const step=ds.length?ds[ds.length>>1]:null;
  if(!step||ok.length<2) return {t:ts.slice(), step:null, real:true};
  const an=ok.map(([k,t])=>t-k*step).sort((a,b)=>a-b), a0=an[an.length>>1];
  return {t:ts.map((v,k)=>{ const f=a0+k*step; return v!==null&&Math.abs(v-f)<=step/2?v:f; }), step, real:true};
}
async function ltDecodeFile(f, st){
  const isGif=/gif$/i.test(f.type)||/\.gif$/i.test(f.name), out=[];
  let first=null, last=null, W=0, H=0;
  const push=(d,w,h,idx)=>{
    if(!W){ W=w; H=h; } if(w!==W||h!==H) return;
    if(st.W && (w!==st.W||h!==st.H)) return;
    const B=ltBounds(w,h); let t=null; try{ const r=readTimes({data:d,w,h,file:{name:f.name}}); const e=r&&(r.end||r.valid); t=e?+e:null; }catch(e){}
    const mk=ltMake(d,w,B); out.push({t, m:mk.m, nz:mk.nz, h:mk.h, f:f.name, i:idx});
    if(idx===0) first=d.slice(); if(!last) last=new Uint8ClampedArray(d.length); last.set(d);
  };
  if(isGif){ const buf=await f.arrayBuffer(); await tick(); gifDecode(buf,g=>push(g.data,g.w,g.h,g.index)); }
  else if(isImg(f)){ const m=await readFile(f); push(m.data,m.w,m.h,0); }
  if(!out.length) return null;
  const fx=ltFixTimes(out.map(o=>o.t)); out.forEach((o,k)=>{ o.t=fx.t[k]; });
  return {frames:out, W, H, first, last, real:fx.real};
}
// ادغام: ترتیب زمانی، حذف فریم‌های هم‌زمان و (بدون زمان) فریم‌های کاملاً مشابه پشت‌سرهم
function ltMerge(parts){
  const W=parts[0].W, H=parts[0].H; let all=[]; parts.forEach((p,pi)=>p.frames.forEach(o=>{ o.pi=pi; all.push(o); }));
  const real=parts.every(p=>p.real); let dropped=0;
  if(real){ all.sort((a,b)=>a.t-b.t || a.pi-b.pi || a.i-b.i); }
  const keep=[]; let prevT=null, prevH=null;
  for(const o of all){
    if(real && prevT!==null && Math.abs(o.t-prevT)<30000){ dropped++; continue; }                 // همان تاریخ، ساعت و دقیقه
    if(!real && prevH===o.h && keep.length && keep[keep.length-1].nz===o.nz){ dropped++; continue; } // بدون زمان: تکرار عین‌به‌عین
    keep.push(o); prevT=o.t; prevH=o.h;
  }
  // اولین و آخرین فریم کامل (برای خواندن عنوان، زمان و زوم)
  const firstP=parts.reduce((a,p)=>!a?p:(p.frames[0].t<a.frames[0].t?p:a),null), lastP=parts.reduce((a,p)=>!a?p:(p.frames[p.frames.length-1].t>a.frames[a.frames.length-1].t?p:a),null);
  return {W,H,real,frames:keep,dropped,firstData:(real?firstP:parts[0]).first,lastData:(real?lastP:parts[parts.length-1]).last};
}
function ltBuildE(M){
  const {W,H,frames}=M, n=frames.length, B=ltBounds(W,H), FW=B.fx1-B.fx0+1, FH=B.fy1-B.fy0+1, N=FW*FH;
  const bit=(m,i)=>(m[i>>3]>>(i&7))&1;
  const cnt=new Uint16Array(N);
  for(const o of frames){ const m=o.m; for(let i=0;i<N;i++) if((m[i>>3]>>(i&7))&1) cnt[i]++; }
  // پیکسل‌هایی که در بیش‌ترِ فریم‌ها سفیدند (مربع شهرها، نام‌ها، حقوق نقشه) ثابت‌اند
  const thr=Math.max(3,Math.ceil(0.4*n)), stat0=new Uint8Array(N), stat=new Uint8Array(N);
  for(let i=0;i<N;i++) if(cnt[i]>=thr) stat0[i]=1;
  for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ if(!stat0[y*FW+x]) continue;
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ const yy=y+dy,xx=x+dx; if(yy>=0&&yy<FH&&xx>=0&&xx<FW) stat[yy*FW+xx]=1; } }
  const union=new Uint8Array(N), pts=[], per=[], prev=new Uint8Array(N), cur=new Uint8Array(N), lab=new Int32Array(N);
  let mark=0, prevList=[];
  for(let k=0;k<n;k++){
    const m=frames[k].m, cand=[], base=mark;
    for(let i=0;i<N;i++) if(((m[i>>3]>>(i&7))&1) && !stat[i]){ cur[i]=1; cand.push(i); }
    let nk=0;
    for(const i0 of cand){
      if(lab[i0]>base) continue;
      const id=++mark; let sx=0,sy=0,a=0,nw=0; const st=[i0]; lab[i0]=id;
      while(st.length){
        const i=st.pop(), x=i%FW, y=(i/FW)|0; a++;
        if(!prev[i]){ nw++; sx+=x; sy+=y; }
        for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
          if(dx===0&&dy===0) continue; const xx=x+dx,yy=y+dy; if(xx<0||yy<0||xx>=FW||yy>=FH) continue;
          const j=yy*FW+xx; if(cur[j]&&lab[j]<=base){ lab[j]=id; st.push(j); } }
      }
      if(a>=4){ const wgt=nw<0.35*28?0:Math.max(1,Math.round(nw/28)); if(wgt&&nw>0){ pts.push({x:sx/nw,y:sy/nw,w:wgt,k}); nk+=wgt; } }
    }
    for(const i of cand) union[i]=1;
    per.push(nk);
    for(const i of prevList) prev[i]=0; for(const i of cand) prev[i]=1; prevList=cand; for(const i of cand) cur[i]=0;
  }
  const times=frames.map(o=>o.t), ds=[]; for(let i=1;i<n;i++) if(times[i]>times[i-1]) ds.push(times[i]-times[i-1]); ds.sort((a,b)=>a-b);
  return {fx0:B.fx0,fy0:B.fy0,fx1:B.fx1,fy1:B.fy1,FW,FH,union,pts,per,stat,w:W,h:H,n,times,real:M.real,step:ds.length?ds[ds.length>>1]:null,dropped:M.dropped,firstData:M.firstData,lastData:M.lastData};
}
const lt={ frames:[], w:0, h:0, files:[], res:null, busy:false, streamE:null, frameCount:0, firstData:null, lastData:null };
const LT_COLS=[[30,144,255],[255,212,0],[255,140,0],[255,0,0]];   // کم، متوسط، زیاد، خیلی زیاد (از راهنمای کاربر)
function ltStatus(t, frac){ $("ltStatus").hidden=false; $("ltStText").textContent=t; if(frac!==undefined) $("ltStBar").style.width=(frac*100)+"%"; }
async function ltAddFiles(files){
  files=[...files].filter(f=>/\.gif$/i.test(f.name)||/gif$/i.test(f.type)||isImg(f)); if(!files.length) return;
  ltStatus("خواندن پرونده‌ها…", 0.05); await tick();
  lt.streamE=null; lt.firstData=null; lt.lastData=null; lt.frameCount=0; lt.frames=[];
  const st={W:0,H:0}, parts=[], bad=[];
  for(let fi=0; fi<files.length; fi++){ const f=files[fi];
    ltStatus(`رمزگشایی ${f.name}${files.length>1?` (${FA(fi+1)} از ${FA(files.length)})`:""}…`, 0.05+0.1*fi/files.length); await tick();
    try{ const r=await ltDecodeFile(f, st); if(r){ if(!st.W){ st.W=r.W; st.H=r.H; } parts.push(r); } else bad.push(f.name); }catch(e){ console.error(e); bad.push(f.name); }
  }
  if(!parts.length){ ltStatus("⚠ هیچ فریمی خوانده نشد",0); return; }
  ltStatus("ادغام و حذف فریم‌های تکراری…", 0.17); await tick();
  const M=ltMerge(parts), E=ltBuildE(M);
  lt.streamE=E; lt.w=E.w; lt.h=E.h; lt.frameCount=E.n; lt.firstData=E.firstData; lt.lastData=E.lastData; lt.files=files.map(f=>f.name);
  const n=E.n;
  $("ltInfo").textContent=`${FA(n)} فریم ${FA(lt.w)}×${FA(lt.h)} از ${files.map(f=>f.name).join("، ")}`+(E.dropped?` — ${FA(E.dropped)} فریم تکراری حذف شد`:"")+(bad.length?` — ناسازگار یا ناخوانا: ${bad.join("، ")}`:"");
  ltRun();
}
// تراکم نقطه‌ای: کرنل گاوسی، قطع تیز (دیسک)، دوجمله‌ای (quartic)، اپانچنیکوف، KDE تطبیقی، شمارش شبکه‌ای
function ltDensity(E, method, rKm, kx, ky, alpha){
  const FW=E.FW, FH=E.FH, A=kx*ky, km=(kx+ky)/2, r=Math.max(0.6, rKm/km), out=new Float32Array(FW*FH), pts=E.pts;
  const stamp=(px,py,w,R,K)=>{ const x0=Math.max(0,Math.floor(px-R)), x1=Math.min(FW-1,Math.ceil(px+R)), y0=Math.max(0,Math.floor(py-R)), y1=Math.min(FH-1,Math.ceil(py+R));
    for(let y=y0;y<=y1;y++) for(let x=x0;x<=x1;x++){ const d2=((x-px)**2+(y-py)**2); const v=K(d2); if(v>0) out[y*FW+x]+=w*v; } };
  if(method==="gauss"){ const s2=r*r, c=1/(2*Math.PI*s2*A); for(const p of pts) stamp(p.x,p.y,p.w,3*r,d2=>c*Math.exp(-d2/(2*s2))); }
  else if(method==="tophat"){ const c=1/(Math.PI*r*r*A); for(const p of pts) stamp(p.x,p.y,p.w,r,d2=>d2<=r*r?c:0); }
  else if(method==="quartic"){ const c=3/(Math.PI*r*r*A); for(const p of pts) stamp(p.x,p.y,p.w,r,d2=>{ const t=1-d2/(r*r); return t>0?c*t*t:0; }); }
  else if(method==="epan"){ const c=2/(Math.PI*r*r*A); for(const p of pts) stamp(p.x,p.y,p.w,r,d2=>{ const t=1-d2/(r*r); return t>0?c*t:0; }); }
  else if(method==="adaptive"){ // Abramson: h_i = h0·(f̃(x_i)/g)^(-α)
    const s2=r*r, fp=pts.map(p=>{ let s=0; for(const q of pts) s+=q.w*Math.exp(-((p.x-q.x)**2+(p.y-q.y)**2)/(2*s2)); return s/(2*Math.PI*s2); });
    const g=Math.exp(fp.reduce((a,v,i)=>a+pts[i].w*Math.log(Math.max(v,1e-12)),0)/Math.max(1,pts.reduce((a,p)=>a+p.w,0)));
    pts.forEach((p,i)=>{ const h=Math.max(0.6, Math.min(6*r, r*Math.pow(fp[i]/g, -alpha))), hs=h*h, c=1/(2*Math.PI*hs*A); stamp(p.x,p.y,p.w,3*h,d2=>c*Math.exp(-d2/(2*hs))); }); }
  else if(method==="grid"){ const cs=Math.max(2,Math.round(2*r)), nx=Math.ceil(FW/cs), ny=Math.ceil(FH/cs), g=new Float32Array(nx*ny);
    for(const p of pts){ const cx=Math.min(nx-1,Math.floor(p.x/cs)), cy=Math.min(ny-1,Math.floor(p.y/cs)); g[cy*nx+cx]+=p.w; }
    const ca=cs*cs*A; for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const fx=Math.min(nx-1.001,Math.max(0,x/cs-0.5)), fy=Math.min(ny-1.001,Math.max(0,y/cs-0.5)), x0=Math.floor(fx), y0=Math.floor(fy), tx=fx-x0, ty=fy-y0, x1=Math.min(nx-1,x0+1), y1=Math.min(ny-1,y0+1);
      out[y*FW+x]=((g[y0*nx+x0]*(1-tx)+g[y0*nx+x1]*tx)*(1-ty)+(g[y1*nx+x0]*(1-tx)+g[y1*nx+x1]*tx)*ty)/ca; } }
  return out;
}
// شعاع خودکار (قاعدهٔ اسکات برای دوبعدی: h = σ·n^(-1/6))
function ltAutoR(pts, kx, ky){
  // نسخهٔ سریع همان قاعدهٔ «فاصلهٔ همسایهٔ پنجم + میانه» است.
  // پیاده‌سازی قبلی ماتریس فاصلهٔ O(P²) می‌ساخت و برای ده‌ها هزار رعد عملاً متوقف می‌شد.
  const K=5, Q=[];
  for(const p of pts) Q.push({x:p.x,y:p.y,w:Math.min(p.w,4)});
  if(Q.length<3) return 10;
  const sx=Math.max(1e-6,Math.abs(kx)), sy=Math.max(1e-6,Math.abs(ky));
  // شبکهٔ مکانی: هر سلول تقریباً 2 پیکسل است؛ جست‌وجو به‌صورت حلقه‌ای بزرگ می‌شود.
  const cell=2, grid=new Map(), key=(cx,cy)=>cx+'|'+cy;
  for(let i=0;i<Q.length;i++){ const q=Q[i], cx=Math.floor(q.x/cell), cy=Math.floor(q.y/cell), kk=key(cx,cy); let a=grid.get(kk); if(!a) grid.set(kk,a=[]); a.push(i); }
  const kth=[];
  for(let i=0;i<Q.length;i++){
    const q=Q[i], cx=Math.floor(q.x/cell), cy=Math.floor(q.y/cell);
    let need=K-Math.min(q.w,4), cand=[];
    // تا وقتی دست‌کم K همسایهٔ وزنی پیدا نشده، شعاع شبکه را زیاد می‌کنیم.
    for(let ring=0;ring<80;ring++){
      const x0=cx-ring,x1=cx+ring,y0=cy-ring,y1=cy+ring;
      for(let gy=y0;gy<=y1;gy++) for(let gx=x0;gx<=x1;gx++){
        if(Math.max(Math.abs(gx-cx),Math.abs(gy-cy))!==ring) continue;
        const a=grid.get(key(gx,gy)); if(!a) continue;
        for(const j of a){ if(j===i) continue; const z=Q[j], dx=(z.x-q.x)*sx, dy=(z.y-q.y)*sy; cand.push({d:Math.hypot(dx,dy), w:z.w}); }
      }
      cand.sort((a,b)=>a.d-b.d);
      let c=0,d=10;
      for(const z of cand){ c+=z.w; if(c>=need){ d=z.d; break; } }
      if(c>=need){ kth.push(d); break; }
    }
    if(kth.length<i+1) kth.push(10);
  }
  kth.sort((a,b)=>a-b);
  return Math.max(3,Math.min(40,+(kth[kth.length>>1]||10).toFixed(1)));
}
function ltAutoR_scott(pts, kx, ky){ const n=pts.reduce((a,p)=>a+p.w,0); if(n<3) return 10; let mx=0,my=0; for(const p of pts){ mx+=p.w*p.x; my+=p.w*p.y; } mx/=n; my/=n;
  let vx=0,vy=0; for(const p of pts){ vx+=p.w*(p.x-mx)**2; vy+=p.w*(p.y-my)**2; } const s=Math.sqrt((vx*kx*kx+vy*ky*ky)/(2*n));
  return Math.max(3, Math.min(60, s*Math.pow(n,-1/6))); }
const niceNum=v=>{ if(!(v>0)) return 0; const e=Math.pow(10,Math.floor(Math.log10(v))), f=v/e; return +((f<1.5?1:f<2.25?2:f<3.5?2.5:f<7.5?5:10)*e).toPrecision(3); };
function ltThresholds(field){ const a=[]; let mx=0; for(let i=0;i<field.length;i+=2){ const v=field[i]; if(v>mx) mx=v; } const eps=mx*0.02; for(let i=0;i<field.length;i+=2) if(field[i]>eps) a.push(field[i]); a.sort((x,y)=>x-y);
  if(!a.length) return {t:[0,0,0], mx, eps:0};
  const q=f=>a[Math.min(a.length-1,Math.floor(f*(a.length-1)))]; let t=[niceNum(q(0.5)), niceNum(q(0.8)), niceNum(q(0.95))];
  for(let k=1;k<3;k++) if(!(t[k]>t[k-1])) t[k]=niceNum(t[k-1]*2.2); return {t, mx, eps}; }
function ltColor(v, T){ const [t1,t2,t3]=T.t; if(!(v>T.eps)) return null;
  const mix=(a,b,f)=>[0,1,2].map(i=>Math.round(a[i]+(b[i]-a[i])*Math.max(0,Math.min(1,f))));
  const lf=(v,a,b)=> b>a ? (Math.log(Math.max(v,1e-12))-Math.log(Math.max(a,1e-12)))/(Math.log(b)-Math.log(Math.max(a,1e-12))) : 1;
  if(v<t1) return mix([170,210,255], LT_COLS[0], lf(v, T.eps||t1/10, t1));
  if(v<t2) return mix(LT_COLS[0], LT_COLS[1], lf(v,t1,t2));
  if(v<t3) return mix(LT_COLS[1], LT_COLS[2], lf(v,t2,t3));
  return mix(LT_COLS[2], LT_COLS[3], lf(v,t3,Math.max(t3*1.0001,T.mx))); }
// زمان هر فریم از روی خود فریم (ساعت و دقیقه)؛ خوانش‌های پرت با برازش خطی جایگزین می‌شوند
function ltFrameTimes(tA, tB){
  const E=lt.streamE, n=E.n;
  if(E.real && E.times.every(t=>t!==null)) return {t:E.times.slice(), step:E.step||3e5, real:true};
  const step=tA&&tB&&n>1?(+tB-+tA)/(n-1):3e5, a0=tA?+tA:0; return {t:Array.from({length:n},(_,k)=>a0+k*step),step,real:!!(tA&&tB)};
}
// ردیابی توده‌های تندری (شبیه روش‌های ردیابی سلول: خوشه‌بندی مکانی رعدهای هر فریم، سپس پیوند خوشه‌ها در زمان)
// ۱) در هر فریم، رعدهایی که فاصله‌شان کمتر از Ds کیلومتر است یک «تکهٔ توده» می‌سازند (DBSCAN وزنی)
// ۲) تکه‌ها در فریم‌های بعدی (حداکثر Gt دقیقه فاصله) به نزدیک‌ترین توده‌ای که با سرعت معقول به آن می‌رسد وصل می‌شوند؛
//    اگر یک منطقه پس از وقفه‌ای طولانی‌تر از Gt دوباره فعال شود، تودهٔ جداگانه حساب می‌شود
// ۳) مسیر هر توده = برازش خطی مرکز ثقل تکه‌ها بر زمان؛ توده‌های پهن چند پیکان موازی دارند
function ltTracks(E, T, kx, ky){
  // bin>0: رعدها در بازه‌های bin دقیقه‌ای (مثلاً ۳۰) خوشه‌بندی می‌شوند؛ هر بازه تراکم پایدارتری می‌دهد و توده‌های واحد بهتر دیده می‌شوند
  const O=self.LT_TRK||{}, bin=O.bin??0, Ds=O.Ds??15, Gt=O.Gt??(bin?2*bin+1:20), vmax=O.vmax??1.2, Rs=O.Rs??12, minW=O.minW??2;   // کیلومتر، دقیقه، کیلومتر بر دقیقه
  const tFirst=Math.min(...T)/6e4;
  const P_=E.pts.map((p,i)=>{ const t=T[p.k]/6e4; return {x:p.x, y:p.y, w:p.w, t, k: bin ? Math.floor((t-tFirst)/bin+1e-9) : p.k, i}; });
  const byK=new Map(); for(const p of P_){ if(!byK.has(p.k)) byK.set(p.k,[]); byK.get(p.k).push(p); }
  const dist=(a,b)=>Math.hypot((a.x-b.x)*kx,(a.y-b.y)*ky);
  // ۱) تکه‌های هر فریم
  const snaps=[];
  for(const k of [...byK.keys()].sort((a,b)=>a-b)){ const ps=byK.get(k), n=ps.length, lab=new Int32Array(n).fill(-1); let nc=0;
    const nb=ps.map((a,i)=>{ const l=[]; for(let j=0;j<n;j++) if(j!==i && dist(a,ps[j])<=Ds) l.push(j); return l; });
    const core=ps.map((a,i)=>a.w+nb[i].reduce((s,j)=>s+ps[j].w,0)>=minW);
    for(let i=0;i<n;i++){ if(lab[i]>=0||!core[i]) continue; lab[i]=nc; const st=[i]; while(st.length){ const a=st.pop(); if(!core[a]) continue; for(const j of nb[a]) if(lab[j]<0){ lab[j]=nc; st.push(j); } } nc++; }
    for(let i=0;i<n;i++) if(lab[i]<0) lab[i]=nc++;    // رعد منفرد = تکهٔ کوچک (اگر بعداً به توده‌ای نپیوندد، به‌تنهایی شمرده نمی‌شود)
    const g=Array.from({length:nc},()=>[]); ps.forEach((p,i)=>g[lab[i]].push(p));
    for(const q of g){ let W=0,x=0,y=0,tt=0; for(const p of q){ W+=p.w; x+=p.w*p.x; y+=p.w*p.y; tt+=p.w*p.t; } x/=W; y/=W; tt/=W; let r=0; for(const p of q) r=Math.max(r, dist(p,{x,y}));
      snaps.push({k, t: bin ? tt : q[0].t, x, y, W, r, pts:q}); } }
  // ۲) پیوند زمانی
  const tracks=[]; snaps.sort((a,b)=>a.t-b.t || b.W-a.W);
  const frames=[...new Set(snaps.map(s=>s.k))].sort((a,b)=>a-b);
  for(const k of frames){ const cur=snaps.filter(s=>s.k===k).sort((a,b)=>b.W-a.W), taken=new Set();
    for(const s of cur){ let best=null, bd=Infinity;
      for(const tr of tracks){ if(taken.has(tr)) continue; const L=tr.snaps[tr.snaps.length-1], dt=s.t-L.t; if(dt<=0 || dt>Gt) continue;
        // مکان پیش‌بینی‌شده با سرعت فعلی توده
        const px=L.x+(tr.vx||0)*dt/kx, py=L.y+(tr.vy||0)*dt/ky, d=Math.min(dist(s,{x:px,y:py}), dist(s,L)), lim=Rs+Math.max(L.r,s.r)*0.6+vmax*dt;
        if(d<=lim && d/lim<bd){ bd=d/lim; best=tr; } }
      if(best){ const L=best.snaps[best.snaps.length-1], dt=s.t-L.t; const vx=(s.x-L.x)*kx/dt, vy=(s.y-L.y)*ky/dt;
        best.vx = best.vx===undefined ? vx : 0.6*best.vx+0.4*vx; best.vy = best.vy===undefined ? vy : 0.6*best.vy+0.4*vy; best.snaps.push(s); taken.add(best); }
      else tracks.push({snaps:[s]}); } }
  // ۳) توده‌ها و پیکان‌ها
  const cells=[], arrows=[];
  const fit=ps=>{ let W=0,t=0,x=0,y=0; for(const p of ps){ W+=p.w; t+=p.w*p.t; x+=p.w*p.x*kx; y+=p.w*p.y*ky; } t/=W; x/=W; y/=W;
    let stt=0,stx=0,sty=0; for(const p of ps){ const dt=p.t-t; stt+=p.w*dt*dt; stx+=p.w*dt*(p.x*kx-x); sty+=p.w*dt*(p.y*ky-y); }
    return {W,t,x,y,vx:stt>0?stx/stt:0, vy:stt>0?sty/stt:0}; };
  for(const tr of tracks){ const g=tr.snaps.flatMap(s=>s.pts), W=g.reduce((a,p)=>a+p.w,0);
    if(W<3) continue;                                              // کمتر از ۳ رعد در کل عمر: توده شمرده نمی‌شود
    const tmin=tr.snaps[0].t, tmax=tr.snaps[tr.snaps.length-1].t, F=fit(g), nfr=tr.snaps.length;
    let good = nfr>=2 && tmax-tmin>=9 && 60*Math.hypot(F.vx,F.vy)<=110;
    const cell={n:W, frames:nfr, tmin, tmax, vx:good?F.vx:0, vy:good?F.vy:0, x:F.x, y:F.y, arrows:[], pts:g.map(p=>[p.x,p.y]), still:false,
      r:Math.max(...tr.snaps.map(s=>s.r))};
    cells.push(cell);
    const sp=Math.hypot(F.vx,F.vy)*(tmax-tmin);                    // جابه‌جایی کل (کیلومتر)
    if(!good || sp<6){ cell.still=true; const m=tr.snaps.reduce((a,s)=>a.W>s.W?a:s); arrows.push({still:true, x0:m.x, y0:m.y, x1:m.x, y1:m.y, t0:tmin, t1:tmax, tm:tmin, n:W, cell:cells.length-1}); cell.arrows.push(arrows[arrows.length-1]); continue; }
    const v=Math.hypot(F.vx,F.vy), ux=-F.vy/v, uy=F.vx/v;
    const pr=g.map(p=>({p, s:(p.x*kx-F.x)*ux+(p.y*ky-F.y)*uy})).sort((a,b)=>a.s-b.s);
    const q=f=>pr[Math.min(pr.length-1,Math.max(0,Math.round(f*(pr.length-1))))].s, width=q(0.95)-q(0.05);
    const nb=Math.max(1, Math.min(4, Math.ceil(width/45)));
    const bands = nb===1 ? [g] : Array.from({length:nb},(_,b)=>pr.slice(Math.floor(b*pr.length/nb), Math.floor((b+1)*pr.length/nb)).map(o=>o.p));
    for(const bp of bands){ if(!bp.length || bp.reduce((a,p)=>a+p.w,0)<2) continue;
      const B=fit(bp), sorted=bp.slice().sort((p,q)=>p.t-q.t), t0=sorted[0].t, t1=sorted[sorted.length-1].t; if(t1-t0<5) continue;
      // ابتدا و انتها روی خط برازش‌شده (مرکز ثقل + سرعت توده × زمان)
      const x0=(B.x+F.vx*(t0-B.t))/kx, y0=(B.y+F.vy*(t0-B.t))/ky, x1=(B.x+F.vx*(t1-B.t))/kx, y1=(B.y+F.vy*(t1-B.t))/ky;
      const a={x0, y0, x1, y1, t0, t1, tm:t0, n:B.W, cell:cells.length-1}; cell.arrows.push(a); arrows.push(a); } }
  let sx=0, sy=0, sw=0, sv=0; for(const c of cells){ if(c.still) continue; const w=c.n; sx+=w*c.vx; sy+=w*c.vy; sv+=w*Math.hypot(c.vx,c.vy); sw+=w; }
  const dom = sw ? {vx:sx/sw, vy:sy/sw, speed:60*sv/sw, speedVec:60*Math.hypot(sx,sy)/sw} : null;
  return {cells, arrows, dom, tStart:Math.min(...P_.map(p=>p.t)), tEnd:Math.max(...P_.map(p=>p.t))};
}
// جهت به سمتِ … (بردار حرکت؛ y پیکسلی رو به پایین است)
function ltDirName(vx, vy){
  const ang=(Math.atan2(vx, -vy)*180/Math.PI+360)%360, names=["شمال","شمال‌شمال‌شرق","شمال‌شرق","شرق‌شمال‌شرق","شرق","شرق‌جنوب‌شرق","جنوب‌شرق","جنوب‌جنوب‌شرق","جنوب","جنوب‌جنوب‌غرب","جنوب‌غرب","غرب‌جنوب‌غرب","غرب","غرب‌شمال‌غرب","شمال‌غرب","شمال‌شمال‌غرب"];
  return {ang, name:names[Math.round(ang/22.5)%16]};
}
const LT_ARROW="#1d3fd1", LT_POLY="#d0006f", LT_POLY_FILL="rgba(208,0,111,0.13)";
function ltHull(pts, pad){
  const P_=[...new Map(pts.map(p=>[Math.round(p[0]*2)+","+Math.round(p[1]*2), p])).values()].sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
  if(!P_.length) return [];
  const cr=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);
  let H=P_;
  if(P_.length>=3){ const lo=[], up=[]; for(const p of P_){ while(lo.length>=2 && cr(lo[lo.length-2],lo[lo.length-1],p)<=0) lo.pop(); lo.push(p); }
    for(let i=P_.length-1;i>=0;i--){ const p=P_[i]; while(up.length>=2 && cr(up[up.length-2],up[up.length-1],p)<=0) up.pop(); up.push(p); }
    up.pop(); lo.pop(); H=lo.concat(up); }
  const cx=H.reduce((s,p)=>s+p[0],0)/H.length, cy=H.reduce((s,p)=>s+p[1],0)/H.length;
  if(H.length<3){ const r=pad+3, out=[]; for(let k=0;k<12;k++){ const a=k*Math.PI/6; out.push([cx+r*Math.cos(a)+(H.length>1?(H[1][0]-H[0][0])/2*Math.cos(a)*Math.cos(a):0), cy+r*Math.sin(a)]); } return out; }
  return H.map(([x,y])=>{ const dx=x-cx, dy=y-cy, d=Math.hypot(dx,dy)||1; return [x+dx/d*pad, y+dy/d*pad]; });
}
// رنگ سن: قدیمی‌تر آبی ← فیروزه‌ای ← سبز ← نارنجی ← قرمز ← ارغوانی (جدیدتر)؛ بدون سیاه
const LT_AGE=[[37,99,235],[6,166,196],[22,163,74],[234,140,0],[230,40,30],[200,20,140]];
function ltAgeCol(f){ f=Math.max(0,Math.min(1,f)); const s=f*(LT_AGE.length-1), i=Math.min(LT_AGE.length-2,Math.floor(s)), u=s-i, a=LT_AGE[i], b=LT_AGE[i+1]; return [0,1,2].map(k=>Math.round(a[k]+(b[k]-a[k])*u)); }
function ltArrow(ctx, x0, y0, x1, y1, col, lw){
  let dx=x1-x0, dy=y1-y0, L=Math.hypot(dx,dy);
  if(L<20){ const ux=L>0.01?dx/L:1, uy=L>0.01?dy/L:0; x1=x0+20*ux; y1=y0+20*uy; dx=x1-x0; dy=y1-y0; L=20; }   // پیکان کوتاه از نقطهٔ شروع، در همان جهت، تا دیده شود
  const ux=dx/L, uy=dy/L, h=Math.min(13, 8+L*0.12), hw=h*0.5;
  const path=()=>{ ctx.beginPath(); ctx.moveTo(x0,y0); ctx.lineTo(x1-ux*h*0.75, y1-uy*h*0.75); };
  const head=()=>{ ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x1-ux*h-uy*hw, y1-uy*h+ux*hw); ctx.lineTo(x1-ux*h*0.72, y1-uy*h*0.72); ctx.lineTo(x1-ux*h+uy*hw, y1-uy*h-ux*hw); ctx.closePath(); };
  ctx.save(); ctx.lineCap="round"; ctx.lineJoin="round"; ctx.globalAlpha=0.88;
  // حاشیهٔ تیرهٔ نازک با سایهٔ نرم (حالت برجسته)، بدون هالهٔ سفید
  ctx.shadowColor="rgba(0,0,0,0.35)"; ctx.shadowBlur=3; ctx.shadowOffsetX=1; ctx.shadowOffsetY=1.5;
  ctx.strokeStyle="rgba(20,22,30,0.95)"; ctx.lineWidth=lw+1.6; path(); ctx.stroke(); head(); ctx.stroke(); ctx.fillStyle="rgba(20,22,30,0.95)"; head(); ctx.fill();
  ctx.shadowColor="transparent";
  ctx.strokeStyle=col; ctx.fillStyle=col; ctx.lineWidth=lw; path(); ctx.stroke(); head(); ctx.fill();
  // نوار روشن باریک روی پیکان برای حس سه‌بعدی
  ctx.globalAlpha=0.35; ctx.strokeStyle="#fff"; ctx.lineWidth=Math.max(0.6,lw*0.28); ctx.beginPath(); ctx.moveTo(x0-uy*lw*0.22, y0+ux*lw*0.22); ctx.lineTo(x1-ux*h*0.9-uy*lw*0.22, y1-uy*h*0.9+ux*lw*0.22); ctx.stroke();
  ctx.restore();
}
// کادر شمارش در گوشهٔ پایین‌چپِ داخل کادر نقشه
function ltBadge(ctx, E, lines){
  const pad=7, lh=19; ctx.save(); ctx.font=`bold 14px ${FT.body}`; let w=0; for(const l of lines) w=Math.max(w, ctx.measureText(l).width);
  const bw=w+2*pad, bh=lines.length*lh+pad, x=E.fx0+6, y=E.fy1-bh-6;
  ctx.fillStyle="rgba(255,255,255,0.9)"; ctx.strokeStyle="#555"; ctx.lineWidth=1; ctx.beginPath(); ctx.rect(x+.5,y+.5,bw,bh); ctx.fill(); ctx.stroke(); ctx.restore();
  lines.forEach((l,k)=>txt(ctx, l, x+bw/2, y+pad+lh*(k+1)-5, `bold 14px ${FT.body}`, {align:"center", color:"#111"}));
}

// نقشهٔ خروجی در قالب weather.us (۷۶۰×۷۶۰) با مقیاس دلخواه و مرزبندی زوم
function renderLT(o){
  const sc=o.scale||1, W=o.W, H=o.H, E=o.E, cv=document.createElement("canvas"); cv.width=W*sc; cv.height=H*sc;
  const ctx=cv.getContext("2d"); ctx.scale(sc,sc); ctx.imageSmoothingQuality="high"; ctx.fillStyle="#fff"; ctx.fillRect(0,0,W,H);
  const dark=o.bg==="dark", BG=dark?[74,74,74]:[244,244,240];
  const FW=E.FW, FH=E.FH, c=document.createElement("canvas"); c.width=FW*sc; c.height=FH*sc; const x=c.getContext("2d"), im=x.createImageData(c.width,c.height), dd=im.data;
  if(o.kind==="strokes"){ const sym=dark?[255,255,255]:(o.symCol||[200,0,0]);
    for(let Y=0;Y<c.height;Y++) for(let X=0;X<c.width;X++){ const fx=(X+0.5)/sc-0.5, fy=(Y+0.5)/sc-0.5, x0=Math.max(0,Math.floor(fx)), y0=Math.max(0,Math.floor(fy)), x1=Math.min(FW-1,x0+1), y1=Math.min(FH-1,y0+1), tx=Math.max(0,fx-x0), ty=Math.max(0,fy-y0);
      const g=(xx,yy)=>E.union[Math.min(E.FH-1,Math.max(0,yy))*E.FW+Math.min(E.FW-1,Math.max(0,xx))]; const a=(g(x0,y0)*(1-tx)+g(x1,y0)*tx)*(1-ty)+(g(x0,y1)*(1-tx)+g(x1,y1)*tx)*ty, al=sc>1?Math.max(0,Math.min(1,(a-0.25)*2)):a, q=(Y*c.width+X)*4;
      for(let k=0;k<3;k++) dd[q+k]=Math.round(BG[k]*(1-al)+sym[k]*al); dd[q+3]=255; } }
  else if(o.kind==="tracks"||o.kind==="blank"){ for(let q=0;q<dd.length;q+=4){ dd[q]=BG[0]; dd[q+1]=BG[1]; dd[q+2]=BG[2]; dd[q+3]=255; } }
  else { const f=o.field, T=o.T;
    for(let Y=0;Y<c.height;Y++) for(let X=0;X<c.width;X++){ const fx=Math.min(FW-1,Math.max(0,(X+0.5)/sc-0.5)), fy=Math.min(FH-1,Math.max(0,(Y+0.5)/sc-0.5)), x0=Math.floor(fx), y0=Math.floor(fy), x1=Math.min(FW-1,x0+1), y1=Math.min(FH-1,y0+1), tx=fx-x0, ty=fy-y0;
      const v=(f[y0*FW+x0]*(1-tx)+f[y0*FW+x1]*tx)*(1-ty)+(f[y1*FW+x0]*(1-tx)+f[y1*FW+x1]*tx)*ty, col=ltColor(v,T)||BG, q=(Y*c.width+X)*4; dd[q]=col[0]; dd[q+1]=col[1]; dd[q+2]=col[2]; dd[q+3]=255; } }
  x.putImageData(im,0,0); ctx.drawImage(c, E.fx0, E.fy0, FW, FH);
  // فقط در نقشهٔ جهت حرکت توده‌ها، لایهٔ مرزها کمی شفاف است تا پیکان‌ها بهتر دیده شوند
  if(o.overlay){ ctx.save(); ctx.beginPath(); ctx.rect(E.fx0,E.fy0,FW,FH); ctx.clip(); if(o.kind==="tracks") ctx.globalAlpha=0.55; drawOv(ctx, o.overlay, W, H); ctx.restore(); }
  if(o.kind==="tracks"){ const TR=o.tracks, span=Math.max(1e-6, TR.tEnd-TR.tStart);
    ctx.save(); ctx.beginPath(); ctx.rect(E.fx0,E.fy0,FW,FH); ctx.clip();
    const col=a=>`rgb(${ltAgeCol((a.t0-TR.tStart)/span).join(",")})`;
    // توده‌های ساکن: دایرهٔ کوچک به رنگ زمان
    /* توده‌های ساکن روی نقشهٔ جهت حرکت رسم نمی‌شوند؛ فقط در متن شمارش می‌شوند */
    // ترتیب رسم: قدیمی‌تر زیر، جدیدتر رو
    for(const a of TR.arrows.filter(a=>!a.still).sort((p,q)=>p.t0-q.t0)) ltArrow(ctx, E.fx0+a.x0, E.fy0+a.y0, E.fx0+a.x1, E.fy0+a.y1, col(a), Math.min(4.2, 2.2+Math.log10(1+a.n)*0.9));
    ctx.restore(); }
  if(o.badge) ltBadge(ctx, E, o.badge);
  ctx.strokeStyle="#000"; ctx.lineWidth=2; ctx.strokeRect(E.fx0-1,E.fy0-1,FW+2,FH+2);
  // سربرگ پایین، مثل weather.us
  const R=W-18, L=18, S=o.S, hy=E.fy1+1;
  ctx.font=`15px ${FT.body}`; const dw=Math.max(ctx.measureText(o.t1||"").width, ctx.measureText(o.t2||"").width);
  txt(ctx, o.title, R, hy+39, `21px ${FT.titr}`, {maxW: R-L-dw-24});
  txt(ctx, o.t1||"", L, hy+29, `15px ${FT.body}`, {align:"left", color:"#222"}); txt(ctx, o.t2||"", L, hy+47, `15px ${FT.body}`, {align:"left", color:"#222"});
  const by0=hy+57, bh=18, bx0=30, bx1=W-18;
  if(o.kind==="strokes"){
    const sym=dark?"#fff":`rgb(${(o.symCol||[200,0,0]).join(",")})`; ctx.fillStyle=dark?"rgb(74,74,74)":"rgb(244,244,240)"; ctx.fillRect(bx1-120, by0, 120, bh); ctx.strokeStyle="#000"; ctx.lineWidth=1; ctx.strokeRect(bx1-119.5, by0+.5, 119, bh);
    ctx.strokeStyle=sym; ctx.lineWidth=3; ctx.beginPath(); ctx.moveTo(bx1-60-6,by0+9); ctx.lineTo(bx1-60+6,by0+9); ctx.moveTo(bx1-60,by0+3); ctx.lineTo(bx1-60,by0+15); ctx.stroke();
    txt(ctx, o.legend||"", bx1-130, by0+14, `16px ${FT.body}`, {color:"#111"});
  } else if(o.kind==="blank"){
    const yy=by0+bh/2; ctx.fillStyle="#e00000"; ctx.strokeStyle="#5a0000"; ctx.beginPath(); ctx.arc(bx1-14,yy,5,0,2*Math.PI); ctx.fill(); ctx.stroke();
    txt(ctx, "رعد در همین بازه", bx1-24, yy+5, `14px ${FT.body}`, {align:"right", color:"#111"});
    ctx.fillStyle="rgba(120,120,120,.8)"; ctx.beginPath(); ctx.arc(bx1-200,yy,3,0,2*Math.PI); ctx.fill();
    txt(ctx, "رعدهای بازه‌های قبل", bx1-210, yy+5, `14px ${FT.body}`, {align:"right", color:"#111"});
  } else if(o.kind==="tracks"){
    // راهنما: پیکان = مسیر حرکت، چندضلعی = محدودهٔ فعالیت
    // نوار رنگ زمان شروع توده‌ها + نمونهٔ پیکان و نماد تودهٔ ساکن
    const gx0=bx0+150, gx1=bx1-10, yy=by0+bh/2+2;
    const gr=ctx.createLinearGradient(gx0,0,gx1,0); for(let k=0;k<=10;k++) gr.addColorStop(k/10, `rgb(${ltAgeCol(k/10).join(",")})`);
    ctx.fillStyle=gr; ctx.fillRect(gx0,by0,gx1-gx0,bh); ctx.strokeStyle="#000"; ctx.lineWidth=1; ctx.strokeRect(gx0+.5,by0+.5,gx1-gx0,bh);
    (o.ticks||[]).forEach(([f,l])=>{ const px=gx0+f*(gx1-gx0); txt(ctx, l, Math.min(gx1-14,Math.max(gx0+14,px)), by0+bh+15, `13px ${FT.lal}`, {align:"center", color:"#111", dir:"ltr"}); });
    txt(ctx, o.unit||"", (gx0+gx1)/2, by0-4, `12.5px ${FT.body}`, {align:"center", color:"#333"});
    ltArrow(ctx, bx0+8, yy, bx0+70, yy, `rgb(${ltAgeCol(0.5).join(",")})`, 3);
    txt(ctx, "مسیر توده", bx0+76, yy+5, `12.5px ${FT.body}`, {align:"left", color:"#222"});
  } else {
    const gw=36, x0=bx0+gw+8, x1=bx1, T=o.T, q=(x1-x0)/4;
    ctx.fillStyle="#9e9e9e"; ctx.fillRect(bx0,by0,gw,bh); ctx.strokeStyle="#000"; ctx.lineWidth=1; ctx.strokeRect(bx0+.5,by0+.5,gw,bh);
    txt(ctx, "بدون رعدوبرق", bx0+gw/2, by0+bh+16, `12px ${FT.body}`, {align:"center", color:"#222"});
    const anchors=[[x0,[170,210,255]],[x0+q,LT_COLS[0]],[x0+2*q,LT_COLS[1]],[x0+3*q,LT_COLS[2]],[x1,LT_COLS[3]]];
    const gr=ctx.createLinearGradient(x0,0,x1,0); for(const [px,col] of anchors) gr.addColorStop((px-x0)/(x1-x0), `rgb(${col.join(",")})`);
    ctx.fillStyle=gr; ctx.fillRect(x0,by0,x1-x0,bh); ctx.strokeRect(x0+.5,by0+.5,x1-x0,bh);
    const labs=["کم","متوسط","زیاد","خیلی زیاد"]; labs.forEach((l,k)=>txt(ctx, l, x0+q*(k+0.5), by0+bh+16, `13px ${FT.body}`, {align:"center", color:"#333"}));
    T.t.forEach((v,k)=>{ const px=x0+q*(k+1); ctx.beginPath(); ctx.moveTo(px+.5,by0); ctx.lineTo(px+.5,by0+bh+4); ctx.strokeStyle="#000"; ctx.stroke(); txt(ctx, ltFmt(v), px, by0-4, `13px ${FT.lal}`, {align:"center", color:"#111", dir:"ltr"}); });
    txt(ctx, o.unit||"", x1, by0-4, `12px ${FT.body}`, {align:"right", color:"#444", maxW:(x1-x0)*0.2});
  }
  txt(ctx, o.info1||"", L, H-29, `15px ${FT.body}`, {align:"left", color:"#111", maxW:470});
  txt(ctx, o.info2||"", L, H-9, `13px ${FT.body}`, {align:"left", color:"#333", maxW:470});
  const lx0=W-240, ly0=H-46, lw=R-lx0, lh=42;
  drawBrand(ctx, S, lx0, ly0-4, lw, lh+6, {side:true, align:"right", fs:14});
  cv.__lt=o; return cv;
}
const ltFmt=v=>{ if(!(v>0)) return "0"; const s = v>=100 ? Math.round(v) : v>=10 ? +v.toFixed(1) : v>=1 ? +v.toFixed(2) : +v.toPrecision(2); return FA(s); };
async function ltRun(){
  if(lt.busy || !lt.streamE) return; lt.busy=true;
  try{
    ltStatus("استخراج رعدهای سفید از فریم‌ها…", 0.2); await tick();
    const E=lt.streamE, W=lt.w, H=lt.h;
    // زمان فریم‌های اول و آخر و نام زوم
    const f0={data:lt.firstData, w:W, h:H, file:{name:lt.files[0]||""}}, fN={...f0, data:lt.lastData};
    let t0=null, tN=null; try{ t0=readTimes(f0); tN=readTimes(fN); }catch(e){}
    const tA=t0&&(t0.end||t0.valid), tB=tN&&(tN.end||tN.valid), hrs = tA&&tB ? Math.max(1/12,(+tB-+tA)/3.6e6 + 5/60) : lt.streamE.n*5/60;
    try{ if(!CV_OCR_T) await cvOcrFonts(); }catch(e){}
    let zoom=null, geo=null; try{ f0.prof=cvProfile({...f0}); }catch(e){}
    if(W===760&&H===760){ zoom = wuZoomOCR(f0) || wuSigRegion(f0.data); }
    ltStatus("یافتن مقیاس و مکان نقشه…", 0.4); await tick();
    try{ if(f0.prof && !(zoom && WU_ZOOM_GEO[zoom])){ geo=await cvGeo(f0); } }catch(e){}
    let kx, ky, scaleSrc;
    const userKm=parseFloat($("ltKm").value);
    if(userKm>0){ kx=ky=userKm; scaleSrc="دستی"; }
    else if(zoom && WU_ZOOM_GEO[zoom]){ const g=WU_ZOOM_GEO[zoom], latc=(E.fy0+E.FH/2-g[2])/g[3]; kx=111.32*Math.cos(latc*Math.PI/180)/Math.abs(g[1]); ky=110.57/Math.abs(g[3]); scaleSrc=`از زمین‌مرجع زوم «${zoom}»`; geo=g; }
    else if(geo){ const latc=(E.fy0+E.FH/2-geo[2])/geo[3]; kx=111.32*Math.cos(latc*Math.PI/180)/Math.abs(geo[1]); ky=110.57/Math.abs(geo[3]); scaleSrc="از مکان‌یابی خودکار نقشه"; }
    else { const lat=32, bx=WU_GEO[1]*(zoom&&zoom!=="ایران"?2.2:1); kx=111.32*Math.cos(lat*Math.PI/180)/bx; ky=110.57/Math.abs(WU_GEO[3]*(zoom&&zoom!=="ایران"?2.2:1)); scaleSrc="تقریبی (مکان نقشه پیدا نشد؛ مقیاس را دستی وارد کنید)"; }
    const nS=E.pts.reduce((a,p)=>a+p.w,0), method=$("ltMethod").value, alpha=parseFloat($("ltAlpha").value)||0.5, perH=$("ltUnit").value==="h";
    const rAuto=ltAutoR(E.pts, kx, ky), rTxt=$("ltRadii").value.trim();
    let radii = rTxt ? rTxt.split(/[,،\s]+/).map(parseFloat).filter(v=>v>0) : [];
    if(!radii.length) radii=[Math.max(2,+(rAuto/2).toFixed(1)), +rAuto.toFixed(1), +(rAuto*2).toFixed(1)];
    const tStr = tA&&tB ? [`از ${persianDT(tA,210)} به وقت ایران`, `تا ${persianDT(tB,210)} (${FA(lt.streamE.n)} فریم)`] : [`${FA(lt.streamE.n)} فریم`, ""];
    const S={brand:$("brand").value.trim(), handle:$("handle").value.trim(), logoImg:state.logoImg};
    const zl = zoom ? " — "+zoom : "";
    await document.fonts.ready;
    ltStatus("نقشهٔ رعدهای تجمعی…", 0.6); await tick();
    const base={W, H, E, S, bg:$("ltBg").value, symCol:hexRGB($("ltSym").value), t1:tStr[0], t2:tStr[1], zoom};
    const strokes=renderLT({...base, kind:"strokes", badge:[`تعداد کل رعدوبرق: ${FA(nS)}`], title:"رعدوبرق‌های ثبت‌شده"+zl, legend:`رعد (${FA(nS)} مورد)`, info1:`مجموع: ${FA(nS)} رعدوبرق در ${FA(Math.round(hrs*60))} دقیقه`, info2:`فقط رعدهای تازه (سفید) هر فریم؛ مقیاس ${scaleSrc}`, overlay:wuOverlay(zoom)});
    // مسیر حرکت توده‌های تندری
    ltStatus("ردیابی توده‌های تندری…", 0.65); await tick();
    const FT_=ltFrameTimes(tA, tB), spanM=(Math.max(...FT_.t)-Math.min(...FT_.t))/6e4;
    // جهت و طول پیکان‌ها از تراکم‌های ۳۰ دقیقه‌ای (اگر زمان واقعی فریم‌ها خوانده شد و بازه دست‌کم ۶۰ دقیقه است)
    const useBin = FT_.real && spanM>=60; self.LT_TRK={...(self.LT_TRK||{}), bin: useBin?30:0};
    const TR=ltTracks(E, FT_.t, kx, ky); TR.bin=useBin?30:0;
    const hm=ms=>FA(new Date(ms+210*6e4).toISOString().slice(11,16)), msA=TR.tStart*6e4, msB=TR.tEnd*6e4;
    const ticks = FT_.real && isFinite(msA) ? [0,0.5,1].map(f=>[f, hm(msA+f*(msB-msA))]) : [];
    const nCell=TR.cells.length, nArr=TR.arrows.length, dir=TR.dom ? ltDirName(TR.dom.vx, TR.dom.vy) : null;
    const domTxt = dir ? `حرکت غالب به سمت ${dir.name}، حدود ${FA(Math.round(TR.dom.speedVec))} کیلومتر بر ساعت` : "جهت غالب مشخص نشد";
    const tracks=renderLT({...base, kind:"tracks", tracks:TR, ticks, unit: FT_.real ? "زمان شروع توده (به وقت ایران)" : "ترتیب فریم‌ها", badge:[`رعدوبرق: ${FA(nS)}`, `تودهٔ تندری: ${FA(nCell)} (${FA(TR.cells.filter(c=>!c.still).length)} متحرک، ${FA(TR.cells.filter(c=>c.still).length)} ساکن)`], title:"جهت حرکت توده‌های تندری"+zl, info1:domTxt, info2:`ابتدای پیکان = شروع رعدوبرق، نوک پیکان = پایان · ${FA(nArr)} پیکان`, overlay:wuOverlay(zoom)});
    const MN={gauss:"KDE گاوسی", tophat:"قطع تیز (دیسک)", quartic:"کرنل دومجذوری (Quartic)", epan:"کرنل اپانچنیکوف", adaptive:"KDE تطبیقی (آبرامسون)", grid:"شمارش شبکه‌ای"};
    const dens=[];
    for(const r of radii){ ltStatus(`تراکم با شعاع ${FA(r)} کیلومتر…`, 0.7); await tick();
      let f=ltDensity(E, method, r, kx, ky, alpha); if(perH) for(let i=0;i<f.length;i++) f[i]/=hrs;
      const T=ltThresholds(f), unit = perH ? "رعد در کیلومتر مربع در ساعت" : "رعد در کیلومتر مربع (کل بازه)";
      const cv_=renderLT({...base, kind:"density", field:f, T, unit, title:`تراکم رعدوبرق${zl}`, info1:`${MN[method]} · شعاع ${FA(r)} کیلومتر${Math.abs(r-rAuto)<0.05?" (خودکار)":""}${method==="adaptive"?` · توان α=${FA(alpha)}`:""}`, info2:`${FA(nS)} رعد · بیشینه ${ltFmt(T.mx)} ${unit}`, overlay:wuOverlay(zoom)});
      dens.push({r, field:f, T, cv:cv_, unit}); }
    lt.res={E, strokes, dens, nS, hrs, zoom, kx, ky, rAuto, method, per:E.per, tA, tB, tracks, TR, dir, domTxt, frameT:FT_, base:{...base, overlay:wuOverlay(zoom)}};
    ltShow(); try{ wuzSync(); }catch(e){} ltStatus(`${FA(nS)} رعدوبرق از ${FA(lt.streamE.n)} فریم استخراج شد`, 1);
  }catch(e){ console.error(e); ltStatus("خطا: "+e.message, 0); }
  lt.busy=false;
}
function ltShow(){
  const r=lt.res, box=$("ltCards"); box.replaceChildren(); $("ltEmpty").hidden=true;
  const dl=(label,name,make)=>{ const b=document.createElement("button"); b.className="btn"; b.type="button"; b.textContent=label; b.onclick=async()=>{ b.disabled=true; await tick(); try{ const blob=await make(); const u=URL.createObjectURL(blob), a=document.createElement("a"); a.href=u; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),3000); }catch(e){ console.error(e); } b.disabled=false; }; return b; };
  const c1=cvCard("نقشهٔ رعدوبرق‌های ثبت‌شده", "همهٔ رعدهای سفید (تازه) فریم‌ها از اول تا آخر انیمیشن، هر کدام در جای خود؛ بدون مرز، نام شهر و لوگوی سایت مبدأ", true);
  c1.img.src=r.strokes.toDataURL("image/png"); c1.img.alt="نقشهٔ رعدوبرق‌های ثبت‌شده";
  c1.sx.innerHTML=`<span>تعداد رعد<b>${FA(r.nS)}</b></span><span>مدت<b>${FA(Math.round(r.hrs*60))} دقیقه</b></span><span>مقیاس<b>${FA(+r.kx.toFixed(2))} کیلومتر در پیکسل</b></span>`;
  c1.dl.append(dl("PNG","lightning_strokes.png",()=>exportPNG(r.strokes)), dl("GIF ۳۰ دقیقه‌ای · ۲۴۰","lightning_30min_240.gif",()=>ltGif(r,30,240)), dl("GIF ۳۰ دقیقه‌ای · ۳۲۰","lightning_30min_320.gif",()=>ltGif(r,30,320)), dl("GIF ۳۰ دقیقه‌ای · ۴۸۰","lightning_30min_480.gif",()=>ltGif(r,30,480)), dl("CSV نقاط","lightning_points.csv",async()=>new Blob(["x_px,y_px,count,frame\n"+r.E.pts.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)},${p.w},${p.k+1}`).join("\n")],{type:"text/csv"})));
  const c2=cvCard("نقشهٔ تراکم رعدوبرق", "تعداد رعد در کیلومتر مربع با روش تراکم نقطه‌ای؛ شعاع بزرگ‌تر خوشه‌ها را پیوسته‌تر و شعاع کوچک‌تر جزئیات محلی را نشان می‌دهد", true);
  const tabs=document.createElement("div"); tabs.className="cvtabs"; c2.card.insertBefore(tabs, c2.img);
  const setR=k=>{ const d=r.dens[k]; c2.img.src=d.cv.toDataURL("image/png"); c2.img.alt=`تراکم رعدوبرق، شعاع ${d.r} کیلومتر`;
    tabs.querySelectorAll("button").forEach((b,i)=>b.setAttribute("aria-selected", i===k?"true":"false"));
    c2.sx.innerHTML=`<span>کم تا<b>${ltFmt(d.T.t[0])}</b></span><span>متوسط تا<b>${ltFmt(d.T.t[1])}</b></span><span>زیاد تا<b>${ltFmt(d.T.t[2])}</b></span><span>بیشینه<b>${ltFmt(d.T.mx)}</b></span>`;
    c2.dl.replaceChildren(dl("PNG",`lightning_density_${d.r}km.png`,()=>exportPNG(d.cv)), dl("CSV",`lightning_density_${d.r}km.csv`,async()=>{ const E=r.E, rows=["y_px,x_px,density"]; for(let y=0;y<E.FH;y+=2) for(let x=0;x<E.FW;x+=2) rows.push(`${y},${x},${d.field[y*E.FW+x].toPrecision(4)}`); return new Blob([rows.join("\n")],{type:"text/csv"}); })); };
  r.dens.forEach((d,k)=>{ const b=document.createElement("button"); b.type="button"; b.className="btn sm"; b.textContent=`شعاع ${FA(d.r)} کیلومتر${Math.abs(d.r-r.rAuto)<0.05?" (خودکار)":""}`; b.onclick=()=>setR(k); tabs.append(b); });
  setR(r.dens.findIndex(d=>Math.abs(d.r-r.rAuto)<0.05)>=0 ? r.dens.findIndex(d=>Math.abs(d.r-r.rAuto)<0.05) : 0);
  const c3=document.createElement("article"); c3.className="card wide"; c3.innerHTML=`<header><h3>رعد در هر فریم</h3><div class="sub">تعداد رعدهای تازهٔ شمرده‌شده در هر فریم (بخش‌های تکراریِ فریم قبل حذف شده‌اند)</div></header><p class="hint" style="padding:0 14px 12px;margin:0;direction:rtl">${r.per.map((n,k)=>LANG==="en"?`Frame ${k+1}: ${n}`:`فریم ${FA(k+1)}: ${FA(n)}`).join(" · ")}</p>`; if(LANG==="en") c3.querySelector("p.hint").style.direction="ltr";
  const c4=cvCard("جهت حرکت توده‌های تندری", LANG==="en" ? ((r.TR.bin ? `Strikes are grouped into ${r.TR.bin}-minute bins; strikes closer than 15 km in a bin form one cell, and cell centroids in consecutive bins (up to ${2*r.TR.bin} min apart) are linked at plausible speeds;` : "Strikes closer than 15 km in a frame form one cell, and pieces are linked for up to 20 minutes at plausible speeds;")+" a region that re-activates after a longer gap is treated as a new cell. The arrow tail is the start and the head the end of the cell track; arrow colour shows the start time; circle = nearly stationary cell; wide cells have several parallel arrows.") : (r.TR.bin ? `رعدها در بازه‌های ${FA(r.TR.bin)} دقیقه‌ای جمع می‌شوند و رعدهای نزدیک‌تر از ۱۵ کیلومتر در هر بازه یک توده‌اند؛ مرکز ثقل توده‌ها در بازه‌های پشت‌سرهم (تا ${FA(2*r.TR.bin)} دقیقه) با سرعت معقول به هم پیوند می‌خورد؛` : "رعدهای نزدیک‌تر از ۱۵ کیلومتر در هر فریم یک توده‌اند و تکه‌ها تا ۲۰ دقیقه با سرعت معقول به هم پیوند می‌خورند؛")+" اگر منطقه‌ای پس از وقفهٔ بیشتر دوباره فعال شود، تودهٔ جداگانه است. ابتدای پیکان شروع و نوک آن پایان مسیر توده است؛ رنگ پیکان زمان شروع توده را نشان می‌دهد؛ دایره = تودهٔ تقریباً ساکن؛ توده‌های پهن چند پیکان موازی دارند.", true);
  c4.img.src=r.tracks.toDataURL("image/png"); c4.img.alt="جهت حرکت توده‌های تندری";
  c4.sx.innerHTML=`<span>تودهٔ تندری<b>${FA(r.TR.cells.length)}</b></span><span>تودهٔ متحرک<b>${FA(r.TR.cells.filter(c=>!c.still).length)}</b></span><span>پیکان<b>${FA(r.TR.arrows.filter(a=>!a.still).length)}</b></span><span>رعدوبرق<b>${FA(r.nS)}</b></span><span>حرکت غالب<b>${r.dir?r.dir.name+" · "+FA(Math.round(r.TR.dom.speedVec))+" km/h":"—"}</b></span>`;
  c4.dl.append(dl("PNG","thunderstorm_tracks.png",()=>exportPNG(r.tracks)), dl("CSV پیکان‌ها","thunderstorm_tracks.csv",async()=>new Blob(["cell,x0_px,y0_px,x1_px,y1_px,start_utc,end_utc,strokes,speed_kmh\n"+r.TR.arrows.map(a=>{ const c=r.TR.cells[a.cell]; return `${a.cell+1},${a.x0.toFixed(1)},${a.y0.toFixed(1)},${a.x1.toFixed(1)},${a.y1.toFixed(1)},${new Date(a.t0*6e4).toISOString()},${new Date(a.t1*6e4).toISOString()},${a.n},${(60*Math.hypot(c.vx,c.vy)).toFixed(1)}`; }).join("\n")],{type:"text/csv"})));
  box.append(c1.card, c4.card, c2.card, c3);
}
function openLT(){ for(const id of ["landing","app","dsApp","cvApp","wnApp","cqcApp","caApp"]) $(id).hidden=true; $("ltApp").hidden=false; $("srcName").textContent="رعدوبرق"; $("srcBtn").hidden=false; store.set("mode","lt"); try{ wuzSync(); }catch(e){} }
$("ltFiles").onchange=()=>{ ltAddFiles($("ltFiles").files); $("ltFiles").value=""; };
{ const el=$("ltDrop"); el.addEventListener("dragover", e=>{ e.preventDefault(); el.classList.add("over"); }); el.addEventListener("dragleave", ()=>el.classList.remove("over"));
  el.addEventListener("drop", e=>{ e.preventDefault(); el.classList.remove("over"); ltAddFiles(e.dataTransfer.files); }); }
["ltMethod","ltRadii","ltAlpha","ltUnit","ltBg","ltSym","ltKm"].forEach(id=>{ const v=store.get(id,null); if(v!==null) $(id).value=v; $(id).addEventListener("change", ()=>{ store.set(id,$(id).value); $("ltAlphaRow").hidden=$("ltMethod").value!=="adaptive"; if(lt.frames.length || lt.streamE) ltRun(); }); });
$("ltAlphaRow").hidden=$("ltMethod").value!=="adaptive";
$("ltRun").onclick=()=>ltRun();

// ===== انیمیشن GIF رعدوبرق در بازه‌های ۳۰ دقیقه‌ای (کدگذار GIF داخلی، بدون کتابخانه) =====
function gifEncode(frames, W, H, delays){
  // پالت مشترک: پرتکرارترین ۲۵۶ رنگ (رنگ‌های نقشه گسسته‌اند؛ لبه‌های نرم نوشته‌ها به نزدیک‌ترین رنگ می‌روند)
  const cnt=new Map(); for(const f of frames){ for(let i=0;i<f.length;i+=4*3){ const k=(f[i]<<16)|(f[i+1]<<8)|f[i+2]; cnt.set(k,(cnt.get(k)||0)+1); } }
  const pal=[...cnt.entries()].sort((a,b)=>b[1]-a[1]).slice(0,256).map(e=>e[0]); while(pal.length<256) pal.push(0);
  const pr=pal.map(k=>(k>>16)&255), pg_=pal.map(k=>(k>>8)&255), pb=pal.map(k=>k&255), memo=new Map();
  const near=(r,g,b)=>{ const k=(r<<16)|(g<<8)|b; let v=memo.get(k); if(v!==undefined) return v; let bd=1e9; v=0; for(let j=0;j<256;j++){ const d=(r-pr[j])**2+(g-pg_[j])**2+(b-pb[j])**2; if(d<bd){ bd=d; v=j; if(!d) break; } } memo.set(k,v); return v; };
  const out=[]; const w8=b=>out.push(b&255), w16=v=>{ w8(v); w8(v>>8); }, str=s=>{ for(const c of s) w8(c.charCodeAt(0)); };
  str("GIF89a"); w16(W); w16(H); w8(0xF7); w8(0); w8(0); for(let j=0;j<256;j++){ w8(pr[j]); w8(pg_[j]); w8(pb[j]); }
  str("\x21\xFF\x0BNETSCAPE2.0\x03\x01"); w16(0); w8(0);           // تکرار بی‌پایان
  frames.forEach((f,fi)=>{
    w8(0x21); w8(0xF9); w8(4); w8(0); w16(delays[fi]||80); w8(0); w8(0);
    w8(0x2C); w16(0); w16(0); w16(W); w16(H); w8(0);
    const idx=new Uint8Array(W*H); for(let i=0,p=0;i<idx.length;i++,p+=4) idx[i]=near(f[p],f[p+1],f[p+2]);
    // LZW
    const minCode=8; w8(minCode); const clear=256, eoi=257; let codeSize=9, next=258, dict=new Map(), buf=0, nb=0; const bytes=[];
    const emit=c=>{ buf|=c<<nb; nb+=codeSize; while(nb>=8){ bytes.push(buf&255); buf>>>=8; nb-=8; } };
    emit(clear); let prefix=idx[0];
    for(let i=1;i<idx.length;i++){ const c=idx[i], key=prefix*256+c, v=dict.get(key);
      if(v!==undefined){ prefix=v; continue; }
      emit(prefix); if(next<4096){ dict.set(key,next++); if(next>(1<<codeSize) && codeSize<12) codeSize++; } else { emit(clear); dict=new Map(); next=258; codeSize=9; }
      prefix=c; }
    emit(prefix); emit(eoi); if(nb>0) bytes.push(buf&255);
    for(let i=0;i<bytes.length;i+=255){ const n=Math.min(255,bytes.length-i); w8(n); for(let k=0;k<n;k++) w8(bytes[i+k]); }
    w8(0); });
  w8(0x3B); return new Blob([new Uint8Array(out)],{type:"image/gif"});
}
async function ltGif(r, binMin=30, outW=0){
  const E=r.E, T=r.frameT.t, t0=Math.min(...T), t1=Math.max(...T), span=(t1-t0)/6e4;
  if(span<binMin*1.5) binMin=Math.max(5, Math.round(span/4/5)*5||5);
  const nb=Math.max(1,Math.ceil((span+1e-6)/binMin)), frames=[], delays=[];
  const hm=ms=>FA(new Date(ms+210*6e4).toISOString().slice(11,16));
  for(let b=0;b<nb;b++){ const a=t0+b*binMin*6e4, z=a+binMin*6e4;
    const inBin=E.pts.filter(p=>T[p.k]>=a && (T[p.k]<z || (b===nb-1&&T[p.k]<=z))), before=E.pts.filter(p=>T[p.k]<a), n=inBin.reduce((s,p)=>s+p.w,0);
    const cv=renderLT({...r.base, kind:"blank", title:`رعدوبرق هر ${FA(binMin)} دقیقه`+(r.zoom?" — "+r.zoom:""), t1:r.frameT.real?`از ${hm(a)} تا ${hm(z)} به وقت ایران`:`بازهٔ ${FA(b+1)} از ${FA(nb)}`, t2:"", badge:[`رعد در این بازه: ${FA(n)}`]});
    const ctx=cv.getContext("2d"); ctx.save(); ctx.beginPath(); ctx.rect(E.fx0,E.fy0,E.FW,E.FH); ctx.clip();
    ctx.fillStyle="rgba(120,120,120,.55)"; for(const p of before){ ctx.beginPath(); ctx.arc(E.fx0+p.x, E.fy0+p.y, 1.6, 0, 2*Math.PI); ctx.fill(); }
    ctx.fillStyle="#e00000"; ctx.strokeStyle="#5a0000"; ctx.lineWidth=0.8; for(const p of inBin){ ctx.beginPath(); ctx.arc(E.fx0+p.x, E.fy0+p.y, Math.min(5,2.4+Math.sqrt(p.w)), 0, 2*Math.PI); ctx.fill(); ctx.stroke(); }
    ctx.restore();
    if(outW && outW<cv.width){ const sc=document.createElement("canvas"); sc.width=outW; sc.height=Math.round(cv.height*outW/cv.width); const sx=sc.getContext("2d"); sx.imageSmoothingQuality="high"; sx.drawImage(cv,0,0,sc.width,sc.height); frames.push(sx.getImageData(0,0,sc.width,sc.height).data); }
    else frames.push(ctx.getImageData(0,0,cv.width,cv.height).data);
    delays.push(b===nb-1?250:90);
    if(b%2===1) await tick(); }
  const gw = outW && outW<r.base.W ? outW : r.base.W, gh = outW && outW<r.base.W ? Math.round(r.base.H*outW/r.base.W) : r.base.H;
  return gifEncode(frames, gw, gh, delays);
}
