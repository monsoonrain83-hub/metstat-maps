/* =====================================================================
   هشدارهای جوی خودکار: نقشه‌های پدیده‌های خطرناک ← نقشهٔ هشدار زرد/نارنجی/قرمز + متن هشدار
   ===================================================================== */
// آستانه‌ها [زرد، نارنجی، قرمز]؛ پیش‌فرض‌ها برای ایران (اقلیم خشک و نیمه‌خشک) و قابل ویرایش
const WN = {
  w_rain:  {n:"بارش سنگین (از مقدار بارش تجمعی)", lvn:["بارش","بارش شدید","بارش بسیار شدید"], lvnEn:["Rain","Heavy rain","Very heavy rain"], en:"Heavy precipitation (from accumulated amount)", u:"mm", thr:[2,20,40], dir:"up", nn:true, noNum:true, units:{"mm":1,"cm":10,"in":25.4},
            re:/precip(?!itable)|rain|apcp|(^|[^a-z])tp([^a-z]|$)|بارش|باران/i,
            imp:["آبگرفتگی معابر و لغزندگی جاده‌ها","آبگرفتگی معابر، طغیان مسیل‌ها و رودخانه‌های فصلی","سیلاب ناگهانی، طغیان رودخانه‌ها و خسارت به زیرساخت‌ها"],
            impEn:["ponding on roads and slippery roads","street flooding and rising seasonal streams and rivers","flash floods, river flooding and damage to infrastructure"]},
  w_rate:  {n:"رگبار شدید (از شدت بارش)", lvn:["رگبار","رگبار شدید","رگبار سیل‌آسا"], lvnEn:["Showers","Heavy showers","Torrential showers"], en:"Intense showers (from rainfall rate)", u:"mm/h", thr:[4,10,20], dir:"up", nn:true, noNum:true, units:{"mm/h":1,"mm/3h":1/3,"in/h":25.4},
            re:/rate|intens|شدت\s*بارش|mm\/h/i,
            imp:["رگبارهای تند و کاهش دید","رگبارهای شدید و آبگرفتگی سریع معابر","رگبارهای بسیار شدید و سیلاب ناگهانی در مسیل‌ها"],
            impEn:["heavy showers and reduced visibility","intense showers and rapid street flooding","torrential showers and flash floods in dry riverbeds"]},
  w_gust:  {n:"تندباد لحظه‌ای", lvn:["وزش باد شدید","تندباد","تندباد بسیار شدید"], lvnEn:["Strong winds","Damaging gusts","Very damaging gusts"], en:"Wind gusts", u:"km/h", thr:[50,70,90], dir:"up", nn:true, units:{"km/h":1,"m/s":3.6,"kt":1.852,"mph":1.609},
            re:/gust|تندباد/i,
            imp:["وزش باد شدید و برخاستن گردوخاک","شکستن درختان و خسارت به سازه‌های سبک","خسارت گسترده به سازه‌ها، درختان و شبکهٔ برق"],
            impEn:["strong winds and blowing dust","falling trees and damage to light structures","widespread damage to buildings, trees and power lines"]},
  w_wind:  {n:"سرعت باد", en:"Wind speed", u:"km/h", thr:[40,55,70], dir:"up", nn:true, units:{"km/h":1,"m/s":3.6,"kt":1.852,"mph":1.609},
            re:/wind(?!.*gust)|(^|[^a-z])ws([^a-z]|$)|سرعت\s*باد/i,
            imp:["وزش باد نسبتاً شدید","وزش باد شدید و گردوخاک","باد بسیار شدید و خسارت به سازه‌ها"],
            impEn:["fairly strong winds","strong winds and dust","very strong winds and structural damage"]},
  w_ltg:   {n:"رعدوبرق (چگالی رعد)", en:"Lightning (flash density)", u:"flash/km²/day", thr:[0.05,1,5], dir:"up", nn:true,
            re:/lightn|flash|رعد/i,
            imp:["رعدوبرق پراکنده","رعدوبرق فعال و خطر صاعقه","رعدوبرق بسیار فعال و خطر جدی صاعقه"],
            impEn:["scattered lightning","active lightning and risk of strikes","very active lightning and serious risk of strikes"]},
  w_tsp:   {n:"احتمال توفان تندری", en:"Thunderstorm probability", u:"%", thr:[30,50,70], dir:"up", nn:true,
            re:/thunder|tstm|storm[-_ ]?prob|توفان\s*تندری/i,
            imp:["رگبار و رعدوبرق پراکنده","توفان تندری همراه با رگبار و تندباد","توفان‌های تندری شدید، تگرگ و تندباد"],
            impEn:["scattered showers and thunder","thunderstorms with showers and gusts","severe thunderstorms with hail and damaging gusts"]},
  w_cape:  {n:"CAPE", en:"CAPE", u:"J/kg", thr:[1000,2000,3000], dir:"up", nn:true, seaOff:true,
            re:/cape/i,
            imp:["ناپایداری متوسط و امکان رگبار","ناپایداری قوی و امکان توفان تندری","ناپایداری بسیار قوی و توفان‌های شدید"],
            impEn:["moderate instability with possible showers","strong instability with possible thunderstorms","very strong instability and severe storms"]},
  w_flood: {n:"ریسک سیلاب", en:"Flood risk", u:"% مقیاس", thr:[25,50,75], dir:"up", rel:true,
            re:/flood|سیل/i,
            imp:["احتمال آبگرفتگی محلی","احتمال سیلاب در مسیل‌ها و رودخانه‌ها","ریسک بالای سیلاب و طغیان رودخانه‌ها"],
            impEn:["local flooding possible","flooding of streams and rivers likely","high risk of floods and river overflow"]},
  w_snow:  {n:"انباشت برف (سانتی‌متر)", lvn:["بارش برف","بارش برف سنگین","بارش برف بسیار سنگین و کولاک"], lvnEn:["Snow","Heavy snow","Very heavy snow and blizzard"], en:"Snow accumulation (cm)", u:"cm", thr:[2,10,25], dir:"up", nn:true, noNum:true, units:{"cm":1,"mm":0.1,"in":2.54},
            re:/snow|برف/i,
            imp:["لغزندگی جاده‌ها","انسداد راه‌های فرعی و گردنه‌ها","کولاک، انسداد راه‌ها و قطع برق"],
            impEn:["slippery roads","blocked secondary roads and mountain passes","blizzards, closed roads and power cuts"]},
  w_tanom: {n:"دمای غیرعادی (انومالی دما)", en:"Unusual temperature (anomaly)", u:"°C", thr:[5,8,11], dir:"abs",
            re:/anom|ناهنجاری|انومالی/i,
            imp:["دمای غیرعادی","گرما یا سرمای غیرعادی و آسیب به محصولات حساس","موج گرما یا سرمای شدید و خطر برای سلامت و کشاورزی"],
            impEn:["unusual temperatures","abnormal heat or cold affecting sensitive crops","severe heat or cold wave with risks to health and agriculture"]},
  w_tmax:  {n:"گرمای شدید (از بیشینهٔ دما)", en:"Extreme heat (from maximum temperature)", u:"°C", thr:[40,44,48], dir:"up",
            re:/t[-_ ]?max|max[a-z]*[-_ ]?temp|بیشینه/i,
            imp:["هوای گرم","گرمای شدید و خطر گرمازدگی","موج گرمای شدید و خطر جدی گرمازدگی"],
            impEn:["hot weather","severe heat with risk of heat stress","extreme heat wave with serious risk of heatstroke"]},
  w_tmin:  {n:"یخبندان هوا (از کمینهٔ دما)", en:"Air frost (from minimum temperature)", u:"°C", thr:[0,-5,-10], dir:"down",
            re:/t[-_ ]?min|min[a-z]*[-_ ]?temp|frost|کمینه|یخبندان/i,
            imp:["یخبندان سبک","یخبندان و سرمازدگی محصولات و لغزندگی جاده‌ها","یخبندان شدید، یخ‌زدگی لوله‌ها و خسارت به باغ‌ها"],
            impEn:["light frost","frost damaging crops and icy roads","severe frost, frozen pipes and damage to orchards"]},
  w_uv:    {n:"شاخص پرتو فرابنفش (UV)", en:"UV index", u:"", thr:[6,8,11], dir:"up", nn:true,
            re:/(^|[^a-z])uv/i,
            imp:["پرتو فرابنفش زیاد","پرتو فرابنفش بسیار زیاد و آفتاب‌سوختگی سریع","پرتو فرابنفش فوق‌العاده و آسیب جدی به پوست و چشم"],
            impEn:["high UV","very high UV and fast sunburn","extreme UV and serious harm to skin and eyes"]},
  w_hail:  {n:"تگرگ", en:"Hail", u:"cm", thr:[1,2,4], dir:"up", nn:true, units:{"cm":1,"mm":0.1,"in":2.54},
            re:/hail|تگرگ/i,
            imp:["تگرگ ریز","تگرگ و خسارت به محصولات کشاورزی","تگرگ درشت و خسارت به خودروها، بام‌ها و باغ‌ها"],
            impEn:["small hail","hail damaging crops","large hail damaging cars, roofs and orchards"]},
  w_wave:  {n:"ارتفاع موج", en:"Wave height", u:"m", thr:[1.5,2.5,4], dir:"up", nn:true,
            re:/wave|موج/i,
            imp:["دریای مواج برای شناورهای سبک","دریای متلاطم؛ مخاطره برای شناورهای سبک و صیادی","دریای بسیار متلاطم؛ توقف تردد دریایی"],
            impEn:["rough sea for small craft","very rough sea, risky for small craft and fishing","high seas; marine traffic should stop"]},
  w_dust:  {n:"گردوخاک", lvn:["گردوخاک","گردوخاک شدید","طوفان گردوخاک"], lvnEn:["Dust","Heavy dust","Dust storm"], en:"Dust", u:"µg/m³", thr:[200,500,1000], dir:"up", nn:true,
            re:/dust|pm10|گردوخاک|گرد\s*و\s*خاک/i,
            imp:["کاهش کیفیت هوا","هوای ناسالم و کاهش دید","هوای خطرناک و کاهش شدید دید"],
            impEn:["reduced air quality","unhealthy air and reduced visibility","hazardous air and very low visibility"]},
  w_vis:   {n:"کاهش دید افقی", en:"Low visibility", u:"km", thr:[1,0.4,0.1], dir:"down", nn:true, units:{"m":0.001,"km":1,"mi":1.609}, lvn:["کاهش دید (مه یا غبار)","کاهش شدید دید (مه غلیظ)","دید بسیار کم"], lvnEn:["Reduced visibility (fog or haze)","Poor visibility (dense fog)","Very poor visibility"],
            re:/visib|دید\s*افقی|fog|مه/i,
            imp:["کاهش دید","کاهش شدید دید (مه یا گردوخاک)","دید بسیار کم و خطر تصادف"],
            impEn:["reduced visibility","poor visibility (fog or dust)","very poor visibility and high crash risk"]},
  // نقشه‌های ورودی دما (خودشان هشدار نمی‌سازند؛ پدیده‌های مشتق از آن‌ها ساخته می‌شوند)
  w_tsoil: {n:"دمای نزدیک سطح خاک", en:"Near-surface soil temperature", u:"°C", input:true, re:/soil|tsoil|skin|خاک/i},
  w_td:    {n:"نقطهٔ شبنم ۲ متری", en:"2 m dew point", u:"°C", input:true, re:/dew|td2?m|نقطه\s*شبنم/i},
  w_rh:    {n:"رطوبت نسبی", en:"Relative humidity", u:"%", input:true, re:/(^|[^a-z])rh([^a-z0-9]|$)|humid|رطوبت/i},
  w_t2m:   {n:"دمای ۲ متری", en:"2 m temperature", u:"°C", input:true, re:/t2m|temp|دمای?\s*(۲|2)|دما/i},
  // پدیده‌های مشتق
  w_frost: {n:"یخبندان هوا (از دمای ۲ متری)", lvn:["یخبندان سبک","یخبندان","یخبندان شدید"], lvnEn:["Light frost","Frost","Severe frost"], en:"Air frost (from 2 m temperature)", u:"°C", thr:[0,-4,-8], dir:"down", derived:true,
            imp:["یخبندان سبک و سرمازدگی گیاهان حساس","یخبندان، سرمازدگی محصولات و لغزندگی معابر","یخبندان شدید، یخ‌زدگی لوله‌ها و خسارت گسترده به باغ‌ها"],
            impEn:["light frost harming sensitive plants","frost damaging crops and icy roads","severe frost, frozen pipes and widespread orchard damage"]},
  w_gfrost:{n:"یخبندان سطح خاک (برآوردی)", lvn:["یخ‌زدگی سطح زمین","یخبندان سطح خاک","یخبندان شدید سطح خاک"], lvnEn:["Ground frost","Hard ground frost","Severe ground frost"], en:"Ground frost (estimated)", u:"°C", thr:[0,-3,-6], dir:"down", derived:true,
            imp:["یخ‌زدگی سطح زمین و احتمال آسیب به نشاها و جوانه‌ها","یخبندان سطح خاک، سرمازدگی محصولات و یخ‌زدگی سطح جاده‌ها","یخبندان شدید سطح خاک و خسارت جدی به محصولات کشاورزی"],
            impEn:["ground frost that may harm seedlings and buds","ground frost damaging crops and icy road surfaces","severe ground frost and serious crop damage"]},
  w_heat:  {n:"گرمای شدید (فقط از دمای ۲ متری)", lvn:["هوای گرم","گرمای شدید","موج گرمای شدید"], lvnEn:["Hot weather","Extreme heat","Severe heat wave"], en:"Extreme heat (from 2 m temperature only)", u:"°C", thr:[40,44,48], dir:"up", derived:true,
            imp:["هوای گرم","گرمای شدید و خطر گرمازدگی","موج گرمای شدید و خطر جدی گرمازدگی"],
            impEn:["hot weather","severe heat with risk of heat stress","extreme heat wave with serious risk of heatstroke"]},
  w_hi:    {n:"شرجی (شاخص گرما از دما و رطوبت)", lvn:["هوای شرجی","شرجی شدید","شرجی بسیار شدید"], lvnEn:["Sultry air","Very sultry air","Dangerously sultry air"], en:"Sultry heat (heat index from temperature and humidity)", u:"°C", thr:[32,39,52], dir:"up", derived:true,
            imp:["هوای شرجی و آزاردهنده؛ احتیاط در فعالیت‌های طولانی در فضای باز","شرجی شدید؛ خطر گرمازدگی و کم‌آبی بدن با فعالیت بیرونی","شرجی بسیار شدید و خطرناک؛ خطر جدی گرمازدگی"],
            impEn:["sultry, uncomfortable air; take care with long outdoor activity","very sultry; risk of heat exhaustion and dehydration outdoors","dangerously sultry; serious risk of heatstroke"]},
  w_wchill:{n:"سوز سرما (دمای احساسی از دما و باد)", lvn:["سوز سرما","سوز شدید سرما (خطر سرمازدگی)","سوز بسیار شدید سرما"], lvnEn:["Wind chill","Severe wind chill (frostbite risk)","Extreme wind chill"], en:"Wind chill (feels-like from temperature and wind)", u:"°C", thr:[-10,-28,-40], dir:"down", derived:true,
            imp:["سرمای آزاردهنده؛ خطر سرمازدگی و کاهش دمای بدن در ماندن طولانی در فضای باز","پوست بی‌پوشش در ۱۰ تا ۳۰ دقیقه دچار سرمازدگی می‌شود","پوست بی‌پوشش در کمتر از ۱۰ دقیقه دچار سرمازدگی می‌شود؛ ماندن در فضای باز خطرناک است"],
            impEn:["uncomfortable cold; risk of hypothermia and frostbite on long exposure","exposed skin can freeze in 10 to 30 minutes","exposed skin can freeze in under 10 minutes; being outdoors is dangerous"]},
  w_snowmm:{n:"بارش برف (معادل آب)", en:"Snowfall (water equivalent)", u:"mm", thr:[1,5,15], dir:"up", nn:true, noNum:true, units:{"mm":1,"cm":10},
            lvn:["بارش برف","بارش برف سنگین","بارش برف بسیار سنگین و کولاک"], lvnEn:["Snow","Heavy snow","Very heavy snow and blizzard"], re:/snow.*(mm|swe)|swe/i,
            imp:["لغزندگی جاده‌ها","انسداد راه‌های فرعی و گردنه‌ها","کولاک، انسداد راه‌ها و قطع برق"], impEn:["slippery roads","blocked secondary roads and mountain passes","blizzards, closed roads and power cuts"]},
  // نقشهٔ «پدیده‌های مهم جوی» weather.us (Significant Weather): نقشهٔ ورودی دسته‌ای که چند پدیده می‌سازد
  w_sigwx: {n:"پدیده‌های مهم جوی (Significant Weather)", en:"Significant weather", u:"", input:true, re:/sig(nificant)?[-_ ]?w(eather|x)/i},
  w_ts:    {n:"توفان تندری (از نقشهٔ پدیده‌های مهم جوی)", en:"Thunderstorm (from significant-weather map)", u:"", thr:[0.5,1.5,2.5], dir:"up", cat:true, noNum:true, derived:true,
            lvn:["احتمال رعدوبرق و توفان تندری در نزدیکی","توفان تندری خفیف تا متوسط","توفان تندری شدید"], lvnEn:["Thunderstorms nearby","Light to moderate thunderstorms","Severe thunderstorms"],
            imp:["رعدوبرق پراکنده؛ پرهیز از فضای باز و ارتفاعات هنگام رعدوبرق","رگبار، رعدوبرق و وزش باد شدید موقت؛ احتمال آبگرفتگی معابر و خطر صاعقه","رگبار سیل‌آسا، تندباد، تگرگ و رعدوبرق شدید؛ خطر سیلاب ناگهانی، صاعقه و خسارت به سازه‌ها"],
            impEn:["scattered lightning; avoid open ground and heights during thunder","showers, lightning and brief strong gusts; street flooding and lightning risk","torrential rain, damaging gusts, hail and intense lightning; risk of flash floods, strikes and structural damage"]},
  w_fog:   {n:"مه (از نقشهٔ پدیده‌های مهم جوی)", en:"Fog (from significant-weather map)", u:"", thr:[0.5,1.5,2.5], dir:"up", cat:true, noNum:true, derived:true,
            lvn:["مه","مه یخ‌زده","مه یخ‌زدهٔ غلیظ"], lvnEn:["Fog","Freezing fog","Dense freezing fog"],
            imp:["کاهش دید افقی و کندی تردد","کاهش شدید دید و یخ‌زدگی سطح جاده‌ها؛ خطر تصادف","دید بسیار کم و یخ‌زدگی گسترده؛ خطر جدی تصادف"],
            impEn:["reduced visibility and slower traffic","poor visibility and icy road surfaces; crash risk","very poor visibility and widespread icing; serious crash risk"]},
  w_ice:   {n:"یخ‌زدگی و باران یخ‌زا (از نقشهٔ پدیده‌های مهم جوی)", en:"Ice and freezing rain (from significant-weather map)", u:"", thr:[0.5,1.5,2.5], dir:"up", cat:true, noNum:true, derived:true,
            lvn:["یخ‌زدگی سبک","باران یخ‌زا و یخ‌زدگی","باران یخ‌زا و یخ‌زدگی شدید"], lvnEn:["Light icing","Freezing rain and ice","Severe freezing rain and ice"],
            imp:["لغزندگی موضعی معابر","لغزندگی شدید جاده‌ها و پیاده‌روها و آسیب به شاخه‌ها","یخ‌بستن گسترده، قطع برق و انسداد راه‌ها"],
            impEn:["locally slippery surfaces","very slippery roads and pavements and damage to branches","widespread glaze ice, power cuts and closed roads"]},
  w_snowwx:{n:"برف و برف‌وباران (از نقشهٔ پدیده‌های مهم جوی)", en:"Snow and sleet (from significant-weather map)", u:"", thr:[0.5,1.5,2.5], dir:"up", cat:true, noNum:true, derived:true,
            lvn:["بارش برف سبک یا برف‌وباران","بارش برف متوسط یا برف‌وباران شدید","بارش برف سنگین"], lvnEn:["Light snow or sleet","Moderate snow or heavy sleet","Heavy snow"],
            imp:["لغزندگی جاده‌ها","انسداد راه‌های فرعی و گردنه‌ها","کولاک، انسداد راه‌ها و قطع برق"], impEn:["slippery roads","blocked secondary roads and mountain passes","blizzards, closed roads and power cuts"]},
  w_rainwx:{n:"باران (از نقشهٔ پدیده‌های مهم جوی)", en:"Rain (from significant-weather map)", u:"", thr:[0.5,1.5,2.5], dir:"up", cat:true, noNum:true, derived:true,
            lvn:["باران متوسط","باران شدید","باران بسیار شدید"], lvnEn:["Moderate rain","Heavy rain","Very heavy rain"],
            imp:["لغزندگی جاده‌ها و آبگرفتگی موضعی","آبگرفتگی معابر و طغیان مسیل‌ها","سیلاب و طغیان رودخانه‌ها"], impEn:["slippery roads and local ponding","street flooding and rising streams","floods and river overflow"]},
  w_floodp:{n:"پتانسیل سیلاب (آزمایشی)", en:"Flood potential (experimental)", u:"/100", thr:[40,60,80], dir:"up", noNum:true, derived:true,
            lvn:["احتمال آبگرفتگی و سیلاب محلی","سیلاب ناگهانی محتمل","سیلاب ناگهانی و طغیان رودخانه‌ها"], lvnEn:["Possible local flooding","Flash floods likely","Flash floods and river flooding"],
            imp:["آبگرفتگی معابر و جاری شدن آب در مسیل‌ها","سیلاب ناگهانی در مسیل‌ها و دره‌ها و خطر برای تردد و سکونت در حریم رودخانه","سیلاب گسترده و طغیان رودخانه‌ها؛ خطر جانی و خسارت جدی به زیرساخت‌ها"],
            impEn:["ponding on streets and water flowing in dry channels","flash floods in channels and valleys; danger near riverbeds","widespread flooding and overflowing rivers; danger to life and serious damage"]},
  w_flash:{n:"سیل ناگهانی (آزمایشی)", en:"Flash flood (experimental)", u:"/100", thr:[40,60,80], dir:"up", noNum:true, derived:true,
            lvn:["احتمال جاری شدن آب در مسیل‌ها","سیل ناگهانی محتمل در دره‌ها و مسیل‌ها","سیل ناگهانی شدید و طغیان رودخانه‌ها"], lvnEn:["Water may flow in dry channels","Flash floods likely in valleys and channels","Severe flash floods and overflowing rivers"],
            imp:["جاری شدن آب در مسیل‌ها و آبراهه‌های دامنه‌ها","سیل ناگهانی در دره‌ها، مسیل‌ها و مخروط‌افکنه‌ها؛ خطر برای تردد و اتراق در حریم رودخانه","سیل شدید و گل‌آلود با حمل سنگ و درخت؛ خطر جانی و تخریب جاده‌ها و پل‌ها"],
            impEn:["water running in channels and hillside gullies","flash floods in valleys, channels and alluvial fans; danger for traffic and camping near riverbeds","violent muddy floods carrying rocks and trees; danger to life and damage to roads and bridges"]},
  w_wlog:{n:"آب‌گرفتگی (آزمایشی)", en:"Waterlogging / ponding (experimental)", u:"/100", thr:[40,60,80], dir:"up", noNum:true, derived:true,
            lvn:["آب‌گرفتگی موضعی معابر","آب‌گرفتگی گستردهٔ معابر و زمین‌های پست","آب‌گرفتگی شدید و ماندگاری آب در دشت‌ها"], lvnEn:["Local ponding on streets","Widespread ponding on streets and low ground","Severe and lasting waterlogging on plains"],
            imp:["آب‌گرفتگی موضعی معابر و زیرگذرها","آب‌گرفتگی معابر، زیرگذرها، زمین‌های کشاورزی پست و ورود آب به زیرزمین‌ها","ماندگاری آب در دشت‌ها، شوره‌زارها و محله‌های پست، قطع تردد و آسیب به محصولات"],
            impEn:["local ponding on streets and underpasses","ponding on streets, underpasses and low farmland, water entering basements","lasting water on plains, salt flats and low-lying districts; closed roads and crop damage"]},
  w_custom:{n:"پدیدهٔ دیگر (سفارشی)", en:"Other hazard (custom)", u:"% مقیاس", thr:[40,70,90], dir:"up", rel:true, re:null,
            imp:["شرایط نامساعد","شرایط خطرناک","شرایط بسیار خطرناک"], impEn:["adverse conditions","dangerous conditions","very dangerous conditions"]}
};
// نوع‌ها در جدول CV_IDX هم ثبت می‌شوند تا رقومی‌سازی مشترک (cvDigitize) کار کند؛ در فهرست همرفت دیده نمی‌شوند
for(const [k,v] of Object.entries(WN)) CV_IDX[k]={n:v.n, u:v.u, g:"haz", haz:true, occ:null, sev:null, nn:!!v.nn, rel:!!v.rel, units:v.units, abs:false, re:null, ref:""};
const wn={maps:[], res:null, busy:false, timer:null, pending:false};
function wnStatus(t, frac){ $("wnStatus").hidden=false; $("wnStText").textContent=t; if(frac!==undefined) $("wnStBar").style.width=(frac*100)+"%"; }
const wnThr = () => { const o=store.get("wn.thr",{}), r={}; for(const k in WN) if(WN[k].thr) r[k]=(o[k]&&o[k].length===3&&o[k].every(isFinite))?o[k]:WN[k].thr; return r; };
function wnGuessName(name){ if(/(^|[^a-z0-9])(t2m|2m|2\s*متر)/i.test(name) && !/dew|td2?m|نقطه/i.test(name)) return "w_t2m"; for(const [k,v] of Object.entries(WN)) if(v.re && v.re.test(name)) return k; return null; }
// نوع پدیده از واژه‌های عنوان نقشه (همان OCR همرفت) و نوار رنگ
function wnTypeFromTitle(bt, m){
  if(!bt) return null; const kb=bt.kb||{}, vb=bt.vb||{}, hb=bt.hb||{}, ok=(o,k,t=0.64)=>o[k]>=t;
  if(ok(hb,"anom")) return "w_tanom";
  if(ok(kb,"td2m",0.66)) return "w_td";
  if(ok(kb,"rh",0.66) || ok(vb,"rh",0.66)) return "w_rh";
  if(ok(hb,"soil",0.7) && !(bt.level==="2m") && (ok(vb,"temp",0.6) || (m&&m.prof&&wuTempEdges(m.prof.T)))) return "w_tsoil";
  if(ok(hb,"uv",0.7)) return "w_uv";
  if(ok(hb,"flood")) return "w_flood";
  if(ok(hb,"hail")) return "w_hail";
  if(ok(hb,"wave")) return "w_wave";
  if(ok(hb,"dust")) return "w_dust";
  if(ok(hb,"vis")) return "w_vis";
  if(ok(kb,"ltg",0.66)) return "w_ltg";
  if(ok(kb,"tsc",0.66) && ok(hb,"prob")) return "w_tsp";
  if(ok(kb,"gust",0.66) || ok(vb,"gust",0.66)) return "w_gust";
  if(ok(vb,"snow",0.66)) return "w_snow";
  if((ok(kb,"precip",0.66) || ok(vb,"precip",0.66))) return ok(hb,"rate") ? "w_rate" : "w_rain";
  if(ok(vb,"tmax",0.66) && ok(vb,"temp",0.6)) return "w_tmax";
  if(ok(vb,"tmin",0.66) && ok(vb,"temp",0.6)) return "w_tmin";
  if(ok(kb,"cape",0.66)) return "w_cape";
  if(ok(vb,"temp",0.66) || ok(kb,"t500",0.66) && m && m.prof && wuTempEdges(m.prof.T)) return "w_t2m";
  if(ok(vb,"wind",0.66) || ok(kb,"jet",0.7)) return "w_wind";
  return null;
}
// قفل هر صفحه: افزودن نقشه‌ها و تحلیل پشت سر هم اجرا می‌شوند (هر دو از قالب سراسری P استفاده می‌کنند؛ هم‌زمانی آن‌ها نتیجه را خراب می‌کرد)
function mkLock(){ let q=Promise.resolve(); return fn=>{ const r=q.then(fn, fn); q=r.catch(()=>{}); return r; }; }
const WN_LOCK=mkLock();
function wnAdd(files){ files=[...files]; return WN_LOCK(()=>wnAdd_(files)); }
async function wnAdd_(files){
  files=[...files].filter(isImg); if(!files.length) return; const gen=wn.gen||0;
  const prev=P?P.key:null;
  if(!CV_OCR_T) await cvOcrFonts();
  for(const f of files){
    if((wn.gen||0)!==gen) break;
    const m={file:f, name:f.name.replace(/\.[^.]+$/,""), unit:null, bgAbove:false, role:"haz"};
    try{
      wnStatus(`خواندن ${f.name}…`, 0.02); await tick();
      Object.assign(m, await readFile(f));
      if(wuSigWx(m)){   // نقشهٔ دسته‌ای پدیده‌های مهم جوی: بدون نوار رنگ عددی
        m.type="w_sigwx"; m.sig=true; m.v=[0,1]; m.edgesTxt=""; m.typeSrc="رنگ‌های راهنمای نقشه (Significant Weather)"; m.edgeSrc="";
        m.prof={key:null, fx0:2, fy0:2, fx1:757, fy1:614, T:{colors:WU_SIGWX.map(e=>e[0])}, fp:"wu_sigwx"};
        try{ m.regionFa = wuZoomOCR(m) || wuSigRegion(m.data) || "ایران"; }catch(e){ m.regionFa="ایران"; }
        m.region = m.regionFa==="ایران" ? "Iran" : null; m.geo = WU_ZOOM_GEO[m.regionFa] || WU_GEO; m.geoDone=true;
        try{ await useProfile("wu"); const nm=recognize(m.data); if(nm) m.model=nm; }catch(e){}
        try{ const tt=readTimes(m); if(tt && tt.end) m.times=tt; }catch(e){}
        wn.maps.push(m); continue; }
      m.prof=cvProfile(m);
      const learned=learnedFP("wn.fp.", m.prof.fp), cvL=learnedFP("cv.fp.", m.prof.fp), gs=guessScale(m.prof.T.colors, m.prof.T);
      const byName=wnGuessName(f.name), byTitle=cvTitleType(m)||{}, byT=wnTypeFromTitle(byTitle, m);
      m.type = byName || byT || (learned&&learned.type) || (gs && !gs.kind ? "w_rain" : gs && gs.kind==="temp" ? "w_t2m" : "w_custom");
      m.typeSrc = byName ? "نام فایل" : byT ? `عنوان نقشه («${byTitle.w||"…"}»)` : (learned&&learned.type) ? "قالب یادگرفته" : gs ? (gs.kind==="temp"?"نوار رنگ دما":"نوار رنگ بارش") : "";
      m.region = (m.w===984&&m.h===808) ? "Iran" : byTitle.region;
      if(!m.region && m.w===760 && m.h===760) m.regionFa = wuSigRegion(m.data);
      m.model = byTitle.model ? CV_MODELS[byTitle.model] : null;
      if(!m.model){ const key=(m.w===760&&m.h===760)?"wu":(m.w===984&&m.h===808)?"wb":null; if(key){ await useProfile(key); const nm=recognize(m.data); if(nm) m.model=nm; } }
      if((m.type==="w_rain" || (m.type==="w_snow" && gs && !gs.kind)) && wuSnowTitle(m)){ m.type="w_snowmm"; m.typeSrc="عنوان نقشه («Snow»)"; }
      if(gs && gs.kind==="vis"){ m.type="w_vis"; m.typeSrc="نوار رنگ دید افقی"; }
      if(gs && gs.kind==="rh" && !byName){ m.type="w_rh"; m.typeSrc = byT==="w_rh" ? `عنوان و نوار رنگ («${byTitle.w||"Humidity"}»)` : "نوار رنگ رطوبت نسبی"; }
      const U=WN[m.type].units; m.unit = learned&&learned.unit&&U&&U[learned.unit] ? learned.unit : (U && byTitle.unit && U[byTitle.unit]) ? byTitle.unit : (U ? Object.keys(U)[0] : null);
      m.bgAbove = learned && learned.bgAbove!==undefined ? learned.bgAbove : WN[m.type].dir==="down";
      let txt=(gs&&gs.kind&&gs.edges) || (learned&&learned.edges) || (cvL&&cvL.edges) || (gs&&gs.edges) || "", rd=null;
      m.edgeSrc = learned&&learned.edges ? "یادگرفته" : cvL&&cvL.edges ? "یادگرفته" : gs ? "مقیاس آشنا" : "";
      if(!txt){ try{ rd=cvReadBar(m); }catch(e){ console.warn("cvReadBar",e); } if(rd){ txt=rd.txt; m.edgeSrc=`خوانده از نوار رنگ (${FA(rd.n)} برچسب) — بررسی کنید`; } }
      if(txt){ const e=cvSetEdges(m, txt); if(e){ m.note=e; if(rd){ m.v=null; m.edgesTxt=txt; } } } else m.note="اعداد نوار رنگ خوانده نشد؛ دستی وارد کنید (یک بار برای این قالب)";
      try{ const t=readTimes(m); if(t && t.end) m.times=t; }catch(e){}
    }catch(e){ console.error(e); m.bad=true; m.note="قالب نقشه تشخیص داده نشد: "+e.message; }
    if((wn.gen||0)!==gen) break;
    wn.maps.push(m);
  }
  const groups={}; for(const m of wn.maps) if(!m.bad && m.prof && !m.sig) (groups[m.w+"x"+m.h]=groups[m.w+"x"+m.h]||[]).push(m);
  for(const g of Object.values(groups)){ if(g.length<2) continue; const area=p=>(p.fx1-p.fx0)*(p.fy1-p.fy0), big=g.map(m=>m.prof).reduce((a,b)=>area(b)>area(a)?b:a);
    const med=k=>{ if(g.length===2) return big[k]; const a=g.map(m=>m.prof[k]).sort((x,y)=>x-y); return a[(a.length-1)>>1]; };
    const F={fx0:med("fx0"), fy0:med("fy0"), fx1:med("fx1"), fy1:med("fy1")};
    for(const m of g){ const p=m.prof; if(["fx0","fy0","fx1","fy1"].some(k=>p[k]!==F[k])){ Object.assign(p,F); p.staticDirty=true; } } }
  shareEdges(wn.maps);
  if(prev && PROFILES[prev]) await useProfile(prev); else P=undefined;
  wnDrawList(); wnThrPanel(); wnSchedule(50);
}
function wnRemember(m){ store.set("wn.fp."+m.prof.fp, {edges:m.edgesTxt, type:m.type, bgAbove:m.bgAbove, unit:m.unit}); }
function wnSchedule(d=400){ clearTimeout(wn.timer); wn.timer=setTimeout(()=>WN_LOCK(wnRun), d); }
function wnDrawList(){
  const box=$("wnList"); box.innerHTML="";
  const firstIdx=wn.maps.findIndex(m=>!m.bad);
  wn.maps.forEach((m,idx)=>{
    const row=document.createElement("div"); row.className="cvrow";
    const l1=document.createElement("div"); l1.className="l1";
    const nm=document.createElement("b"); nm.textContent=(idx===firstIdx?"★ ":"")+m.file.name; nm.title=idx===firstIdx?"نقشهٔ مرجع: قالب و کادر خروجی از این نقشه است":m.file.name;
    const sel=document.createElement("select"); sel.setAttribute("aria-label","نوع پدیده");
    sel.innerHTML=Object.entries(WN).filter(([k,v])=>!v.derived).map(([k,v])=>`<option value="${k}">${v.n}${v.input?" (ورودی)":""}</option>`).join(""); sel.value=m.type||"w_custom"; sel.disabled=!!m.bad;
    sel.onchange=()=>{ m.type=sel.value; const U=WN[m.type].units; m.unit=U?Object.keys(U)[0]:null; m.bgAbove=WN[m.type].dir==="down"; if(m.v) wnRemember(m); wnDrawList(); wnThrPanel(); wnSchedule(100); };
    const del=document.createElement("button"); del.className="del"; del.type="button"; del.textContent="×"; del.setAttribute("aria-label","حذف "+m.file.name);
    del.onclick=()=>{ wn.maps.splice(idx,1); wnDrawList(); wnThrPanel(); wnSchedule(50); };
    l1.append(nm, sel, del);
    const l2=document.createElement("div"); l2.className="l2";
    if(!m.bad && !m.sig){
      const ed=document.createElement("input"); ed.className="ed"; ed.value=m.edgesTxt||""; ed.placeholder=`${FA(m.prof.T.colors.length+1)} عدد: حد پایین هر رنگ و حد بالای آخرین`;
      ed.title="اعداد نوار رنگ این نقشه، به ترتیب از اولین رنگ"; if(!m.v) ed.style.borderColor="var(--warn)";
      ed.onchange=()=>{ const e=cvSetEdges(m, ed.value); m.note=e; if(!e){ wnRemember(m); try{ cvLearnBar(m, ed.value); }catch(err){} m.edgeSrc="دستی"; shareEdges(wn.maps); } wnDrawList(); wnSchedule(50); };
      l2.append(ed);
      if(m.prof.T.bgSep){ const bg=document.createElement("select"); bg.innerHTML=`<option value="0">زمینهٔ بی‌رنگ: کمتر از کمترین عدد</option><option value="1">زمینهٔ بی‌رنگ: بیشتر از بیشترین عدد</option>`; bg.value=m.bgAbove?"1":"0";
        bg.onchange=()=>{ m.bgAbove=bg.value==="1"; if(m.v) wnRemember(m); wnSchedule(50); }; l2.append(bg); }
      const U=WN[m.type].units; if(U){ const un=document.createElement("select"); un.innerHTML=Object.keys(U).map(u=>`<option>${u}</option>`).join(""); un.value=m.unit; un.onchange=()=>{ m.unit=un.value; if(m.v) wnRemember(m); wnSchedule(50); }; l2.append(un); }
    }
    const sm=document.createElement("small");
    sm.textContent=(m.note||(m.sig?`${FA(m.w)}×${FA(m.h)} · ${FA(WU_SIGWX.length)} دستهٔ پدیده`:m.v?`${FA(m.w)}×${FA(m.h)} · ${FA(m.prof.T.colors.length)} رنگ · واحد ${m.unit||WN[m.type].u||"—"}`:""))+(m.model?` · مدل ${m.model}`:"")+(m.typeSrc&&!m.bad?` · نوع از ${m.typeSrc}`:(!m.bad&&m.type==="w_custom"?" · نوع پدیده شناخته نشد؛ از فهرست انتخاب کنید":""))+(m.edgeSrc&&!m.bad?` · اعداد نوار: ${m.edgeSrc}`:"");
    if(m.bad||!m.v) sm.className="bad";
    row.append(l1, l2, sm); box.append(row);
  });
  $("wnEmpty").hidden = wn.maps.length>0;
}
// نقشهٔ Significant Weather سایت weather.us: رنگ‌های راهنما (از خود نقشه اسکن شده) → سطح هشدار هر پدیده
const WU_SIGWX=[[[253,247,51],"w_fog",1],[[193,188,41],"w_fog",2],[[67,255,67],"w_rainwx",0],[[52,193,52],"w_rainwx",1],[[0,130,0],"w_rainwx",2],
  [[140,140,140],"w_ts",1],[[253,95,255],"w_ts",2],[[186,26,188],"w_ts",3],[[255,193,137],"w_snowwx",1],[[255,151,58],"w_snowwx",2],
  [[71,240,255],"w_snowwx",1],[[71,140,255],"w_snowwx",2],[[53,104,189],"w_snowwx",3],[[255,67,67],"w_ice",2],[[200,0,0],"w_ice",3]];
const WU_SIGWX_BG=[110,110,110], WU_SIGWX_T=["w_ts","w_rainwx","w_snowwx","w_ice","w_fog"];
function wuSigWx(m){ if(!m || m.w!==760 || m.h!==760) return false; const d=m.data, px=(x,y)=>{ const q=(y*760+x)*4; return [d[q],d[q+1],d[q+2]]; };
  return [[35,676,[253,247,51]],[130,676,[193,188,41]],[240,694,[71,240,255]],[600,694,[200,0,0]],[500,694,[255,67,67]]].filter(([x,y,c])=>cdist(px(x,y),c)<=12).length>=4; }
function wnSigwxFields(m){
  const fx0=2, fy0=2, FW_=756, FH_=613, n=FW_*FH_, d=m.data, out={}, ok=new Uint8Array(n);
  for(const t of WU_SIGWX_T) out[t]=new Float32Array(n);
  for(let y=0;y<FH_;y++) for(let x=0;x<FW_;x++){ const i=y*FW_+x, q=((y+fy0)*760+x+fx0)*4, c=[d[q],d[q+1],d[q+2]];
    if(Math.abs(c[0]-110)<=3 && Math.abs(c[1]-110)<=3 && Math.abs(c[2]-110)<=3){ ok[i]=1; continue; }
    let best=null, bd=1e9; for(const e of WU_SIGWX){ const dd=Math.abs(c[0]-e[0][0])+Math.abs(c[1]-e[0][1])+Math.abs(c[2]-e[0][2]); if(dd<bd){ bd=dd; best=e; } }
    const tol = best && best[1]==="w_ts" && best[2]===1 ? 10 : 30;
    if(best && bd<=tol){ ok[i]=1; out[best[1]][i]=best[2]; } }
  for(const t of WU_SIGWX_T){ const v=out[t], k=Uint8Array.from(ok); cvIDW(v, k, FW_, FH_, 2, 6); }
  return {fx0, fy0, FW:FW_, FH:FH_, out};
}
// پدیده‌هایی که از نقشه‌های موجود ساخته می‌شوند (نقشه‌های دما ورودی‌اند و پدیدهٔ مشتق می‌سازند)
function wnHazTypes(types){
  const s=new Set(types), out=[];
  for(const t of types) if(!WN[t].input && !out.includes(t)) out.push(t);
  if(s.has("w_t2m")) out.push("w_frost","w_heat");
  if(s.has("w_tsoil") || s.has("w_t2m")) out.push("w_gfrost");
  if(s.has("w_t2m") && (s.has("w_td") || s.has("w_rh"))) out.push("w_hi");
  if(s.has("w_t2m") && s.has("w_wind")) out.push("w_wchill");
  if(["w_rain","w_rainwx","w_rate","w_sigwx"].some(k=>s.has(k))) out.push("w_flash","w_wlog");
  if(s.has("w_sigwx")) out.push(...WU_SIGWX_T.filter(t=>t!=="w_rainwx"||true));
  return out;
}
function wnThrPanel(){
  const box=$("wnThr"); if(!box) return; const T=wnThr(), types=wnHazTypes([...new Set(wn.maps.filter(m=>!m.bad).map(m=>m.type))]);
  const list = (types.length ? types : Object.keys(WN).filter(k=>k!=="w_custom" && !WN[k].input)).filter(k=>!WN[k].cat);
  box.innerHTML=`<table class="cvref"><thead><tr><th>پدیده</th><th>زرد</th><th>نارنجی</th><th>قرمز</th></tr></thead><tbody>${list.map(k=>`<tr data-k="${k}"><td>${WN[k].n}${WN[k].u?` <small>(${WN[k].u})</small>`:""}${WN[k].dir==="down"?" ↓":WN[k].dir==="abs"?" ±":""}</td>${[0,1,2].map(j=>`<td><input type="number" step="any" value="${T[k][j]}" style="width:64px" aria-label="${["زرد","نارنجی","قرمز"][j]}"></td>`).join("")}</tr>`).join("")}</tbody></table>`;
  box.querySelectorAll("tr[data-k]").forEach(tr=>tr.querySelectorAll("input").forEach(inp=>inp.onchange=()=>{ const k=tr.dataset.k, o=store.get("wn.thr",{}); o[k]=[...tr.querySelectorAll("input")].map(i=>parseFloat(i.value)); store.set("wn.thr",o); wnSchedule(100); }));
}
// سطح و «شدت درون سطح» یک مقدار: L=۰..۳ و e=۰..۱
function wnLevel(v, t, dir){
  if(!(v===v)) return [0,0];
  let x=v, y=t[0], o=t[1], r=t[2];
  if(dir==="abs") x=Math.abs(v);
  if(dir==="down"){ x=-v; y=-y; o=-o; r=-r; }
  if(x<y) return [0,0];
  if(x<o) return [1,(x-y)/Math.max(1e-9,o-y)];
  if(x<r) return [2,(x-o)/Math.max(1e-9,r-o)];
  return [3, Math.min(1,(x-r)/Math.max(1e-9,(r-o)))];
}
// شاخص گرما (NWS، رگرسیون Rothfusz با تصحیح‌ها) از دما و نقطهٔ شبنم (°C)؛ زیر ۲۶٫۷ درجه همان دما
function heatIndex(T, Td){
  if(!(T===T) || !(Td===Td)) return NaN; if(T<26.7) return T;
  const RH=Math.max(1, Math.min(100, 100*Math.exp(17.625*Td/(243.04+Td))/Math.exp(17.625*T/(243.04+T)))), F=T*9/5+32;
  let H=0.5*(F+61+(F-68)*1.2+RH*0.094);
  if((H+F)/2>=80){ H=-42.379+2.04901523*F+10.14333127*RH-0.22475541*F*RH-0.00683783*F*F-0.05481717*RH*RH+0.00122874*F*F*RH+0.00085282*F*RH*RH-0.00000199*F*F*RH*RH;
    if(RH<13 && F>=80 && F<=112) H-=((13-RH)/4)*Math.sqrt((17-Math.abs(F-95))/17);
    else if(RH>85 && F>=80 && F<=87) H+=((RH-85)/10)*((87-F)/5); }
  return (H-32)*5/9;
}
// شاخص گرما از دما و رطوبت نسبی (همان رگرسیون Rothfusz سرویس ملی هواشناسی آمریکا)
function heatIndexRH(T, RH){
  if(!(T===T) || !(RH===RH)) return NaN; if(T<26.7) return T;
  RH=Math.max(1, Math.min(100, RH)); const Td=243.04*(Math.log(RH/100)+17.625*T/(243.04+T))/(17.625-Math.log(RH/100)-17.625*T/(243.04+T));
  return heatIndex(T, Td);
}
// سوز باد (Wind Chill؛ فرمول مشترک کانادا و آمریکا، ۲۰۰۱): T دمای هوا (°C) و V سرعت باد ۱۰ متری (km/h)؛ فقط برای T ≤ ۱۰ و V ≥ ۴٫۸
function windChill(T, V){
  if(!(T===T) || !(V===V)) return NaN; if(T>10 || V<4.8) return T;
  const p=Math.pow(V,0.16); return Math.min(T, 13.12+0.6215*T-11.37*p+0.3965*T*p);
}
// ماتریس ریسک (مثل هشدارهای تأثیرمحور): سطر = احتمال (۰ خیلی کم … ۳ زیاد)، ستون = شدت پیامد (۰ … ۳)
const WN_MATRIX=[[0,0,1,1],[0,1,1,2],[0,1,2,2],[0,1,2,3]];
const WN_COL=[null, [[255,248,176],[255,222,0],[214,172,0]], [[255,214,168],[255,140,0],[200,92,0]], [[255,176,176],[232,20,20],[128,0,0]]];
function wnColor(v){ if(!(v>0)) return [255,255,255]; const L=Math.min(3,Math.ceil(v-1e-9)), f=Math.max(0,Math.min(1,v-(L-1))), c=WN_COL[L], s=f*2, i=Math.min(1,Math.floor(s)), u=s-i;
  return [0,1,2].map(k=>Math.round(c[i][k]+(c[i+1][k]-c[i][k])*u)); }
const WN_SCHEME={colors:[1,2,3].flatMap(L=>[0.17,0.5,0.83].map(f=>{ const c=wnColor(L-1+f); return "#"+c.map(x=>x.toString(16).padStart(2,"0")).join(""); })),
  cls:v=>!(v>0)?-1:Math.min(8,Math.floor((v-1e-9)*3)), labs:["بدون هشدار","زرد","","زرد شدید","نارنجی","","نارنجی شدید","قرمز","","قرمز جدی"], title:"سطح هشدار",
  maxTxt:v=>`بالاترین سطح: ${["بدون هشدار","زرد","نارنجی","قرمز"][Math.min(3,Math.ceil(v-1e-9))]||"بدون هشدار"}${v>2.66?" (جدی)":""}`};
// نقشه‌های مقداری شدت شرجی و سوز باد (رده‌های استاندارد)
const fmtC=v=>"\u2066"+FA(Math.round(v))+" °C\u2069";
// شاخص گرما (NWS): احتیاط ۲۶٫۷، احتیاط شدید ۳۲٫۲، خطر ۳۹٫۴ و خطر شدید ۵۱٫۷ درجه
const HI_SCHEME={colors:["#fff59d","#ffc400","#ff6d00","#c62828"], cls:v=>!(v>=26.7)?-1:v<32.2?0:v<39.4?1:v<51.7?2:3,
  labs:["کمتر از ۲۷","احتیاط ۲۷–۳۲","احتیاط شدید ۳۲–۳۹","خطر ۳۹–۵۲","خطر شدید ۵۲+"], title:"شاخص گرما (°C)", maxTxt:v=>`بیشینهٔ شاخص گرما: ${fmtC(v)}`};
// سوز باد (Environment Canada): کم ۰ تا ۹-، متوسط ۱۰- تا ۲۷-، زیاد ۲۸- تا ۳۹-، خیلی زیاد ۴۰- تا ۴۷-، شدید ۴۸- و سردتر
const WC_SCHEME={colors:["#c9e4ff","#8fc6ff","#2f6fdc","#6a2bbf","#d2a8ff"], cls:v=>!(v<0)?-1:v>-10?0:v>-28?1:v>-40?2:v>-48?3:4,
  labs:["بالای صفر","کم ۰ تا ۹-","متوسط ۱۰- تا ۲۷-","زیاد ۲۸- تا ۳۹-","خیلی زیاد ۴۰- تا ۴۷-","شدید ۴۸-"], title:"سوز باد (°C)", maxTxt:v=>`کمینهٔ دمای احساسی: ${fmtC(v)}`};
// پتانسیل سیلاب (آزمایشی): شاخص ۰ تا ۱۰۰
const FP_SCHEME={colors:["#c6e6ff","#6fb6f2","#2b6fd6","#5b1fa8"], cls:v=>!(v>=20)?-1:v<40?0:v<60?1:v<80?2:3,
  labs:["خیلی کم","کم","متوسط","زیاد","خیلی زیاد"], title:"پتانسیل سیلاب (۰ تا ۱۰۰)", maxTxt:v=>`بیشینهٔ شاخص: ${FA(Math.round(v))} از ۱۰۰`};
const VM_DEF={
  w_hi:{sch:()=>HI_SCHEME, nm:"شاخص گرما (شرجی) — مقدار", card:"نقشهٔ مقدار شاخص گرما (شرجی)", hi:true, file:"heat_index.png", fmt:v=>fmtC(v),
    sub:"شاخص گرمای سرویس ملی هواشناسی آمریکا (رگرسیون Rothfusz) از دما و رطوبت؛ رده‌ها: احتیاط، احتیاط شدید، خطر و خطر شدید"},
  w_wchill:{sch:()=>WC_SCHEME, nm:"دمای احساسی سوز سرما — مقدار", card:"نقشهٔ مقدار دمای احساسی (سوز سرما)", hi:false, file:"wind_chill.png", fmt:v=>fmtC(v),
    sub:"فرمول سوز باد کانادا و آمریکا (۲۰۰۱) از دما و سرعت باد ۱۰ متری؛ رده‌های خطر سرمازدگی Environment Canada"},
  w_flash:{sch:()=>FP_SCHEME, nm:"پتانسیل سیل ناگهانی (آزمایشی)", card:"نقشهٔ پتانسیل سیل ناگهانی (آزمایشی)", hi:true, file:"flash_flood_potential.png", fmt:v=>FA(Math.round(v))+" از ۱۰۰",
    sub:"شاخص پتانسیل سیل ناگهانی FFPI (شیب از DEM ۹۰ متری، گروه هیدرولوژیک خاک، شکل زمین، ردهٔ فرسایش‌پذیری) × محرک بارش (روان‌آب SCS-CN و شدت بارش) + روان‌آب متمرکز بالادست (روندیابی D8). پوشش گیاهی و رطوبت پیشین خاک (AMC) فرض متوسط است."},
  w_wlog:{sch:()=>FP_SCHEME, nm:"پتانسیل آب‌گرفتگی (آزمایشی)", card:"نقشهٔ پتانسیل آب‌گرفتگی (آزمایشی)", hi:true, file:"waterlogging_potential.png", fmt:v=>FA(Math.round(v))+" از ۱۰۰",
    sub:"روان‌آب SCS-CN (خاک ریزبافت و شور = نفوذ کم) + آب رسیده از بالادست، روی زمین کم‌شیب (شیب DEM ۹۰ متری) و شاخص رطوبت توپوگرافی TWI؛ دشت، کف دره، چاله و پلایا مستعدترند. زهکشی شهری در محاسبه نیست."},
  w_floodp:{sch:()=>FP_SCHEME, nm:"پتانسیل وقوع سیلاب (آزمایشی)", card:"نقشهٔ پتانسیل وقوع سیلاب (نسخهٔ آزمایشی)", hi:true, file:"flood_potential.png", fmt:v=>FA(Math.round(v))+" از ۱۰۰",
    sub:"بیشینهٔ دو خطر: آب‌گرفتگی (روان‌آب SCS-CN روی زمین کم‌شیب، TWI) و سیل ناگهانی (FFPI × شدت بارش و آب بالادست). ورودی‌ها: بارش و شدت آن، همرفت، سهم برف، DEM ۹۰ متری، خاک و شکل زمین، فرسایش‌پذیری. رطوبت پیشین خاک، کاربری زمین، آبراهه‌ها و سدها در محاسبه نیست؛ جایگزین هشدار رسمی سیلاب نیست."}
};
// شاخص پتانسیل سیلاب روی شبکهٔ خروجی
async function floodPotential(fields, rp, sea, meanF){
  const of=t=>fields.filter(f=>f.m.type===t), RN=of("w_rain"), RWX=of("w_rainwx"), RT=of("w_rate");
  if(!RN.length && !RWX.length && !RT.length) return null;
  const clamp=v=>v<0?0:v>1?1:v;
  const RTm=RT.length?meanF(RT):null;
  let Pm=RN.length?meanF(RN):null, src=RN.length?"mm":"";
  if(!Pm && RWX.length){ const lv=meanF(RWX); Pm=Float32Array.from(lv,v=>v===v?[0,6,18,40][Math.max(0,Math.min(3,Math.round(v)))]:NaN); src="cat"; }
  if(!Pm && RTm){ Pm=Float32Array.from(RTm,v=>v*3); src="rate"; }
  const SW=of("w_snowmm"), SC=of("w_snow"), Sw=SW.length?meanF(SW):SC.length?meanF(SC):null;   // ۱ سانتی‌متر برف ≈ ۱ میلی‌متر آب
  const conv=new Float32Array(N).fill(NaN), up=(i,v)=>{ if(v===v && !(conv[i]>=v)) conv[i]=v; };
  const add=(t,fn)=>{ const fs=of(t); if(!fs.length) return; const m_=meanF(fs); for(let i=0;i<N;i++) up(i, fn(m_[i])); };
  add("w_ts",v=>v>=2.5?1:v>=1.5?0.8:v>=0.5?0.5:0); add("w_cape",v=>clamp(v/2000)); add("w_tsp",v=>clamp(v/70)); add("w_ltg",v=>v>0.05?Math.min(1,0.5+v/10):0);
  if(RTm) for(let i=0;i<N;i++) up(i, clamp((RTm[i]-2)/18));
  const Pe=new Float32Array(N); for(let i=0;i<N;i++){ const p=Pm[i]; Pe[i]= p===p ? Math.max(0, p-(Sw&&Sw[i]===Sw[i]?0.9*Sw[i]:0)) : 0; }
  // ارتفاع، شیب و روندیابی D8 (آب بالادست)
  const E=new Float32Array(N).fill(NaN), kmx=new Float32Array(FH); let dem=null; try{ dem=await dsBuiltinDEM(); }catch(e){}
  for(let y=0;y<FH;y++){ const lat=(y+rp.fy0-rp.ay)/rp.by; kmx[y]=111.32*Math.cos(lat*Math.PI/180)/Math.abs(rp.bx); }
  const kmy=111.32/Math.abs(rp.by);
  if(dem && rp.geo) for(let i=0;i<N;i++){ const X=rp.fx0+i%FW, Y=rp.fy0+((i/FW)|0), lat=(Y-rp.ay)/rp.by, lon=(X-rp.ax)/rp.bx, jj=Math.round((lon-dem.x0)/dem.dx), ii=Math.round((dem.y0-lat)/dem.dy);
    if(jj>=0&&ii>=0&&jj<dem.nx&&ii<dem.ny) E[i]=dem.data[ii*dem.nx+jj]; }
  const slope=new Float32Array(N).fill(NaN);
  for(let y=1;y<FH-1;y++) for(let x=1;x<FW-1;x++){ const i=y*FW+x, a=E[i-1], b=E[i+1], c=E[i-FW], d=E[i+FW]; if(a===a&&b===b&&c===c&&d===d){ const gx=(b-a)/(2000*kmx[y]), gy=(d-c)/(2000*kmy); slope[i]=Math.atan(Math.hypot(gx,gy))*180/Math.PI; } }
  const A=new Float64Array(N), V=new Float64Array(N), ord=[];
  for(let i=0;i<N;i++){ const ar=kmx[(i/FW)|0]*kmy; A[i]=ar; V[i]=Pe[i]*ar; if(E[i]===E[i] && !(sea&&sea[i])) ord.push(i); }
  ord.sort((p,q)=>E[q]-E[p]);
  for(const i of ord){ const x=i%FW, y=(i/FW)|0; let j=-1, ez=E[i], best=0;
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ if(!dx&&!dy) continue; const xx=x+dx, yy=y+dy; if(xx<0||yy<0||xx>=FW||yy>=FH) continue; const k=yy*FW+xx, e=E[k]; if(!(e===e)) continue;
      const g=(ez-e)/((dx&&dy)?1.414:1); if(g>best){ best=g; j=k; } }
    if(j>=0){ A[j]+=A[i]; V[j]+=V[i]; } }
  // ===== مدل استاندارد سیل‌خیزی (بازطراحی‌شده) =====
  // ۱) روان‌آب از روش شمارهٔ منحنی SCS-CN (USDA TR-55، رطوبت پیشین متوسط AMC II):
  //    S=25400/CN−254 ، Ia=0.2S ، Q=(P−Ia)²/(P−Ia+S)   ← گروه هیدرولوژیک خاک از بافت خاک سطحی، شوری و شکل زمین
  // ۲) آب‌گرفتگی: روان‌آب محلی + آبِ رسیده از بالادست روی زمین کم‌شیب؛ با شاخص رطوبت توپوگرافی TWI=ln(a/tanβ) (Beven & Kirkby 1979)
  // ۳) سیل ناگهانی: شاخص پتانسیل سیل ناگهانی FFPI (Smith 2003) از شیب، خاک، شکل زمین و فرسایش‌پذیری × شدت بارش و روان‌آب بالادست
  // شیب β از DEM ۹۰ متری (میانگین شیب واقعی دامنه‌ها در هر خانهٔ ۱ دقیقه‌ای)
  let TR=null; try{ if(rp.geo) TR=await terrainLoad(); }catch(e){ console.warn("terrain",e); }
  let SL90=null; try{ if(rp.geo) SL90=await demSlopeLoad(); }catch(e){}
  const F=new Float32Array(N), WL=new Float32Array(N), FF=new Float32Array(N), QR=new Float32Array(N), CNa=new Float32Array(N), BETA=new Float32Array(N); let nSoil=0;
  // گروه هیدرولوژیک: ۰=A ۱=B ۲=C ۳=D ؛ CN مراتع خشک و نیمه‌خشک با پوشش ضعیف (TR-55: A63 B77 C85 D88)، سنگلاخ و بدلند ≈ ۹۱–۹۴، تپهٔ ماسه‌ای ≈ ۴۵
  const CN_RANGE=[63,77,85,88];
  // امتیاز شکل زمین برای FFPI (۱ تا ۱۰): ۰ نامعلوم، ۱ دشت/کف دره/پلایا، ۲ فلات، ۳ پای‌دامنهٔ کم‌شیب، ۴ تپه، ۵ کوه متوسط، ۶ کوه پرشیب/سنگلاخ، ۷ بدلند/گنبد نمکی/کلوت، ۸ تپهٔ ماسه‌ای، ۹ دره، ۱۰ آب
  const LF_FF=[5,2,3,4,6,8,9,9,1,8,0];
  for(let i=0;i<N;i++){
    const X=rp.fx0+i%FW, Y=rp.fy0+((i/FW)|0), lat=(Y-rp.ay)/rp.by, lon=(X-rp.ax)/rp.bx;
    let ter=null; if(TR){ ter=terrainAt(TR,lat,lon); if(ter) nSoil++; }
    let b = SL90 && rp.geo ? demSlopeAt(SL90,lat,lon) : NaN; if(!(b===b)) b=slope[i]; BETA[i]=b;
    let hsg = ter ? ({0:1,1:0,2:1,3:2})[ter.tx] : 1; if(ter && (ter.sal || ter.lf===1&&ter.sal)) hsg=3;
    let cn=CN_RANGE[hsg];
    if(ter){ if(ter.lf===6) cn=Math.max(cn,91); else if(ter.lf===7) cn=Math.max(cn,94); else if(ter.lf===8) cn=45; else if(ter.lf===10) cn=100; else if(ter.lf===5) cn=Math.max(cn,84); }
    else if(b===b){ cn = b>15 ? 88 : b>6 ? 82 : 77; }
    CNa[i]=cn;
    const p=Pe[i], S=25400/cn-254, Ia=0.2*S;
    QR[i] = p>Ia ? (p-Ia)*(p-Ia)/(p-Ia+S) : 0;
  }
  // روندیابی D8 روان‌آب (حجم) — جهت جریان از DEM
  const AQ=new Float64Array(N), VQ=new Float64Array(N);
  for(let i=0;i<N;i++){ AQ[i]=A[i]; VQ[i]=QR[i]*A[i]; }
  for(const i of ord){ const x=i%FW, y=(i/FW)|0; let j=-1, ez=E[i], best=0;
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ if(!dx&&!dy) continue; const xx=x+dx, yy=y+dy; if(xx<0||yy<0||xx>=FW||yy>=FH) continue; const k=yy*FW+xx, e=E[k]; if(!(e===e)) continue;
      const g=(ez-e)/((dx&&dy)?1.414:1); if(g>best){ best=g; j=k; } }
    if(j>=0){ AQ[j]+=AQ[i]; VQ[j]+=VQ[i]; } }
  for(let i=0;i<N;i++){
    if(sea&&sea[i]){ continue; }
    const q=QR[i], b=BETA[i]===BETA[i]?BETA[i]:2, tb=Math.tan(Math.max(0.1,b)*Math.PI/180);
    const cellKm=Math.sqrt(A[i]), aSpec=AQ[i]/Math.max(1e-6,cellKm)*1000;              // مساحت ویژهٔ حوضه (متر)
    const twi=Math.log(Math.max(1,aSpec)/tb), twiN=clamp((twi-6)/8);                    // TWI ≈ ۶ (ستیغ) تا ۱۴ (کف دره)
    const qUp = AQ[i]>A[i]*1.5 ? (VQ[i]-q*A[i])/(AQ[i]-A[i]) : 0;                       // روان‌آب میانگین بالادست (mm)
    const ratio = AQ[i]/A[i];
    const intens = RTm&&RTm[i]===RTm[i] ? clamp((RTm[i]-4)/21) : clamp((Pe[i]*(0.4+0.9*(conv[i]===conv[i]?conv[i]:0.3))-5)/30);
    // آب‌گرفتگی: عمق تجمعی تقریبی روی زمین کم‌شیب
    const flat = clamp((5-b)/4);                                                         // کمتر از ۱° = ۱ ، بیش از ۵° = ۰
    let ter=null; if(TR){ const X=rp.fx0+i%FW, Y=rp.fy0+((i/FW)|0); ter=terrainAt(TR,(Y-rp.ay)/rp.by,(X-rp.ax)/rp.bx); }
    const lowland = ter ? (ter.lf===1||ter.lf===9 ? 1 : ter.lf===2||ter.lf===3 ? 0.6 : 0.25) : 0.6;
    const pond = q + qUp*Math.min(1, Math.log10(Math.max(1,ratio))/2)*0.6;
    WL[i]=100*clamp((pond/25) * flat * (0.45+0.35*twiN+0.2*lowland) * (0.7+0.3*intens) * 1.4);
    // سیل ناگهانی (FFPI ۱ تا ۱۰ × محرک بارش)
    const sS = 1+9*clamp(b/30), sSoil=[2,4,7,9][CNa[i]>=88?3:CNa[i]>=85?2:CNa[i]>=77?1:0], sLF = ter ? (LF_FF[ter.lf]||5) : 1+8*clamp(b/25), sE = ter&&ter.ero ? ter.ero : 5;
    const ffpi=(sS+sSoil+sLF+sE)/4;
    const trig = Math.max(clamp(q/30)*(0.5+0.5*intens), 0.6*intens*clamp(Pe[i]/15));
    const upst = clamp(Math.log10(Math.max(1,AQ[i]/10))/2.5) * clamp(qUp/20);              // آب متمرکز بالادست (بیش از ۱۰ کیلومتر مربع)
    FF[i]=100*clamp(Math.max(trig*(ffpi/10)*1.5, upst*(0.5+0.5*ffpi/10)*1.2));
    F[i]=Math.max(WL[i], FF[i]);
  }
  const G=gauss(F, 1.0), GW=gauss(WL,1.0), GF=gauss(FF,1.0); for(let i=0;i<N;i++) if(sea&&sea[i]){ G[i]=NaN; GW[i]=NaN; GF[i]=NaN; }
  return {vals:G, wl:GW, ff:GF, src, hasDem:!!(dem&&rp.geo), hasSoil:nSoil>0.05*N};
}
async function wnRun(){
  if(wn.busy){ wn.pending=true; return; }
  const maps=wn.maps.filter(m=>!m.bad && m.v);
  if(!maps.length){ if(wn.maps.length) wnStatus("⚠ هنوز هیچ نقشه‌ای آماده نیست: اعداد نوار رنگ نقشه‌ها را در فهرست کناری وارد کنید.", 0); return; }
  wn.busy=true; $("wnRun").disabled=true; const prev=P?P.key:null, warns=[];
  { const sk=wn.maps.filter(m=>m.bad||!m.v), nm=a=>a.slice(0,6).map(m=>"«"+m.file.name+"»").join("، ")+(a.length>6?` و ${FA(a.length-6)} نقشهٔ دیگر`:"");
    const nb=sk.filter(m=>m.bad), ne=sk.filter(m=>!m.bad);
    if(ne.length) warns.push(`${FA(ne.length)} نقشه هنوز اعداد نوار رنگ ندارد و در تحلیل نیامد (${nm(ne)})؛ اعداد را در فهرست کناری وارد کنید.`);
    if(nb.length) warns.push(`قالب ${FA(nb.length)} نقشه تشخیص داده نشد (${nm(nb)}).`); }
  try{
    const ref=maps.find(m=>!m.sig); if(!ref) throw new Error("دست‌کم یک نقشهٔ عددی (مثلاً بارش یا دما) لازم است تا قالب و کادر خروجی از آن گرفته شود");
    const rp=ref.prof, TH=wnThr(), fields=[];
    for(let k=0;k<maps.length;k++){ const m=maps[k];
      wnStatus(`رقومی‌سازی ${m.file.name}…`, 0.05+0.5*k/maps.length); await tick();
      if(m.sig){ const S_=wnSigwxFields(m);
        for(const ty of WU_SIGWX_T){ const al=await cvAlign(m, {vals:S_.out[ty], FW:S_.FW, FH:S_.FH, fx0:S_.fx0, fy0:S_.fy0}, ref, rp); if(al) fields.push({m:{...m, type:ty}, vals:al.out, same:al.same}); }
        await useProfile(rp.key); continue; }
      const D=await cvDigitize(m), al=await cvAlign(m, D, ref, rp);
      if(!al){ warns.push(`«${m.file.name}» قالب دیگری دارد و مکانش پیدا نشد؛ کنار گذاشته شد.`); continue; }
      fields.push({m, vals:al.out, same:al.same, cls:al.same?D.cls:null, D}); }
    if(!fields.length) throw new Error("هیچ نقشه‌ای قابل استفاده نبود");
    await useProfile(rp.key);
    // خطوط ثابت (مرز و ساحل) از نقشه‌های هم‌قالب؛ پربندها و نوشته‌ها حذف
    { let same=fields.filter(f=>f.same && f.cls);
      if(same.length>=2){ const bgc=rp.pal[rp.bgIdx||0];
        const synth=same.map(f=>{ const dd=new Uint8ClampedArray(ref.data), src=f.m.data, ox=f.D.fx0, oy=f.D.fy0, fw=f.D.FW;
          for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const X=x+rp.fx0, Y=y+rp.fy0, sx=X-ox, sy=Y-oy, q=(Y*ref.w+X)*4; if(sx<0||sy<0||sx>=fw||sy>=f.D.FH) continue;
            const c=f.cls[sy*fw+sx]; if(c>=0){ dd[q]=bgc[0]; dd[q+1]=bgc[1]; dd[q+2]=bgc[2]; } else { const k=(Y*f.m.w+X)*4, l=Math.round(Math.min(0.299*src[k]+0.587*src[k+1]+0.114*src[k+2], Math.min(src[k],src[k+1],src[k+2])+40)); dd[q]=l; dd[q+1]=l; dd[q+2]=l; } }
          return {data:dd, w:ref.w, h:ref.h}; });
        computeStatic(synth); rp.staticDirty=true;
        if(P.ov && P.ov.bold){ const c=P.ov.bold.getContext("2d"), im=c.getImageData(0,0,P.W,P.H), d=im.data; for(let q=0;q<d.length;q+=4) if(d[q+3] && 0.299*d[q]+0.587*d[q+1]+0.114*d[q+2] > 170) d[q+3]=0; c.putImageData(im,0,0); }
      } else if(rp.staticDirty){ computeStatic(rp.models); rp.staticDirty=false; } }
    const g0=await cvGeo(ref); if(g0){ rp.geo=true; [rp.ax,rp.bx,rp.ay,rp.by]=g0; } else rp.geo=false;
    if(rp.geo){ P.ov={bold:vectorBorders(rp)}; }
    await useProfile(rp.key);
    wnStatus("محاسبهٔ سطح هشدار…", 0.7); await tick();
    let sea=null; if(rp.geo){ sea=new Uint8Array(N); for(let i=0;i<N;i++){ const X=rp.fx0+i%FW, Y=rp.fy0+Math.floor(i/FW); if(landAt((Y-rp.ay)/rp.by,(X-rp.ax)/rp.bx)===0) sea[i]=1; } }
    // سطح هر پدیده در هر پیکسل؛ سطح کل = بیشینه؛ شدت درون سطح = شدت بیشینه + تأکید برای چند پدیدهٔ هم‌سطح
    const Lv=new Uint8Array(N), Ex=new Float32Array(N), Cn=new Uint8Array(N);
    // پدیده‌های مشتق از نقشه‌های دما: یخبندان، گرمای شدید، یخبندان سطح خاک (از دمای خاک یا دمای ۲ متری منهای اختلاف هنگام طلوع) و شرجی (شاخص گرما از دما و نقطهٔ شبنم)
    const gOff=Math.max(0, parseFloat($("wnGOff").value)||3), hzF=fields.filter(f=>!WN[f.m.type].input), notes=[];
    const T2=fields.filter(f=>f.m.type==="w_t2m"), TS=fields.filter(f=>f.m.type==="w_tsoil"), TD=fields.filter(f=>f.m.type==="w_td");
    const der=(f, type, fn)=>({m:{...f.m, type}, vals:Float32Array.from(f.vals, fn)});
    for(const f of T2){ hzF.push(der(f,"w_frost",v=>v)); hzF.push(der(f,"w_heat",v=>v)); }
    if(TS.length) for(const f of TS) hzF.push(der(f,"w_gfrost",v=>v));
    else if(T2.length){ for(const f of T2) hzF.push(der(f,"w_gfrost",v=>v-gOff)); notes.push(gOff); }
    // جفت‌کردن نقشه‌های دو پارامتر: هم‌مدل و هم‌زمان؛ اگر جفتی نبود، میانگین هر پارامتر
    const meanF=fs=>{ const o=new Float32Array(N); for(let i=0;i<N;i++){ let s=0,n=0; for(const f of fs){ const v=f.vals[i]; if(v===v){ s+=v; n++; } } o[i]=n?s/n:NaN; } return o; };
    const tk=f=>f.m.times&&f.m.times.end?+f.m.times.end:null;
    const pairUp=(A,B)=>{ const out=[]; for(const a of A){ const b=B.find(g=>g.m.model===a.m.model && tk(g)===tk(a)) || B.find(g=>g.m.model && g.m.model===a.m.model && (tk(g)===null || tk(a)===null)) || B.find(g=>tk(g)!==null && tk(g)===tk(a) && !g.m.model);
        if(b) out.push({m:a.m, a:a.vals, b:b.vals}); }
      if(out.length) return out;
      const ta=new Set(A.map(tk).filter(x=>x!==null)), tb=new Set(B.map(tk).filter(x=>x!==null));
      if(ta.size && tb.size && ![...ta].some(x=>tb.has(x))) warns.push(`زمان اعتبار نقشه‌های «${WN[A[0].m.type].n}» و «${WN[B[0].m.type].n}» یکی نیست؛ میانگین هر کدام با هم ترکیب شد. برای دقت بیشتر نقشه‌های هم‌زمان و هم‌مدل بدهید.`);
      return [{m:A[0].m, a:meanF(A), b:meanF(B)}]; };
    const RH=fields.filter(f=>f.m.type==="w_rh"), WS=fields.filter(f=>f.m.type==="w_wind"), valMaps=[];
    // شدت شرجی: شاخص گرما از دما و رطوبت نسبی (یا نقطهٔ شبنم)
    if(T2.length && (RH.length || TD.length)){ const useRH=RH.length>0, list=pairUp(T2, useRH?RH:TD), ext=new Float32Array(N).fill(NaN);
      for(const p of list){ const v=new Float32Array(N); for(let i=0;i<N;i++){ v[i]= useRH ? heatIndexRH(p.a[i], p.b[i]) : heatIndex(p.a[i], p.b[i]); if(v[i]===v[i] && !(ext[i]>=v[i])) ext[i]=v[i]; } hzF.push({m:{...p.m, type:"w_hi"}, vals:v}); }
      valMaps.push({type:"w_hi", vals:ext, n:list.length, src:useRH?"rh":"td"}); }
    // سوز باد: از دما و سرعت باد ۱۰ متری (km/h)
    if(T2.length && WS.length){ const list=pairUp(T2, WS), ext=new Float32Array(N).fill(NaN);
      for(const p of list){ const v=new Float32Array(N); for(let i=0;i<N;i++){ v[i]=windChill(p.a[i], p.b[i]); if(v[i]===v[i] && !(ext[i]<=v[i])) ext[i]=v[i]; } hzF.push({m:{...p.m, type:"w_wchill"}, vals:v}); }
      valMaps.push({type:"w_wchill", vals:ext, n:list.length}); }
    // پتانسیل سیلاب (آزمایشی) از بارش، همرفت، برف، شیب و آب بالادست
    { let fp=null; try{ wnStatus("برآورد پتانسیل سیلاب…", 0.72); await tick(); fp=await floodPotential(fields, rp, sea, meanF); }catch(e){ console.warn("flood",e); }
      if(fp){ const base=fields.find(f=>/^w_(rain|rainwx|rate)$/.test(f.m.type));
        // آب‌گرفتگی (زمین کم‌شیب، نفوذ کم) و سیل ناگهانی (شیب تند، دره، سنگلاخ، فرسایش) جدا از هم
        hzF.push({m:{...base.m, type:"w_wlog"}, vals:fp.wl}); hzF.push({m:{...base.m, type:"w_flash"}, vals:fp.ff});
        valMaps.push({type:"w_flash", vals:fp.ff, n:1, src:fp.src, hasDem:fp.hasDem, hasSoil:fp.hasSoil}); valMaps.push({type:"w_wlog", vals:fp.wl, n:1, src:fp.src, hasDem:fp.hasDem, hasSoil:fp.hasSoil}); } }
    const likeDef=+($("wnLike").value||3), byType={}; for(const f of hzF) (byType[f.m.type]=byType[f.m.type]||[]).push(f);
    const per=Object.entries(byType).map(([type, fs])=>{ const L=new Uint8Array(N), E=new Float32Array(N), K=new Uint8Array(N), LK=new Uint8Array(N), V=new Float32Array(N).fill(NaN), t=TH[type], dir=WN[type].dir, n=fs.length;
      const off=WN[type].seaOff && sea;   // CAPE روی دریا معتبر نیست
      for(let i=0;i<N;i++){ if(off && sea[i]) continue;
        const lv=[], ev=[]; let vx=NaN; for(const f of fs){ const v=f.vals[i]; const [l,e]=wnLevel(v, t, dir); lv.push(l); ev.push(e); if(v===v){ const a=dir==="down"?-v:dir==="abs"?Math.abs(v):v, b=dir==="down"?-vx:dir==="abs"?Math.abs(vx):vx; if(!(vx===vx) || a>b) vx=v; } }
        V[i]=vx; let best=0, be=0, bk=0, bl=likeDef;
        for(let k=1;k<=3;k++){ const fr=lv.filter(l=>l>=k).length/n; if(!fr) break; const lik = n===1 ? likeDef : (fr>=0.75?3:fr>=0.5?2:fr>=0.25?1:0); const w=WN_MATRIX[lik][k];
          if(w>best || (w===best && w>0)){ best=w; bk=k; bl=lik; be=Math.max(...ev.filter((e,j)=>lv[j]===Math.max(...lv))); } }
        L[i]=best; E[i]=best ? (bk>best ? 1 : be) : 0; K[i]=bk; LK[i]=bl; }
      return {f:{m:{type}, vals:V}, L, E, K, LK, n}; });
    for(let i=0;i<N;i++){ let L=0, e=0, c=0; const seen=new Set();
      for(const p of per){ const l=p.L[i]; if(l>L){ L=l; e=p.E[i]; c=1; seen.clear(); seen.add(p.f.m.type); } else if(l===L && l>0){ if(p.E[i]>e) e=p.E[i]; if(!seen.has(p.f.m.type)){ seen.add(p.f.m.type); c++; } } }
      Lv[i]=L; Ex[i]=e; Cn[i]=c; }
    const S0=new Float32Array(N); for(let i=0;i<N;i++) if(Lv[i]) S0[i]=Lv[i]-1+Math.min(1, 0.08+0.62*Ex[i]+(Cn[i]>=2?0.3:0)+(Cn[i]>=3?0.15:0));
    const Sg=gauss(S0, 1.2), out=new Float32Array(N); for(let i=0;i<N;i++){ const L=Lv[i]; out[i] = L ? Math.max(L-1+0.02, Math.min(L, Sg[i])) : 0; }
    // زمان، منطقه، شهرها
    const ts=fields.map(f=>f.m.times).filter(t=>t&&t.end); let from="", tStr="";
    if(ts.length){ const a=ts.reduce((x,y)=>+y.end<+x.end?y:x), b=ts.reduce((x,y)=>+y.end>+x.end?y:x), off=b.offset||0;
      const EN_=LANG==="en", pa=wnDayPart(+a.end,off,EN_), pb=wnDayPart(+b.end,off,EN_);
      if(EN_){ from = +a.end===+b.end ? "Valid for "+(pb?pb+", ":"")+persianDT(b.end,off)+tzSuffix(off) : "From "+(pa?pa+", ":"")+persianDT(a.end,off)+tzSuffix(off)+" to "+(pb?pb+", ":"")+persianDT(b.end,off)+tzSuffix(off); tStr=from; } else
      from = +a.end===+b.end ? "معتبر برای "+(pb?pb+" ":"")+persianDT(b.end,off)+tzSuffix(off) : "از "+(pa?pa+" ":"")+persianDT(a.end,off)+tzSuffix(off)+" تا "+(pb?pb+" ":"")+persianDT(b.end,off)+tzSuffix(off); tStr=from; }
    const regionFa=(ref.region&&CV_REGIONS[ref.region]) || ref.regionFa || cvRegionFromGeo(rp) || "";
    WUZ.autoWn = WU_ZOOMS[regionFa] ? regionFa : null; try{ wuzSync(); }catch(e){}
    const FOREIGN=new Set(["بغداد","بصره","کویت","ریاض","دوحه","دبی","مسقط","باکو","عشق‌آباد","هرات","کابل","کراچی","اربیل","ایروان","آنکارا","دمشق","منامه"]);
    const cities=[]; if(rp.geo) for(const [nm,la,lo] of CV_CITIES){ if(FOREIGN.has(nm)) continue; const X=Math.round(rp.ax+rp.bx*lo)-rp.fx0, Y=Math.round(rp.ay+rp.by*la)-rp.fy0; if(X<3||Y<3||X>=FW-3||Y>=FH-3) continue;
      let bi=Y*FW+X; for(let dy=-2;dy<=2;dy++) for(let dx=-2;dx<=2;dx++){ const j=(Y+dy)*FW+X+dx; if(out[j]>out[bi]) bi=j; }
      const hz=per.map(p=>({type:p.f.m.type, L:p.L[bi], e:p.E[bi], v:p.f.vals[bi]})).filter(h=>h.L>0).sort((a,b)=>b.L-a.L||b.e-a.e);
      if(cities.some(c=>c.nm===nm)) continue;
      cities.push({nm, L:Lv[bi], s:out[bi], hz}); }
    const SEC=["شمال‌غرب","شمال","شمال‌شرق","غرب","مرکز","شرق","جنوب‌غرب","جنوب","جنوب‌شرق"], secOf=i=>Math.min(2,Math.floor(3*((i/FW)|0)/FH))*3+Math.min(2,Math.floor(3*(i%FW)/FW));
    const area=[0,0,0,0], secMax=new Array(9).fill(0), typeMax={}; let nL=0;
    for(let i=0;i<N;i++){ if(sea&&sea[i]) continue; nL++; area[Lv[i]]++; const k=secOf(i); if(Lv[i]>secMax[k]) secMax[k]=Lv[i]; }
    for(const p of per){ const t=p.f.m.type; let mx=-Infinity, mn=Infinity, lv=0; for(let i=0;i<N;i++){ const v=p.f.vals[i]; if(!(v===v)) continue; if(v>mx) mx=v; if(v<mn) mn=v; if(p.L[i]>lv) lv=p.L[i]; }
      const o=typeMax[t]||{mx:-Infinity, mn:Infinity, lv:0}; typeMax[t]={mx:Math.max(o.mx,mx), mn:Math.min(o.mn,mn), lv:Math.max(o.lv,lv)}; }
    // بازهٔ زمانی هر پدیده (از زمان اعتبار نقشه‌های همان پدیده) و سهم خشکی زیر هر سطح
    const times={}, typeArea={};
    for(const [t,fs] of Object.entries(byType)){ const tt=fs.map(f=>f.m.times).filter(x=>x&&x.end); if(!tt.length) continue;
      const a=tt.reduce((x,y)=>+y.end<+x.end?y:x), b=tt.reduce((x,y)=>+y.end>+x.end?y:x), off=b.offset||0;
      times[t]={a:+a.end, b:+b.end, off, sa:persianDT(a.end,off)+tzSuffix(off), sb:persianDT(b.end,off)+tzSuffix(off)}; }
    for(const p of per){ const a=[0,0,0,0]; let n=0; for(let i=0;i<N;i++){ if(sea&&sea[i]) continue; n++; a[p.L[i]]++; } const t=p.f.m.type, o_=typeArea[t]||[0,0,0,0]; typeArea[t]=a.map((c,k)=>Math.max(o_[k], n?c/n:0)); }
    // استان و بخش استان (شمال، شرق، …) زیر هر پدیده و سطح؛ برای متن هشدار وقتی نام شهرها زیاد یا هیچ است
    let typeProv=null; try{ if(rp.geo) typeProv=wnProvParts(rp, per, sea); }catch(e){ console.warn("prov parts",e); }
    const text=wnText({cities, regionFa, from, area, nL, SEC, secMax, typeMax, types:Object.keys(byType), gOff:notes.length?gOff:null, times:new Set(Object.values(times).map(w=>w.sa+"|"+w.sb)).size>1?times:null, typeArea, typeProv});
    // نقشه
    const names=Object.keys(byType).map(t=>WN[t].n);
    const S={from, to:"", region:"", init:"", thr:[], sigma:0, cap:Infinity, barMode:"full", borders:wbBorders(), grid:true, showBorders:$("wnBorders").checked, brand:$("brand").value.trim(), handle:$("handle").value.trim(), logoImg:state.logoImg};
    await document.fonts.ready; await Promise.all(["21px Titr","14px Ketab","14px Lalezar","27px Nastaliq"].map(f=>document.fonts.load(f,"آبAa1")));
    let mx=0; for(let i=0;i<N;i++) if(out[i]>mx) mx=out[i];
    const info=`پدیده‌ها: ${names.join("، ")}`;
    CUR_SCHEME=WN_SCHEME;
    // آیکن پدیده‌ها روی هر ناحیهٔ هشدار (رنگ = سطح هشدار همان پدیده) و راهنمای آیکن‌ها
    let icons=null, iconLegend=null; try{ icons=hzPlace(per, Lv, sea); iconLegend=[...new Set(icons.flatMap(g=>g.list.map(h=>h.kind)))]; }catch(e){ console.warn("hz icons",e); }
    const cvW=renderMap({field:out, kind:"prob", colorFn:wnColor, title:"هشدارهای جوی"+(regionFa?" — "+regionFa:""), info1:info, info2:info, info, S, max:mx, ref:ref.data, zoom:WUZ.autoWn, icons, iconLegend});
    // نقشهٔ جداگانهٔ هر پدیده‌ای که به حد هشدار رسیده
    const perMaps=[];
    for(const p of per){ let any=false; for(let i=0;i<N;i++) if(p.L[i]){ any=true; break; } if(!any) continue;
      const s0=new Float32Array(N); for(let i=0;i<N;i++) if(p.L[i]) s0[i]=p.L[i]-1+Math.min(1, 0.08+0.62*p.E[i]);
      const sg=gauss(s0,1.2), o=new Float32Array(N); let mx_=0; for(let i=0;i<N;i++){ const L=p.L[i]; o[i]=L?Math.max(L-1+0.02, Math.min(L, sg[i])):0; if(o[i]>mx_) mx_=o[i]; }
      const nm=WN[p.f.m.type].n, inf=`${nm}${p.n>1?`  |  ${FA(p.n)} مدل (توافق مدل‌ها = احتمال وقوع)`:""}`;
      const cvp=renderMap({field:o, kind:"prob", colorFn:wnColor, title:"هشدار "+nm+(regionFa?" — "+regionFa:""), info1:inf, info2:inf, info:inf, S, max:mx_, ref:ref.data, zoom:WUZ.autoWn});
      perMaps.push({type:p.f.m.type, cv:cvp, max:mx_}); }
    for(const vm of valMaps){ const D_=VM_DEF[vm.type], hi=D_.hi, sch=D_.sch(); CUR_SCHEME=sch;
      let ex=hi?-Infinity:Infinity; for(let i=0;i<N;i++){ if(sea&&sea[i]) continue; const v=vm.vals[i]; if(v===v && (hi?v>ex:v<ex)) ex=v; }
      const nm=D_.nm, inf=(vm.type==="w_hi"?(vm.src==="rh"?"از دمای ۲ متری و رطوبت نسبی":"از دمای ۲ متری و نقطهٔ شبنم"):vm.type==="w_wchill"?"از دمای ۲ متری و سرعت باد ۱۰ متری":"نسخهٔ آزمایشی؛ به دلیل کمبود داده لزوماً دقیق نیست")+(vm.n>1?`  |  ${hi?"بیشینه":"کمینه"} ${FA(vm.n)} نقشه`:"");
      vm.cv=renderMap({field:vm.vals, kind:"prob", title:nm+(regionFa?" — "+regionFa:""), info1:inf, info2:inf, info:inf, S, max:isFinite(ex)?ex:0, ref:ref.data, zoom:WUZ.autoWn}); vm.ext=ex; vm.sch=sch; }
    CUR_SCHEME=null;
    const charts=wnCharts(per, sea, +($("wnLike").value||3));
    wn.res={perMaps, valMaps, charts, out, Lv, cvW, text, cities, regionFa, from, area, nL, fields, warns, typeMax, refKey:rp.key};
    wnShow();
    { const used=new Set(fields.map(f=>f.m.file)).size; wnStatus(`نقشهٔ هشدار آماده است: ${FA(used)} از ${FA(wn.maps.length)} نقشه در تحلیل آمد`+(warns.length?" · "+FA(warns.length)+" هشدار":""), 1); }
  }catch(e){ console.error(e); wnStatus("خطا: "+e.message, 0); }
  CUR_SCHEME=null;
  if(prev && PROFILES[prev]) await useProfile(prev); else P=undefined;
  wn.busy=false; $("wnRun").disabled=false;
  if(wn.pending){ wn.pending=false; wnSchedule(10); }
}
// متن هشدار (فارسی یا انگلیسی بسته به زبان سایت)
// اولویت پدیده‌ها در متن هشدار (خطر جانی و گستردگی پیامد؛ مشابه ترتیب انواع هشدار در سامانه‌های رنگی مثل Meteoalarm)
const WN_PRI=["w_ts","w_flash","w_wlog","w_floodp","w_flood","w_rate","w_rain","w_rainwx","w_gust","w_wind","w_snowwx","w_snowmm","w_snow","w_ice","w_hail","w_fog","w_vis","w_dust","w_hi","w_heat","w_tmax","w_frost","w_gfrost","w_tmin","w_wave","w_tsp","w_ltg","w_cape","w_tanom","w_uv","w_custom"];
const WN_ICON=["","🟡","🟠","🔴"];
// توصیه‌های کوتاه بخشی (کشاورزی و باغداری، سفر، ساخت‌وساز) برای هر گروه پدیده
const WN_ADV_GRP={w_ts:"ts",w_ltg:"ts",w_tsp:"ts",w_cape:"ts",w_rate:"rain",w_rain:"rain",w_rainwx:"rain",w_flood:"rain",w_floodp:"rain",w_flash:"flash",w_wlog:"wlog",w_gust:"wind",w_wind:"wind",
  w_snow:"snow",w_snowmm:"snow",w_snowwx:"snow",w_ice:"snow",w_wchill:"snow",w_frost:"frost",w_gfrost:"frost",w_tmin:"frost",w_fog:"vis",w_vis:"vis",w_dust:"dust",
  w_hi:"heat",w_heat:"heat",w_tmax:"heat",w_uv:"heat",w_hail:"hail",w_wave:"wave"};
const WN_ADV={
  ts:{a:["دام را هنگام رعدوبرق در فضای باز رها نکنید و سم‌پاشی و برداشت را به بعد از رگبار موکول کنید","keep livestock indoors during thunder and postpone spraying and harvest until after the showers"],
      t:["هنگام رعدوبرق در فضای باز، کنار مسیل‌ها و زیر درختان توقف نکنید","do not stop in the open, near dry riverbeds or under trees during thunderstorms"],
      b:["کار در ارتفاع، با جرثقیل و روی داربست را هنگام رعدوبرق متوقف کنید","stop work at height, with cranes and on scaffolding during thunderstorms"]},
  rain:{a:["زهکش مزارع و باغ‌ها را باز کنید، کود و سم ندهید و دام را از حاشیهٔ رودخانه دور کنید","open field and orchard drains, avoid fertiliser and spraying, and move livestock away from riverbanks"],
      t:["از عبور از مسیل‌ها و جاده‌های حاشیهٔ رودخانه پرهیز کنید و مراقب ریزش و رانش در جاده‌های کوهستانی باشید","avoid crossing flooded channels and riverside roads, and watch for rockfalls and landslides on mountain roads"],
      b:["گودها و ترانشه‌ها را ایمن، مصالح را از مسیر آب جمع و آبروها را لایروبی کنید","secure excavations and trenches, move materials out of water paths and clear drains"]},
  flash:{a:["دام و ماشین‌آلات را از کف دره‌ها و حاشیهٔ مسیل‌ها دور کنید و برداشت محصول باغ‌های کنار رودخانه را جلو بیندازید","move livestock and machinery away from valley floors and channel banks and bring forward harvest in riverside orchards"],
      t:["در کف دره‌ها و کنار رودخانه‌ها اتراق نکنید، از مسیل‌ها و گذرگاه‌های آب عبور نکنید و در جاده‌های کوهستانی مراقب ریزش سنگ باشید","do not camp on valley floors or by rivers, do not cross channels or fords, and watch for rockfalls on mountain roads"],
      b:["کارگاه‌های حریم رودخانه و مسیل را تخلیه و مصالح و ماشین‌آلات را به بالادست منتقل کنید","evacuate work sites near rivers and channels and move materials and machinery to higher ground"]},
  wlog:{a:["زهکش و آبراهه‌های مزارع دشتی را باز کنید و دام را از زمین‌های پست بیرون ببرید","open drains in lowland fields and move livestock off low ground"],
      t:["از زیرگذرها و معابر آب‌گرفته عبور نکنید و با سرعت کم برانید","avoid flooded underpasses and streets and drive slowly"],
      b:["آبروها و جوی‌ها را لایروبی، پمپ تخلیه آماده و ورودی زیرزمین‌ها و پارکینگ‌ها را مسدود کنید","clear drains and gutters, prepare pumps and block basement and car-park entrances"]},
  wind:{a:["گلخانه‌ها و پوشش‌های پلاستیکی را مهار کنید و سم‌پاشی نکنید","secure greenhouses and plastic covers and avoid spraying"],
      t:["خودروهای سبک و کامیون‌های بلند در جاده‌های باز و روی پل‌ها با احتیاط برانند","high-sided and light vehicles should drive carefully on open roads and bridges"],
      b:["داربست، تابلوها و مصالح سبک را مهار و کار با جرثقیل را متوقف کنید","secure scaffolding, signs and loose materials and stop crane work"]},
  snow:{a:["دام و آغل را در برابر سرما محافظت، علوفه ذخیره و بار برف را از سقف گلخانه‌ها برداشت کنید","protect livestock and barns from cold, store fodder and clear snow from greenhouse roofs"],
      t:["زنجیر چرخ و سوخت کافی همراه داشته باشید و از سفر غیرضروری به گردنه‌ها پرهیز کنید","carry snow chains and enough fuel and avoid unnecessary trips over mountain passes"],
      b:["بتن‌ریزی بدون تمهیدات زمستانی انجام نشود و بار برف روی سقف‌ها پایش شود","do not pour concrete without cold-weather measures and monitor snow load on roofs"]},
  frost:{a:["آبیاری سبک پیش از شب، روشن‌کردن بخاری یا مه‌پاش در باغ‌ها و پوشاندن نشاها از سرمازدگی جلوگیری می‌کند","light irrigation before night, orchard heaters or sprinklers and covering seedlings reduce frost damage"],
      t:["سطح جاده‌ها و پل‌ها در ساعات اولیهٔ صبح لغزنده است","roads and bridges are slippery in the early morning"],
      b:["بتن‌ریزی شبانه بدون محافظت انجام نشود و لوله‌های آب در معرض سرما عایق شوند","avoid unprotected night-time concreting and insulate exposed water pipes"]},
  vis:{a:["سم‌پاشی و جابه‌جایی ماشین‌آلات کشاورزی در دید کم انجام نشود","avoid spraying and moving farm machinery in poor visibility"],
      t:["با چراغ مه‌شکن، سرعت کم و فاصلهٔ ایمنی زیاد رانندگی کنید؛ احتمال تأخیر پروازها هست","drive with fog lights, low speed and long following distance; flight delays are possible"],
      b:["کار با ماشین‌آلات سنگین و در ارتفاع در دید کم محدود شود","limit heavy machinery and work at height in low visibility"]},
  dust:{a:["دام را در جای سرپوشیده نگه دارید و سم‌پاشی و گرده‌افشانی را به بعد موکول کنید","keep livestock under cover and postpone spraying and pollination"],
      t:["با چراغ روشن و سرعت کم برانید و افراد حساس از سفر غیرضروری پرهیز کنند","drive with lights on at low speed; sensitive people should avoid unnecessary trips"],
      b:["کارگران ماسک بزنند و کارهای پرگردوغبار متوقف شود","workers should wear masks and dusty work should stop"]},
  heat:{a:["آبیاری را به صبح زود یا شب منتقل کنید، از دام در برابر گرمازدگی محافظت کنید و کار در مزرعه در ساعات گرم متوقف شود","irrigate early morning or at night, protect livestock from heat stress and stop field work in the hottest hours"],
      t:["آب کافی همراه داشته باشید و پیش از سفر لاستیک‌ها و سامانهٔ خنک‌کنندهٔ خودرو را بررسی کنید","carry enough water and check tyres and the car's cooling system before travelling"],
      b:["کار در فضای باز بین ساعت ۱۱ تا ۱۶ متوقف یا محدود شود و آب و سایه برای کارگران فراهم باشد","stop or limit outdoor work between 11:00 and 16:00 and provide water and shade for workers"]},
  hail:{a:["تور ضدتگرگ باغ‌ها را بکشید و ماشین‌آلات و دام را زیر سقف ببرید","deploy anti-hail nets and move machinery and livestock under cover"],
      t:["هنگام تگرگ زیر پل یا سرپناه توقف کنید","pull over under a bridge or shelter during hail"],
      b:["نورگیرها، شیشه‌ها و پنل‌های خورشیدی را محافظت کنید","protect skylights, windows and solar panels"]},
  wave:{a:["قفس‌های پرورش ماهی و تأسیسات ساحلی را مهار کنید","secure fish-farm cages and coastal installations"],
      t:["تردد شناورهای سبک، صیادی و تفریحی متوقف شود","light, fishing and leisure boats should stay in port"],
      b:["کار در اسکله‌ها و سازه‌های ساحلی متوقف شود","stop work on piers and coastal structures"]}
};
// بخش روز (به وقت محلی): برای بیان زمان هشدار مثل «صبح»، «بعدازظهر»، «اواخر شب»
function wnDayPart(ms, offMin, en){ const h=new Date(ms+(offMin||0)*6e4).getUTCHours();
  const P_=[[0,3,"اواخر شب","late night"],[3,6,"بامداد","early morning"],[6,10,"صبح","morning"],[10,14,"ظهر","midday"],[14,17,"بعدازظهر","afternoon"],[17,20,"عصر","evening"],[20,24,"شب","night"]];
  const q=P_.find(r=>h>=r[0]&&h<r[1]); return q? q[en?3:2] : ""; }
function wnText(o){
  const en=LANG==="en", T=s=>en?tr(s):s, LV=en?["","Yellow","Orange","Red"]:["","زرد","نارنجی","قرمز"], LVM=en?["","be aware","be prepared","take action"]:["","آگاهی","آمادگی","اقدام"], A=en?", ":"، ", AND=en?" and ":" و ";
  const list=a=>{ a=a.map(T); return a.length<=1 ? (a[0]||"") : a.slice(0,-1).join(A)+AND+a[a.length-1]; };
  const nmT=t=>en?WN[t].en:WN[t].n, unitOf=t=>WN[t].u==="% مقیاس"?(en?"% of scale":"٪ مقیاس"):WN[t].u;
  const lvName=(t,L)=>{ const a=en?WN[t].lvnEn:WN[t].lvn; return a&&a[L-1] ? a[L-1] : nmT(t); };
  const fv=(v,t)=>{ if(!isFinite(v)) return "—"; const a=Math.abs(v); const r=a>=100?Math.round(v):a>=10?Math.round(v):a>=1?Math.round(v*10)/10:Math.round(v*100)/100; return FA(r); };
  const pri=t=>{ const k=WN_PRI.indexOf(t); return k<0?99:k; };
  const when=t=>{ const w=o.times&&o.times[t]; if(!w) return ""; const pa=wnDayPart(w.a,w.off,en), pb=wnDayPart(w.b,w.off,en), A_=pa?` (${pa})`:"", B_=pb?` (${pb})`:"";
    const s=w.a===w.b ? (en?`valid for ${T(w.sa)}${B_}`:`معتبر برای ${pb?pb+" ":""}${w.sa}`) : (en?`from ${T(w.sa)}${A_} to ${T(w.sb)}${B_}`:`از ${pa?pa+" ":""}${w.sa} تا ${pb?pb+" ":""}${w.sb}`); return s; };
  const where=o.regionFa?T(o.regionFa):(en?"the region":"منطقه"), out=[];
  let top=o.area[3]?3:o.area[2]?2:o.area[1]?1:0;
  const pct=L=>o.nL?Math.round(100*o.area.slice(L).reduce((a,b)=>a+b,0)/o.nL):0;
  const fromEn=o.from?T(o.from):"";
  const head = en ? `⚠️ Weather warning — ${where}${fromEn?" ("+fromEn.charAt(0).toLowerCase()+fromEn.slice(1)+")":""}` : `⚠️ هشدار هواشناسی ${where}${o.from?` (${o.from})`:""}`;
  if(!top){ out.push(head+" — "+(en?"no hazardous weather above the warning thresholds is expected.":"پدیدهٔ جوی خطرناکی بالاتر از آستانه‌های هشدار پیش‌بینی نمی‌شود.")); return out; }
  const serious=o.cities.filter(c=>c.L===3 && new Set(c.hz.filter(h=>h.L===3).map(h=>h.type)).size>=2);
  // پدیده‌های هر سطح (بر پایهٔ شهرها و اگر شهری نبود بر پایهٔ مساحت)
  const byL={1:{},2:{},3:{}};
  for(const c of o.cities) for(const h of c.hz) if(h.L>=1 && h.L===c.L){ const g=byL[h.L][h.type]||(byL[h.L][h.type]={c:[],v:[]}); g.c.push(c.nm); g.v.push(h.v); }
  for(const [t,a] of Object.entries(o.typeArea||{})) for(let L=1;L<=3;L++) if(a[L]>0 && !byL[L][t] && (o.typeMax[t]||{}).lv===L) byL[L][t]={c:[],v:[]};
  for(let L=3;L>=1;L--) if(Object.keys(byL[L]).length){ top=L; break; }
  const mainHz=[...new Set([3,2,1].flatMap(L=>Object.keys(byL[L]).sort((a,b)=>pri(a)-pri(b))))].slice(0,5).map(t=>nmT(t));
  out.push(head+"\n"+(en ? `Highest level: ${WN_ICON[top]} ${LV[top]}${top===3&&serious.length?" (serious)":""} — ${LVM[top]}. Main hazards: ${list(mainHz)}. About ${FA(pct(1))}% of the land area is under a warning${top>=2?`, ${FA(pct(2))}% at orange or red`:""}.`
    : `بالاترین سطح: ${WN_ICON[top]} هشدار ${LV[top]}${top===3&&serious.length?" جدی":""} (${LVM[top]}). پدیده‌های اصلی: ${list(mainHz)}. حدود ${FA(pct(1))}٪ از خشکی‌ها زیر هشدار است${top>=2?` و ${FA(pct(2))}٪ در سطح نارنجی یا قرمز`:""}.`));
  const ADV=en?["",
    "👥 Be aware: daily activities may be disrupted in some places; follow the latest forecasts.",
    "👥 Be prepared: review travel and outdoor plans and protect property before the weather arrives; relief and service agencies should be on standby.",
    "👥 Take action: avoid travel and high-risk areas and follow the instructions of emergency services; responsible agencies should carry out preventive measures (dam management, clearing channels, road maintenance)."]
    :["",
    "👥 توصیهٔ عمومی (آگاهی): فعالیت‌های روزمره ممکن است در برخی نقاط مختل شود؛ پیش‌بینی‌های بعدی را دنبال کنید.",
    "👥 توصیهٔ عمومی (آمادگی): برنامهٔ سفر و کارهای بیرونی را بازبینی و پیش از رسیدن هوای بد از اموال خود محافظت کنید؛ دستگاه‌های امدادی و خدماتی در آماده‌باش باشند.",
    "👥 توصیهٔ عمومی (اقدام): از سفر و حضور در مناطق پرخطر پرهیز و از دستور نیروهای امدادی پیروی کنید؛ دستگاه‌های مسئول اقدامات پیشگیرانه (مدیریت سدها، لایروبی مسیل‌ها، راهداری) را اجرا کنند."];
  for(let L=3;L>=1;L--){
    const ents0=Object.entries(byL[L]).sort((a,b)=>pri(a[0])-pri(b[0])); if(!ents0.length) continue;
    // پدیده‌های هم‌نام (مثلاً باران از نقشهٔ بارش و از نقشهٔ پدیده‌های مهم) در یک سطر
    const ents=[]; for(const [t,g] of ents0){ const nm_=lvName(t,L), e=ents.find(([t2])=>lvName(t2,L)===nm_); if(e){ for(const c of g.c) if(!e[1].c.includes(c)){ e[1].c.push(c); } e[1].v=e[1].v.concat(WN[e[0]].noNum?[]:g.v); } else ents.push([t,{c:g.c.slice(),v:g.v.slice()}]); }
    const lines=ents.map(([t,g])=>{
      const vs=g.v.filter(isFinite), ext=!vs.length?NaN:WN[t].dir==="down"?Math.min(...vs):WN[t].dir==="abs"?vs.reduce((a,v)=>Math.abs(v)>Math.abs(a)?v:a,0):Math.max(...vs);
      const pv=o.typeProv&&o.typeProv[t]&&o.typeProv[t][L], pvTxt=pv&&pv.length ? list(pv.slice(0,6).map(q=>en?q.en:q.fa))+(pv.length>6?(en?` and ${pv.length-6} more areas`:` و ${FA(pv.length-6)} ناحیهٔ دیگر`):"") : null;
      const fr=((o.typeArea||{})[t]||[])[L]||0, cl=(pvTxt && (g.c.length>6 || !g.c.length)) ? pvTxt : !g.c.length ? (fr<0.005 ? (en?`a few isolated spots of ${where}`:`نقاط محدودی از ${where}`) : en?`parts of ${where} away from the main cities`:`بخش‌هایی از ${where} دور از شهرهای اصلی`) : g.c.length>8 ? list(g.c.slice(0,8))+(en?` and ${g.c.length-8} more places`:` و ${FA(g.c.length-8)} نقطهٔ دیگر`) : list(g.c);
      const imp=en?WN[t].impEn[L-1]:WN[t].imp[L-1], tm=when(t), name=lvName(t,L);
      const val = WN[t].noNum || !isFinite(ext) ? "" : (WN[t].dir==="down" ? (en?` (down to ${fv(ext,t)} ${unitOf(t)})`:` (کمینه ${fv(ext,t)} ${unitOf(t)})`) : en?` (up to ${fv(ext,t)} ${unitOf(t)})`:` (تا ${fv(ext,t)} ${unitOf(t)})`);
      return en ? `▪ ${name}${val}\n   📍 Where: ${cl}${tm?`\n   🕒 When: ${tm}`:""}\n   ⚡ Impact: ${imp}.` : `▪ ${name}${val}\n   📍 مناطق: ${cl}${tm?`\n   🕒 زمان: ${tm}`:""}\n   ⚡ پیامد: ${imp}.`; });
    let p = (en ? `${WN_ICON[L]} ${LV[L].toUpperCase()} WARNING${L===3&&serious.length?" (SERIOUS)":""} — ${LVM[L]}` : `${WN_ICON[L]} هشدار ${LV[L]}${L===3&&serious.length?" جدی":""} — ${LVM[L]}`)+"\n"+lines.join("\n");
    if(L===3 && serious.length) p += "\n"+(en ? `In ${list(serious.slice(0,6).map(c=>c.nm))} several hazards reach the red level at the same time.` : `در ${list(serious.slice(0,6).map(c=>c.nm))} چند پدیده هم‌زمان در سطح قرمز است.`);
    p += "\n"+ADV[L];
    out.push(p);
  }
  // توصیه‌های بخشی (کوتاه): گروه‌های پدیده به ترتیب سطح و اهمیت
  { const grp=[]; for(let L=3;L>=1;L--) for(const t of Object.keys(byL[L]).sort((a,b)=>pri(a)-pri(b))){ const g=WN_ADV_GRP[t]; if(g && !grp.includes(g)) grp.push(g); }
    if(grp.length){ const k=en?1:0, pick=f=>grp.slice(0,4).map(g=>WN_ADV[g][f][k]).join(en?"; ":"؛ ");
      out.push((en?"📋 Advice":"📋 توصیه‌ها")+"\n"+(en?`🌾 Agriculture and orchards: ${pick("a")}.\n🚗 Travel and transport: ${pick("t")}.\n🏗️ Construction and outdoor work: ${pick("b")}.`
        :`🌾 کشاورزی و باغداری: ${pick("a")}.\n🚗 سفر و حمل‌ونقل: ${pick("t")}.\n🏗️ ساخت‌وساز و کارهای عمرانی: ${pick("b")}.`)); } }
  const why = o.types.filter(t=>!WN[t].noNum && !WN[t].cat).map(t=>{ const th=wnThr()[t], d=WN[t].dir, s=d==="down"?"≤":"≥", u=unitOf(t); return en ? `${nmT(t)} (yellow ${s}${FA(th[0])}, orange ${s}${FA(th[1])}, red ${s}${FA(th[2])} ${u})` : `${nmT(t)} (زرد ${s}${FA(th[0])}، نارنجی ${s}${FA(th[1])}، قرمز ${s}${FA(th[2])} ${u})`; });
  const pr=o.types.filter(t=>WN[t].noNum && !WN[t].cat).map(nmT); if(pr.length) why.push(en ? `${list(pr)} (by the defined warning levels)` : `${list(pr)} (بر پایهٔ سطوح هشدار تعریف‌شده)`);
  const ct=o.types.filter(t=>WN[t].cat).map(nmT); if(ct.length) why.push(en ? `${list(ct)} (from the significant-weather map categories)` : `${list(ct)} (از دسته‌های نقشهٔ پدیده‌های مهم جوی)`);
  if(o.gOff!=null) why.push(en ? `ground temperature estimated as 2 m temperature minus ${FA(o.gOff)} °C (around sunrise)` : `دمای سطح خاک = دمای ۲ متری منهای ${FA(o.gOff)} درجه (حدود طلوع آفتاب)`);
  out.push(en ? `ℹ️ Basis: ${why.join("; ")}. The level combines likelihood (model agreement where several models are given) and severity through a risk matrix; where several hazards share the highest level, the colour is darker. Local impact factors (terrain, rivers, soil saturation, exposed population and infrastructure) are not included, so a lower level does not rule out serious local impacts such as flash floods.`
    : `ℹ️ مبنای هشدار: ${why.join("؛ ")}. سطح هشدار از ترکیب احتمال وقوع (توافق مدل‌ها، اگر چند مدل داده شده باشد) و شدت پدیده با ماتریس ریسک تعیین شده و هر جا چند پدیده هم‌زمان در بالاترین سطح باشند، رنگ تیره‌تر است. عوامل پیامد محلی (توپوگرافی، رودخانه‌ها و مسیل‌ها، اشباع خاک، جمعیت و زیرساخت در معرض خطر) در این محاسبه نیامده‌اند؛ پس سطح پایین‌تر، پیامد شدید محلی مثل سیلاب ناگهانی را منتفی نمی‌کند.`);
  return out;
}
// نمودارهای هشدار: ماتریس ریسک (احتمال × شدت پیامد) و مساحت زیر هشدار هر پدیده
function wnCharts(per, sea, likeDef){
  const land=i=>!(sea&&sea[i]); let nL=0; for(let i=0;i<N;i++) if(land(i)) nL++;
  const st=per.map(p=>{ const a=[0,0,0,0]; for(let i=0;i<N;i++) if(land(i)) a[p.L[i]]++;
    let imp=0, lik=likeDef; for(let k=3;k>=1;k--){ const lk=[]; for(let i=0;i<N;i+=2) if(land(i) && p.K[i]>=k) lk.push(p.LK[i]); if(lk.length*2/Math.max(1,nL)>=0.003){ lk.sort((x,y)=>x-y); imp=k; lik=lk[lk.length>>1]; break; } }
    return {type:p.f.m.type, n:p.n, frac:a.map(c=>nL?c/nL:0), imp, lik}; });
  const COLS=["#5cb85c","#ffd21f","#ff8c00","#e01b1b"], dpr=2;
  // ۱) ماتریس ریسک
  const W=760, H=430, cm=document.createElement("canvas"); cm.width=W*dpr; cm.height=H*dpr; const x=cm.getContext("2d"); x.scale(dpr,dpr);
  x.fillStyle="#fff"; x.fillRect(0,0,W,H);
  txt(x, "ماتریس ریسک هشدار: احتمال وقوع × شدت پیامد", W/2, 28, `bold 18px ${FT.body}`, {align:"center", color:"#1d2433"});
  const gx0=150, gy0=52, cw=135, ch=72, impL=["خیلی کم","کم","متوسط","زیاد"], likL=["زیاد","متوسط","کم","خیلی کم"];
  for(let r=0;r<4;r++) for(let c=0;c<4;c++){ const lik=3-r, col=COLS[WN_MATRIX[lik][c]]; x.fillStyle=col; x.globalAlpha=0.85; x.fillRect(gx0+c*cw, gy0+r*ch, cw-3, ch-3); x.globalAlpha=1; }
  impL.forEach((l,c)=>txt(x, l, gx0+c*cw+cw/2, gy0+4*ch+18, `14px ${FT.body}`, {align:"center", color:"#333"}));
  likL.forEach((l,r)=>txt(x, l, gx0-12, gy0+r*ch+ch/2+5, `14px ${FT.body}`, {align:"right", color:"#333"}));
  txt(x, "شدت پیامد (بر پایهٔ آستانه‌ها)", gx0+2*cw, gy0+4*ch+42, `bold 14px ${FT.body}`, {align:"center", color:"#1d2433"});
  x.save(); x.translate(26, gy0+2*ch); x.rotate(-Math.PI/2); txt(x, "احتمال وقوع (توافق مدل‌ها)", 0, 0, `bold 14px ${FT.body}`, {align:"center", color:"#1d2433"}); x.restore();
  const cells={}; for(const s of st){ const k=s.imp+"_"+s.lik; (cells[k]=cells[k]||[]).push(s); }
  for(const [k,arr] of Object.entries(cells)){ const [imp,lik]=k.split("_").map(Number), cx=gx0+imp*cw, cy=gy0+(3-lik)*ch;
    let yy=cy+16; arr.forEach(s=>{ if(yy>cy+ch-4) return; x.beginPath(); x.arc(cx+12, yy-4, 5, 0, 2*Math.PI); x.fillStyle="#1d2433"; x.fill(); x.strokeStyle="#fff"; x.lineWidth=1.5; x.stroke();
      txt(x, WN[s.type].n.replace(/\s*\(.*\)/,""), cx+22, yy, `12.5px ${FT.body}`, {align:"left", color:"#111", maxW:cw-28});
      if(s.n>1){ yy+=14; txt(x, `(${FA(s.n)} مدل)`, cx+22, yy, `11px ${FT.body}`, {align:"left", color:"#333"}); } yy+=18; }); }
  // ۲) مساحت زیر هشدار
  const bh=26, H2=70+st.length*(bh+12), cb=document.createElement("canvas"); cb.width=W*dpr; cb.height=H2*dpr; const y=cb.getContext("2d"); y.scale(dpr,dpr);
  y.fillStyle="#fff"; y.fillRect(0,0,W,H2);
  txt(y, "درصد خشکی‌های زیر هشدار برای هر پدیده", W/2, 28, `bold 18px ${FT.body}`, {align:"center", color:"#1d2433"});
  const bx0=200, bw=W-bx0-80;
  st.forEach((s,k)=>{ const yy=52+k*(bh+12); txt(y, WN[s.type].n, bx0-10, yy+bh/2+5, `14px ${FT.body}`, {align:"right", color:"#111", maxW:bx0-20});
    y.fillStyle="#eef1f5"; y.fillRect(bx0,yy,bw,bh); let xx=bx0;
    for(let L=1;L<=3;L++){ const w=bw*s.frac[L]; if(w>0){ y.fillStyle=COLS[L]; y.fillRect(xx,yy,w,bh); xx+=w; } }
    const tot=s.frac[1]+s.frac[2]+s.frac[3]; txt(y, FA(Math.round(100*tot))+"٪", Math.min(xx+8, W-60), yy+bh/2+5, `bold 14px ${FT.body}`, {align:"left", color:"#111", dir:"ltr"}); });
  [["زرد",1],["نارنجی",2],["قرمز",3]].forEach(([l,L],j)=>{ const lx=bx0+j*110, ly=H2-14; y.fillStyle=COLS[L]; y.fillRect(lx,ly-11,16,12); txt(y, l, lx+22, ly, `13px ${FT.body}`, {align:"left", color:"#333"}); });
  return {matrix:cm, bars:cb, st};
}
function wnShow(){
  const r=wn.res, box=$("wnCards"); box.replaceChildren();
  const c1=cvCard("نقشهٔ هشدارهای جوی", "سفید = بدون هشدار؛ زرد، نارنجی و قرمز هر کدام از کم‌رنگ تا پررنگ بر پایهٔ مقدار پدیده؛ چند پدیدهٔ هم‌سطح = رنگ تیره‌تر (قرمز جدی)", true);
  c1.img.src=r.cvW.toDataURL("image/png"); c1.img.alt="نقشهٔ هشدارهای جوی";
  const pc=L=>r.nL?FA(Math.round(100*r.area[L]/r.nL)):"۰";
  c1.sx.innerHTML=`<span>زرد<b>${pc(1)}٪</b></span><span>نارنجی<b>${pc(2)}٪</b></span><span>قرمز<b>${pc(3)}٪</b></span><span>شهرهای زیر هشدار<b>${FA(r.cities.filter(c=>c.L>0).length)}</b></span>`;
  const dl=(label,name,make)=>{ const b=document.createElement("button"); b.className="btn"; b.type="button"; b.textContent=label; b.onclick=async()=>{ b.disabled=true; await tick(); try{ const blob=await make(); const u=URL.createObjectURL(blob), a=document.createElement("a"); a.href=u; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),4000); }catch(e){ console.error(e); } b.disabled=false; }; return b; };
  c1.dl.append(dl("PNG","weather_warnings.png",async()=>{ await useProfile(r.refKey); return exportPNG(r.cvW); }));
  const rep=document.createElement("article"); rep.className="card wide cvrep";
  rep.innerHTML=`<header><h3>متن هشدار${r.regionFa?" — "+r.regionFa:""}</h3></header><div class="paras"></div><div class="dl"></div>`;
  const paras=rep.querySelector(".paras"); for(const t of r.text){ const p=document.createElement("p"); p.style.whiteSpace="pre-line"; p.textContent=t; paras.append(p); }
  const txt=r.text.join("\n\n");
  const cp=document.createElement("button"); cp.className="btn"; cp.type="button"; cp.textContent="کپی متن";
  cp.onclick=async()=>{ try{ await navigator.clipboard.writeText(trText(txt)); cp.textContent="کپی شد ✓"; }catch(e){} };
  const tx=dl("TXT","weather_warning.txt",async()=>new Blob(["﻿"+trText(txt)],{type:"text/plain;charset=utf-8"}));
  rep.querySelector(".dl").append(cp, tx);
  const ch=document.createElement("article"); ch.className="card wide";
  ch.innerHTML=`<header><h3>نمودارهای هشدار</h3><div class="sub">ماتریس ریسک: جای هر پدیده بر پایهٔ بالاترین شدتی که در بخش معناداری از منطقه رخ می‌دهد و احتمال وقوع آن (توافق مدل‌ها)؛ رنگ خانه سطح هشدار حاصل است. نمودار دوم سهم خشکی‌های زیر هر سطح هشدار است.</div></header>`;
  for(const c of [r.charts.matrix, r.charts.bars]){ const im=new Image(); im.src=c.toDataURL("image/png"); im.style.cssText="width:100%;max-width:760px;display:block;margin:8px auto"; im.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=im.src; d.showModal(); }; ch.append(im); }
  const cdl=document.createElement("div"); cdl.className="dl"; cdl.append(dl("PNG ماتریس","warning_matrix.png",async()=>new Promise(res=>r.charts.matrix.toBlob(res,"image/png"))), dl("PNG مساحت","warning_area.png",async()=>new Promise(res=>r.charts.bars.toBlob(res,"image/png")))); ch.append(cdl);
  box.append(c1.card, rep);
  for(const pm of r.perMaps){ const c=cvCard("هشدار "+WN[pm.type].n, "نقشهٔ جداگانهٔ همین پدیده با همان رنگ‌های استاندارد هشدار (زرد، نارنجی، قرمز از کم‌رنگ تا پررنگ)", false);
    try{ const lv=Math.max(1,Math.min(3,Math.ceil(pm.max))), ic=hzIconURL(pm.type, lv, 40); c.card.dataset.icon=ic; const im=new Image(); im.src=ic; im.className="hzic"; im.alt=""; c.hd.querySelector("h3").prepend(im); }catch(e){}
    c.img.src=pm.cv.toDataURL("image/png"); c.img.alt="هشدار "+WN[pm.type].n;
    const L=Math.min(3,Math.ceil(pm.max-1e-9)); c.sx.innerHTML=`<span>بالاترین سطح<b>${["—","زرد","نارنجی","قرمز"][L]||"—"}</b></span>`;
    c.dl.append(dl("PNG",`warning_${pm.type.slice(2)}.png`,async()=>{ await useProfile(r.refKey); return exportPNG(pm.cv); })); box.append(c.card); }
  for(const vm of (r.valMaps||[])){ const D_=VM_DEF[vm.type], hi=D_.hi;
    const c=cvCard(D_.card, D_.sub, false);
    c.img.src=vm.cv.toDataURL("image/png"); c.img.alt=D_.nm;
    c.sx.innerHTML=`<span>${hi?"بیشینه":"کمینه"}<b>${isFinite(vm.ext)?D_.fmt(vm.ext):"—"}</b></span>`;
    c.dl.append(dl("PNG",D_.file,async()=>{ await useProfile(r.refKey); return exportPNG(vm.cv); })); box.append(c.card); }
  box.append(ch);
  if(r.warns.length){ const w=document.createElement("p"); w.className="hint"; w.style.cssText="color:var(--warn);padding:0 4px"; w.textContent=r.warns.join(" "); box.append(w); }
}
function openWN(){ for(const id of ["landing","app","dsApp","cvApp","ltApp","cqcApp","caApp"]) $(id).hidden=true; $("wnApp").hidden=false; $("srcName").textContent="هشدارهای جوی"; $("srcBtn").hidden=false; store.set("mode","wn"); wnThrPanel(); try{ wuzSync(); }catch(e){} }
$("wnFiles").onchange=()=>{ wnAdd($("wnFiles").files); $("wnFiles").value=""; };
{ const el=$("wnDrop"); el.addEventListener("dragover", e=>{ e.preventDefault(); el.classList.add("over"); }); el.addEventListener("dragleave", ()=>el.classList.remove("over"));
  el.addEventListener("drop", e=>{ e.preventDefault(); el.classList.remove("over"); wnAdd(e.dataTransfer.files); }); }
$("wnRun").onclick=()=>WN_LOCK(wnRun);
$("wnThrReset").onclick=()=>{ store.set("wn.thr",{}); wnThrPanel(); wnSchedule(50); };
{ const v=store.get("wnGOff",null); if(v!==null) $("wnGOff").value=v; $("wnGOff").addEventListener("change",()=>{ store.set("wnGOff",$("wnGOff").value); wnSchedule(50); }); }
{ const v=store.get("wnLike",null); if(v!==null) $("wnLike").value=v; $("wnLike").addEventListener("change",()=>{ store.set("wnLike",$("wnLike").value); wnSchedule(50); }); }
{ const v=store.get("wnBorders",null); if(v!==null) $("wnBorders").checked=v; $("wnBorders").addEventListener("change",()=>{ store.set("wnBorders",$("wnBorders").checked); wnSchedule(50); }); }
$("wnEmpty").onclick=()=>$("wnFiles").click();

// کنترل‌های مرزبندی زوم weather.us (مشترک بین حالت اصلی و همرفت)
function wuzSync(){
  const autoM=WUZ.auto, autoC=WUZ.autoCv;
  document.querySelectorAll("[data-wuz]").forEach(box=>{
    const on=box.querySelector(".wuzOn"), sel=box.querySelector(".wuzSel"), note=box.querySelector(".wuzNote"), isCv=box.closest("#cvApp"), isLt=box.closest("#ltApp"), isWn=box.closest("#wnApp"), isDs=box.closest("#dsApp");
    const auto=isCv?autoC:isLt?(lt.res&&lt.res.zoom):isWn?WUZ.autoWn:isDs?((ds.maps.find(q=>q.zone)||{}).zone||null):autoM;
    on.checked=WUZ.on;
    sel.innerHTML=`<option value="auto">خودکار${auto?` (تشخیص: ${auto})`:" (تشخیص داده نشد)"}</option>`+Object.keys(WU_ZOOMS).map(k=>`<option value="${k}">${k}</option>`).join("");
    sel.value=WUZ.sel; if(sel.value!==WUZ.sel) sel.value="auto";
    const z=wuZoomName(auto); note.textContent = !WUZ.on ? "خاموش: نقشه بدون مرزبندی زوم دانلود می‌شود" : z ? `مرزبندی «${z}» روی نقشه‌های weather.us می‌افتد؛ PNG با دقت ۴ برابر (۳۰۴۰×۳۰۴۰) دانلود می‌شود` : "زوم شناخته نشد؛ از فهرست انتخاب کنید";
  });
}
document.querySelectorAll("[data-wuz]").forEach(box=>{
  box.querySelector(".wuzOn").addEventListener("change", e=>{ store.set("wuz.on", e.target.checked); wuzSync(); wuzRefresh(); });
  box.querySelector(".wuzSel").addEventListener("change", e=>{ store.set("wuz.sel", e.target.value);
    const v=e.target.value; if(v!=="auto" && !/جزئیات/.test(v) && v!==WU_ROADS_KEY){ if(box.closest("#dsApp")){ const m=ds.maps.find(q=>!q.bad && q.w===760 && q.h===760); if(m){ wuLearnSig(m.data, v); ds.maps.forEach(q=>{ if(q.w===760&&q.h===760) q.zone=v; }); } } else if(box.closest("#wnApp")){ const m=wn.maps.find(q=>!q.bad && q.w===760 && q.h===760 && !q.region); if(m){ wuLearnSig(m.data, v); m.regionFa=v; } } else if(box.closest("#cvApp")){ const m=cv.maps.find(q=>!q.bad && q.w===760 && q.h===760 && !q.region); if(m){ wuLearnSig(m.data, v); m.regionFa=v; } }
      else { const m=state.models.find(q=>q.ok && q.w===760 && q.h===760); if(m && $("regionSel").value!==v && REGIONS.includes(v)){ setRegion(v, "از منوی زوم انتخاب شد"); learnRegion(v); } } }
    wuzSync(); wuzRefresh(); });
});
document.querySelectorAll(".wbBrd").forEach(sel=>{ sel.value=wbBorders(); sel.addEventListener("change", e=>{ store.set("wb.borders", e.target.value); if($("borders")){ $("borders").value=e.target.value; } document.querySelectorAll(".wbBrd").forEach(q=>q.value=e.target.value); wuzRefresh(); }); });
if($("borders") && store.get("wb.borders",null)) $("borders").value=wbBorders();
if($("borders")){ $("borders").addEventListener("change", ()=>{ store.set("wb.borders", $("borders").value); document.querySelectorAll(".wbBrd").forEach(q=>q.value=$("borders").value); }); }
function wuzRefresh(){ if(!$("dsApp").hidden){ if(ds.maps.some(q=>q.prof&&q.prof.key==="wu")){ ds.maps.forEach(q=>{ if(!q.bad) q.result=null; }); dsSchedule(50); } } else if(!$("wnApp").hidden){ if(wn.res) wnSchedule(50); } else if(!$("ltApp").hidden){ if(lt.frames.length || lt.streamE) ltRun(); } else if(!$("cvApp").hidden){ if(cv.res) cvSchedule(50); } else if(state.models.some(m=>m.ok)) schedule(); }
wuzSync(); try{ setTimeout(()=>cvOcrPrewarm(),400); }catch(e){}
$("cvRun").onclick=()=>CV_LOCK(cvRun);
["cvMethod2","cvSigma","cvPmin","cvSeaW","cvIdwP","cvBorders"].map(k=>k==="cvMethod2"?"cvMethod":k).forEach(id=>{ const v=store.get(id,null); if(v!==null){ if($(id).type==="checkbox") $(id).checked=v; else $(id).value=v; }
  $(id).addEventListener("change", ()=>{ store.set(id, $(id).type==="checkbox" ? $(id).checked : $(id).value); cvSchedule(100); }); });
$("cvThrReset").onclick=()=>{ store.set("cv.thr2",{}); cvThrPanel(); cvSchedule(50); };

/* ---- راهنمای هر صفحه (پنجرهٔ بازشو) ---- */
const HELP = {
  landing:{
    fa:{t:"راهنمای صفحهٔ اول", s:[
      ["این سایت چه می‌کند؟","«نقشه‌های آماری هواشناسی» نقشه‌های تصویری مدل‌های عددی را از سایت‌هایی مثل WeatherBELL و weather.us (یا هر سایت دیگر) رقومی می‌کند و از روی آن‌ها نقشه‌های آماری، تحلیلی و هشداری می‌سازد. همهٔ پردازش‌ها روی همین دستگاه و بدون اینترنت انجام می‌شود."],
      ["ابزارها","سه ابزار اول (WeatherBELL، weather.us و آزاد) میانگین، بیشینه، کمینه و توافق مدل‌ها را می‌سازند. «اصلاح نقشه‌های بارش و دما با توجه به ارتفاع» نقشهٔ بارش و دما را با مدل رقومی ارتفاع (DEM) بازسازی می‌کند، «همرفت» احتمال و شدت توفان تندری را از شاخص‌ها برآورد می‌کند، «رعدوبرق» انیمیشن رعدوبرق را به نقشهٔ تجمعی، تراکم و جهت حرکت توده‌ها تبدیل می‌کند و «هشدارهای جوی» از نقشه‌های پدیده‌های خطرناک نقشه و متن هشدار می‌سازد."],
      ["نکته","همهٔ خروجی‌ها هم‌قالب نقشهٔ ورودی (همان ابعاد، کادر و جای نوار رنگ) و با لوگوی سایت ساخته می‌شوند و با دقت بالا قابل دانلودند. زبان سایت با دکمهٔ بالای صفحه بین فارسی و انگلیسی عوض می‌شود."]]},
    en:{t:"Home page help", s:[
      ["What does this site do?","Meteorological Statistical Maps digitizes model map images from sites such as WeatherBELL and weather.us (or any other site) and builds statistical, analytical and warning maps from them. All processing runs on this device, offline."],
      ["Tools","The first three tools (WeatherBELL, weather.us and Free) build the models' mean, maximum, minimum and agreement maps. “Elevation correction” rebuilds precipitation and temperature maps with a digital elevation model (DEM), “Convection” estimates thunderstorm probability and intensity from indices, “Lightning” turns a lightning animation into accumulated, density and storm-movement maps, and “Weather warnings” builds a warning map and text from hazard maps."],
      ["Note","Every output keeps the input map's layout (size, frame and colorbar position), carries the site logo and can be downloaded at high resolution. Switch the language with the button at the top of the page."]]}},
  wb:{
    fa:{t:"راهنما: نقشه‌های WeatherBELL", s:[
      ["چه کاری می‌توان کرد؟","چند نقشهٔ یک پارامتر از مدل‌های مختلف (مثلاً بارش تجمعی ECMWF، GFS، ICON، UKMO و GEM) را با هم ترکیب کنید تا نقشهٔ میانگین وزنی، بیشینه، کمینه و احتمال بر پایهٔ توافق مدل‌ها ساخته شود. وزن هر مدل در کارت میانگین قابل تنظیم است."],
      ["ورودی","تصاویر ۹۸۴×۸۰۸ سایت WeatherBELL (برش ایران). علاوه بر بارش، دما، باد، تندباد، رطوبت و شاخص‌های همرفت هم پذیرفته می‌شوند؛ نام پارامتر از عنوان و اعداد از نوار رنگ خوانده می‌شوند. همهٔ نقشه‌های یک بار باید برای یک زمان و یک پارامتر باشند. نوع نقشه (بارش، برف، دما و …) خودکار تشخیص داده می‌شود و برای نقشه‌های دما آستانه‌ها بر حسب درجهٔ سلسیوس است."],
      ["خروجی و تفسیر","نقشهٔ میانگین برآورد مرکزی است، بیشینه و کمینه بازهٔ اختلاف مدل‌ها را نشان می‌دهند و نقشهٔ توافق درصد مدل‌هایی است که از آستانهٔ انتخابی بیشتر را پیش‌بینی کرده‌اند (سفید = ۰٪، صورتی پررنگ = توافق کامل). خروجی‌ها به صورت PNG، CSV و NetCDF دانلود می‌شوند. برای نقشه‌های دمای ۲ متری (و کمینهٔ دما یا دمای نزدیک سطح خاک)، نقشهٔ ریسک یخبندان و ریسک یخبندان سطح خاک هم ساخته می‌شود: بنفش کم‌رنگ خیلی زیاد، بنفش زیاد، آبی پررنگ متوسط، آبی کم‌رنگ کم و سفید بدون ریسک؛ دمای سطح خاک هنگام طلوع آفتاب ۲ تا ۴ درجه کمتر از دمای ۲ متری فرض می‌شود."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• میانگین وزنی مدل\u200cها — ورودی: دست\u200cکم دو نقشه از یک پارامتر و یک زمان، از مدل\u200cهای مختلف. پارامتر: وزن هر مدل (کارت میانگین).\n• بیشینه و کمینهٔ مدل\u200cها — ورودی: همان نقشه\u200cها.\n• احتمال توافق مدل\u200cها — ورودی: همان نقشه\u200cها. پارامترها: آستانه\u200cها (بارش بر حسب میلی\u200cمتر، دما بر حسب درجهٔ سلسیوس)، هموارسازی توافق و همسایگی توافق.\n• ریسک یخبندان و یخبندان سطح خاک — ورودی: دمای ۲ متری یا کمینهٔ دما (یا دمای نزدیک سطح خاک). پارامتر: اختلاف دمای سطح خاک با دمای ۲ متری (پیش\u200cفرض ۳ درجه).\n• پارامترهای مشترک: سقف مقدار معتبر و نوار رنگ (فقط بارش)، زمان شروع و پایان، مرزها و خطوط شبکه، لوگو.\n• مرزبندی WeatherBELL: «پررنگ»، «مثل اصل WeatherBELL» یا «پررنگ + نقشهٔ راه\u200cها»."]]},
    en:{t:"Help: WeatherBELL maps", s:[
      ["What can you do?","Combine several maps of one parameter from different models (e.g. ECMWF, GFS, ICON, UKMO and GEM accumulated precipitation) into weighted-mean, maximum, minimum and model-agreement probability maps. Each model's weight can be set in the mean card."],
      ["Input","984×808 WeatherBELL images (Iran crop). Besides precipitation, temperature, wind, gusts, humidity and convective indices are accepted; the parameter is read from the title and the numbers from the colorbar. All maps in one batch must be for the same time and parameter. The map type (precipitation, snow, temperature …) is detected automatically, and thresholds for temperature maps are in °C."],
      ["Outputs and interpretation","The mean is the central estimate, maximum and minimum show the spread between models, and the agreement map is the percentage of models exceeding the chosen threshold (white = 0%, dark pink = full agreement). Outputs download as PNG, CSV and NetCDF. For 2 m temperature maps (and minimum or near-surface soil temperature), frost-risk and ground-frost-risk maps are also made: light purple very high, purple high, dark blue medium, light blue low and white no risk; ground temperature at sunrise is taken as 2–4 degrees below the 2 m temperature."],
      ["Maps: required inputs and parameters","• Models' weighted mean — input: at least two maps of the same parameter and time from different models. Parameter: each model's weight (in the mean card).\n• Models' maximum and minimum — input: the same maps.\n• Model-agreement probability — input: the same maps. Parameters: thresholds (precipitation in mm, temperature in °C), agreement smoothing and neighbourhood.\n• Frost and ground-frost risk — input: 2 m temperature or minimum temperature (or near-surface soil temperature). Parameter: ground-minus-2 m temperature offset (default 3 degrees).\n• Shared parameters: valid-value cap and colorbar (precipitation only), start and end time, borders and grid lines, logo.\n• WeatherBELL borders: “bold”, “as WeatherBELL original” or “bold + road map”."]]}},
  wu:{
    fa:{t:"راهنما: نقشه‌های weather.us", s:[
      ["چه کاری می‌توان کرد؟","مانند صفحهٔ WeatherBELL، نقشه‌های چند مدل را به میانگین، بیشینه، کمینه و احتمال توافق تبدیل می‌کند؛ مرزها و نام شهرهای weather.us کاملاً حذف و نقشه‌ای تمیز ساخته می‌شود."],
      ["ورودی","تصاویر ۷۶۰×۷۶۰ weather.us از هر زوم (ایران، فارس، خوزستان، هرمزگان، تهران، گیلان، آذربایجان‌ها و …) و هر پارامتر (بارش ۱ تا ۲۴ ساعته یا تجمعی، دما، باد، رطوبت، شاخص‌ها). زوم از پانویس نقشه تشخیص داده می‌شود و اگر شناخته نشد، با یک بار انتخاب از منو یاد گرفته می‌شود. نوار رنگ بارش ن، هرمزگان، تهران، گیلان، آذربایجان‌ها و …) و هر پارامتر (بارش ۱ تا ۲۴ ساعته یا تجمعی، دما، باد، رطوبت، شاخص‌ها). زوم از پانویس نقشه تشخیص داده می‌شود و اگر شناخته نشد، با یک بار انتخاب از منو یاد گرفته می‌شود. نوار رنگ بارش تجمعی کل و ۲۴ ساعته جدا شناخته می‌شوند و نقشه‌های برف از عنوانشان؛ برای نقشه‌های دما آستانه‌ها بر حسب درجهٔ سلسیوس است."],
      ["خروجی و تفسیر","تفسیر نقشه‌ها مثل صفحهٔ WeatherBELL است. با تیک «مرزبندی زوم»، مرز استان‌ها و شهرستان‌های همان زوم روی نقشه می‌آید و دانلود PNG با دقت ۴ برابر انجام می‌شود. برای نقشه‌های دمای ۲ متری (و کمینهٔ دما یا دمای نزدیک سطح خاک)، نقشهٔ ریسک یخبندان و ریسک یخبندان سطح خاک هم ساخته می‌شود: بنفش کم‌رنگ خیلی زیاد، بنفش زیاد، آبی پررنگ متوسط، آبی کم‌رنگ کم و سفید بدون ریسک؛ دمای سطح خاک هنگام طلوع آفتاب ۲ تا ۴ درجه کمتر از دمای ۲ متری فرض می‌شود."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• میانگین وزنی مدل\u200cها — ورودی: دست\u200cکم دو نقشه از یک پارامتر و یک زمان، از مدل\u200cهای مختلف. پارامتر: وزن هر مدل (کارت میانگین).\n• بیشینه و کمینهٔ مدل\u200cها — ورودی: همان نقشه\u200cها.\n• احتمال توافق مدل\u200cها — ورودی: همان نقشه\u200cها. پارامترها: آستانه\u200cها (بارش بر حسب میلی\u200cمتر، دما بر حسب درجهٔ سلسیوس)، هموارسازی توافق و همسایگی توافق.\n• ریسک یخبندان و یخبندان سطح خاک — ورودی: دمای ۲ متری یا کمینهٔ دما (یا دمای نزدیک سطح خاک). پارامتر: اختلاف دمای سطح خاک با دمای ۲ متری (پیش\u200cفرض ۳ درجه).\n• پارامترهای مشترک: سقف مقدار معتبر و نوار رنگ (فقط بارش)، زمان شروع و پایان، مرزها و خطوط شبکه، لوگو.\n• مرزبندی زوم: خودکار از پانویس نقشه؛ برای نقشه\u200cهای زوم ایران گزینهٔ «ایران + نقشهٔ راه\u200cها» هم در فهرست هست."]]},
    en:{t:"Help: weather.us maps", s:[
      ["What can you do?","As on the WeatherBELL page, maps from several models become mean, maximum, minimum and agreement-probability maps; weather.us borders and city names are fully removed to give a clean map."],
      ["Input","760×760 weather.us images from any zoom (Iran, Fars, Khuzestan, Hormozgan, Tehran, Gilan, the Azerbaijans …) and any parameter (1–24 h or accumulated precipitation, temperature, wind, humidity, indices). The zoom is read from the map footer; if it is not recognised, choosing it once from the menu teaches the app. The total and 24 h precipitation colorbars are told apart, snow maps are recognised from their title, and thresholds for temperature maps are in °C."],
      ["Outputs and interpretation","Interpretation is the same as for WeatherBELL. With “zoom boundaries” ticked, the province and county borders of that zoom are drawn on the map and PNG downloads are 4× resolution. For 2 m temperature maps (and minimum or near-surface soil temperature), frost-risk and ground-frost-risk maps are also made: light purple very high, purple high, dark blue medium, light blue low and white no risk; ground temperature at sunrise is taken as 2–4 degrees below the 2 m temperature."],
      ["Maps: required inputs and parameters","• Models' weighted mean — input: at least two maps of the same parameter and time from different models. Parameter: each model's weight (in the mean card).\n• Models' maximum and minimum — input: the same maps.\n• Model-agreement probability — input: the same maps. Parameters: thresholds (precipitation in mm, temperature in °C), agreement smoothing and neighbourhood.\n• Frost and ground-frost risk — input: 2 m temperature or minimum temperature (or near-surface soil temperature). Parameter: ground-minus-2 m temperature offset (default 3 degrees).\n• Shared parameters: valid-value cap and colorbar (precipitation only), start and end time, borders and grid lines, logo.\n• Zoom boundaries: automatic from the map footer; for Iran-zoom maps the list also offers “Iran + road map”."]]}},
  cu:{
    fa:{t:"راهنما: حالت آزاد", s:[
      ["چه کاری می‌توان کرد؟","نقشه‌های هر سایتی را (حتی سایت‌هایی که برنامه نمی‌شناسد) ترکیب کنید تا همان نقشه‌های میانگین، بیشینه، کمینه و توافق ساخته شود."],
      ["ورودی","چند نقشه از یک سایت و یک قالب (هم‌اندازه). کادر نقشه، نوار رنگ، زمینه، مرزها و نوشته‌ها خودکار پیدا می‌شوند. اعداد نوار رنگ خودکار خوانده می‌شوند؛ اگر نه، یک بار در «قالب نقشه‌ها» وارد کنید تا برای دفعه‌های بعد یاد گرفته شود. PNG بهتر از JPG است."],
      ["خروجی و تفسیر","خروجی‌ها در همان ابعاد و قالب نقشهٔ ورودی ساخته می‌شوند. پیش‌نمایش «کادر و نوار رنگ تشخیص‌داده‌شده» را بررسی کنید تا مطمئن شوید رنگ‌ها درست جفت شده‌اند. برای نقشه‌های دمای ۲ متری (و کمینهٔ دما یا دمای نزدیک سطح خاک)، نقشهٔ ریسک یخبندان و ریسک یخبندان سطح خاک هم ساخته می‌شود: بنفش کم‌رنگ خیلی زیاد، بنفش زیاد، آبی پررنگ متوسط، آبی کم‌رنگ کم و سفید بدون ریسک؛ دمای سطح خاک هنگام طلوع آفتاب ۲ تا ۴ درجه کمتر از دمای ۲ متری فرض می‌شود."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• میانگین وزنی مدل\u200cها — ورودی: دست\u200cکم دو نقشه از یک پارامتر و یک زمان، از مدل\u200cهای مختلف. پارامتر: وزن هر مدل (کارت میانگین).\n• بیشینه و کمینهٔ مدل\u200cها — ورودی: همان نقشه\u200cها.\n• احتمال توافق مدل\u200cها — ورودی: همان نقشه\u200cها. پارامترها: آستانه\u200cها (بارش بر حسب میلی\u200cمتر، دما بر حسب درجهٔ سلسیوس)، هموارسازی توافق و همسایگی توافق.\n• ریسک یخبندان و یخبندان سطح خاک — ورودی: دمای ۲ متری یا کمینهٔ دما (یا دمای نزدیک سطح خاک). پارامتر: اختلاف دمای سطح خاک با دمای ۲ متری (پیش\u200cفرض ۳ درجه).\n• پارامترهای مشترک: سقف مقدار معتبر و نوار رنگ (فقط بارش)، زمان شروع و پایان، مرزها و خطوط شبکه، لوگو.\n• اگر اعداد نوار رنگ خوانده نشد، یک بار در «قالب نقشه\u200cها» وارد کنید."]]},
    en:{t:"Help: Free mode", s:[
      ["What can you do?","Combine maps from any website (even ones the app does not know) into the same mean, maximum, minimum and agreement maps."],
      ["Input","Several maps from one site and one template (same size). The map frame, colorbar, background, borders and text are found automatically. Colorbar numbers are read automatically; if not, enter them once under “Map template” and they are learned for next time. PNG is better than JPG."],
      ["Outputs and interpretation","Outputs keep the size and template of the input map. Check the “detected frame and colorbar” preview to make sure the colours were paired correctly. For 2 m temperature maps (and minimum or near-surface soil temperature), frost-risk and ground-frost-risk maps are also made: light purple very high, purple high, dark blue medium, light blue low and white no risk; ground temperature at sunrise is taken as 2–4 degrees below the 2 m temperature."],
      ["Maps: required inputs and parameters","• Models' weighted mean — input: at least two maps of the same parameter and time from different models. Parameter: each model's weight (in the mean card).\n• Models' maximum and minimum — input: the same maps.\n• Model-agreement probability — input: the same maps. Parameters: thresholds (precipitation in mm, temperature in °C), agreement smoothing and neighbourhood.\n• Frost and ground-frost risk — input: 2 m temperature or minimum temperature (or near-surface soil temperature). Parameter: ground-minus-2 m temperature offset (default 3 degrees).\n• Shared parameters: valid-value cap and colorbar (precipitation only), start and end time, borders and grid lines, logo.\n• If the colorbar numbers are not read, enter them once under “Map template”."]]}},
  ds:{
    fa:{t:"راهنما: اصلاح توپوگرافی بارش با DEM", s:[
      ["چه کاری می‌توان کرد؟","نقشهٔ بارش مدل‌ها (که تفکیک افقی درشتی دارند) با مدل رقومی ارتفاع ایران و یک مدل آماری غیرخطی (GAM) بازسازی می‌شود تا اثر کوه‌ها و دره‌ها در آن دیده شود."],
      ["ورودی","یک یا چند نقشهٔ بارش از هر سایت و هر محدوده (کل ایران یا یک استان). مکان نقشه با تطبیق مرزها خودکار پیدا می‌شود؛ اگر پیدا نشد، استان یا مختصات کادر را انتخاب کنید. DEM داخلی ایران در خود فایل هست و GeoTIFF دیگری هم می‌توان داد."],
      ["خروجی و تفسیر","نقشهٔ اصلاح‌شده در همان قالب، نقشهٔ ضریب اصلاح (بیشتر از ۱ = افزایش روی ارتفاعات بادپناه/بادرو)، نقشهٔ اختلاف و نمودار پاسخ بارش به ارتفاع. ضریب‌ها محدود شده‌اند تا مجموع بارش تقریباً ثابت بماند؛ این یک برآورد آماری است نه شبیه‌سازی دینامیکی."],
      ["نقشه‌های weather.us","زوم نقشه‌های weather.us مثل صفحه‌های دیگر خودکار تشخیص داده می‌شود؛ مرزها و نوشته‌های خود weather.us از خروجی برداشته می‌شوند و مرز استان‌ها و شهرستان‌های همان زوم (مرزبندی زوم) جای آن‌ها رسم می‌شود. مرزهای WeatherBELL و Kachelmann دست نمی‌خورند و در محاسبهٔ اصلاح دخالت ندارند."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• نقشهٔ بارش اصلاح\u200cشده، نقشهٔ ضریب اصلاح، نقشهٔ اختلاف و نمودار پاسخ بارش به ارتفاع — ورودی: یک یا چند نقشهٔ بارش (تجمعی یا چندساعته) از هر سایت. DEM داخلی ایران در خود فایل است یا GeoTIFF دیگری بدهید.\n• پارامترها: هموارسازی زمین (km)، شدت اصلاح (۰ تا ۱)، کمترین و بیشترین ضریب، آستانهٔ بارش و «اصلاح کامل از» (mm)، ضریب رزولوشن مؤثر مدل، سقف هسته و پیچیدگی GAM. اگر مکان نقشه خودکار پیدا نشد، زوم یا مختصات را انتخاب کنید."]]},
    en:{t:"Help: Topographic correction with DEM", s:[
      ["What can you do?","A model precipitation map (which has coarse resolution) is rebuilt with Iran's digital elevation model and a nonlinear statistical model (GAM), so that the effect of mountains and valleys shows up."],
      ["Input","One or more precipitation maps from any site and any extent (all of Iran or a province). The map location is found automatically by border matching; if not, choose the province or frame coordinates. The built-in Iran DEM is included, or you can load another GeoTIFF."],
      ["Outputs and interpretation","The corrected map in the same template, the correction-factor map (above 1 = increase over windward heights), the difference map and the precipitation–elevation response chart. Factors are limited so the total precipitation stays about the same; this is a statistical estimate, not a dynamical simulation."],
      ["weather.us maps","The zoom of weather.us maps is detected automatically as on the other pages; weather.us's own borders and labels are removed from the output and the province and county borders of that zoom (zoom boundaries) are drawn instead. WeatherBELL and Kachelmann borders are left as they are and play no part in the correction."],
      ["Maps: required inputs and parameters","• Corrected precipitation map, correction-factor map, difference map and precipitation–elevation chart — input: one or more precipitation maps (accumulated or a few hours) from any site. The built-in Iran DEM is included, or load another GeoTIFF.\n• Parameters: terrain smoothing (km), correction strength (0–1), minimum and maximum factor, precipitation threshold and “full correction from” (mm), model effective-resolution factor, kernel cap and GAM complexity. If the map location is not found automatically, choose the zoom or coordinates."]]}},
  cv:{
    fa:{t:"راهنما: همرفت", s:[
      ["چه کاری می‌توان کرد؟","از روی نقشه‌های شاخص‌های همرفتی، احتمال وقوع همرفت و شدت بالقوهٔ آن برآورد می‌شود؛ همراه با گزارش متنی، نمودار مطلوبیت شاخص‌ها در بخش‌های منطقه و نقشه‌های آماری میانگین و بیشینهٔ هر شاخص برای هر مدل."],
      ["ورودی","نقشه‌های CAPE، CIN، LI، شاخص K، Total Totals، GDI، چینش باد، SRH، آب قابل بارش، رطوبت، نقطهٔ شبنم، چگالی رعدوبرق، بازتاب و … از هر سایتی؛ نام شاخص از عنوان و اعداد از نوار رنگ خوانده می‌شود. دست‌کم یک نقشهٔ بارش مدل هم برای مقایسه لازم است (در تحلیل دخالت ندارد)."],
      ["خروجی و تفسیر","«احتمال وقوع» شانس شکل‌گیری همرفت از ترکیب ناپایداری، رطوبت و عامل صعود است و «شدت بالقوه» توان همرفت در صورت وقوع. وزن شاخص‌ها علمی-فصلی (فصل گرم با تأکید بر ساعت ۱۱ تا ۲۰) یا دستی است. CAPE و CIN روی دریا معتبر نیستند و وزنشان آنجا کم می‌شود."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• احتمال وقوع همرفت — ورودی: دست\u200cکم یک شاخص ناپایداری (CAPE، LI، K، Total Totals، شوالتر …)، بهتر همراه رطوبت (آب قابل بارش، رطوبت نسبی، نقطهٔ شبنم) و عامل صعود (CIN …)؛ و الزاماً یک نقشهٔ بارش مدل برای مقایسه. پارامترها: روش ترکیب، روش وزن\u200cدهی، آستانهٔ شاخص\u200cها، هموارسازی، توان IDW و وزن CAPE/CIN روی دریا.\n• شدت بالقوهٔ همرفت — ورودی: همان، به\u200cعلاوهٔ چینش باد، SRH یا بارش همرفتی برای دقت بیشتر. پارامتر: کمینهٔ احتمال برای نمایش شدت.\n• احتمال بارش تگرگ — ورودی: نقشه\u200cهای احتمال همرفت به\u200cعلاوهٔ CAPE یا LI (یا K، Total Totals یا بازتاب رادار). برای دقت بیشتر: چینش باد ۰ تا ۶ کیلومتر، ارتفاع تراز صفر درجه، دمای ۵۰۰ هکتوپاسکال و آهنگ کاهش دمای ۷۰۰ تا ۵۰۰.\n• نقشه\u200cهای آماری هر شاخص و نمودار مطلوبیت — ورودی: همان شاخص\u200cها؛ با چند مدل یا چند ساعت، هر مدل و هر ساعت جداگانه هم تحلیل می\u200cشود."]]},
    en:{t:"Help: Convection", s:[
      ["What can you do?","From convective index maps, the probability of convection and its potential intensity are estimated, with a text report, a chart of index favourability across the region's sectors, and mean/maximum statistical maps of each index for each model."],
      ["Input","CAPE, CIN, LI, K-Index, Total Totals, GDI, wind shear, SRH, precipitable water, humidity, dew point, lightning density, reflectivity … maps from any website; the index name is read from the title and the numbers from the colorbar. At least one model precipitation map is also required for comparison (it is not used in the analysis)."],
      ["Outputs and interpretation","“Probability” is the chance of convection forming from instability, moisture and lift; “potential intensity” is how strong it could be if it forms. Index weights are scientific-seasonal (warm season emphasises 11:00–20:00) or manual. CAPE and CIN are not valid over sea, so their weight is reduced there."],
      ["Maps: required inputs and parameters","• Probability of convection — input: at least one instability index (CAPE, LI, K, Total Totals, Showalter …), ideally with moisture (precipitable water, relative humidity, dew point) and a lift factor (CIN …); a model precipitation map is required for comparison. Parameters: combination method, weighting method, index thresholds, smoothing, IDW power and CAPE/CIN weight over sea.\n• Potential convective intensity — input: the same, plus wind shear, SRH or convective precipitation for better accuracy. Parameter: minimum probability to show intensity.\n• Hail probability — input: the convection inputs plus CAPE or LI (or K, Total Totals or model reflectivity). For better accuracy: 0–6 km shear, freezing-level height, 500 hPa temperature and 700–500 hPa lapse rate.\n• Per-index statistical maps and favourability chart — input: the same indices; with several models or hours, each model and hour is also analysed separately."]]}},
  lt:{
    fa:{t:"راهنما: رعدوبرق", s:[
      ["چه کاری می‌توان کرد؟","انیمیشن رعدوبرق فریم‌به‌فریم بررسی می‌شود و فقط رعدهای سفیدِ تازه (نه رعدهای قدیمی زرد و نارنجی، نه مربع شهرها) استخراج می‌شوند. سه نقشه ساخته می‌شود: همهٔ رعدهای ثبت‌شده، تراکم رعدوبرق و جهت حرکت توده‌های تندری."],
      ["ورودی","انیمیشن GIF «Lightning» یا «Age of lightning» سایت weather.us از هر زوم، یا فریم‌های PNG آن. زمان هر فریم از روی خود فریم خوانده می‌شود."],
      ["خروجی و تفسیر","نقشهٔ تراکم تعداد رعد در کیلومتر مربع است (روش پیش‌فرض KDE گاوسی؛ شعاع بزرگ‌تر خوشه‌ها را پیوسته‌تر نشان می‌دهد). در نقشهٔ جهت حرکت، ابتدای هر پیکان جای شروع رعدوبرق توده و نوک آن جای پایان است و توده‌های پهن چند پیکان دارند."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• نقشهٔ همهٔ رعدهای ثبت\u200cشده، نقشهٔ تراکم رعدوبرق و نقشهٔ جهت حرکت توده\u200cها — ورودی: انیمیشن GIF «Lightning» یا «Age of lightning» سایت weather.us یا فریم\u200cهای PNG آن.\n• پارامترها: روش تراکم نقطه\u200cای، شعاع\u200cهای جست\u200cوجو (km)، توان حساسیت α، یکای تراکم، زمینهٔ نقشه، رنگ رعد و زوم weather.us."]]},
    en:{t:"Help: Lightning", s:[
      ["What can you do?","A lightning animation is examined frame by frame and only fresh white strokes are extracted (not older yellow/orange strokes or city squares). Three maps are made: all recorded strokes, lightning density and thunderstorm movement direction."],
      ["Input","A weather.us “Lightning” or “Age of lightning” GIF from any zoom, or its PNG frames. The time of each frame is read from the frame itself."],
      ["Outputs and interpretation","The density map is strokes per km² (default Gaussian KDE; a larger radius shows clusters more continuously). On the movement map, each arrow's tail is where the cell's lightning started and its head where it ended; wide cells get several arrows."],
      ["Maps: required inputs and parameters","• All-strokes map, lightning density map and storm-movement map — input: a weather.us “Lightning” or “Age of lightning” GIF, or its PNG frames.\n• Parameters: point-density method, search radii (km), sensitivity power α, density unit, map background, stroke colour and weather.us zoom."]]}},
  wn:{
    fa:{t:"راهنما: هشدارهای جوی", s:[
      ["چه کاری می‌توان کرد؟","از نقشه‌های پدیده‌های خطرناک، نقشهٔ هشدار سه‌سطحی و متن هشدار با نام شهرها، دلیل هشدار، پیامدهای احتمالی و توصیه به مردم و مسئولین ساخته می‌شود. نمودار ماتریس ریسک (احتمال × شدت پیامد) و نمودار مساحت زیر هشدار هر پدیده هم رسم می‌شود و برای هر پدیده‌ای که به حد هشدار برسد نقشهٔ جداگانه ساخته می‌شود. در متن هشدار، بارش فقط با سطح هشدار بیان می‌شود و مقدار عددی آن نمی‌آید."],
      ["ورودی","هر تعداد نقشه از بارش تجمعی، شدت بارش، تندباد، سرعت باد، رعدوبرق، احتمال توفان تندری، CAPE، ریسک سیلاب، برف، انومالی دما، بیشینه و کمینهٔ دما، UV، تگرگ، موج، گردوخاک و دید افقی؛ و نقشه‌های دمای ۲ متری، نقطهٔ شبنم و دمای نزدیک سطح خاک که از آن‌ها هشدار یخبندان، یخبندان سطح خاک (اگر دمای خاک نباشد، از دمای ۲ متری منهای ۲ تا ۴ درجه)، گرمای شدید و شرجی (شاخص گرما از دما و نقطهٔ شبنم) ساخته می‌شود. اگر از یک پدیده نقشهٔ چند مدل بدهید، توافق مدل‌ها به عنوان «احتمال وقوع» در سطح هشدار اثر می‌گذارد."],
      ["خروجی و تفسیر","زرد = آگاهی، نارنجی = آمادگی، قرمز = اقدام (مطابق مفهوم رنگ‌ها در هشدارهای سازمان هواشناسی). هر رنگ از کم‌رنگ تا پررنگ است و هر جا چند پدیده هم‌زمان در بالاترین سطح باشند رنگ تیره‌تر می‌شود (قرمز جدی). آستانه‌ها قابل ویرایش‌اند؛ سطح هشدار در عمل ترکیب احتمال وقوع، شدت پدیده و پیامد آن است، پس این خروجی کمکی برای تصمیم‌گیری است و جایگزین هشدار رسمی نیست."],
      ["دید افقی و پدیده‌های مهم جوی","نقشهٔ Visibility سایت weather.us (نوار رنگ و عنوانش) خودکار شناخته می‌شود و هشدار «کاهش دید افقی» می‌سازد. نقشهٔ Significant Weather از روی رنگ‌های راهنمایش به هشدار توفان تندری (در نزدیکی، خفیف تا متوسط، شدید)، مه و مه یخ‌زده، یخ‌زدگی و باران یخ‌زا، بارش برف و برف‌وباران و باران (سبک، متوسط، شدید) تبدیل می‌شود؛ کنار آن دست‌کم یک نقشهٔ عددی (مثلاً بارش یا دما) بدهید. نقشه‌های برف weather.us (تجمعی کل یا ۲۴ ساعته) از عنوانشان شناخته می‌شوند."],
      ["شدت شرجی و سوز باد","با دادن نقشهٔ دمای ۲ متری همراه نقشهٔ رطوبت نسبی (یا نقطهٔ شبنم)، نقشهٔ «شدت شرجی» با شاخص گرمای سرویس ملی هواشناسی آمریکا (رگرسیون Rothfusz) ساخته می‌شود: احتیاط ۲۷ تا ۳۲، احتیاط شدید ۳۲ تا ۳۹، خطر ۳۹ تا ۵۲ و خطر شدید بالای ۵۲ درجه. با نقشهٔ دما و نقشهٔ سرعت باد ۱۰ متری، نقشهٔ «سوز باد» با فرمول مشترک کانادا و آمریکا ساخته می‌شود (WCI = 13.12 + 0.6215T − 11.37V^0.16 + 0.3965TV^0.16؛ برای دمای ۱۰ درجه و کمتر و باد ۴٫۸ کیلومتر بر ساعت و بیشتر) با رده‌های خطر سرمازدگی Environment Canada. هر دو هشدار هم می‌سازند. نقشه‌های هم‌مدل و هم‌زمان با هم جفت می‌شوند."],
      ["ساختار متن هشدار","متن با یک خلاصه (بالاترین سطح و پدیده‌های اصلی) شروع می‌شود و سپس برای هر سطح، از قرمز 🔴 به نارنجی 🟠 و زرد 🟡، یک بند می‌آید. در هر بند پدیده‌ها به ترتیب اهمیت (خطر جانی و گستردگی پیامد: توفان تندری و سیلاب، باد، برف و یخ، مه و دید، گرما و سرما) با نام نوع و شدت پدیده، شهرها، زمان و پیامد فهرست می‌شوند و توصیهٔ رسمی همان رنگ در پایان بند می‌آید."],
      ["نقشه‌ها: ورودی‌ها و پارامترهای لازم","• نقشهٔ هشدار کلی و متن هشدار — ورودی: هر نقشه از پدیده\u200cهای خطرناک. پارامترها: آستانه\u200cهای زرد، نارنجی و قرمز هر پدیده و «احتمال وقوع برای پدیده\u200cهای تک\u200cنقشه».\n• یخبندان، گرمای شدید و یخبندان سطح خاک — ورودی: دمای ۲ متری (و اختیاری دمای نزدیک سطح خاک). پارامتر: اختلاف دمای سطح خاک با دمای ۲ متری.\n• شدت شرجی (هشدار و نقشهٔ مقدار) — ورودی: دمای ۲ متری به\u200cعلاوهٔ رطوبت نسبی (یا نقطهٔ شبنم)، ترجیحاً هم\u200cزمان و هم\u200cمدل.\n• سوز باد (هشدار و نقشهٔ مقدار) — ورودی: دمای ۲ متری به\u200cعلاوهٔ سرعت باد ۱۰ متری.\n• پتانسیل سیلاب (آزمایشی) — ورودی: بارش تجمعی (یا Significant Weather یا شدت بارش). برای دقت بیشتر: شدت بارش، CAPE یا احتمال توفان تندری یا Significant Weather (همرفتی بودن بارش) و نقشهٔ برف (سهم برف). شیب و آب بالادست از DEM داخلی حساب می\u200cشود.\n• کاهش دید افقی — ورودی: نقشهٔ Visibility.\n• توفان تندری، مه، یخ\u200cزدگی، برف و باران — ورودی: نقشهٔ Significant Weather همراه دست\u200cکم یک نقشهٔ عددی."]]},
    en:{t:"Help: Weather warnings", s:[
      ["What can you do?","From hazard maps, a three-level warning map and a warning text are built with city names, reasons, likely impacts and advice for the public and officials. A risk-matrix chart (likelihood × impact) and a chart of the area under warning for each hazard are also drawn, plus a separate warning map for each hazard that reaches a warning level. Precipitation is described by warning level, without amounts."],
      ["Input","Any number of maps of accumulated precipitation, precipitation rate, gusts, wind speed, lightning, thunderstorm probability, CAPE, flood risk, snow, temperature anomaly, maximum/minimum temperature, UV, hail, waves, dust and visibility; plus 2 m temperature, dew point and near-surface soil temperature maps, from which frost, ground frost (2 m temperature minus 2–4 degrees if no soil map), extreme heat and sultry-heat (heat index from temperature and dew point) warnings are built. If you give maps of one hazard from several models, model agreement acts as the “likelihood” in the warning level."],
      ["Outputs and interpretation","Yellow = be aware, orange = be prepared, red = take action (as in the national meteorological service's colour warnings). Each colour runs from light to dark, and where several hazards share the highest level the colour gets darker (serious red). Thresholds are editable; in practice the warning level combines likelihood, severity and impact, so this output supports decisions and does not replace official warnings."],
      ["Visibility and significant weather","The weather.us Visibility map (its colorbar and title) is recognised automatically and gives a “low visibility” warning. The Significant Weather map is turned, from its legend colours, into warnings for thunderstorms (nearby, light to moderate, severe), fog and freezing fog, ice and freezing rain, snow and sleet, and rain (light, moderate, heavy); add at least one numeric map (e.g. precipitation or temperature) alongside it. weather.us snow maps (total or 24 h) are recognised from their title."],
      ["Sultry heat and wind chill","Give a 2 m temperature map with a relative humidity (or dew point) map to get a “sultry heat” map from the US National Weather Service heat index (Rothfusz regression): caution 27–32, extreme caution 32–39, danger 39–52 and extreme danger above 52 °C. With a temperature map and a 10 m wind speed map, a “wind chill” map is made with the joint Canada/US formula (WCI = 13.12 + 0.6215T − 11.37V^0.16 + 0.3965TV^0.16, for 10 °C or colder and wind of 4.8 km/h or more) using Environment Canada frostbite risk categories. Both also produce warnings. Maps of the same model and time are paired."],
      ["Warning text layout","The text opens with a summary (highest level and main hazards), followed by one paragraph per level, from red 🔴 to orange 🟠 and yellow 🟡. In each paragraph hazards are listed in order of importance (danger to life and extent of impact: thunderstorms and floods, wind, snow and ice, fog and visibility, heat and cold) with the hazard type and intensity, places, time and impact, and the official advice for that colour closes the paragraph."],
      ["Maps: required inputs and parameters","• Overall warning map and warning text — input: any hazard maps. Parameters: yellow, orange and red thresholds of each hazard and the “likelihood for single-map hazards”.\n• Frost, extreme heat and ground frost — input: 2 m temperature (optionally near-surface soil temperature). Parameter: ground-minus-2 m temperature offset.\n• Sultry heat (warning and value map) — input: 2 m temperature plus relative humidity (or dew point), ideally same time and model.\n• Wind chill (warning and value map) — input: 2 m temperature plus 10 m wind speed.\n• Flood potential (experimental) — input: accumulated precipitation (or Significant Weather or precipitation rate). For better accuracy: precipitation rate, CAPE, thunderstorm probability or Significant Weather (convective rain), and a snow map (snow share). Slope and upstream water come from the built-in DEM.\n• Low visibility — input: the Visibility map.\n• Thunderstorm, fog, ice, snow and rain — input: the Significant Weather map plus at least one numeric map."]]}}
};
// بخش‌های تازهٔ راهنما: چیدمان صفحه، اصلاح دما با ارتفاع، شناسایی توده‌های تندری
(function(){
  const LAY={fa:["چیدمان صفحه","هر صفحه یک کادر نقشه دارد. بالای کادر: آیکون «ذخیره» (پنجرهٔ ذخیرهٔ PNG، CSV، NetCDF و اشتراک در X، تلگرام، واتساپ، اینستاگرام و فیسبوک) و دو منوی مرزبندی: «تفکیک با مرز MetStat» (پیش‌فرض)، «تفکیک با مرز weather.us» یا «بدون مرز»، و منوی منطقه (زوم) که خودکار تشخیص داده می‌شود و می‌توانید دستی عوض کنید. زیر کادر: دکمه‌های انتخاب نوع نقشه؛ با زدن هر دکمه همان نقشه و تنظیمات مخصوص آن (مثلاً وزن مدل‌ها برای نقشهٔ میانگین) نمایش داده می‌شود. پایین‌تر «تنظیمات کل صفحه» است که برای همهٔ نقشه‌ها به کار می‌رود. دکمهٔ پهن «تولید گزارش و تحلیل» متن گزارش را در پنجره‌ای جدا با امکان کپی و ذخیرهٔ PDF باز می‌کند. پرسش‌های یادگیری (مثلاً درستی تاریخ خوانده‌شده) پس از بارگذاری در پنجرهٔ کوچکی پرسیده می‌شوند. هر صفحه نشانی جداگانه دارد (مثلاً wtafkik.ir/alertmaps)."],
    en:["Page layout","Each page has one map frame. Above it: the “Save” icon (a window to save PNG, CSV, NetCDF and to share on X, Telegram, WhatsApp, Instagram and Facebook) and two border menus: “MetStat borders” (default), “weather.us borders” or “No borders”, plus the region (zoom) menu, which is detected automatically and can be changed by hand. Below the frame: the map-type buttons; each button shows that map and its own settings (e.g. model weights for the mean map). Further down are the “Page settings” that apply to all maps. The wide “Generate report & analysis” button opens the report text in a separate window with Copy and PDF buttons. Learning questions (e.g. whether the date read from the map is right) are asked in a small window after upload. Each page has its own address (e.g. wtafkik.ir/alertmaps)."]};
  for(const k of Object.keys(HELP)) if(k!=="landing") for(const g of ["fa","en"]) HELP[k][g].s.push(LAY[g]);
  HELP.ds.fa.t="راهنما: اصلاح نقشه‌های بارش و دما با توجه به ارتفاع"; HELP.ds.en.t="Help: Elevation correction of precipitation and temperature maps";
  HELP.ds.fa.s.splice(3,0,["اصلاح دما با ارتفاع","اگر نقشهٔ ورودی دما باشد (از عنوان یا نوار رنگ تشخیص داده می‌شود)، روش «آهنگ کاهش دمای محلی» به کار می‌رود: دمای هر نقطه = دمای مدل + Γ × (ارتفاع DEM − ارتفاع هموارشدهٔ مدل). ارتفاع مدل با هموار کردن DEM به اندازهٔ رزولوشن مدل ساخته می‌شود. Γ (آهنگ کاهش دما) از رگرسیون وزنی دمای مدل بر ارتفاع مدل در پنجره‌های ۴ درجه‌ای با هم‌پوشانی برآورد می‌شود؛ جایی که رابطه ضعیف است (R² کم یا اختلاف ارتفاع کم) به مقدار استاندارد −۶٫۵ درجه بر کیلومتر نزدیک می‌شود و بین −۱۰ و +۳ محدود است (وارونگی دما در دره‌ها هم ممکن است). نمای «آهنگ کاهش دما» نقشهٔ Γ را نشان می‌دهد. ورودی: نقشهٔ دمای ۲ متری (یا بیشینه/کمینهٔ دما) با نوار رنگ. پارامترها: رزولوشن مدل (در فهرست نقشه‌ها)، شدت اصلاح و هموارسازی زمین."]);
  HELP.ds.en.s.splice(3,0,["Temperature correction with elevation","If the input map is temperature (detected from the title or colorbar), the “local lapse rate” method is used: temperature at each point = model temperature + Γ × (DEM elevation − smoothed model elevation). Model elevation is made by smoothing the DEM to the model resolution. Γ (lapse rate) is estimated from a weighted regression of model temperature on model elevation in overlapping 4° windows; where the relation is weak (low R² or little relief) it is pulled toward the standard −6.5 °C/km and limited to −10…+3 (valley inversions are possible). The “Lapse rate” view shows the Γ map. Input: a 2 m temperature (or max/min temperature) map with its colorbar. Parameters: model resolution (in the map list), correction strength and terrain smoothing."]);
  HELP.lt.fa.s.splice(3,0,["شناسایی توده‌های تندری","رعدهای هر فریم با خوشه‌بندی چگالی (رعدهای نزدیک‌تر از ۱۵ کیلومتر) به توده‌ها تقسیم می‌شوند و توده‌های فریم‌های پیاپی اگر فاصلهٔ زمانی‌شان حداکثر ۲۰ دقیقه و جابه‌جایی‌شان با سرعت واقعی (تا حدود ۷۰ کیلومتر بر ساعت) سازگار باشد به هم پیوند می‌خورند. اگر منطقه‌ای پس از وقفهٔ طولانی‌تر (مثلاً نیم ساعت یا چند ساعت) دوباره فعال شود، تودهٔ جداگانه شمرده می‌شود. رنگ پیکان زمان شروع توده را نشان می‌دهد (افسانهٔ زمانی زیر نقشه) و دایره یعنی تودهٔ تقریباً ساکن. روی این نقشه مرزها کمی شفاف‌اند تا پیکان‌ها بهتر دیده شوند."]);
  HELP.lt.en.s.splice(3,0,["Thunderstorm cell identification","The strokes of each frame are split into cells by density clustering (strokes closer than 15 km), and cells in consecutive frames are linked when the time gap is at most 20 minutes and the displacement fits a realistic speed (up to about 70 km/h). If an area becomes active again after a longer gap (e.g. half an hour or several hours), it counts as a separate cell. Arrow colour shows the cell start time (time legend under the map) and a circle means a nearly stationary cell. On this map the borders are slightly transparent so the arrows stand out."]);
})();
// فهرست کامل خروجی‌های سایت (تعداد نقشه، نمودار و گزارش هر صفحه و ورودی لازم)
(function(){
  const OUT_FA=["فهرست خروجی‌ها و ورودی‌های لازم",
`• WeatherBELL / weather.us / آزاد / tropicaltidbits — ورودی: دست‌کم دو نقشه از یک پارامتر و بازه (بارش، برف، دما، آنومالی، باد، …).
  نقشه‌ها (۵ تا ۱۰): میانگین وزنی، بیشینه، کمینه، توافق مدل‌ها برای هر آستانه (پیش‌فرض ۳)، ریسک یخبندان هوا و سطح خاک (برای دما)، نقشهٔ آستانه، نقشهٔ اختلاف دو نقشه، نقشهٔ تجمعی از نقشه‌های ساعتی.
  گزارش: «گزارش و تحلیل» برای هر نقشه (پهنه‌ها، شهرها، درصد مساحت) + PDF. خروجی: PNG، CSV، NetCDF.
• اصلاح ارتفاعی (DEM) — ورودی: نقشهٔ بارش یا دمای مدل (+ DEM داخلی یا GeoTIFF). نقشه‌ها: اصلاح‌شده، ورودی، مکان، ضریب/آهنگ کاهش، اختلاف، ارتفاع (۶). نمودار: رابطهٔ ارتفاع (۱). گزارش: متن کامل + درصد مساحت در بازه‌ها و جدول ۱۱ پهنه.
• همرفت — ورودی: نقشه‌های CAPE، CIN، LI، K، Total Totals، چینش باد، PWAT، بازتاب، … (+ نقشهٔ بارش برای مقایسه). نقشه‌ها: احتمال همرفت، شدت بالقوه، احتمال تگرگ، نقشه‌های آماری هر شاخص (۴+). نمودار: تحلیل شاخص‌ها و مطلوبیت (۲). گزارش: متن شرایط همرفتی.
• رعدوبرق — ورودی: انیمیشن GIF یا تصاویر رعد (چند فایل ادغام می‌شوند). نقشه‌ها: رعدهای ثبت‌شده، جهت حرکت توده‌ها، تراکم با ۳ شعاع (۵). نمودار: رعد در هر فریم (۱). انیمیشن GIF سی‌دقیقه‌ای. خروجی CSV نقاط و پیکان‌ها.
• هشدارهای جوی — ورودی: هر نقشهٔ پدیدهٔ خطر (بارش، شدت بارش، باد، تندباد، دما، رطوبت، رعد، CAPE، دید، برف، …). نقشه‌ها: هشدار کلی + هشدار جداگانهٔ هر پدیده + شاخص گرما/سوز سرما + پتانسیل سیل ناگهانی و آب‌گرفتگی. نمودار: نمودارهای هشدار. گزارش: متن هشدار رنگی با شهرها یا بخش استان‌ها و توصیه‌های کشاورزی، سفر و ساخت‌وساز + PDF.
• عملیات آماری — ورودی: فایل‌های ایستگاهی xlsx/xls/csv/txt/dbf/nc/pdf (روزانه یا ماهانه، شمسی/میلادی/سال زراعی) + فایل مختصات اختیاری. خروجی: گزارش کنترل کیفیت و ترمیم، داده‌های ترمیم‌شده، اکسل هر ایستگاه، اکسل GIS، GeoJSON، نقشهٔ پهنه‌بندی، تحلیل شاخص‌های اقلیمی (با فایل indices.xlsx).`];
  const OUT_EN=["List of outputs and required inputs",
`• WeatherBELL / weather.us / Free / tropicaltidbits — input: at least two maps of the same parameter and period (precipitation, snow, temperature, anomaly, wind, …).
  Maps (5–10): weighted mean, maximum, minimum, model agreement per threshold (3 by default), air and ground frost risk (temperature), threshold map, difference map, accumulated map from hourly maps.
  Report: “Report and analysis” for every map (regions, cities, area shares) + PDF. Downloads: PNG, CSV, NetCDF.
• Elevation correction (DEM) — input: model precipitation or temperature map (+ built-in DEM or GeoTIFF). Maps: corrected, input, location, factor/lapse rate, difference, elevation (6). Chart: elevation relationship (1). Report: full text + area shares by range and an 11-region table.
• Convection — input: CAPE, CIN, LI, K, Total Totals, wind shear, PWAT, reflectivity … maps (+ a precipitation map for comparison). Maps: convection probability, potential intensity, hail probability, index statistics (4+). Charts: index analysis and favourability (2). Report: convective conditions text.
• Lightning — input: lightning GIF animation or images (several files are merged). Maps: recorded strokes, cell motion, density at 3 radii (5). Chart: strokes per frame (1). 30-minute animated GIF. CSV of points and arrows.
• Weather warnings — input: any hazard maps (precipitation, rate, wind, gusts, temperature, humidity, lightning, CAPE, visibility, snow, …). Maps: overall warning + one per hazard + heat index/wind chill + flash-flood and waterlogging potential. Charts: warning charts. Report: colour-coded warning text naming cities or parts of provinces, with farming, travel and construction advice + PDF.
• Statistical operations — input: station files xlsx/xls/csv/txt/dbf/nc/pdf (daily or monthly; Solar Hijri, Gregorian or crop year) + optional coordinates file. Outputs: QC and repair report, repaired data, one Excel per station, GIS Excel, GeoJSON, zoning map, climate-index analysis (with indices.xlsx).`];
  HELP.landing.fa.s.push(OUT_FA); HELP.landing.en.s.push(OUT_EN);
  const TOOLS_FA=["ابزارهای نقشه، دکمهٔ «i»، بزرگ‌نمایی و گزارش","• پنل «ابزارهای نقشه»: نقشهٔ آستانه (آماده یا دلخواه، با همان رنگ‌های ورودی)، اختلاف دو نقشه (الف منهای ب، با متن تحلیل)، جمع نقشه‌های ساعتی هر مدل با حذف ساعت‌های اول، و رنگ‌های خروجی (همان ورودی، شبیه Windy یا کدهای دلخواه).\n• دکمهٔ «i» زیر کادر: ماهیت نقشه، راهنمای رنگ‌ها و ورودی‌های لازم.\n• کلیک روی استان: بزرگ‌نمایی روی همان استان؛ ذره‌بین +/− و ⟲ بالا‌چپ کادر.\n• «گزارش و تحلیل»: بیشینه و محل آن، درصد مساحت، ۱۱ پهنهٔ اقلیمی و شهرها.\n• tropicaltidbits: زوم خاورمیانه خودکار؛ نقشه‌های CanSIPS، CFSv2 و NMME با اندازه‌های مختلف روی هم منتقل می‌شوند."];
  const TOOLS_EN=["Map tools, the “i” button, zoom and report","• “Map tools” panel: threshold map (preset or custom, in the input colours), difference of two maps (A minus B, with analysis text), sum of each model's hourly maps with the first hours dropped, and output colours (input, Windy-like or custom codes).\n• “i” button under the frame: what the map shows, colour key and required inputs.\n• Click a province to zoom into it; +/− and ⟲ magnifier at the top-left of the frame.\n• “Report and analysis”: maximum and its location, area shares, 11 climatic regions and cities.\n• tropicaltidbits: automatic Middle East zoom; CanSIPS, CFSv2 and NMME maps of different sizes are re-projected onto each other."];
  for(const k of ["wb","wu","cu"]) if(HELP[k]){ HELP[k].fa.s.push(TOOLS_FA); HELP[k].en.s.push(TOOLS_EN); }
})();
function helpMode(){
  if(!$("landing").hidden) return "landing";
  if(!$("dsApp").hidden) return "ds"; if(!$("cvApp").hidden) return "cv"; if(!$("ltApp").hidden) return "lt"; if(!$("wnApp").hidden) return "wn";
  if(!$("app").hidden){ const k=P&&P.key; return (k==="wb"||k==="wu") ? k : "cu"; }
  return "landing";
}
function openHelp(){
  const h=HELP[helpMode()][LANG==="en"?"en":"fa"], d=$("help");
  d.dir = LANG==="en" ? "ltr" : "rtl";
  $("helpTitle").textContent=h.t; const b=$("helpBody"); b.replaceChildren();
  for(const [hd,tx] of h.s){ const e=document.createElement("h4"); e.textContent=hd; const p=document.createElement("p"); p.style.whiteSpace="pre-line"; p.textContent=tx; b.append(e,p); }
  d.showModal();
}
$("helpBtn").onclick=openHelp;
$("help").addEventListener("click", e=>{ if(e.target===$("help")) $("help").close(); });

/* ---- حذف همهٔ نقشه‌های هر صفحه ---- */
const CLEAR={
  main(){ state.models=[]; state.cards={}; state.order=[]; wPanel=null; $("grid").replaceChildren(); $("status").hidden=true; $("stText").textContent=""; if(P&&P.custom) P.dirty=true; try{ syncWeights(true); }catch(e){} drawModels(); try{ updateTimeUI(); }catch(e){} },
  ds(){ ds.maps=[]; $("dsCards").replaceChildren(); $("dsStatus").hidden=true; dsDrawList(); $("dsEmpty").hidden=false; },
  cv(){ cv.gen=(cv.gen||0)+1; cv.maps=[]; cv.res=null; $("cvCards").replaceChildren(); $("cvStatus").hidden=true; cvDrawList(); try{ cvThrPanel(); }catch(e){} },
  lt(){ lt.frames=[]; lt.streamE=null; lt.frameCount=0; lt.firstData=null; lt.lastData=null; lt.files=[]; lt.res=null; $("ltCards").replaceChildren(); $("ltStatus").hidden=true; $("ltEmpty").hidden=false; $("ltInfo").textContent=""; try{ wuzSync(); }catch(e){} },
  wn(){ wn.gen=(wn.gen||0)+1; wn.maps=[]; wn.res=null; $("wnCards").replaceChildren(); $("wnStatus").hidden=true; wnDrawList(); wnThrPanel(); }
};
const CLEAR_N={ main:()=>state.models.length, ds:()=>ds.maps.length, cv:()=>cv.maps.length, lt:()=>lt.frameCount||lt.frames.length, wn:()=>wn.maps.length };
document.querySelectorAll("[data-clear]").forEach(b=>b.onclick=()=>{ const k=b.dataset.clear; if(!CLEAR_N[k]()) return; try{ CLEAR[k](); }catch(e){ console.error(e); } b.hidden=true; window.scrollTo({top:0, behavior:"smooth"}); });
setInterval(()=>{ document.querySelectorAll("[data-clear]").forEach(b=>{ const on=CLEAR_N[b.dataset.clear]()>0; if(b.hidden===on) b.hidden=!on; }); }, 600);


// ===== استان‌ها و بخش‌های استان زیر هشدار (برای متن: «شرق فارس»، «استان بوشهر») =====
const WN_PART_EN={"شمال":"northern","جنوب":"southern","شرق":"eastern","غرب":"western","شمال‌شرق":"north-eastern","شمال‌غرب":"north-western","جنوب‌شرق":"south-eastern","جنوب‌غرب":"south-western","مرکز":"central"};
function wnProvParts(rp, per, sea){
  const L_=window.CQC_LAYERS&&CQC_LAYERS.ostan; if(!L_) return null;
  const c=document.createElement("canvas"); c.width=FW; c.height=FH; const x=c.getContext("2d",{willReadFrequently:true}); x.imageSmoothingEnabled=false;
  L_.forEach((f,k)=>{ x.fillStyle=`rgb(${k+1},0,0)`; x.beginPath(); for(const poly of f.g) for(const ring of poly){ ring.forEach(([lo,la],j)=>{ const X=rp.ax+rp.bx*lo-rp.fx0, Y=rp.ay+rp.by*la-rp.fy0; if(j) x.lineTo(X,Y); else x.moveTo(X,Y); }); x.closePath(); } x.fill("evenodd"); });
  const d=x.getImageData(0,0,FW,FH).data, prov=new Uint8Array(N); for(let i=0;i<N;i++){ const a=d[i*4+3]; if(a>200 && d[i*4+1]===0 && d[i*4+2]===0) prov[i]=d[i*4]; }
  // کادر و مساحت هر استان روی همین شبکه
  const P=L_.map(()=>({n:0,x0:1e9,x1:-1,y0:1e9,y1:-1}));
  for(let i=0;i<N;i++){ const k=prov[i]; if(!k) continue; const o=P[k-1], X=i%FW, Y=(i/FW)|0; o.n++; if(X<o.x0)o.x0=X; if(X>o.x1)o.x1=X; if(Y<o.y0)o.y0=Y; if(Y>o.y1)o.y1=Y; }
  const out={};
  for(const p of per){ const t=p.f.m.type; out[t]=out[t]||{};
    for(let L=1;L<=3;L++){ const A=L_.map(()=>({n:0,sx:0,sy:0})); let any=0;
      for(let i=0;i<N;i++){ if(p.L[i]!==L) continue; const k=prov[i]; if(!k) continue; const a=A[k-1]; a.n++; a.sx+=i%FW; a.sy+=(i/FW)|0; any++; }
      if(!any) continue; const items=[];
      A.forEach((a,k)=>{ const o=P[k]; if(!a.n || !o.n) return; const fr=a.n/o.n; if(a.n<4) return;
        const nm=L_[k].p.name, en=L_[k].p.en||nm;
        if(fr>=0.6){ items.push({fa:`استان ${nm}`, en:`${en} province`, n:a.n}); return; }
        const cx=(a.sx/a.n-o.x0)/Math.max(1,o.x1-o.x0), cy=(a.sy/a.n-o.y0)/Math.max(1,o.y1-o.y0);
        const ns=cy<0.38?"شمال":cy>0.62?"جنوب":"", ew=cx<0.38?"غرب":cx>0.62?"شرق":"", part=ns&&ew?ns+"‌"+ew:(ns||ew||"مرکز");
        items.push({fa:`${part} ${nm}`, en:`${WN_PART_EN[part]||part} ${en}`, n:a.n}); });
      items.sort((a,b)=>b.n-a.n); out[t][L]=items; } }
  return out;
}
