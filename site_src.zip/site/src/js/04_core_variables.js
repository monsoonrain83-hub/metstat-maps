/* ---------- متغیر نقشه‌ها ---------- */
const VARS = {
  precip:{n:"بارش تجمعی", p:"بارش", u:"میلی‌متر", us:"mm", accum:true, nc:"precipitation", re:/prec|rain|apcp|qpf|\btp\b|بارش|باران/i},
  snowp: {n:"بارش برف (معادل آب)", p:"بارش برف", u:"میلی‌متر", us:"mm", accum:true, nc:"snowfall_water_equivalent", re:/snow.*mm|swe/i},
  snow:  {n:"بارش برف تجمعی", p:"بارش برف", u:"سانتی‌متر", us:"cm", accum:true, nc:"snowfall", re:/snow|برف/i},
  panom: {n:"انومالی بارش", p:"انومالی بارش", u:"میلی‌متر", us:"mm", accum:false, nc:"precipitation_anomaly", re:/precip.*anom|anom.*precip|انومالی\s*بارش/i},
  tanom: {n:"انومالی دما", p:"انومالی دما", u:"درجهٔ سلسیوس", us:"°C", accum:false, nc:"temperature_anomaly", re:/anom|ناهنجاری|انومالی/i},
  td:    {n:"نقطهٔ شبنم ۲ متری", p:"نقطهٔ شبنم", u:"درجهٔ سلسیوس", us:"°C", accum:false, nc:"dew_point", re:/dew|td2?m|نقطه\s*شبنم/i},
  tsoil: {n:"دمای نزدیک سطح خاک", p:"دمای سطح خاک", u:"درجهٔ سلسیوس", us:"°C", accum:false, nc:"soil_temperature", frost:"ground", re:/soil|ground|tsoil|خاک/i},
  temp:  {n:"دمای ۲ متری", p:"دمای ۲ متری", u:"درجهٔ سلسیوس", us:"°C", accum:false, nc:"temperature", frost:"air", re:/temp|t2m|tmp|\bt2\b|دما/i},
  tmax:  {n:"بیشینهٔ دما", p:"بیشینهٔ دما", u:"درجهٔ سلسیوس", us:"°C", accum:false, nc:"tmax", re:/tmax|max[-_ ]?temp/i},
  tmin:  {n:"کمینهٔ دما", p:"کمینهٔ دما", u:"درجهٔ سلسیوس", us:"°C", accum:false, nc:"tmin", frost:"air", re:/tmin|min[-_ ]?temp/i},
  wind:  {n:"سرعت باد", p:"سرعت باد", u:"کیلومتر بر ساعت", us:"km/h", accum:false, nc:"wind_speed", re:/wind|wspd|باد/i},
  gust:  {n:"تندباد", p:"تندباد", u:"کیلومتر بر ساعت", us:"km/h", accum:false, nc:"wind_gust", re:/gust|تندباد/i},
  mslp:  {n:"فشار سطح دریا", p:"فشار سطح دریا", u:"هکتوپاسکال", us:"hPa", accum:false, nc:"mslp", re:/mslp|pres|فشار/i},
  rh:    {n:"رطوبت نسبی", p:"رطوبت نسبی", u:"درصد", us:"%", accum:false, nc:"relative_humidity", re:/\brh\b|humid|رطوبت/i},
  cloud: {n:"پوشش ابر", p:"پوشش ابر", u:"درصد", us:"%", accum:false, nc:"cloud_cover", re:/cloud|tcc|ابر/i},
  cape:  {n:"CAPE", p:"CAPE", u:"ژول بر کیلوگرم", us:"J/kg", accum:false, nc:"cape", re:/cape|کیپ|انرژی\s*پتانسیل/i},
  custom:{n:"", p:"", u:"", us:"", accum:false, nc:"value"}
};
// آستانه‌های پیش‌فرض نقشهٔ توافق برای هر متغیر، با یکای خودش (دما بر حسب سلسیوس، نه میلی‌متر)
var VAR_THR={panom:"10, 30, 50", precip:"1, 5, 10", snowp:"1, 5, 10", snow:"1, 5, 10", tanom:"2, 5", td:"16, 20, 24", tsoil:"0, 10, 20", temp:"0, 30, 40", tmax:"35, 40, 45", tmin:"0, 10, 20", wind:"30, 50, 70", gust:"50, 70, 90", mslp:"1010, 1020", rh:"70, 90", cloud:"50, 80", cape:"500, 1000, 2000"};
var VAR_THR_CUR=null;
function varThr(k){
  try{ if(typeof snowCmSync==="function") snowCmSync(); }catch(e){}
  if(k===VAR_THR_CUR) return; VAR_THR_CUR=k; const V=VARS[k]||{}, u = k==="custom" ? ($("varUnit").value||"") : (V.u||"");
  $("thrLbl").textContent=`آستانه‌های نقشهٔ توافق (${u||"یکای نقشه"}، با کاما جدا کنید)`;
  const s=store.get("thr."+k, null); if(s!==null) $("thr").value=s; else if(VAR_THR[k]) $("thr").value=VAR_THR[k];
}
function curVar(){
  const k=$("varSel").value||"precip", v={...VARS[k], key:k};
  if(k==="custom"){ v.n=$("varName").value.trim()||"متغیر"; v.p=v.n; v.u=$("varUnit").value.trim(); v.us=v.u; }
  if(k==="snowp" && typeof snowCmFactor==="function" && snowCmFactor()){ const sv=$("snowCm").value, slr=sv==="T"?snowSLR(parseFloat($("snowT").value)||0):+sv;
    v.n="برف تازهٔ برآوردی"; v.p="برف"; v.u="سانتی‌متر"; v.us="cm"; v.nc="snow_depth_estimated"; v.slrNote=`نسبت برف به آب ${FA(+slr.toFixed(1))}:۱`; }
  // weather.us ساعتی: عنوان «بارش ۶ ساعته» به‌جای «بارش تجمعی»
  if(P && P.key==="wu" && P.hours && (k==="precip"||k==="snowp")){ const h=FA(P.hours); v.n = k==="precip" ? `بارش ${h} ساعته` : `بارش برف ${h} ساعته (معادل آب)`; v.p = k==="precip" ? `بارش ${h} ساعته` : `بارش برف ${h} ساعته`; }
  return v;
}
// سفید ۰ · آبی کم‌رنگ ۱–۱۰ · آبی پررنگ ۱۱–۲۰ · سبز پررنگ ۲۱–۳۰ · سبز کم‌رنگ ۳۱–۴۰ · زرد ۴۱–۵۰ · نارنجی ۵۱–۶۰ · قرمز ۶۱–۷۰ · آب‌اناری ۷۱–۸۰ · صورتی پررنگ ۸۱–۹۰ · صورتی متوسط ۹۱–۹۵ · صورتی کم‌رنگ ۹۶–۹۹
const PROB_EDGES = [0,10,20,30,40,50,60,70,80,90,95,99], PROB_COLORS = ["#a9d8ff","#1f5fd6","#138a36","#8edb6a","#ffe128","#ff8c14","#e31a1c","#9e0e3c","#ff1f8e","#ff6fb5","#ffc2df"], PROB_MAX = 99, ZERO_BELOW = 1;
const lonOf = x => (x - P.ax)/P.bx, latOf = y => (y - P.ay)/P.by;

/* ------------------------- ابزار عمومی ------------------------- */
function showErr(msg){ const vis=id=>{ const e=document.getElementById(id); return e && !e.hidden; }, pre = vis("cvApp") ? "cv" : vis("dsApp") ? "ds" : "";
  const s=document.getElementById(pre?pre+"StText":"stText"); if(s){ document.getElementById(pre?pre+"Status":"status").hidden=false; s.textContent="خطا: "+msg; } }
window.addEventListener("error", e=>showErr(e.message||e));
window.addEventListener("unhandledrejection", e=>showErr((e.reason&&e.reason.message)||e.reason));
const $ = id => document.getElementById(id);
const FA = s => LANG==="en" ? String(s) : String(s).replace(/[0-9]/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]).replace(/\./g, "٫");
const fmt = (v, d=1) => FA((+v).toFixed(d).replace(/\.0+$/, ""));
const tick = () => new Promise(r => setTimeout(r, 0));
const store = {
  get(k, d){ try{ const v = localStorage.getItem("mmap."+k); return v===null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem("mmap."+k, JSON.stringify(v)); }catch(e){} }
};
// یافتن قالب یادگرفته با اثر انگشت نوار رنگ؛ اگر دقیقاً نبود، نزدیک‌ترین (اختلاف روشنایی اسکرین‌شات یا یک رنگ کم/زیاد)
function fpParse(f){ const m=/^(\d+)x(\d+):(\d+):(.*)$/.exec(f||""); if(!m) return null; return {W:+m[1], H:+m[2], n:+m[3], c:m[4].split("|").map(x=>x.split(".").map(Number))}; }
function fpSim(fa, fb){ const A=fpParse(fa), B=fpParse(fb); if(!A||!B||A.W!==B.W||A.H!==B.H||A.n!==B.n) return 0; let ok=0; for(let j=0;j<A.n;j++){ const a=A.c[j], b=B.c[j]; if(a&&b&&a.every((v,q)=>Math.abs(v-b[q])<=1)) ok++; } return ok/A.n; }
// نقشه‌هایی که اعداد نوارشان خوانده نشده، از نقشهٔ هم‌قالبِ همان فهرست که اعدادش معلوم است پر می‌شوند
function shareEdges(list){ let n=0; for(const m of list){ if(m.bad || m.v || !m.prof || m.sig) continue;
    const o=list.find(q=>q!==m && q.v && q.edgesTxt && q.prof && !q.sig && fpSim(q.prof.fp, m.prof.fp)>=0.9);
    if(o && !cvSetEdges(m, o.edgesTxt)){ m.note=""; m.edgeSrc="از نقشهٔ هم‌قالب "+o.file.name; if(m.type==="w_custom"||m.type==="custom") m.type=o.type; n++; } } return n; }
function learnedFP(prefix, fp){
  const ex=store.get(prefix+fp, null); if(ex) return ex;
  if(!fpParse(fp)) return null; let best=null, bs=0;
  try{ for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); if(!k || !k.startsWith("mmap."+prefix)) continue;
      const sc=fpSim(fp, k.slice(5+prefix.length)); if(sc>=0.9 && sc>bs){ bs=sc; best=k.slice(5); } } }catch(e){}
  return best ? store.get(best, null) : null;
}
function g2j(gy, gm, gd){
  const gdm=[0,31,59,90,120,151,181,212,243,273,304,334];
  let jy = gy<=1600 ? 0 : 979; gy -= gy<=1600 ? 621 : 1600;
  const gy2 = gm>2 ? gy+1 : gy;
  let days = 365*gy + Math.floor((gy2+3)/4) - Math.floor((gy2+99)/100) + Math.floor((gy2+399)/400) - 80 + gd + gdm[gm-1];
  jy += 33*Math.floor(days/12053); days %= 12053;
  jy += 4*Math.floor(days/1461); days %= 1461;
  if(days>365){ jy += Math.floor((days-1)/365); days = (days-1)%365; }
  const jm = days<186 ? 1+Math.floor(days/31) : 7+Math.floor((days-186)/30);
  const jd = 1 + (days<186 ? days%31 : (days-186)%30);
  return [jy, jm, jd];
}
const MONTHS = ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
const WDAYS = ["یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"];
function faDate(str, withTime){
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(str||""); if(!m) return "";
  const [jy,jm,jd] = g2j(+m[1], +m[2], +m[3]);
  const wd = new Date(Date.UTC(+m[1], +m[2]-1, +m[3])).getUTCDay();
  if(LANG==="en") return `${["Sun","Mon","Tue","Wed","Thu","Fri","Sat"][wd]} ${+m[3]} ${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][+m[2]-1]} ${m[1]}` + (withTime && m[4] ? `, ${m[4]}:${m[5]}` : "");
  return `${WDAYS[wd]} ${FA(jd)} ${MONTHS[jm-1]} ${FA(jy)}` + (withTime && m[4] ? `، ساعت ${FA(m[4]+":"+m[5])}` : "");
}

/* ------------------------- رقومی‌سازی ------------------------- */
// پالت خودِ هر تصویر از نوار رنگش (سایه‌ها بین تصاویر چند واحد فرق دارند)
function ownPalette(d){
  if(P.custom){
    const cols=P.segCenters.map(([x,y])=>{ const i=(y*P.W+x)*4; return [d[i],d[i+1],d[i+2]]; });
    const pal=(P.bgSep?[P.bg]:[]).concat(cols);
    for(let c=0;c<NC;c++) if(cdist(pal[c],PAL[c])>30) return PAL;
    return pal;
  }
  const cols=[]; let prev=-1;
  for(let x=P.barX0;x<=P.barX1;x++){ const i=(P.barY*P.W+x)*4, k=(d[i]<<16)|(d[i+1]<<8)|d[i+2]; if(k!==prev){ cols.push([d[i],d[i+1],d[i+2]]); prev=k; } }
  if(cols.length!==NC-P.barStart) return PAL;
  const pal = PAL.slice(0, P.barStart).concat(cols);
  for(let c=0;c<NC;c++){ const a=pal[c], b=PAL[c]; if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2])>15) return PAL; }
  return pal;
}
function classify(d, cap, rects){
  const cls = new Int8Array(N), bm = P.baseMask, pal = ownPalette(d), tol = (P.tol||6)+1;
  const key = new Map(pal.map((c,i)=>[(c[0]<<16)|(c[1]<<8)|c[2], i]));
  // قالب weathermodels (JPEG): خاکستری خنثی فقط با خانه‌های خنثی (خاکستری/سفید) جور می‌شود، نه با صورتی/یاسی روشن
  const ng = !!(P.T && P.T.wm), neu = pal.map(c=>Math.max(c[0],c[1],c[2])-Math.min(c[0],c[1],c[2])<=10), weak = ng ? new Uint8Array(N) : null, wkey = ng ? new Map() : null;
  // ترتیب کانال‌ها (فام): وقتی اختلاف دو کانال خانهٔ پالت دست‌کم ۱۲ است، پیکسل هم باید همان ترتیب را داشته باشد
  const psat = pal.map(c=>Math.max(c[0],c[1],c[2])-Math.min(c[0],c[1],c[2]));
  const hueOk = (k,r,g,b)=>{ const p=pal[k]; const t=(a,c,pa,pc)=> Math.abs(pa-pc)<12 || Math.sign(a-c)===Math.sign(pa-pc);
    if(psat[k]>=20 && Math.max(r,g,b)-Math.min(r,g,b) < 0.6*psat[k]) return false;   // پیکسل کم‌رنگ‌تر از خانهٔ پالت (مخلوط با خاکستری/دریاچه)
    return t(r,g,p[0],p[1]) && t(g,b,p[1],p[2]) && t(r,b,p[0],p[2]); };
  for(let y=0;y<FH;y++){
    const iy = y+P.fy0;
    for(let x=0;x<FW;x++){
      const ix = x+P.fx0, i = (iy*P.W+ix)*4, r=d[i], g=d[i+1], b=d[i+2];
      const kk=(r<<16)|(g<<8)|b; let c = key.get(kk);
      if(c===undefined){
        c = -1; let best = tol;
        const pn = ng && (Math.max(r,g,b)-Math.min(r,g,b)<=20), sat=Math.max(r,g,b)-Math.min(r,g,b), lossy=!ng && tol>=30;
        for(let k=0;k<NC;k++){ if(ng && (pn!==neu[k] || !hueOk(k,r,g,b))) continue;
          if(lossy && ((sat<=18 && psat[k]>24) || (sat>=45 && psat[k]<=16))) continue;   /* JPEG: خاکستری خنثی با رنگ اشباع جور نمی‌شود و برعکس */ const p=pal[k], dd=Math.abs(r-p[0])+Math.abs(g-p[1])+Math.abs(b-p[2]); if(dd<best){best=dd;c=k;} }
        key.set(kk,c); if(ng && c>=0 && best>26) wkey.set(kk,1);   // حافظهٔ رنگ‌های تکراری (اسکرین‌شات‌ها هزاران رنگ نزدیک به هم دارند)
      }
      if(c>=0 && EDGES[c]>=cap) c = -1;                          // خاکستری‌های ۴۰۰+ = خط، نه بارش
      if(bm && bm[y*FW+x]) c = -1;                               // مرزها و خطوط ثابت نقشهٔ پایه
      for(const r of rects) if(ix>=r[0] && ix<r[2] && iy>=r[1] && iy<r[3]){ c = -1; break; }   // لوگو و متن منبع
      cls[y*FW+x] = c; if(ng && c>=0 && wkey.has(kk)) weak[y*FW+x]=1;
    }
  }
  // رنگ‌های دورتر (فشرده‌سازی JPEG): فقط اگر در همسایگی ۵×۵ پیکسل مطمئنی با ردهٔ نزدیک (±۲) باشد پذیرفته می‌شود
  if(ng){ const c0=Int8Array.from(cls);
    for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x; if(!weak[i]) continue; const c=c0[i]; let ok=false;
      for(let dy=-2;dy<=2&&!ok;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if(xx<0||xx>=FW) continue; const j=yy*FW+xx; if(weak[j]) continue; const q=c0[j]; if(q>=0 && Math.abs(q-c)<=2){ ok=true; break; } } }
      if(!ok) cls[i]=-1; }
    // پیوستگی رده‌ها: پیکسل باران‌دار باید در پنجرهٔ ۵×۵ دست‌کم ۵ همسایه با ردهٔ نزدیک (±۲) داشته باشد (پیکسل‌های مخلوط JPEG حذف و از اطراف پر می‌شوند)
    const c1=Int8Array.from(cls);
    for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x, c=c1[i]; if(c<5) continue; let n=0;
      for(let dy=-2;dy<=2&&n<5;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if((!dx&&!dy)||xx<0||xx>=FW) continue; const q=c1[yy*FW+xx]; if(q>=0 && Math.abs(q-c)<=2) n++; } }
      if(n<5) cls[i]=-1; }
    // پرش ناگهانی: ردهٔ بارش که در فاصلهٔ ۲ پیکسلی ردهٔ ۷ پله پایین‌تر دارد (بدون نوارهای میانی) مخلوط JPEG است
    if(P.T.wm.id==="t2m"){ const c2=Int8Array.from(cls);   // دما: پیکسلی که بیشتر همسایه‌هایش ۹+ درجه با آن فاصله دارند، مخلوط است
      for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x, c=c2[i]; if(c<0) continue; let nc=0, nf=0;
        for(let dy=-2;dy<=2;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if((!dx&&!dy)||xx<0||xx>=FW) continue; const q=c2[yy*FW+xx]; if(q<0) continue; const df=Math.abs(q-c); if(df<=3) nc++; else if(df>=9) nf++; } }
        if(nf>nc || (nc<3 && nf>0)) cls[i]=-1; }
      // لکه‌های کوچک (کمتر از ۶۰ پیکسل) که ردهٔ میانه‌شان با حلقهٔ اطراف ۸+ درجه فرق دارد (دریاچه/نوشتهٔ مخلوط) حذف می‌شوند
      const lab=new Int32Array(N).fill(-1), st=[], comp=[], ring=[];
      for(let s0=0;s0<N;s0++){ if(cls[s0]<0||lab[s0]>=0) continue; comp.length=0; ring.length=0; lab[s0]=s0; st.push(s0); let big=false;
        while(st.length){ const q=st.pop(); comp.push(q); if(comp.length>400){ big=true; } const x=q%FW, y=(q/FW)|0, c=cls[q];
          for(let dy=-1;dy<=1;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-1;dx<=1;dx++){ const xx=x+dx; if(xx<0||xx>=FW) continue; const j=yy*FW+xx, cj=cls[j]; if(cj<0||lab[j]===s0) continue;
            if(Math.abs(cj-c)<=2){ if(lab[j]<0){ lab[j]=s0; st.push(j); } } else ring.push(cj); } } }
        if(big) continue;
        if(ring.length<6) for(const q of comp){ const x=q%FW, y=(q/FW)|0; for(let dy=-8;dy<=8;dy+=2){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-8;dx<=8;dx+=2){ const xx=x+dx; if(xx<0||xx>=FW) continue; const j=yy*FW+xx; if(cls[j]>=0 && lab[j]!==s0) ring.push(cls[j]); } } }
        if(!ring.length){ if(comp.length<30) for(const q of comp) cls[q]=-1; continue; }
        const md=a=>{ const b=a.slice().sort((p,q)=>p-q); return b[b.length>>1]; }, cm=md(comp.map(q=>cls[q])), rm=md(ring);
        if(Math.abs(cm-rm)>=8) for(const q of comp) cls[q]=-1; } }
    if(P.T.wm.id==="precip"){ const c2=Int8Array.from(cls);
      for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x, c=c2[i]; if(c<9) continue; let bad=false;
        for(let dy=-2;dy<=2&&!bad;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if(xx<0||xx>=FW) continue; const q=c2[yy*FW+xx]; if(q>=0 && q<=c-7){ bad=true; break; } } }
        if(bad) cls[i]=-1; } } }
  // برچسب شهرها در همین تصویر (متن سفید با هالهٔ خاکستری): حتی اگر در نقشه‌های دیگر جای برچسب فرق کند یا ماسک ثابت آن را نگیرد،
  // جعبهٔ دور متن سفید از داده کنار گذاشته می‌شود؛ وگرنه هالهٔ خاکستری با رنگ‌های ۲۰۰+ پالت اشتباه گرفته شده و شش‌ضلعی خاکستری/صورتی می‌سازد
  labelMaskOwn(d, pal, cls);
  if(ng){ try{ wmTextMask(d, cls); }catch(e){ console.warn(e); } }
  // نوار نیمه‌شفاف بالای بعضی نقشه‌ها (مثلاً ECMWF): سطرهایی که بیشترشان رنگ داده نیستند
  if(P.topStrip) for(let y=0;y<40;y++){
    let ok=0; for(let x=0;x<FW;x++) if(cls[y*FW+x]>=0) ok++;
    if(ok < FW*0.5) for(let x=0;x<FW;x++) cls[y*FW+x] = -1;
  }
  // حذف هالهٔ ضدِ دندانه‌ای کنار خطوط: پیکسل تنهایی که کنار پیکسل نامعتبر است
  const out = Int8Array.from(cls);
  for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){
    const i=y*FW+x, c=cls[i]; if(c<0) continue;
    let bad=0, same=0;
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
      if(!dx&&!dy) continue; const xx=x+dx, yy=y+dy; if(xx<0||yy<0||xx>=FW||yy>=FH) continue;
      const n=cls[yy*FW+xx]; if(n<0) bad++; else if(n===c) same++;
    }
    if(bad && same<2) out[i] = -1;
  }
  // حالت آزاد: رنگ‌های خاکستری خنثی تا ۲ پیکسلی خط یا نوشته، لبهٔ ضدِدندانه‌ای‌اند نه بارش
  if(P.custom){
    const gray = pal.map((c,k)=> k!==P.bgIdx+(P.bgSep?0:0) && Math.abs(c[0]-c[1])<=6 && Math.abs(c[1]-c[2])<=6);
    if(P.bgSep) gray[0]=false; else gray[P.bgIdx]=false;
    const near = new Uint8Array(N);
    for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ if(out[y*FW+x]>=0) continue;
      for(let dy=-2;dy<=2;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if(xx>=0&&xx<FW) near[yy*FW+xx]=1; } } }
    for(let i=0;i<N;i++){ const c=out[i]; if(c>=0 && gray[c] && near[i]) out[i]=-1; }
  }
  // حذف «سیخک»: پیکسلی که در پنجرهٔ ۵×۵ هیچ همسایه‌ای در یکی از سه کلاس پایین‌ترش ندارد، داده نیست (رد خط یا برچسب)
  const sp = Int8Array.from(out);
  for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){
    const i=y*FW+x, c=out[i]; if(c<8) continue;
    let ok=false, n=0;
    for(let dy=-2;dy<=2&&!ok;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue;
      for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if((!dx&&!dy)||xx<0||xx>=FW) continue;
        const q=out[yy*FW+xx]; if(q<0) continue; n++; if(q>=c-3 && q<c){ ok=true; break; } } }
    if(!ok && n>0){ let hasSame=false; for(let dy=-2;dy<=2&&!hasSame;dy++) for(let dx=-2;dx<=2;dx++){ const yy=y+dy, xx=x+dx; if(yy<0||yy>=FH||xx<0||xx>=FW||(!dx&&!dy)) continue; if(out[yy*FW+xx]>c){ hasSame=true; break; } }
      if(!hasSame) sp[i] = -1; }
  }
  return sp;
}
function labelMaskOwn(d, pal, cls){
  const bg=P.bg||[0,0,0]; if(bg[0]>=240&&bg[1]>=240&&bg[2]>=240&&Math.abs(bg[0]-bg[2])<4 && bg[0]>=246) return;   // زمینهٔ سفید: سفید نشانهٔ برچسب نیست
  const isW=(r,g,b)=>{ if(r<244||g<244||b<244||Math.abs(r-g)>8||Math.abs(g-b)>8) return false; if(P.tol>=30 && (r<250||g<250||Math.abs(r-b)>6)) return false; for(const p of pal){ if(Math.abs(r-p[0])+Math.abs(g-p[1])+Math.abs(b-p[2])<=6) return false; }
    const bz=P.bg||pal[0]; if(bz && Math.abs(r-bz[0])+Math.abs(g-bz[1])+Math.abs(b-bz[2])<=(P.tol>=30?26:16)) return false;   // نویز JPEG زمینه، نوشته نیست
    return true; };
  const W=new Uint8Array(N); let any=0;
  for(let y=0;y<FH;y++){ const iy=y+P.fy0; for(let x=0;x<FW;x++){ const i=(iy*P.W+x+P.fx0)*4; if(isW(d[i],d[i+1],d[i+2])){ W[y*FW+x]=1; any++; } } }
  if(!any || any>N*0.08) return;
  // خوشه‌بندی پیکسل‌های سفید با فاصلهٔ تا ۴ پیکسل (حروف یک برچسب به هم وصل می‌شوند)
  const lab=new Int32Array(N).fill(-1), st=[]; let id=0;
  for(let s=0;s<N;s++){ if(!W[s]||lab[s]>=0) continue;
    let mnx=1e9,mxx=-1,mny=1e9,mxy=-1,cnt=0; lab[s]=id; st.push(s);
    while(st.length){ const q=st.pop(), x=q%FW, y=(q/FW)|0; cnt++; if(x<mnx)mnx=x; if(x>mxx)mxx=x; if(y<mny)mny=y; if(y>mxy)mxy=y;
      for(let dy=-4;dy<=4;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-4;dx<=4;dx++){ const xx=x+dx; if(xx<0||xx>=FW) continue; const j=yy*FW+xx; if(W[j]&&lab[j]<0){ lab[j]=id; st.push(j); } } } }
    id++;
    const bw=mxx-mnx+1, bh=mxy-mny+1;
    if(cnt<3 || bh>40 || bw>220) continue;            // ناحیهٔ بزرگ سفید (دریا، برف…) برچسب نیست
    if(cnt/(bw*bh)>0.6 && bw*bh>40) continue;          // لکهٔ توپر روشن (نه حروف نازک)
    const pad=3;
    for(let y=Math.max(0,mny-pad);y<=Math.min(FH-1,mxy+pad);y++) for(let x=Math.max(0,mnx-pad);x<=Math.min(FW-1,mxx+pad);x++) cls[y*FW+x]=-1;
  }
}
/* پرکردن پیکسل‌های مرز/برچسب با میانگین وزنی همسایه‌های معتبر، لایه به لایه از بیرون به داخل
   (همسایهٔ ضلعی وزن ۱، قطری ۱/√۲). مرزها هیچ نقشی در مقدار ندارند. */
function inpaint(v, known0, depth){
  const known = Uint8Array.from(known0), inF = new Uint8Array(N);
  let front = [];
  for(let i=0;i<N;i++){
    if(known[i]) continue;
    const x=i%FW, y=(i/FW)|0;
    if((x>0&&known[i-1])||(x<FW-1&&known[i+1])||(y>0&&known[i-FW])||(y<FH-1&&known[i+FW])||
       (x>0&&y>0&&known[i-FW-1])||(x<FW-1&&y>0&&known[i-FW+1])||(x>0&&y<FH-1&&known[i+FW-1])||(x<FW-1&&y<FH-1&&known[i+FW+1])){ front.push(i); inF[i]=1; }
  }
  if(!front.length && !known.some(k=>k)){ v.fill(0); return v; }
  const D = 0.70710678, vals = []; let layer=0;
  while(front.length){ layer++;
    vals.length = front.length;
    for(let k=0;k<front.length;k++){
      // مقدار غالب همسایه‌ها (نه میانگین): پرکردن هیچ ردهٔ میانی تازه‌ای نمی‌سازد
      const i=front[k], x=i%FW, y=(i/FW)|0; let bv=0, bw=0; const cv_=[], cw_=[];
      for(let dy=-1;dy<=1;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue;
        for(let dx=-1;dx<=1;dx++){ const xx=x+dx; if((!dx&&!dy)||xx<0||xx>=FW) continue;
          const j=yy*FW+xx; if(!known[j]) continue; const ww=(dx&&dy)?D:1, val=v[j]; let q=cv_.indexOf(val); if(q<0){ cv_.push(val); cw_.push(ww); } else cw_[q]+=ww; } }
      for(let q=0;q<cv_.length;q++) if(cw_[q]>bw){ bw=cw_[q]; bv=cv_[q]; }
      vals[k] = bv;
    }
    const next = [];
    for(let k=0;k<front.length;k++){ const i=front[k]; v[i]=vals[k]; known[i]=1; if(depth) depth[i]=Math.min(65535,layer); }
    for(let k=0;k<front.length;k++){
      const i=front[k], x=i%FW, y=(i/FW)|0;
      for(let dy=-1;dy<=1;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue;
        for(let dx=-1;dx<=1;dx++){ const xx=x+dx; if(xx<0||xx>=FW) continue;
          const j=yy*FW+xx; if(!known[j]&&!inF[j]){ inF[j]=1; next.push(j); } } }
    }
    front = next;
  }
  return v;
}
function recognize(d){
  { const j=P && nwpMetaD(d,P.W,P.H); if(j) return j.m; }
  let best=null, bd=1e9;
  if(!P.sigs) return null;
  for(const [name,s] of Object.entries(P.sigs)){
    let dist=0, k=0;
    for(let y=P.sig.y0;y<P.sig.y0+P.sig.h;y++) for(let x=P.sig.x0;x<P.sig.x0+P.sig.w;x++){
      const i=(y*P.W+x)*4, L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];
      if((L<128?"1":"0")!==s[k++]) dist++;
    }
    if(dist<bd){ bd=dist; best=name; }
  }
  return bd<160 ? best : null;
}
// weather.us دو نوار رنگ دارد: بارش تجمعی چندروزه و بارش ۱ تا ۲۴ ساعته (اعداد متفاوت)
const WU_VARIANTS = {
  acc:{pal:WU_PAL, edges:[0,0.1,1,2,3,5,7,10,15,20,25,30,40,50,60,70,80,90,100,125,150,175,200,250,300,400,500,Infinity], name:"بارش تجمعی"},
  h24:{pal:[WU_PAL[0],...WU_PAL.slice(2)], edges:[0,0.1,0.5,1,2,3,5,7,10,15,20,25,30,35,40,45,50,60,70,80,90,100,125,150,200,300,Infinity], name:"بارش ۳ تا ۲۴ ساعته"},
  // بارش ۱ ساعته: همان رنگ‌ها ولی اعداد نوار رنگ متفاوت (۰٫۲، ۴، ۶… ۱۲۵)؛ از روی شکل اعداد زیر نوار تشخیص داده می‌شود
  h1:{pal:[WU_PAL[0],...WU_PAL.slice(2)], edges:[0,0.1,0.2,0.5,1,2,3,4,5,6,7,8,9,10,12,14,16,20,24,30,40,50,60,80,100,125,Infinity], name:"بارش ۱ ساعته"}
};
const WU_HOUR_REF={"1": [22, 16, "0001110000011000000000011111000011100000000011111100001110000000001111110000111000000000001111000011101111000000011100001111111111000001110000111111111110000111000011110001111000011100001110000011110001110000111000001111000111000011100000011100011100001110000001110001110000111000000111000111000011100000011100011100001110000001110001110000111000000111"], "3": [30, 16, "000011111100000000011000000000001111111111000000111000000000011111111111100000111000000000001100000011110000111000000000000000000001110000111011110000000000000011110000111111111100000000011111100000111111111110000000011111100000111100011110000000011111110000111000001111000000000001110000111000001111000000000000111000111000000111011000000000111000111000000111111110000011111000111000000111111111111111110000111000000111011111111111100000111000000111000011111110000000111000000111"], "6": [30, 16, "000000111111000000011000000000000011111111000000111000000000000111111111000000111000000000001111100000000000111000000000011110000000000000111011110000111100000000000000111111111100111111111110000000111111111110111111111111100000111100011110111111111111110000111000001111111100000011111000111000001111111000000001111000111000000111111000000001111000111000000111111100000011110000111000000111011111111111110000111000000111001111111111100000111000000111000011111110000000111000000111"], "24": [49, 16, "0000011111100000000000000000111100000011000000000001111111111100000000000000111110000011100000000011111111111111000000000000111111000001110000000001111100000111110000000000111111100000111000000000011000000000111000000000111101110000011101111000000000000000111100000000111100111000001111111111000000000000111100000000111100011100000111111111110000000001111110000001111100001110000011110001111000000011111100000001111100000111000001110000011110000111111100000001111100000011100000111000001111000111110000000000111111111111111100011100000011100111100000000000011111111111111110001110000001110111100000000000001111111111111111000111000000111111111111111111000000000000001110000011100000011111111111111111100000000000000111000001110000001111111111111111110000000000000011100000111000000111"]};
const WU_H1_LAB="00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000003008000180c0000c0780000100000018000001f00000010000003c000000c000001f00000030000001800000208000010e000008100000418000030c000018100001e100000108000078400000c30000061800008618000431e000000000120600009068000481000000c00000090000000800000040000008000000480000004000001200000050000018500000c2c00006040000105000012480000904000008a00000450000102800004940000249000062450003124000000000048380002411000120800000700000024000000200000030000004000000120000002000000480000024000006220000311000018300000c2400004920000243000004440000322000041100001248000092400038922001c4900000000002202000108440004438000004000000900000010000000c0000014000000800000008000001200000090000008880000444000020c000010800001244000090c000011100000c880001c4400008220000250800024288001127000000000088080004202000110d000001000000040000006000000500000068000003c000000200000030000002400000222000010100000850000043c00000910000045000006440000522000049100003c880000e42000090a20004092000000000220200010808000440200000400000020000000400000140000001000000c800000100000012000000900000088800004080000214000010900000444000021400000910000148800001440000ca2000029080002428800102040000000008808000420400011008000010000000800000010000009000000040000022000000400000048000001c000002220000104000008900000424000021100001090000014400009220000051000022880000942000090a200041010000000001202000090100004802000004000000400000004000003e0000001000000880000010000002100000010000008880000410000023f000010900000848000043e000005100003e8800001440000892000044900002248800104040000000004808000240800012088000010000001000000110000001000000440000012000000400000084000002400000222000010800000810000042400004120000201000012440000122000045100001248000112400008922000421100000000012420000922000049b40000040000008000000480000004000001a00000050000002000000120000009000000850000042000002040000105000010480000804000048a0000045000012280000514000024900002245000108480000";
let _wuH1Bits=null;
function wuIsH1(d){
  if(!_wuH1Bits){ _wuH1Bits=new Uint8Array(WU_H1_LAB.length*4); for(let i=0;i<WU_H1_LAB.length;i++){ const v=parseInt(WU_H1_LAB[i],16); for(let b=0;b<4;b++) _wuH1Bits[i*4+b]=(v>>(3-b))&1; } }
  let k=0, diff=0;
  for(let y=690;y<708;y++) for(let x=3;x<757;x++){ const i=(y*760+x)*4, L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]; if((L<128?1:0)!==_wuH1Bits[k++]) diff++; }
  return diff<200;   // اعداد نوار ۱ ساعته با ۲۴ ساعته حدود ۶۵۰ پیکسل فرق دارند
}
// مدت بارش از عنوان weather.us («Precipitation, 6h»): ۱، ۳، ۶ یا ۲۴ ساعت؛ null اگر نامعلوم (مثلاً ۱۲ ساعته یا تجمعی)
function wuHours(m){
  if(!m || m.w!==760 || m.h!==760) return null;
  { const j=nwpMeta(m); if(j) return [1,3,6,24].includes(+j.h) ? +j.h : null; }
  const d=m.data, W=760, Y0=634, Y1=668, dark=(x,y)=>{ const q=(y*W+x)*4; return 0.299*d[q]+0.587*d[q+1]+0.114*d[q+2]<140; };
  const words=[]; let st=-1, pv=-10; for(let x=0;x<500;x++){ let c=false; for(let y=Y0;y<Y1;y++) if(dark(x,y)){ c=true; break; } if(c){ if(st<0) st=x; else if(x-pv>6){ words.push([st,pv]); st=x; } pv=x; } } if(st>=0) words.push([st,pv]);
  if(words.length<2) return null;
  const [x0,x1]=words[1]; let y0=Y1, y1=Y0; for(let y=Y0;y<Y1;y++) for(let x=x0;x<=x1;x++) if(dark(x,y)){ if(y<y0) y0=y; if(y>y1) y1=y; }
  const w=x1-x0+1, h=y1-y0+1; let best=null, bs=1;
  for(const [k,[rw,rh,bits]] of Object.entries(WU_HOUR_REF)){ if(Math.abs(rw-w)>1 || Math.abs(rh-h)>1) continue;
    let diff=0, n=0; for(let y=0;y<rh;y++) for(let x=0;x<rw;x++){ const v=(y<h&&x<w&&dark(x0+x,y0+y))?1:0; if(v!==(bits[y*rw+x]==="1"?1:0)) diff++; n++; }
    const s=diff/n; if(s<bs){ bs=s; best=k; } }
  return bs<0.12 ? +best : null;
}
const WU_GEO = [PROFILES.wu.ax, PROFILES.wu.bx, PROFILES.wu.ay, PROFILES.wu.by];
// زمین‌مرجع زوم‌های weather.us (x = ax + bx·lon ، y = ay + by·lat) — فارس از ۵ شهر، خطای کمتر از ۳ پیکسل
const WU_ROADS_KEY="ایران + نقشهٔ راه‌ها";   // مرزبندی ایران همراه نقشهٔ راه‌ها (فقط با انتخاب کاربر، نه خودکار)
const WU_ZOOM_GEO = {"ایران":WU_GEO, "فارس":[-4387.15, 89.808, 3366.55, -103.991], "فارس (با جزئیات، کهگیلویه و بوشهر)":[-4387.15, 89.808, 3366.55, -103.991]};
WU_ZOOM_GEO[WU_ROADS_KEY]=WU_GEO;
function wuVariantOf(d){
  { const j=nwpMetaD(d,760,760); if(j) return j.wv||null; }
  const W=PROFILES.wu, cols=[]; let prev=-1;
  for(let x=W.barX0;x<=W.barX1;x++){ const i=(W.barY*W.W+x)*4, k=(d[i]<<16)|(d[i+1]<<8)|d[i+2]; if(k!==prev){ cols.push([d[i],d[i+1],d[i+2]]); prev=k; } }
  for(const [key,v] of Object.entries(WU_VARIANTS)){ if(cols.length!==v.pal.length-W.barStart) continue;
    if(cols.every((c,j)=>{ const p=v.pal[j+W.barStart]; return Math.abs(c[0]-p[0])+Math.abs(c[1]-p[1])+Math.abs(c[2]-p[2])<=15; })) return key==="h24" && wuIsH1(d) ? "h1" : key; }
  // JPEG: نمونه‌برداری هندسی از وسط خانه‌ها
  for(const key of ["acc","h24"]){ const v=WU_VARIANTS[key]; if(barMatchGeo(d, W, v.pal, W.barStart, 46)) return key==="h24" && wuIsH1(d) ? "h1" : key; }
  return null;
}

// WeatherBELL: نقشهٔ برف تجمعی (سانتی‌متر، نسبت ۱۰:۱) با نوار رنگ ۰٫۲ تا ۱۲۰ و ۵۸ خانه (دو خانه میان هر دو عدد)
const WB_SNOW_PAL=[[243,247,255],[222,222,222],[152,152,152],[110,110,110],[80,80,80],[151,212,250],[119,185,248],[81,165,246],[63,150,244],[42,130,238],[30,109,234],[19,100,209],[10,92,193],[65,0,147],[79,0,142],[92,2,141],[103,4,137],[134,3,141],[160,4,134],[202,3,129],[244,3,123],[244,20,135],[245,60,158],[252,95,177],[253,109,184],[249,133,197],[244,142,200],[239,148,202],[232,158,206],[217,175,215],[208,181,217],[195,197,223],[179,217,232],[171,228,240],[160,239,243],[150,250,247],[150,242,242],[128,217,215],[115,186,198],[123,185,200],[127,182,205],[134,179,210],[138,178,211],[140,175,212],[146,172,214],[150,170,219],[150,169,219],[157,164,222],[163,161,223],[165,160,224],[171,157,231],[172,157,233],[183,149,235],[183,149,236],[186,146,238],[187,146,236],[198,142,242],[198,143,243],[211,133,246]];
const WB_SNOW_EDGES=(()=>{ const e=[0,0.2,1.35]; let v=2.5; while(v<25){ e.push(v, v+1.25); v+=2.5; } while(v<120){ e.push(v, v+2.5); v+=5; } e.push(120); return e; })();
const WB_VARIANTS={
  precip:{pal:null, edges:null, barX0:39, barX1:698, tol:undefined, name:"بارش"},
  snow:{pal:WB_SNOW_PAL, edges:WB_SNOW_EDGES, barX0:34, barX1:700, tol:42, name:"برف تجمعی (سانتی‌متر)"}
};
function wbVariantOf(d){
  // میانگین رنگ ۸ خانهٔ اول نوار برف (خاکستری‌ها و آبی‌های روشن) — مقاوم در برابر JPEG
  const W=984, w=(700-34+1)/58; let s=0;
  for(let k=0;k<12;k++){ const cx=Math.round(34+(k+0.5)*w); let r=0,g=0,b=0,n=0;
    for(let y=783;y<790;y++) for(let x=cx-2;x<=cx+2;x++){ const i=(y*W+x)*4; r+=d[i]; g+=d[i+1]; b+=d[i+2]; n++; }
    const p=WB_SNOW_PAL[k+1]; s+=Math.abs(r/n-p[0])+Math.abs(g/n-p[1])+Math.abs(b/n-p[2]); }
  return s/12<=24 ? "snow" : null;
}
async function setWbVariant(key){
  const W=PROFILES.wb, v=WB_VARIANTS[key]; if(!v || (W.variant||"precip")===key) return false;
  if(!WB_VARIANTS.precip.pal){ WB_VARIANTS.precip.pal=W.pal; WB_VARIANTS.precip.edges=W.edges; }
  W.variant=key; W.pal=v.pal||WB_VARIANTS.precip.pal; W.edges=v.edges||WB_VARIANTS.precip.edges; W.barX0=v.barX0; W.barX1=v.barX1; W.tol=v.tol;
  if(P===W) await useProfile("wb"); return true;
}
async function setWuVariant(key){
  const W=PROFILES.wu, v=WU_VARIANTS[key]; if(!v || (W.variant||"acc")===key) return false;
  W.variant=key; W.pal=v.pal; W.edges=v.edges; if(P===W) await useProfile("wu"); return true;
}
// رنگ وسط هر خانهٔ نوار (میانهٔ پنجرهٔ ۵×۵) — مقاوم در برابر JPEG و اسکرین‌شات
function barCellsGeo(d, Pr, n){
  const w=(Pr.barX1-Pr.barX0+1)/n, out=[];
  for(let k=0;k<n;k++){ const cx=Math.round(Pr.barX0+(k+0.5)*w), R=[],G=[],B=[];
    for(let y=Pr.barY-2;y<=Pr.barY+2;y++) for(let x=cx-Math.min(2,Math.floor(w/3));x<=cx+Math.min(2,Math.floor(w/3));x++){ const i=(y*Pr.W+x)*4; R.push(d[i]); G.push(d[i+1]); B.push(d[i+2]); }
    const md=a=>a.sort((p,q)=>p-q)[a.length>>1]; out.push([md(R),md(G),md(B)]); }
  return out;
}
function barMatchGeo(d, Pr, pal, start, tol=40){
  const n=pal.length-start, cells=barCellsGeo(d,Pr,n); let bad=0, sum=0;
  cells.forEach((c,k)=>{ const p=pal[k+start], e=Math.abs(c[0]-p[0])+Math.abs(c[1]-p[1])+Math.abs(c[2]-p[2]); sum+=e; if(e>tol) bad++; });
  return bad<=Math.max(1,Math.round(n*0.05)) && sum/n<=18;
}
function checkPalette(d){
  if(P.custom) return true;
  if(checkPaletteExact(d)) return true;
  return barMatchGeo(d, P, PAL, P.barStart);
}
function checkPaletteExact(d){
  let prev=-1, idx=0, bad=0;
  for(let x=P.barX0;x<=P.barX1;x++){
    const i=(P.barY*P.W+x)*4, k=(d[i]<<16)|(d[i+1]<<8)|d[i+2];
    if(k!==prev){
      const p=PAL[P.barStart+idx];
      if(!p || Math.abs(d[i]-p[0])+Math.abs(d[i+1]-p[1])+Math.abs(d[i+2]-p[2])>15) bad++;
      idx++; prev=k;
    }
  }
  return bad===0 && idx===NC-P.barStart;
}
// پیکسل‌هایی که بیش از این فاصله (پیکسل) از دادهٔ واقعی همان مدل پر شده‌اند «حدسی»‌اند و در میانگین/بیشینه/کمینه شرکت نمی‌کنند
const FAR_PX = 8;
function digitize(m, cap){
  let cls = classify(m.data, cap, m.rects);
  // تصویر فشرده‌شده (JPEG، اسکرین‌شات گوشی، تغییر اندازه): رنگ‌ها کمی جابه‌جا شده‌اند و بیشتر پیکسل‌ها نامعتبر می‌شوند؛
  // آن‌وقت چند پیکسل اتفاقی کل ناحیه را با رنگ خودشان پر می‌کنند (شش‌ضلعی خاکستری/صورتی). دوباره با رواداری بیشتر رقومی می‌شود.
  const bm=P.baseMask; let free=0, ok=0;
  for(let i=0;i<N;i++){ if(bm&&bm[i]) continue; free++; if(cls[i]>=0) ok++; }
  m.lossy=false;
  if(free && ok/free<0.85){ const t0=P.tol; try{ P.tol=Math.max(t0||6, 34); const c2=classify(m.data, cap, m.rects); let ok2=0; for(let i=0;i<N;i++) if((!bm||!bm[i]) && c2[i]>=0) ok2++; if(ok2>ok*1.1){ cls=c2; m.lossy=true; } } finally{ P.tol=t0; } }
  // دانه‌های تنها: پیکسل معتبری که در پنجرهٔ ۵×۵ کمتر از ۴ همسایهٔ معتبر دارد، بذر پرکردن نمی‌شود
  { const sp=[]; for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x; if(cls[i]<0) continue; let n=0;
      for(let dy=-2;dy<=2&&n<4;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if((dx||dy)&&xx>=0&&xx<FW&&cls[yy*FW+xx]>=0) n++; } }
      if(n<4) sp.push(i); } for(const i of sp) cls[i]=-1; }
  const mm = new Float32Array(N), valid = new Uint8Array(N);
  let nv=0;
  for(let i=0;i<N;i++) if(cls[i]>=0){ mm[i]=REP[cls[i]]; valid[i]=1; nv++; }
  const depth=new Uint16Array(N); inpaint(mm, valid, depth);
  const far=new Uint8Array(N); let nf=0; for(let i=0;i<N;i++) if(depth[i]>FAR_PX){ far[i]=1; nf++; }
  m.far = nf ? far : null;
  m.cls = cls; m.valid = valid; m.mm = mm; m.validFrac = nv/N; m.hit = {};
  let mx=0; for(let i=0;i<N;i++) if(mm[i]>mx) mx=mm[i]; m.max = mx;
}
// سهم «بارش ≥ آستانه» در هر پیکسل: کلاس کامل بالاتر = ۱، پایین‌تر = ۰، کلاسی که آستانه وسطش است = سهم خطی
function hitField(m, thr){
  if(m.hit[thr]) return m.hit[thr];
  const F = PAL.map((_,c)=>{ const lo=EDGES[c], hi=(isFinite(EDGES[c+1]) ? EDGES[c+1] : lo*1.25);
    // کلاس اول (زمینهٔ بی‌بارش / زیر کمترین عدد نوار) بارش ندارد؛ پخش یکنواخت در آن غلط است
    if(c===0) return lo>=thr ? 1 : 0;
    return lo>=thr ? 1 : (hi<=thr ? 0 : (hi-thr)/(hi-lo)); });
  const h = new Float32Array(N);
  for(let i=0;i<N;i++) if(m.valid[i]) h[i]=F[m.cls[i]];
  inpaint(h, m.valid);
  return (m.hit[thr] = h);
}

