/* ===== آیکن پدیده‌های هشدار (روی نقشهٔ کلی، راهنما و کنار نام هر پدیده) =====
   رنگ آیکن = سطح هشدار همان پدیده (زرد/نارنجی/قرمز)، با حاشیهٔ سیاه برای دیده شدن روی زمینهٔ هم‌رنگ؛ کمی شفاف. */
const HZ_KIND={w_ts:"ts",w_ltg:"ts",w_tsp:"ts",w_cape:"ts",w_rate:"rain",w_rain:"rain",w_rainwx:"rain",w_flood:"flood",w_floodp:"flood",w_flash:"flood",w_wlog:"flood",
  w_gust:"wind",w_wind:"wind",w_snow:"snow",w_snowmm:"snow",w_snowwx:"snow",w_ice:"cold",w_frost:"cold",w_gfrost:"cold",w_tmin:"cold",w_wchill:"cold",
  w_heat:"heat",w_tmax:"heat",w_hi:"heat",w_t2m:"heat",w_td:"heat",w_rh:"heat",w_tanom:"heat",w_hail:"hail",w_fog:"fog",w_vis:"fog",w_dust:"dust",w_uv:"sun",w_wave:"wave",w_sigwx:"gen",w_custom:"gen",w_tsoil:"cold"};
const HZ_LVCOL=["#ffffff","#ffd21f","#ff8c00","#e01b1b"];
const HZ_NAME={ts:["توفان تندری","Thunderstorm"],rain:["باران شدید","Heavy rain"],flood:["سیل و آب‌گرفتگی","Flood"],wind:["باد شدید","Strong wind"],snow:["برف","Snow"],cold:["سرما و یخبندان","Cold / frost"],
  heat:["گرما","Heat"],hail:["تگرگ","Hail"],fog:["مه","Fog"],dust:["گردوخاک","Dust"],sun:["پرتو فرابنفش","UV"],wave:["امواج","Waves"],gen:["پدیدهٔ دیگر","Other"]};
const _hzCloud="M6.5 15.5h11a3.6 3.6 0 0 0 .4-7.17A5.4 5.4 0 0 0 7.4 7.1 3.9 3.9 0 0 0 6.5 15.5z";
function hzGlyph(ctx, kind, fill){
  const P2=s=>new Path2D(s), F=(p)=>{ ctx.fillStyle=fill; ctx.fill(p); ctx.lineWidth=1.3; ctx.strokeStyle="#000"; ctx.stroke(p); };
  const L=(pts,w=2.6)=>{ ctx.lineCap="round"; ctx.lineJoin="round"; ctx.beginPath(); pts.forEach((q,i)=>i?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1])); ctx.strokeStyle="#000"; ctx.lineWidth=w+2.2; ctx.stroke(); ctx.strokeStyle=fill; ctx.lineWidth=w; ctx.stroke(); };
  const C=(x,y,r)=>{ const p=new Path2D(); p.arc(x,y,r,0,2*Math.PI); F(p); };
  switch(kind){
    case "ts": F(P2("M5.5 13h10a3.4 3.4 0 0 0 .4-6.77A5 5 0 0 0 6.3 5.2 3.6 3.6 0 0 0 5.5 13z")); F(P2("M12.6 11.5 8.6 17.4h3l-1.2 5 5-6.6h-3.1l1.8-4.3z")); break;
    case "rain": F(P2("M6.5 12.5h11a3.6 3.6 0 0 0 .4-7.17A5.4 5.4 0 0 0 7.4 4.1 3.9 3.9 0 0 0 6.5 12.5z")); for(const [x,y] of [[8,15.5],[12,17],[16,15.5],[10,20.5],[14,21]]) L([[x+0.8,y-1.3],[x-0.6,y+1.3]],1.8); break;
    case "snow": F(P2("M6.5 12.5h11a3.6 3.6 0 0 0 .4-7.17A5.4 5.4 0 0 0 7.4 4.1 3.9 3.9 0 0 0 6.5 12.5z")); for(const [x,y] of [[8,16],[12,18],[16,16],[10,21],[14,21.5]]) C(x,y,1.35); break;
    case "hail": F(P2("M6.5 12.5h11a3.6 3.6 0 0 0 .4-7.17A5.4 5.4 0 0 0 7.4 4.1 3.9 3.9 0 0 0 6.5 12.5z")); for(const [x,y] of [[8.5,16.5],[13,17.5],[10.5,21],[15.5,21]]) C(x,y,1.9); break;
    case "wind": L([[3,8],[14,8],[16.5,7],[16.6,4.6],[14.6,4],[13.4,5.2]]); L([[3,12.5],[19,12.5],[21.3,13.6],[21.2,16],[19,16.6],[17.8,15.4]]); L([[3,17],[11,17],[13,18],[13,20],[11,20.4]]); break;
    case "flood": L([[2.5,10],[5.5,8],[8.5,10],[11.5,8],[14.5,10],[17.5,8],[20.5,10]]); L([[2.5,15],[5.5,13],[8.5,15],[11.5,13],[14.5,15],[17.5,13],[20.5,15]]); L([[2.5,20],[5.5,18],[8.5,20],[11.5,18],[14.5,20],[17.5,18],[20.5,20]]); break;
    case "wave": L([[2,14],[5,10],[8,9],[10,11],[9,13],[7,12.5]]); L([[2,19],[6,17],[10,19],[14,17],[18,19],[22,17]]); L([[11,13],[14,9],[17,8],[19,10],[18,12],[16,11.5]]); break;
    case "fog": for(const [y,a,b] of [[7,4,20],[11.5,2.5,17],[16,6,21.5],[20.5,3.5,18]]) L([[a,y],[b,y]],2.4); break;
    case "dust": L([[3,9],[13,9],[16,7.5],[16,5],[14,4.4]]); L([[3,14],[18,14],[21,15.5],[20.6,18],[18.5,18.4]]); for(const [x,y] of [[6,19.5],[10,20.5],[14,21.5],[18.5,10.5],[8,4.8]]) C(x,y,1.2); break;
    case "heat": { F(P2("M10 3.5a2.5 2.5 0 0 1 5 0v10.2a4.6 4.6 0 1 1-5 0z")); ctx.fillStyle="#000"; ctx.globalAlpha=0.55; ctx.fillRect(11.6,7,1.8,9); ctx.globalAlpha=1; for(const [x1,y1,x2,y2] of [[18,6,21,5],[18,10,21.5,10],[18,14,21,15]]) L([[x1,y1],[x2,y2]],1.6); break; }
    case "cold": { const R=8.5, c=12; for(let k=0;k<3;k++){ const a=k*Math.PI/3, dx=Math.cos(a)*R, dy=Math.sin(a)*R; L([[c-dx,c-dy],[c+dx,c+dy]],2.2); }
      for(let k=0;k<6;k++){ const a=k*Math.PI/3, x=c+Math.cos(a)*R*0.62, y=c+Math.sin(a)*R*0.62, b1=a+0.9, b2=a-0.9; L([[x+Math.cos(b1)*2.6,y+Math.sin(b1)*2.6],[x,y],[x+Math.cos(b2)*2.6,y+Math.sin(b2)*2.6]],1.5); } break; }
    case "sun": C(12,12,4.6); for(let k=0;k<8;k++){ const a=k*Math.PI/4; L([[12+Math.cos(a)*7,12+Math.sin(a)*7],[12+Math.cos(a)*10,12+Math.sin(a)*10]],1.8); } break;
    default: F(P2("M12 2.5 22.5 20.5h-21z")); ctx.fillStyle="#000"; ctx.fillRect(11,8.5,2,6.5); ctx.fillRect(11,16.5,2,2);
  }
}
function hzDraw(ctx, kind, L, x, y, size, alpha=0.92){ ctx.save(); ctx.globalAlpha=alpha; ctx.translate(x,y); ctx.scale(size/24,size/24); hzGlyph(ctx, kind, HZ_LVCOL[L]||"#ddd"); ctx.restore(); }
const _hzURL=new Map();
function hzIconURL(type, L=1, px=40){ const k=(HZ_KIND[type]||type)+"|"+L+"|"+px; if(_hzURL.has(k)) return _hzURL.get(k);
  const c=document.createElement("canvas"); c.width=c.height=px; const x=c.getContext("2d"); hzDraw(x, HZ_KIND[type]||type, L, px*0.04, px*0.04, px*0.92, 1); const u=c.toDataURL("image/png"); _hzURL.set(k,u); return u; }
// جای آیکن‌ها: هر ناحیهٔ پیوستهٔ هشدار (بزرگ‌تر از ۰٫۳٪ کادر) یک دسته آیکن در «دورترین نقطه از لبه»؛ آیکن پدیده‌هایی که در آن ناحیه هشدار دارند، به ترتیب سطح
function hzPlace(per, Lv, sea){
  const minA=Math.max(60, 0.003*N), out=[];
  // فاصله تا لبه (چبیشف، دو گذر) برای ماسک داده‌شده
  const dist=(M)=>{ const D=new Uint16Array(N); for(let i=0;i<N;i++) D[i]=M[i]?60000:0;
    for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x; if(!D[i]) continue; let v=D[i]; v = x>0?Math.min(v,D[i-1]+1):1; if(y>0) v=Math.min(v,D[i-FW]+1); else v=1; D[i]=v; }
    for(let y=FH-1;y>=0;y--) for(let x=FW-1;x>=0;x--){ const i=y*FW+x; if(!D[i]) continue; let v=D[i]; v = x<FW-1?Math.min(v,D[i+1]+1):1; if(y<FH-1) v=Math.min(v,D[i+FW]+1); else v=1; D[i]=v; } return D; };
  // نواحی هر سطح (≥قرمز، ≥نارنجی، ≥زرد): هر ناحیهٔ جدا یک دسته آیکن در دورترین نقطه از لبه؛ دسته‌ها دست‌کم ۷۰ پیکسل از هم فاصله دارند
  for(const th of [3,2,1]){
    const M=new Uint8Array(N); for(let i=0;i<N;i++) M[i]=Lv[i]>=th?1:0; const D=dist(M), lab=new Int32Array(N).fill(-1), comps=[]; let id=0;
    for(let s=0;s<N;s++){ if(!M[s]||lab[s]>=0) continue; const st=[s]; lab[s]=id; const px=[];
      while(st.length){ const p=st.pop(); px.push(p); const x=p%FW, y=(p/FW)|0; for(const q of [x>0?p-1:-1, x<FW-1?p+1:-1, y>0?p-FW:-1, y<FH-1?p+FW:-1]) if(q>=0 && M[q] && lab[q]<0){ lab[q]=id; st.push(q); } }
      comps.push(px); id++; }
    comps.sort((a,b)=>b.length-a.length);
    for(const px of comps){ if(px.length<minA) continue; let best=px[0]; for(const p of px) if(D[p]>D[best]) best=p;
      const bx=best%FW, by=(best/FW)|0; if(out.some(o=>Math.hypot(o.x-bx,o.y-by)<70)) continue;
      const hz=[]; for(const p of per){ let mx=0; for(const q of px){ const l=p.L[q]; if(l>mx) mx=l; if(mx===3) break; } if(mx>=th || (th===1&&mx)) hz.push({type:p.f.m.type, L:mx}); }
      const g=new Map(); for(const h of hz){ const k=HZ_KIND[h.type]||"gen"; if(!g.has(k)||g.get(k).L<h.L) g.set(k,{kind:k, L:h.L, type:h.type}); }
      const list=[...g.values()].sort((a,b)=>b.L-a.L || WN_PRI.indexOf(a.type)-WN_PRI.indexOf(b.type)).slice(0,4);
      if(list.length) out.push({x:bx, y:by, list, r:D[best]});
      if(out.length>=16) break; } }
  return out;
}
// رسم روی بوم خروجی (هر مقیاس): آیکن‌ها روی نواحی + راهنمای آیکن‌ها پایین کادر (بالای نوار رنگ)
function hzRender(cv, icons, legend){
  if(!icons || !P) return; const sc=cv.width/P.W, ctx=cv.getContext("2d"); ctx.save(); ctx.scale(sc,sc);
  ctx.beginPath(); ctx.rect(P.fx0,P.fy0,FW,FH); ctx.clip();
  const sz=Math.max(14, Math.min(22, FW/36));
  for(const g of icons){ const n=g.list.length, s=Math.min(sz, Math.max(11, g.r*1.6)), w=n*s+(n-1)*2, x0=P.fx0+g.x-w/2, y0=P.fy0+g.y-s/2;
    g.list.forEach((h,k)=>hzDraw(ctx, h.kind, h.L, x0+k*(s+2), y0, s)); }
  ctx.restore(); ctx.save(); ctx.scale(sc,sc);
  if(legend && legend.length){ const en=typeof LANG!=="undefined"&&LANG==="en", fs=11, s=15;
    ctx.font=`${fs}px ${FT.body}`; const items=legend.map(k=>({k, t:HZ_NAME[k]?HZ_NAME[k][en?1:0]:k}));
    const iw=it=>s+4+ctx.measureText(it.t).width+10;
    // جا: فاصلهٔ خالی بین کادر و نوار رنگ (بالای نوار)، وگرنه داخل کادر پایین‌چپ (weather.us) یا بالاچپ
    const B=P.bar||null, gap=B&&B.rect ? B.rect[1]-P.fy1 : 0;
    let x, y, maxW;
    if(P.custom && gap>=s+10){ y=P.fy1+Math.round((gap-s)/2); x=P.fx0+4; maxW=FW-8; }
    else if(!P.custom && P.key==="wu"){ y=P.fy1-s-8; x=P.fx0+6; maxW=FW*0.6; }
    else { y=P.fy0+(P.custom&&P.fy0<24?32:8); x=P.fx0+6; maxW=FW*0.55; }
    let w=8; for(const it of items){ if(w+iw(it)>maxW) break; w+=iw(it); }
    ctx.fillStyle="rgba(255,255,255,.88)"; ctx.fillRect(x-4, y-3, w, s+6);
    let cx=x; for(const it of items){ if(cx+iw(it)>x+maxW) break; hzDraw(ctx, it.k, 0, cx, y, s, 1); cx+=s+4; txt(ctx, it.t, cx, y+s-3, `${fs}px ${FT.body}`, {align:"left", dir:en?"ltr":"rtl", color:"#111"}); cx+=ctx.measureText(it.t).width+10; } }
  ctx.restore();
}
