/* ---------- تنظیمات ---------- */
const DS_INPUTS = ["dsSmooth","dsStrength","dsMinF","dsMaxF","dsThr","dsFull","dsEff","dsCap","dsKnots","dsTile","dsTaper","dsSmoothT","dsHour"];
const DS_CHECKS = ["dsMass","dsTiles","dsExpo","dsStamp"];
function dsCfg(){
  const g=id=>parseFloat($(id).value), c=id=>$(id).checked;
  const cfg={smooth:g("dsSmooth"), strength:g("dsStrength"), minF:g("dsMinF"), maxF:g("dsMaxF"), thr:g("dsThr"), full:g("dsFull"),
    eff:g("dsEff"), cap:g("dsCap"), knots:Math.round(g("dsKnots")), tile:g("dsTile"), taper:g("dsTaper"),
    mass:c("dsMass"), tiles:c("dsTiles"), expo:c("dsExpo"), stamp:c("dsStamp"), smoothT:parseFloat(($("dsSmoothT")||{}).value), hour:($("dsHour")||{}).value||"auto", expoKm:10, shrink:0.5, sig:2, minPts:60, minRelief:400};
  const bad=[]; if(!(cfg.minF>0 && cfg.minF<=1)) bad.push("کمترین ضریب باید بین ۰ و ۱ باشد"); if(!(cfg.maxF>=1)) bad.push("بیشترین ضریب باید حداقل ۱ باشد");
  if(!(cfg.full>cfg.thr)) bad.push("«اصلاح کامل از» باید بزرگ‌تر از آستانه باشد"); if(!(cfg.strength>=0 && cfg.strength<=1)) bad.push("شدت اصلاح بین ۰ و ۱");
  if(!(cfg.knots>=5)) bad.push("پیچیدگی GAM حداقل ۵"); if(!(cfg.eff>=1)) bad.push("ضریب رزولوشن مؤثر حداقل ۱");
  if(!(cfg.smooth>=0)) cfg.smooth=0; if(!(cfg.smoothT>=0)) cfg.smoothT=cfg.smooth; if(!(cfg.taper>=0)) cfg.taper=0; if(!(cfg.cap>=1)) cfg.cap=1; if(!(cfg.tile>=1)) cfg.tile=4;
  if(bad.length) throw new Error(bad.join("؛ "));
  return cfg;
}


/* ---------- زمین‌مرجع خودکار: تطبیق خطوط مرز نقشه با مرزهای مرجع ایران و همسایه‌ها ---------- */
// مرجع: لایهٔ مرزهای استانی و کشوری WeatherBELL (زمین‌مرجع دقیق) به صورت نقاط طول و عرض
const IR_PROV = [["کل ایران",53.5,32.5,5],["آذربایجان شرقی",46.5,37.9],["آذربایجان غربی",45.3,37.4],["اردبیل",48.1,38.2],["اصفهان",51.8,32.7],["البرز",50.9,36.0],["ایلام",46.9,33.2],["بوشهر",51.2,28.6],["تهران",51.4,35.6],["چهارمحال و بختیاری",50.8,32.2],["خراسان جنوبی",58.9,33.0],["خراسان رضوی",59.2,35.8],["خراسان شمالی",57.3,37.5],["خوزستان",48.9,31.4],["زنجان",48.5,36.6],["سمنان",54.0,35.3],["سیستان و بلوچستان",60.5,27.8],["فارس",53.0,29.4],["قزوین",49.8,36.1],["قم",50.9,34.6],["کردستان",47.0,35.6],["کرمان",57.1,29.6],["کرمانشاه",46.8,34.4],["کهگیلویه و بویراحمد",50.8,30.7],["گلستان",54.9,37.3],["گیلان",49.6,37.3],["لرستان",48.4,33.5],["مازندران",52.3,36.4],["مرکزی",49.7,34.3],["هرمزگان",56.3,27.2],["همدان",48.6,34.8],["یزد",54.4,31.9]];
const IR_PROV_EN = {"azarbaijan-e-sharqi|east-azerbaijan|tabriz":1,"west-azerbaijan|urmia":2,"ardabil":3,"isfahan|esfahan":4,"alborz|karaj":5,"ilam":6,"bushehr":7,"tehran":8,"chaharmahal|bakhtiari|shahrekord":9,"south-khorasan|birjand":10,"razavi|khorasan|mashhad":11,"north-khorasan|bojnurd":12,"khuzestan|ahvaz":13,"zanjan":14,"semnan":15,"sistan|baluchestan|zahedan":16,"fars|shiraz":17,"qazvin":18,"qom":19,"kurdistan|kordestan|sanandaj":20,"kerman":21,"kermanshah":22,"kohgiluyeh|boyer|yasuj":23,"golestan|gorgan":24,"gilan|rasht":25,"lorestan|khorramabad":26,"mazandaran|sari":27,"markazi|arak":28,"hormozgan|bandar":29,"hamedan|hamadan":30,"yazd":31};
const GR = {G:0.02, LON0:41, LON1:66.5, LAT0:22.5, LAT1:42, ref:null};
// فاصلهٔ اقلیدسی دقیق (Felzenszwalb) با گام sx و sy؛ در صورت نیاز اندیس نزدیک‌ترین پیکسل
function grEDT(feat, W, H, sx, sy, wantIdx){
  const BIG=1e20, n=Math.max(W,H), f=new Float64Array(n), dd=new Float64Array(n), ar=new Int32Array(n), v=new Int32Array(n), z=new Float64Array(n+1);
  const d1=new Float64Array(W*H), a1=wantIdx?new Int32Array(W*H):null, out=new Float32Array(W*H), idx=wantIdx?new Int32Array(W*H):null;
  const dt=(len, s)=>{ let k=0; v[0]=0; z[0]=-Infinity; z[1]=Infinity;
    for(let q=1;q<len;q++){ let p=v[k], x=((f[q]+(s*q)**2)-(f[p]+(s*p)**2))/(2*s*s*(q-p));
      while(x<=z[k]){ k--; p=v[k]; x=((f[q]+(s*q)**2)-(f[p]+(s*p)**2))/(2*s*s*(q-p)); }
      k++; v[k]=q; z[k]=x; z[k+1]=Infinity; }
    k=0; for(let q=0;q<len;q++){ while(z[k+1]<q) k++; dd[q]=(s*(q-v[k]))**2+f[v[k]]; ar[q]=v[k]; } };
  for(let y=0;y<H;y++){ for(let x=0;x<W;x++) f[x]=feat[y*W+x]?0:BIG; dt(W,sx); for(let x=0;x<W;x++){ d1[y*W+x]=dd[x]; if(a1) a1[y*W+x]=ar[x]; } }
  for(let x=0;x<W;x++){ for(let y=0;y<H;y++) f[y]=d1[y*W+x]; dt(H,sy); for(let y=0;y<H;y++){ out[y*W+x]=Math.sqrt(Math.min(dd[y],1e18)); if(idx){ const r=ar[y]; idx[y*W+x]=r*W+a1[r*W+x]; } } }
  return {d:out, idx};
}
async function grRef(){
  if(GR.ref) return GR.ref;
  const W0=PROFILES.wb, im=new Image(); im.src=W0.layers.orig; await im.decode();
  const c=document.createElement("canvas"); c.width=W0.W; c.height=W0.H; const cx=c.getContext("2d",{willReadFrequently:true}); cx.drawImage(im,0,0);
  const a=cx.getImageData(0,0,W0.W,W0.H).data;
  const bad=[[925,80,976,100],[925,283,976,303],[925,485,976,505],[925,686,976,706],[120,35,160,50],[325,35,365,50],[525,35,565,50],[725,35,765,50],[925,35,965,50]];
  const lon=[], lat=[];
  for(let y=W0.fy0+10;y<W0.fy1-9;y++) for(let x=W0.fx0+10;x<W0.fx1-9;x++){ if(!a[(y*W0.W+x)*4+3]) continue; if(bad.some(b=>x>=b[0]&&x<b[2]&&y>=b[1]&&y<b[3])) continue; lon.push((x-W0.ax)/W0.bx); lat.push((y-W0.ay)/W0.by); }
  const nx=Math.round((GR.LON1-GR.LON0)/GR.G)+1, ny=Math.round((GR.LAT1-GR.LAT0)/GR.G)+1, M=new Uint8Array(nx*ny);
  for(let k=0;k<lon.length;k++){ const j=Math.round((lon[k]-GR.LON0)/GR.G), i=Math.round((GR.LAT1-lat[k])/GR.G); M[i*nx+j]=1; }
  const D=grEDT(M,nx,ny,GR.G,GR.G,false).d;
  const I=new Float64Array((nx+1)*(ny+1)); for(let i=0;i<ny;i++){ let row=0; for(let j=0;j<nx;j++){ row+=M[i*nx+j]; I[(i+1)*(nx+1)+j+1]=I[i*(nx+1)+j+1]+row; } }
  GR.ref={lon:Float32Array.from(lon), lat:Float32Array.from(lat), nx, ny, D, I};
  return GR.ref;
}
const grLook=(R,lon,lat)=>{ const j=Math.round((lon-GR.LON0)/GR.G), i=Math.round((GR.LAT1-lat)/GR.G); return (j<0||i<0||j>=R.nx||i>=R.ny) ? 5 : R.D[i*R.nx+j]; };
function grCount(R,lo0,lo1,la0,la1){
  const cl=(v,n)=>v<0?0:v>n?n:v, n1=R.nx+1;
  const j0=cl(Math.floor((lo0-GR.LON0)/GR.G),R.nx), j1=cl(Math.floor((lo1-GR.LON0)/GR.G),R.nx), i0=cl(Math.floor((GR.LAT1-la1)/GR.G),R.ny), i1=cl(Math.floor((GR.LAT1-la0)/GR.G),R.ny);
  return R.I[i1*n1+j1]-R.I[i0*n1+j1]-R.I[i1*n1+j0]+R.I[i0*n1+j0];
}
// پیکسل‌های خطی کادر: رنگی که در پالت نیست و روشن‌تر از حد سفید نیست؛ نسخهٔ دوم بدون خطوط هم‌مقدار
function grLines(maps, prof, pal){
  const [x0,y0,x1,y1]=[prof.fx0,prof.fy0,prof.fx1,prof.fy1], w=x1-x0+1, h=y1-y0+1, n=w*h, tol=(prof.tol||6)+(prof.custom?6:6);
  const cntA=new Uint8Array(n), cntI=new Uint8Array(n), cntD=new Uint8Array(n);
  const use=maps.slice(0,6);
  // رنگ‌های خاکستری خنثی و تیرهٔ پالت (مثلاً ۳۰۰+ میلی‌متر) را بسیاری از سایت‌ها برای مرز استان هم به کار می‌برند
  const grayCls=pal.map(c=>Math.max(...c)-Math.min(...c)<=12 && 0.299*c[0]+0.587*c[1]+0.114*c[2]<200);
  for(const m of use){
    const d=m.data, W=m.w, cls=new Int16Array(n), memo=new Map(), line=new Uint8Array(n);
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){ const i=((y+y0)*W+x+x0)*4, k=(d[i]<<16)|(d[i+1]<<8)|d[i+2]; let c=memo.get(k);
      if(c===undefined){ c=-1; let best=tol+1; for(let q=0;q<pal.length;q++){ const p=pal[q], dd=Math.abs(d[i]-p[0])+Math.abs(d[i+1]-p[1])+Math.abs(d[i+2]-p[2]); if(dd<best){ best=dd; c=q; } }
        if(c<0 && 0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]>=215) c=-2; memo.set(k,c); }
      if(c>=0 && grayCls[c]){ cls[y*w+x]=-1; line[y*w+x]=1; } else { cls[y*w+x]=c; if(c===-1) line[y*w+x]=1; } }
    for(let y=0;y<h;y++) for(let x=0;x<w;x++){ const i=y*w+x; if(!line[i]) continue; cntA[i]++;
      { const q=((y+y0)*W+x+x0)*4; if(0.299*d[q]+0.587*d[q+1]+0.114*d[q+2]<125) cntD[i]++; }
      let mn=999, mx=-1; for(let dy=-2;dy<=2;dy++){ const yy=y+dy; if(yy<0||yy>=h) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if(xx<0||xx>=w) continue; const q=cls[yy*w+xx]; if(q>=0){ if(q<mn) mn=q; if(q>mx) mx=q; } } }
      if(!(mx>mn && mx-mn<=2)) cntI[i]++; }
  }
  const need = use.length>=3 ? Math.ceil(use.length*0.6) : use.length>=2 ? 2 : 1;
  const A=new Uint8Array(n), I=new Uint8Array(n), Dk=new Uint8Array(n); for(let i=0;i<n;i++){ A[i]=cntA[i]>=need?1:0; I[i]=cntI[i]>=need?1:0; Dk[i]=cntD[i]>=need?1:0; }
  // نقشه‌های بزرگ: کوچک‌سازی با OR تا عرض حدود ۱۰۰۰ پیکسل
  const q=Math.max(1,Math.ceil(w/1000)), ws=Math.ceil(w/q), hs=Math.ceil(h/q);
  const down=M=>{ if(q===1) return M; const o=new Uint8Array(ws*hs); for(let y=0;y<h;y++) for(let x=0;x<w;x++) if(M[y*w+x]) o[Math.floor(y/q)*ws+Math.floor(x/q)]=1; return o; };
  // سه برداشت: بدون خطوط هم‌مقدار، همهٔ خطوط، و فقط خطوط تیره (مرز کشور و استان، بدون مرز شهرستان)
  return {variants:[down(I), down(A), down(Dk)], w:ws, h:hs, q, x0, y0};
}
// حذف نوشته و لکه: فقط مؤلفه‌های بلند و کم‌تراکم (مرز و ساحل) می‌مانند
function grClean(M, w, h){
  const lab=new Int32Array(w*h).fill(-1), out=new Uint8Array(w*h), stack=[], minExt=Math.max(20,0.025*w);
  let id=0;
  for(let s=0;s<w*h;s++){ if(!M[s]||lab[s]>=0) continue;
    const comp=[]; stack.push(s); lab[s]=id; let mnx=1e9,mxx=-1,mny=1e9,mxy=-1;
    while(stack.length){ const p=stack.pop(), x=p%w, y=(p/w)|0; comp.push(p); if(x<mnx)mnx=x; if(x>mxx)mxx=x; if(y<mny)mny=y; if(y>mxy)mxy=y;
      for(let dy=-1;dy<=1;dy++){ const yy=y+dy; if(yy<0||yy>=h) continue; for(let dx=-1;dx<=1;dx++){ const xx=x+dx; if(xx<0||xx>=w) continue; const q=yy*w+xx; if(M[q]&&lab[q]<0){ lab[q]=id; stack.push(q); } } } }
    const bw=mxx-mnx+1, bh=mxy-mny+1;
    const keep = Math.max(bw,bh)>=minExt && comp.length/(bw*bh)<0.4 && !((bw>0.6*w&&bh<=4)||(bh>0.6*h&&bw<=4));
    if(keep) for(const p of comp) out[p]=1;
    id++; }
  return out;
}
// نازک‌سازی Zhang–Suen
function grThin(M, w, h){
  const a=Uint8Array.from(M); let changed=true, it=0;
  const P=(x,y)=> (x<0||y<0||x>=w||y>=h)?0:a[y*w+x];
  while(changed && it++<40){ changed=false;
    for(let pass=0;pass<2;pass++){ const del=[];
      for(let y=0;y<h;y++) for(let x=0;x<w;x++){ if(!a[y*w+x]) continue;
        const p2=P(x,y-1),p3=P(x+1,y-1),p4=P(x+1,y),p5=P(x+1,y+1),p6=P(x,y+1),p7=P(x-1,y+1),p8=P(x-1,y),p9=P(x-1,y-1);
        const B=p2+p3+p4+p5+p6+p7+p8+p9; if(B<2||B>6) continue;
        const s=[p2,p3,p4,p5,p6,p7,p8,p9,p2]; let A=0; for(let k=0;k<8;k++) if(!s[k]&&s[k+1]) A++; if(A!==1) continue;
        if(pass===0 ? (p2*p4*p6===0 && p4*p6*p8===0) : (p2*p4*p8===0 && p2*p6*p8===0)) del.push(y*w+x); }
      if(del.length){ changed=true; for(const i of del) a[i]=0; } } }
  return a;
}
function grPrep(M, w, h){
  const sk=grThin(grClean(M,w,h),w,h), xs=[], ys=[];
  for(let i=0;i<w*h;i++) if(sk[i]){ xs.push(i%w); ys.push((i/w)|0); }
  if(xs.length<50) return null;
  const E=grEDT(sk,w,h,1,1,true);
  return {sk, w, h, xs:Int32Array.from(xs), ys:Int32Array.from(ys), Dm:E.d, idx:E.idx};
}
function grProj(R, p, w, h, fn){ for(let k=0;k<R.lon.length;k++){ const x=p[0]+p[1]*R.lon[k], y=p[2]+p[3]*R.lat[k]; if(x>=2&&x<=w-3&&y>=2&&y<=h-3) fn(x,y,k); } }
function grScore(R, S, p, Rr=4){
  let s2=0, n2=0; grProj(R,p,S.w,S.h,(x,y)=>{ s2+=Math.min(S.Dm[Math.round(y)*S.w+Math.round(x)]/Rr,1); n2++; });
  if(n2<30) return 9;
  let s1=0; const st=Math.max(1,Math.floor(S.xs.length/4000)); let n1=0;
  for(let k=0;k<S.xs.length;k+=st){ const d=grLook(R,(S.xs[k]-p[0])/p[1],(S.ys[k]-p[2])/p[3])*Math.abs(p[3]); s1+=Math.min(d/Rr,1); n1++; }
  return (s1/n1+s2/n2)/2;
}
function grICP(R, S, p, Rr){
  let sw=0,sl=0,sll=0,sx=0,slx=0, tw=0,ta=0,taa=0,ty=0,tay=0, n=0;
  grProj(R,p,S.w,S.h,(x,y,k)=>{ const i=Math.round(y)*S.w+Math.round(x), d=S.Dm[i]; if(d>Rr) return;
    const t=S.idx[i], tx=t%S.w, tyy=(t/S.w)|0, w=1/(1+(d/Math.max(Rr/3,1))**2), lo=R.lon[k], la=R.lat[k];
    sw+=w; sl+=w*lo; sll+=w*lo*lo; sx+=w*tx; slx+=w*lo*tx; ta+=w*la; taa+=w*la*la; ty+=w*tyy; tay+=w*la*tyy; n++; });
  if(n<20) return p;
  const dx=sw*sll-sl*sl, dy=sw*taa-ta*ta; if(Math.abs(dx)<1e-9||Math.abs(dy)<1e-9) return p;
  const bx=(sw*slx-sl*sx)/dx, ax=(sx-bx*sl)/sw, by=(sw*tay-ta*ty)/dy, ay=(ty-by*ta)/sw;
  if(!(bx>0) || !(by<0)) return p;
  return [ax,bx,ay,by];
}
function grRefine(R, S, p){
  for(const Rr of [0.08*S.w,0.05*S.w,0.03*S.w,0.015*S.w,6,3]) for(let t=0;t<6;t++) p=grICP(R,S,p,Rr);
  return p;
}
// جست‌وجوی سراسری: مقیاس، نسبت ابعاد و مرکز؛ امتیاز = همبستگی تراکم خطوط در بلوک‌ها + فاصلهٔ چمفر
function grSearch(R, S, hint){
  const w=S.w, h=S.h, cx=(w-1)/2, cy=(h-1)/2, nbx=8, nby=Math.max(4,Math.round(8*h/w)), bxp=w/nbx, byp=h/nby;
  const mb=new Float64Array(nbx*nby); for(let k=0;k<S.xs.length;k++) mb[Math.min(nby-1,Math.floor(S.ys[k]/byp))*nbx+Math.min(nbx-1,Math.floor(S.xs[k]/bxp))]++;
  let mm=0; for(const v of mb) mm+=v; mm/=mb.length; let mn=0; for(let i=0;i<mb.length;i++){ mb[i]-=mm; mn+=mb[i]*mb[i]; } mn=Math.sqrt(mn)+1e-9;
  const st=Math.max(1,Math.floor(S.xs.length/300)), px=[], py=[]; for(let k=0;k<S.xs.length;k+=st){ px.push(S.xs[k]-cx); py.push(S.ys[k]-cy); }
  const cands=[], rc=new Float64Array(nbx*nby);
  for(let si=0;si<34;si++){ const wdeg=26*Math.pow(2/26, si/33), s=w/wdeg;
    if(hint && wdeg>3.2*hint.r+6) continue;
    for(const k of [1.0,1.16]){
      const hdeg=h/(s*k), bw=wdeg/nbx, bh=hdeg/nby, step=bw/2, top=[];
      for(let lc=GR.LON0+wdeg*0.35; lc<GR.LON1-wdeg*0.35; lc+=step){ if(hint && Math.abs(lc-hint.lon)>=hint.r) continue;
        for(let ac=GR.LAT0+hdeg*0.35; ac<GR.LAT1-hdeg*0.35; ac+=step/k){ if(hint && Math.abs(ac-hint.lat)>=hint.r) continue;
          let rm=0; for(let v=0;v<nby;v++){ const la1=ac+hdeg/2-v*bh; for(let u=0;u<nbx;u++){ const lo0=lc-wdeg/2+u*bw; const c=grCount(R,lo0,lo0+bw,la1-bh,la1); rc[v*nbx+u]=c; rm+=c; } }
          rm/=rc.length; let num=0, rn=0; for(let i=0;i<rc.length;i++){ const t=rc[i]-rm; num+=t*mb[i]; rn+=t*t; }
          const ncc=num/(Math.sqrt(rn)*mn+1e-9);
          if(ncc<0.05) continue;
          let ch=0; const tr=2*bw; for(let q=0;q<px.length;q++){ ch+=Math.min(grLook(R, lc+px[q]/s, ac-py[q]/(s*k))/tr, 1); } ch/=px.length;
          const sc=(1-ncc)+ch;
          if(top.length<5 || sc<top[top.length-1][0]){ top.push([sc,s,k,lc,ac]); top.sort((a,b)=>a[0]-b[0]); if(top.length>5) top.pop(); } } }
      cands.push(...top); } }
  cands.sort((a,b)=>a[0]-b[0]);
  const picked=[];
  for(const c of cands){ if(picked.every(p=>Math.abs(Math.log(c[1]/p[1]))>0.08 || Math.hypot(c[3]-p[3],c[4]-p[4])>0.15*w/c[1])) picked.push(c); if(picked.length>=20) break; }
  let best=null;
  for(const c of picked){ const [,s,k,lc,ac]=c; let p=[cx-s*lc, s, cy+s*k*ac, -s*k]; p=grRefine(R,S,p); const sc=grScore(R,S,p); if(!best||sc<best.score) best={p,score:sc}; }
  return best;
}
// زمین‌مرجع کامل یک قالب نقشه
async function grLocate(L, pal, extra){
  const R=await grRef(), lm=grLines(L.maps, L.prof, pal), S=lm.variants.map(M=>grPrep(M,lm.w,lm.h)).filter(Boolean);
  if(!S.length) return {ok:false, score:9, msg:"خط مرز کافی روی نقشه پیدا نشد"};
  const toDs=g=>[(g[0]-lm.x0-(lm.q-1)/2)/lm.q, g[1]/lm.q, (g[2]-lm.y0-(lm.q-1)/2)/lm.q, g[3]/lm.q];
  const toFull=p=>[lm.x0+lm.q*p[0]+(lm.q-1)/2, p[1]*lm.q, lm.y0+lm.q*p[2]+(lm.q-1)/2, p[3]*lm.q];
  const evalG=(g, refine)=>{ let best=null; for(const s of S){ let p=toDs(g); if(refine) p=grRefine(R,s,p); const sc=grScore(R,s,p); if(!best||sc<best.score) best={g:toFull(p), score:sc}; } return best; };
  if(L.manual){ const r=evalG(L.manual, L.manualRefine); return {ok:true, g:r.g, score:r.score, src:L.manualRefine?"دستی + تطبیق":"دستی"}; }
  const known=[]; if(L.tplGeo) known.push(["قالب سایت", L.tplGeo]);
  for(const e of store.get("dsgeo",[])) if(e.W===L.W && e.H===L.H && Math.abs(e.fr[0]-L.prof.fx0)<=3 && Math.abs(e.fr[1]-L.prof.fy0)<=3) known.push(["آموخته‌شده", e.g, e.sc]);
  for(const g of (extra||[])) known.push(["نقشهٔ هم‌قالب همین نوبت", g.g, g.sc]);
  if(!L.hint){ let bk=null; for(const [src,g,s0] of known){ const r=evalG(g,false), lim=Math.max(0.5, Math.min((s0||0)+0.1, 0.7)); if(r.score<lim && (!bk||r.score<bk.score)) bk={ok:true, g, score:r.score, src}; } if(bk) return bk; }
  let best=null;
  for(const s of S){ const b=grSearch(R,s,L.hint); if(b && (!best||b.score<best.score)) best={g:toFull(b.p), score:b.score}; }
  if(!best) return {ok:false, score:9, msg:"مکان نقشه پیدا نشد"};
  return {ok:best.score<0.62, g:best.g, score:best.score, src:L.hint?"خودکار با راهنما":"خودکار", msg: best.score<0.62 ? "" : "مکان نقشه با اطمینان پیدا نشد"};
}
function grLearn(L){ if(!L.geo) return; const list=store.get("dsgeo",[]).filter(e=>!(e.W===L.W&&e.H===L.H&&Math.abs(e.fr[0]-L.prof.fx0)<=3&&Math.abs(e.fr[1]-L.prof.fy0)<=3&&Math.hypot(e.g[0]-L.geo[0],e.g[2]-L.geo[2])<20));
  list.push({W:L.W, H:L.H, fr:[L.prof.fx0,L.prof.fy0,L.prof.fx1,L.prof.fy1], g:L.geo.map(v=>+v.toFixed(4)), sc:+(L.sc||0.5).toFixed(3)}); store.set("dsgeo", list.slice(-60)); }
const grBounds=(g,prof)=>({W:(prof.fx0-g[0])/g[1], E:(prof.fx1-g[0])/g[1], N:(prof.fy0-g[2])/g[3], S:(prof.fy1-g[2])/g[3]});
function grHintFromName(name){ const n=(name||"").toLowerCase(); for(let i=1;i<IR_PROV.length;i++) if((name||"").includes(IR_PROV[i][0])) return i; for(const [k,i] of Object.entries(IR_PROV_EN)) if(k.split("|").some(t=>n.includes(t))) return i; return -1; }


