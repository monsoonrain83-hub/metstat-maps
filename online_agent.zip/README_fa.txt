راهنمای نصب «تحلیل نقشه‌های آنلاین» روی cPanel
================================================
۱) پوشهٔ online را کنار index.html در public_html قرار دهید (همراه پوشهٔ data و فایل‌های .htaccess).
۲) در File Manager فایل online/mx_fetch.php را باز کنید (Edit) و در خط
      const MX_KEY = 'CHANGE-ME-SECRET';
   یک رمز دلخواه بگذارید (مثلاً MX_KEY = 'a8f3k2...').
۳) آزمون آدرس‌ها: در مرورگر باز کنید
      https://wtafkik.ir/online/mx_fetch.php?key=رمز&test=1
   برای هر منطقه/مدل/پارامتر یک خط ✓ یا ✗ می‌آید (حدود ۸۰ خط، چند دقیقه طول می‌کشد).
۴) cPanel ← Cron Jobs ← Add New Cron Job:
      زمان: هر ۵ دقیقه  (*/5 * * * *)
      فرمان:  /usr/local/bin/php /home/USERNAME/public_html/online/mx_fetch.php >/dev/null 2>&1
   (USERNAME نام کاربری cPanel است؛ اگر php در این مسیر نبود از «php» یا مسیری که cPanel در صفحهٔ Cron نشان می‌دهد استفاده کنید)
۵) زمان‌بندی (mx_config.json):
      دریافت اجرای 00Z از ساعت ۰۶:۳۰ UTC (۱۰:۰۰ ایران) و اجرای 12Z از ۱۸:۳۰ UTC (۲۲:۰۰ ایران)
      ۵ دقیقه پیش از شروع هر اجرا، نقشه‌های اجرای قبلی حذف می‌شوند (cleanup_mode = "before")
      اگر نمی‌خواهید صفحه در فاصلهٔ دریافت خالی بماند: "cleanup_mode": "swap"
۶) گزارش کار: online/data/fetch.log (فقط از File Manager؛ از مرورگر بسته است)

۷) اگر diag.php برای meteologix/weather.us «HTTP 403» نشان داد (مسدود شدن IP هاست ایران توسط Akamai):
   رلهٔ رایگان Cloudflare بسازید تا درخواست‌ها از بیرون ایران فرستاده شوند:
   الف) در dash.cloudflare.com ثبت‌نام کنید → Workers & Pages → Create → Create Worker → نام: metstat-relay → Deploy
   ب) Edit code → کل محتوای فایل online/relay_worker.js را جایگزین کنید → Deploy
   ج) Settings → Variables and Secrets → Add: نام RELAY_KEY ، نوع Secret ، مقدار یک رمز طولانی (مثلاً ۳۲ حرف)
   د) در online/mx_config.json بخش اول را پر کنید:
        "relay": {"url": "https://metstat-relay.<نام‌کاربری>.workers.dev", "key": "همان رمز"},
   هـ) دوباره online/diag.php را باز کنید؛ سطر relay باید آدرس رله را نشان دهد و آزمون‌ها HTTP 200 بدهند.
   نکته: اگر هاست به دامنهٔ workers.dev دسترسی نداشت (فیلتر)، در Cloudflare دامنهٔ خودتان را اضافه کنید و برای Worker
   یک زیردامنه مثل relay.wtafkik.ir تعریف کنید (Settings → Domains & Routes) و همان را در "url" بنویسید.
   رله فقط آدرس‌های meteologix و weather.us را می‌پذیرد و بدون رمز درست کار نمی‌کند.

۸) اگر رلهٔ Cloudflare هم «Access Denied» گرفت (Akamai سرورهای ابری را هم می‌بندد): «دانلودکنندهٔ مرورگری»
   یک مرورگر واقعی صفحهٔ هر نقشه را باز می‌کند، تصویر را می‌گیرد و با HTTPS به online/mx_upload.php می‌فرستد؛
   تصاویر در online/data/<اجرا>/<منطقه>/<مدل>_<پارامتر>_<زمان>.png ذخیره می‌شوند و صفحهٔ سایت خودکار نشانشان می‌دهد.
   الف) در online/mx_config.json مقدار "upload_key" را یک رمز طولانی بگذارید (و "relay" را خالی کنید).
   ب) Cron مربوط به mx_fetch.php را در cPanel غیرفعال کنید (از هاست ایران کار نمی‌کند).
   ج) یکی از دو روش اجرا:
      • روی کامپیوتر خودتان (مطمئن‌ترین؛ همان اینترنتی که meteologix را در مرورگرتان باز می‌کند):
          pip install playwright requests
          python -m playwright install chromium
          python mx_agent.py --host https://wtafkik.ir/online --key رمز --loop
        (با --show مرورگر را می‌بینید؛ با --chrome از Chrome نصب‌شده استفاده می‌شود. کامپیوتر باید روشن بماند.)
      • GitHub Actions (رایگان، بدون نیاز به روشن بودن کامپیوتر): یک مخزن خصوصی بسازید، mx_agent.py و پوشهٔ .github را
        در آن بگذارید، در Settings → Secrets دو مقدار MX_HOST و MX_KEY را تعریف کنید. روزی دو بار خودکار اجرا می‌شود؛
        از تب Actions → metstat-maps → Run workflow هم دستی اجرا می‌شود. اگر meteologix سرورهای GitHub را هم ببندد،
        در گزارش اجرا «Access Denied» دیده می‌شود؛ آن‌وقت روش کامپیوتر خودتان را به کار ببرید.
   د) آزمون: python mx_agent.py --host … --key … --test  (برای هر منطقه/مدل/پارامتر یک تصویر آزمایش می‌شود، چیزی آپلود نمی‌شود)
