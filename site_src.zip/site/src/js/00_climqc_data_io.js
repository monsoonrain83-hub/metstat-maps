
(function(){







{{BLOB:data_layers_shapefile}}
try{ window.CQC_LAYERS=LAYERS; }catch(e){}

const $=i=>document.getElementById(i),PD='۰۱۲۳۴۵۶۷۸۹',AD='٠١٢٣٤٥٦٧٨٩';
const SH=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'],GRM=['ژانویه','فوریه','مارس','آوریل','مه','ژوئن','ژوئیه','اوت','سپتامبر','اکتبر','نوامبر','دسامبر'],EN=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
const SEA={ag:['پاییز','زمستان','بهار','تابستان'],sh:['بهار','تابستان','پاییز','زمستان']};
const dig=s=>String(s).replace(/[۰-۹]/g,c=>PD.indexOf(c)).replace(/[٠-٩]/g,c=>AD.indexOf(c));
const num=x=>{if(typeof x=='number')return x;if(x==null)return NaN;let s=dig(x).trim().replace(/[\/٫]/g,'.');return /^[-+]?\d*\.?\d+(e[-+]?\d+)?$/i.test(s)?+s:NaN};
const AL=m=>{if(S.auto)throw new Error(m);alert(m)};
/* اصلاح هوشمند مختصات: درجه‌دقیقهٔ چسبیده (3541 → 35.68) و جابه‌جایی طول/عرض برای ایران و پیرامون */
function fixLL(la,lo){const dm=v=>(v>900&&v<9000)?Math.floor(v/100)+(v%100)/60:v;la=dm(la);lo=dm(lo);if(la>43&&la<64&&lo>23&&lo<42){S.llSwap=(S.llSwap||0)+1;return[lo,la]}return[la,lo]}
const S={gaz:[],tabs:[],st:{},ser:[],idx:null,dem:null,gj:null},log=t=>{$('log').textContent+=t+'\n'};
const TY={P:'بارش',T:'دمای میانگین',X:'دمای حداکثر',N:'دمای حداقل',E:'تبخیر',O:'سایر'};
const isSum=t=>t=='P'||t=='E';
function g2j(gy,gm,gd){const g=[0,31,59,90,120,151,181,212,243,273,304,334],y2=gm>2?gy+1:gy;let d=355666+365*gy+Math.floor((y2+3)/4)-Math.floor((y2+99)/100)+Math.floor((y2+399)/400)+gd+g[gm-1],jy=-1595+33*Math.floor(d/12053);d%=12053;jy+=4*Math.floor(d/1461);d%=1461;if(d>365){jy+=Math.floor((d-1)/365);d=(d-1)%365}return[jy,d<186?1+Math.floor(d/31):7+Math.floor((d-186)/30),1+(d<186?d%31:(d-186)%30)]}
function j2g(jy,jm,jd){jy+=1595;let d=-355668+365*jy+Math.floor(jy/33)*8+Math.floor((jy%33+3)/4)+jd+(jm<7?(jm-1)*31:(jm-7)*30+186),gy=400*Math.floor(d/146097);d%=146097;if(d>36524){gy+=100*Math.floor(--d/36524);d%=36524;if(d>=365)d++}gy+=4*Math.floor(d/1461);d%=1461;if(d>365){gy+=Math.floor((d-1)/365);d=(d-1)%365}let gd=d+1;const sal=[0,31,(gy%4==0&&gy%100!=0)||gy%400==0?29:28,31,30,31,30,31,31,30,31,30,31];let gm=0;for(;gm<13&&gd>sal[gm];gm++)gd-=sal[gm];return[gy,gm,gd]}
const dl=(b,n)=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n;a.click()};
const csv=a=>a.map(r=>r.map(x=>{x=x==null||(typeof x=='number'&&isNaN(x))?'':String(x);return /[",\n]/.test(x)?'"'+x.replace(/"/g,'""')+'"':x}).join(',')).join('\n');
const med=a=>{a=a.filter(x=>!isNaN(x)).sort((x,y)=>x-y);return a.length?(a[a.length>>1]+a[(a.length-1)>>1])/2:NaN};
const mean=a=>{a=a.filter(x=>!isNaN(x));return a.length?a.reduce((x,y)=>x+y,0)/a.length:NaN};
const sd=a=>{a=a.filter(x=>!isNaN(x));if(a.length<2)return NaN;const m=mean(a);return Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/(a.length-1))};
const hav=(a,b)=>{const R=6371,r=Math.PI/180,dl=(b.lon-a.lon)*r,dp=(b.lat-a.lat)*r,h=Math.sin(dp/2)**2+Math.cos(a.lat*r)*Math.cos(b.lat*r)*Math.sin(dl/2)**2;return 2*R*Math.asin(Math.sqrt(h))};
document.querySelectorAll('#cqc_nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#cqc_nav button,.cqc section').forEach(e=>e.classList.remove('on'));b.classList.add('on');$(b.dataset.t).classList.add('on')});

/* ---------- ورود داده ---------- */
function dbf(b){const d=new DataView(b),n=d.getUint32(4,true),hl=d.getUint16(8,true),rl=d.getUint16(10,true),f=[],td=new TextDecoder();for(let o=32;d.getUint8(o)!=13;o+=32)f.push({n:td.decode(new Uint8Array(b,o,11)).replace(/\0.*/,''),l:d.getUint8(o+16)});const rows=[];for(let i=0;i<n;i++){let o=hl+i*rl+1;rows.push(f.map(c=>{const s=td.decode(new Uint8Array(b,o,c.l)).trim();o+=c.l;return s}))}return{headers:f.map(c=>c.n),rows}}
function txt2tab(t){const L=t.split(/\r?\n/).filter(x=>x.trim());const dl=[',',';','\t'].find(c=>(L[0]||'').includes(c));const A=L.map(l=>dl?l.split(dl).map(x=>x.replace(/^"|"$/g,'').trim()):l.trim().split(/\s+/));return{headers:A[0].map(String),rows:A.slice(1)}}
async function pdf2tab(buf){pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';const doc=await pdfjsLib.getDocument({data:buf}).promise,rows=[];for(let p=1;p<=doc.numPages;p++){const tc=await(await doc.getPage(p)).getTextContent(),ln={};tc.items.forEach(it=>{const y=Math.round(it.transform[5]);(ln[y]=ln[y]||[]).push(it.str)});Object.keys(ln).sort((a,b)=>b-a).forEach(y=>{const tk=ln[y].join(' ').trim().split(/\s+/).filter(x=>x);if(tk.filter(x=>!isNaN(num(x))||x=='*').length>=5)rows.push(tk)})}const w=Math.max(...rows.map(r=>r.length));return{headers:Array.from({length:w},(_,i)=>'c'+(i+1)),rows}}
function nc2tab(buf,name){const R=window.NetCDFReader||(window.netcdfjs&&(netcdfjs.NetCDFReader||netcdfjs)),r=new R(buf),V=r.variables.map(v=>v.name),f=a=>V.find(v=>a.includes(v.toLowerCase())),la=f(['lat','latitude']),lo=f(['lon','longitude']),ti=f(['time','date']);const dv=r.variables.find(v=>v.dimensions.length>=3&&![la,lo,ti].includes(v.name));if(!dv||!la||!lo)throw'ساختار netcdf شناسایی نشد';const A=r.getDataVariable(la),O=r.getDataVariable(lo),T=ti?r.getDataVariable(ti):[0],at=n=>{const x=dv.attributes.find(a=>a.name==n);return x?x.value:null},sc=at('scale_factor')??1,of=at('add_offset')??0,fv=at('_FillValue')??at('missing_value');const tu=ti?String((r.variables.find(v=>v.name==ti).attributes.find(a=>a.name=='units')||{}).value||''):'',m=tu.match(/(\w+) since (\d+)-(\d+)-(\d+)/),base=m?Date.UTC(+m[2],+m[3]-1,+m[4]):0,un=m?({days:864e5,hours:36e5,seconds:1e3,minutes:6e4}[m[1].toLowerCase()]||864e5):864e5,D=r.getDataVariable(dv.name),nt=T.length,nla=A.length,nlo=O.length,step=Math.max(1,Math.ceil(Math.sqrt(nla*nlo/150))),rows=[];for(let i=0;i<nla;i+=step)for(let j=0;j<nlo;j+=step)for(let k=0;k<nt;k++){const x=D[(k*nla+i)*nlo+j];if(x==null||x===fv)continue;const d=new Date(base+T[k]*un);rows.push([`g_${A[i].toFixed(2)}_${O[j].toFixed(2)}`,A[i],O[j],'',d.getUTCFullYear()+'-'+(d.getUTCMonth()+1)+'-'+d.getUTCDate(),x*sc+of]);if(rows.length>6e5)break}return{headers:['station','lat','lon','elev','date',dv.name],rows}}
const nrm=s=>dig(String(s??'')).replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[\u200c\u200f\u200e]/g,' ').replace(/\s+/g,' ').trim();
const ptype=x=>{x=nrm(x).replace(/[_\s-]+/g,'').toLowerCase();if(/زمین|ground|tgtg|tmaxg|^rh|^eva|evap|تبخیر/.test(x))return/^eva|evap|تبخیر/.test(x)?'E':'O';if(/رطوبت|humid|فشار|press|باد|wind|ابر|cloud|آفتاب|sun|ساعت|برف|snow|تگرگ|مه\b/i.test(x))return'O';if(/بارش|بارندگی|prec|rain/i.test(x))return'P';if(/تبخیر|evap/i.test(x))return'E';if(/دما|temp|tmax|tmin|tmean|tavg|^t$|^t[xn]$/i.test(x)){if(/حداکثر|max|ماکزیمم|tmax|^tx$/i.test(x))return'X';if(/حداقل|min|مینیمم|tmin|^tn$/i.test(x))return'N';return'T'}return'O'};
function mIdx(v){if(v==null||v==='')return null;const s=nrm(v);if(!s||s.length>14)return null;let i=SH.findIndex(x=>s==x||s.startsWith(x));if(i>=0)return{k:'sh',i};i=GRM.findIndex(x=>s==x);if(i>=0)return{k:'gr',i};if(/^[A-Za-z]{3,9}$/.test(s)){i=EN.indexOf(s.slice(0,3).toLowerCase());if(i>=0)return{k:'gr',i}}return null}
const KW=/سال|ایستگاه|هواشناسی|ماه|جدول|گزارش|سینوپتیک|اقلیمی|کلیماتولوژی|استان|شهرستان|station|year|month|ردیف|روز|پارامتر|واحد/i,PT=/بارش|بارندگی|دما|تبخیر|رطوبت|prec|rain|temp|evap/i;
function smart(a,sn,base){const R=a.length,get=(r,c)=>(a[r]||[])[c];let hr=-1,cols=null,mode='';
for(let r=0;r<Math.min(R,30)&&hr<0;r++){const row=a[r]||[],m={};row.forEach((v,c)=>{const q=mIdx(v);if(q)m[c]=q});if(new Set(Object.values(m).map(q=>q.i)).size>=6){hr=r;cols=m;mode='MC'}else{const nn=[];row.forEach((v,c)=>{const n=num(v);if(Number.isInteger(n)&&n>=1&&n<=12)nn.push([c,n])});if(new Set(nn.map(x=>x[1])).size>=11&&nn.length<=14){hr=r;cols={};nn.forEach(([c,n])=>cols[c]={k:'num',i:n-1});mode='MC'}}}
let mc=-1,mrows=[];if(mode==''){for(let c=0;c<6&&mc<0;c++){const L=[];for(let r=0;r<R;r++)if(mIdx(get(r,c)))L.push(r);if(L.length>=10){mc=c;mrows=L;mode='MR'}}}
if(!mode)return null;
const top=mode=='MC'?hr:Math.max(0,mrows[0]),yrs=[];let yr=null,stn=null,pt=null;
const HDRW=/^(total|sum|mean|avg|average|annual|years?|جمع|مجموع|کل|سالانه|میانگین|متوسط|فصل|پاییز|زمستان|بهار|تابستان|\(?شروع\)?|\(?پایان\)?|ردیف)$/i;
for(let r=0;r<Math.min(top+1,12)&&r<R;r++)for(const c of(a[r]||[])){const n=num(c);if(yr==null&&r<top&&Number.isInteger(n)&&((n>=1300&&n<=1500)||(n>=1900&&n<=2100)))yr=n;if(typeof c=='string'){const s=nrm(c);if(!pt&&PT.test(s))pt=s;if(r<top&&!stn&&s&&s.length>1&&s.length<40&&isNaN(num(s))&&!KW.test(s)&&!PT.test(s)&&!mIdx(s)&&!HDRW.test(s.replace(/[()\s]/g,'')))stn=s.replace(/^(بارانسنجی|باران‌سنجی|تبخیرسنجی|ایستگاه|سینوپتیک|کلیماتولوژی|هواشناسی)\s+/,'').trim()}}
if(yr==null){const m=nrm(sn).match(/1[345]\d\d|19\d\d|20\d\d/);if(m)yr=+m[0]}
stn=stn||base;const recs=[],P0=pt?(pt.length>25?TY[ptype(pt)]:nrm(pt)):(PT.test(nrm(sn))?nrm(sn):(PT.test(nrm(base))?nrm(base):'مقدار'));
const D=(k,y,m,d)=>(k=='gr'||(k=='num'&&y>=1700))?(d?`${y}-${m+1}-${d}`:`${y}-${m+1}`):(d?`${y}/${m+1}/${d}`:`${y}/${m+1}`);
if(mode=='MC'){const cs=Object.keys(cols).map(Number).sort((x,y)=>x-y),minC=cs[0],ag=cols[minC].k=='sh'&&cols[minC].i==6;
const LB=[],AG={};for(let r=hr+1;r<R;r++){const row=a[r]||[];let lab=null;for(let c=0;c<minC;c++){const v=row[c];if(typeof v=='string'&&v.trim()&&isNaN(num(v))){lab=v;break}}if(lab==null)for(let c=0;c<minC;c++)if(row[c]!==''&&row[c]!=null){lab=row[c];break}{const mx=cs[cs.length-1];for(let c=mx+1;c<row.length;c++){const m=/^\s*(\d{2,4})\s*[-–\/]\s*(\d{2,4})\s*$/.exec(dig(row[c]??''));if(m){let y=+m[1];if(y<100)y+=1300;lab=y;AG[r]=1;break}}}LB[r]=lab}
const dayLay=LB.filter(v=>{const n=num(v);return v!=null&&Number.isInteger(n)&&n>=1&&n<=31}).length>=10;
for(let r=hr+1;r<R;r++){const row=a[r]||[],lab=LB[r];if(lab==null)continue;const ln=num(lab),vals=cs.map(c=>num(row[c]));if(vals.every(isNaN))continue;if(dayLay&&isNaN(ln))continue;
if(Number.isInteger(ln)&&ln>=1&&ln<=31){if(yr==null)continue;cs.forEach((c,k)=>{if(!isNaN(vals[k]))recs.push({st:stn,p:P0,d:D(cols[c].k,yr,cols[c].i,ln),v:vals[k]})})}
else if(Number.isInteger(ln)&&ln>=1300&&ln<=2100){cs.forEach((c,k)=>{if(isNaN(vals[k]))return;const q=cols[c];recs.push({st:stn,p:P0,d:D(q.k,((ag||AG[r])&&q.i<6)?ln+1:ln,q.i),v:vals[k]})})}
else if(typeof lab=='string'&&isNaN(ln)){const s=nrm(lab);if(!s||yr==null)continue;cs.forEach((c,k)=>{if(!isNaN(vals[k]))recs.push({st:stn,p:s,d:D(cols[c].k,yr,cols[c].i),v:vals[k]})})}}}
else{const r0=mrows[0],H=a[Math.max(0,r0-1)]||[],pc=[];H.forEach((v,c)=>{if(c!=mc&&typeof v=='string'&&nrm(v)&&!mIdx(v)&&mrows.slice(0,6).some(r=>!isNaN(num(get(r,c)))))pc.push(c)});if(yr==null)return null;
mrows.forEach(r=>{const q=mIdx(get(r,mc));pc.forEach(c=>{const v=num(get(r,c));if(!isNaN(v))recs.push({st:stn,p:nrm(H[c]),d:D(q.k,yr,q.i),v})})})}
return recs.length?{recs,mode,stn,yr}:null}
function toTable(recs){const ps=[...new Set(recs.map(r=>r.p))],K=new Map(),ix=new Map(ps.map((p,i)=>[p,i]));recs.forEach(r=>{const k=r.st+'\u0001'+r.d;let o=K.get(k);if(!o){o=[r.st,r.d,...ps.map(_=>'')];K.set(k,o)}o[2+ix.get(r.p)]=r.v});return{headers:['station','date',...ps],rows:[...K.values()],smart:1}}
// جدول بلند (هر سطر یک روز/ماه): ستون‌های سال/ماه/روز یا تاریخ، مختصات و ایستگاه اختیاری، ستون‌های عددی = پارامترها
function longTab(a,base){
  const H=/^(year|yr|سال)$/i, M=/^(month|mounth|mon|ماه)$/i, Dd=/^(day|روز)$/i, DT=/^(date|تاریخ|time|datetime)$/i, LA=/^(lat|latitude|عرض|عرض جغرافیایی|y|yt)$/i, LO=/^(lon|long|longitude|طول|طول جغرافیایی|x|xt)$/i, EL=/^(elev|elevation|alt|altitude|height|ارتفاع)$/i, ST=/^(station|stn|station ?name|name|ایستگاه|نام ایستگاه|نام|code|station ?code|کد|کد ایستگاه|id)$/i;
  for(let r=0;r<Math.min(a.length,12);r++){const h=(a[r]||[]).map(x=>nrm(x).replace(/\s+/g,' '));const f=re=>h.findIndex(x=>re.test(x));
    const iy=f(H),im=f(M),id=f(Dd),idt=f(DT);if(!((iy>=0&&im>=0)||idt>=0))continue;
    const ila=f(LA),ilo=f(LO),iel=f(EL),ist=f(ST),used=new Set([iy,im,id,idt,ila,ilo,iel,ist].filter(i=>i>=0));
    const body=a.slice(r+1).filter(x=>x&&x.some(v=>v!==''&&v!=null));if(body.length<12)continue;
    const smp=body.slice(0,Math.min(200,body.length));
    const pc=h.map((x,c)=>c).filter(c=>!used.has(c)&&h[c]&&!/^(ردیف|row|index|#)$/i.test(h[c])&&smp.filter(x=>!isNaN(num(x[c]))).length>=0.3*smp.length);
    if(!pc.length)continue;
    const recs=[],gaz=new Map();
    for(const row of body){let y,m,d;
      if(iy>=0&&im>=0){y=num(row[iy]);m=num(row[im]);d=id>=0?num(row[id]):NaN;if(isNaN(m)){const q=monthParse(row[im]);m=(q.sh??q.gr??q.n)+1}}
      else{const v=row[idt];if(typeof v=='number'&&v>20000&&v<80000){const t=new Date(Math.round((v-25569)*864e5));y=t.getUTCFullYear();m=t.getUTCMonth()+1;d=t.getUTCDate()}else{const q=(dig(v).match(/\d+/g)||[]).map(Number);if(q.length<2)continue;if(q[0]>31){y=q[0];m=q[1];d=q[2]}else{y=q[2];m=q[1];d=q[0]}}}
      if(!(y>0)||!(m>=1&&m<=12))continue;const sh=y<1700;const ds=isNaN(d)||!d?(sh?`${y}/${m}`:`${y}-${m}`):(sh?`${y}/${m}/${d}`:`${y}-${m}-${d}`);
      const st=ist>=0&&String(row[ist]).trim()?nrm(row[ist]):base;
      if(ila>=0&&ilo>=0&&!gaz.has(st)){let la=num(row[ila]),lo=num(row[ilo]);[la,lo]=fixLL(la,lo);if(la>-90&&la<90&&lo>-180&&lo<180&&la&&lo)gaz.set(st,[st,lo,la,iel>=0&&!isNaN(num(row[iel]))?num(row[iel]):null])}
      for(const c of pc){const v=num(row[c]);if(!isNaN(v))recs.push({st,p:h[c],d:ds,v})}}
    if(recs.length>=12)return{recs,gaz:[...gaz.values()],mode:'LONG',params:pc.map(c=>h[c])};
  }
  return null;
}
function fromSheets(sh,base,fname){const recs=[];let n=0,modes=new Set();for(const s of sh){if(s.a.length<2)continue;let r=null;try{r=longTab(s.a,base)}catch(e){console.warn(e)}if(r){for(const x of r.recs)recs.push(x);if(r.gaz.length)S.gaz.push(...r.gaz);n++;modes.add('LONG');continue}r=smart(s.a,s.n,base);if(r&&r.recs.length){for(const x of r.recs)recs.push(x);n++;modes.add(r.mode)}}
if(recs.length){
  // روزانه و ماهانه در دو جدول جدا (وگرنه سری ماهانه با روزهای خالی و تاریخ تکراری روزانه می‌شود)
  const isD=r=>/^\d+[-\/]\d+[-\/]\d+$/.test(r.d), dR=recs.filter(isD), mR=recs.filter(r=>!isD(r)); let np=0;
  if(dR.length){const t=toTable(dR);addTab(fname,t);np+=t.headers.length-2}
  if(mR.length){const t=toTable(mR);addTab(fname+(dR.length?' (ماهانه)':''),t);np+=t.headers.length-2}
  log(`شناسایی خودکار «${fname}»: ${n} شیت، ${recs.length} مقدار، ${np} پارامتر${dR.length&&mR.length?' (روزانه و ماهانه جدا)':''}، ${new Set(recs.map(r=>r.st)).size} ایستگاه`);return}
const G=new Map();for(const s of sh){const a=s.a,k=a.findIndex(r=>r.filter(x=>typeof x=='string'&&x.trim()).length>=3);if(k<0)continue;const hd=a[k].map((x,i)=>String(x).trim()||'col'+(i+1)),sig=hd.join('|');let k2=k+1;const ne=r=>(r||[]).filter(x=>x!==''&&x!=null);while(a[k2]&&ne(a[k2]).length>=3&&ne(a[k2]).every(x=>typeof x=='string'&&isNaN(num(x))))k2++;if(!G.has(sig))G.set(sig,{headers:hd,rows:[]});G.get(sig).rows.push(...a.slice(k2))}
[...G.values()].forEach((t,i)=>addTab(fname+(i?'#'+i:''),t));
if(!recs.length){log('ساختار «'+fname+'» به‌طور خودکار شناسایی نشد. اگر اجرا خطا داد، «تنظیمات پیشرفته» را باز کنید. ۸ ردیف اول:');sh[0]&&sh[0].a.slice(0,8).forEach(r=>log(' '+r.slice(0,14).map(x=>String(x).slice(0,12)).join(' | ')))}}
async function loadFile(f){const ext=f.name.split('.').pop().toLowerCase(),base=f.name.replace(/\.[^.]+$/,'');
if(['xlsx','xls'].includes(ext)){const wb=XLSX.read(await f.arrayBuffer(),{type:'array',cellDates:true}),sh=wb.SheetNames.map(n=>({n,a:XLSX.utils.sheet_to_json(wb.Sheets[n],{header:1,raw:true,defval:''})}));const cc=sh.length&&coordCat(sh[0].a);if(cc){S.gaz.push(...cc);return}return fromSheets(sh,base,f.name)}
let t;if(['csv','txt'].includes(ext))t=txt2tab(await f.text());else if(ext=='dbf')t=dbf(await f.arrayBuffer());else if(ext=='pdf')t=await pdf2tab(await f.arrayBuffer());else if(ext=='nc'||ext=='cdf')t=nc2tab(await f.arrayBuffer(),f.name);else{log('ثبت شد ولی نیازمند مبدل (سمت سرور) است: '+f.name);return}
if(['csv','txt'].includes(ext)){const cc=coordCat([t.headers,...t.rows]);if(cc){S.gaz.push(...cc);return}}if(['csv','txt','pdf'].includes(ext)){const r=smart([t.headers,...t.rows],base,base);if(r){addTab(f.name,toTable(r.recs));log('شناسایی خودکار: '+f.name);return}}addTab(f.name,t)}
async function loadAll(){$('log').textContent='';$('maps').innerHTML='';S.tabs=[];S.auto=1;for(const f of $('fin').files){try{await loadFile(f)}catch(e){log('خطا در '+f.name+': '+e)}}log('اسکن و ترمیم خودکار…');await runAll()}
$('fin').onchange=loadAll;
async function cqcFixCoords(){const fx=[];let dem=null;
for(const st of Object.values(S.st)){let{lat,lon,elev}=st;
// مختصات به‌صورت درجه‌دقیقهٔ چسبیده (مثلاً 3541 = ۳۵°۴۱′)
const dm=v=>(v>900&&v<9000)?Math.floor(v/100)+(v%100)/60:v;if(lat>90||lon>180){lat=dm(lat);lon=dm(lon);fx.push(st.id+': درجه‌دقیقه → اعشاری')}
// جابه‌جایی طول و عرض (برای ایران و پیرامون)
if(lat>43&&lat<64&&lon>23&&lon<42){[lat,lon]=[lon,lat];fx.push(st.id+': جابه‌جایی طول و عرض اصلاح شد')}
st.lat=lat;st.lon=lon;
// ارتفاع گم‌شده یا صفرِ نادرست → DEM ۹۰ متری داخلی
if(!isNaN(lat)&&lat>24&&lat<41&&lon>43&&lon<64&&(isNaN(elev)||Math.abs(elev)<1)){try{dem=dem||await dsBuiltinDEM();const j=Math.round((lon-dem.x0)/dem.dx),i=Math.round((dem.y0-lat)/dem.dy),z=dem.data[i*dem.nx+j];if(z===z&&(isNaN(elev)||z>60)){st.elev=Math.round(z);st.elevSrc='DEM';fx.push(st.id+': ارتفاع از DEM ۹۰ متری = '+Math.round(z)+' m')}}catch(e){}}}
if(S.llSwap){fx.unshift('طول و عرض جابه‌جا در '+S.llSwap+' ردیف/ایستگاه اصلاح شد');S.llSwap=0}if(fx.length)log('اصلاح خودکار مختصات/ارتفاع:\n  '+fx.slice(0,40).join('\n  ')+(fx.length>40?'\n  …':''));S.coordFix=fx}
// سازگاری دمای میانگین با بیشینه و کمینه (ستون اشتباه یا جابه‌جا در اکسل)
function cqcTmean(){for(const s of S.ser){if(s.type!='T')continue;const sx=s.s.sr||{},X=Object.values(sx).find(o=>o.type=='X'&&o.fq==s.fq),N=Object.values(sx).find(o=>o.type=='N'&&o.fq==s.fq);if(!X||!N)continue;
const at=(o,i)=>{const j=s.i0+i-o.i0;return j>=0&&j<o.n?o.v[j]:NaN};let d=0,c=0;for(let i=0;i<s.n;i++){const x=at(X,i),n=at(N,i),t=s.v[i];if(isNaN(x)||isNaN(n)||isNaN(t))continue;d+=t-(x+n)/2;c++}
if(c>=12&&Math.abs(d/c)>2.5){(typeof sdone=='function'?m=>sdone('warn',m):log)(`${s.st} · ${s.p}: میانگین ثبت‌شده به‌طور نظام‌مند ${(d/c).toFixed(1)}° با (بیشینه+کمینه)/۲ فاصله دارد (احتمالاً ستون اشتباه) → جایگزینی با (بیشینه+کمینه)/۲`);for(let i=0;i<s.n;i++){const x=at(X,i),n=at(N,i);if(!isNaN(x)&&!isNaN(n)){s.log.push([i,s.o[i],null,'E:tmix']);s.iss.tmix=(s.iss.tmix||0)+1;rec(s,i,(x+n)/2,'H')}}continue}
for(let i=0;i<s.n;i++){const x=at(X,i),n=at(N,i),t=s.v[i];if(!isNaN(x)&&!isNaN(n)&&!isNaN(t)&&x>=n&&(t>x+1||t<n-1)){err(s,i,'tmix');rec(s,i,(x+n)/2,'H')}}}}
async function runAll(){try{build();await cqcFixCoords();if(!S.ser.length){log('داده‌ای ساخته نشد؛ «تنظیمات پیشرفته» را باز و ستون‌ها را مشخص کنید.');$('adv').open=true;return}qc();cqcTmean();repair();S.out={};fillSel();rep();log(`پایان اسکن: ${Object.keys(S.st).length} ایستگاه، ${S.ser.length} سری. گزارش در تب ۲، فایل‌ها در تب ۳.`);await makeOutputs();try{await $('bmap').onclick()}catch(e){log('نقشه: '+e)}}catch(e){log('خطا: '+e+(e.stack?'\n'+e.stack.split('\n')[1]:''))}finally{S.auto=0}}
const FL={H:'(بیشینه+کمینه)/۲',I:'درون‌یابی زمانی',S:'ایستگاه‌های همسایه',C:'میانگین اقلیمی ماه ایستگاه'},ER={range:'خارج از بازه فیزیکی',spike:'جهش/ناهنجاری شدید',stuck:'مقدار ثابت تکراری',spatial:'ناهماهنگ با ایستگاه‌های همسایه',swap:'حداکثر کوچک‌تر از حداقل',tmix:'دمای میانگین ناسازگار با بیشینه/کمینه'};
function reportTxt(){const L=['گزارش کنترل کیفیت و ترمیم داده‌ها (ClimQC)','تاریخ گزارش: '+new Date().toISOString().slice(0,10),'='.repeat(60),`تعداد ایستگاه: ${Object.keys(S.st).length} | تعداد سری (ایستگاه×پارامتر): ${S.ser.length}`,''];
for(const s of S.ser){const c=f=>s.f.filter(x=>x==f).length,i=s.iss,nA=s.n;L.push('-'.repeat(60),`ایستگاه: ${s.st} | پارامتر: ${s.p} (${TY[s.type]}) | گام: ${s.fq=='d'?'روزانه':'ماهانه'} | بازه: ${idxDate(s,0)} تا ${idxDate(s,nA-1)} | تعداد: ${nA}`);
const iss=[['ترتیب تاریخ نادرست',i.unsorted],['تاریخ تکراری',i.dup],['تاریخ نامعتبر',i.bad],['خلأ/مقدار مفقود',i.gap],['مقدار کدی (-9999 و...)',i.sent],['خارج از بازه',i.range],['جهش',i.spike],['مقدار ثابت',i.stuck],['ناهماهنگی مکانی',i.spatial],['Tmax<Tmin',i.swap],['میانگین ناسازگار',i.tmix||0]].filter(x=>x[1]);L.push('مشکلات: '+(iss.length?iss.map(x=>x.join('=')).join('، '):'ندارد')+` | ترمیم‌شده: زمانی ${c('I')}، از بیشینه/کمینه ${c('H')}، همسایه ${c('S')}، اقلیمی ${c('C')} | بدون ترمیم (بارش بدون همسایه): ${c('N')}`);
s.log.slice(0,20000).forEach(l=>{const w=String(l[3]);const why=w.startsWith('E:')?ER[w.slice(2)]||w:null,m=w.replace(/\(E\)/,'');L.push(`   ${idxDate(s,l[0])} | مقدار اولیه: ${isNaN(l[1])?'مفقود':l[1]} | `+(l[2]==null?`حذف شد (خطا: ${why})`:`مقدار جدید: ${l[2]} [${FL[m]||m}${w.includes('(E)')?'، جایگزین مقدار خطادار':''}]`))});
const N=[];for(let k=0;k<s.n&&N.length<30;k++)if(s.f[k]=='N')N.push(idxDate(s,k));if(c('N'))L.push('   بدون ترمیم (نمونه تاریخ‌ها): '+N.join(', '))}return L.join('\n')}
async function makeOutputs(){S.files=[];$('outlist').innerHTML='';const add=(n,b,lab)=>{S.files.push({n,b});const d=document.createElement('div'),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n.split('/').pop();a.textContent='⬇ '+n+(lab?' — '+lab:'');d.appendChild(a);$('outlist').appendChild(d)},pr=t=>$('outprog').textContent=t,tick=()=>new Promise(r=>setTimeout(r,0));
add('QC_report.txt',new Blob(['\ufeff'+reportTxt()],{type:'text/plain'}),'گزارش خطاها و ترمیم‌ها');
const R=[['station','param','date','value','flag']];S.ser.forEach(s=>{for(let i=0;i<s.n;i++)R.push([s.st,s.p,idxDate(s,i),s.v[i],s.f[i]])});add('clean_data.csv',new Blob(['\ufeff'+csv(R)],{type:'text/csv'}),'داده‌های ترمیم‌شده (پرچم: I/S/C/N/E)');
add('ALL_stations_GIS.csv',new Blob(['\ufeff'+csv(gisRows())],{type:'text/csv'}),'جدول مجموع آماده GIS');
add('stations.geojson',new Blob([JSON.stringify({type:'FeatureCollection',features:Object.values(S.st).filter(s=>!isNaN(s.lat)).map(s=>({type:'Feature',geometry:{type:'Point',coordinates:[s.lon,s.lat]},properties:{id:s.id,elev:s.elev}}))})]),'نقطه‌های ایستگاه‌ها');
try{const wb=new ExcelJS.Workbook(),ws=wb.addWorksheet('GIS_wide');gisRows().forEach(r=>ws.addRow(mk2(r)));add('ALL_stations_GIS.xlsx',new Blob([await wb.xlsx.writeBuffer()]),'اکسل مجموع ایستگاه‌ها (GIS)')}catch(e){log('GIS xlsx: '+e)}
const ids=Object.keys(S.st);let k=0;for(const sid of ids){pr(`ساخت اکسل ایستگاه‌ها ${++k}/${ids.length} …`);await tick();try{add('stations/'+sid.replace(/[\\\/:*?"<>|]/g,'_')+'.xlsx',new Blob([await stationBook(sid)]),'')}catch(e){log('اکسل '+sid+': '+e)}}
pr('همه فایل‌ها آماده است ✔');log('فایل‌های خروجی آماده شد (تب ۳).')}
$('bzip').onclick=async()=>{if(!S.files||!S.files.length)return alert('ابتدا داده را وارد کنید');const z=new JSZip();S.files.forEach(f=>z.file(f.n,f.b));dl(await z.generateAsync({type:'blob'}),'climate_outputs.zip')};
const guess=(h,re,av)=>{let i=h.findIndex(x=>re.test(x)&&!(av&&av.test(x)));return i<0?h.findIndex(x=>re.test(x)):i};
function addTab(name,t){const h=t.headers,T={name,t,map:{}};S.tabs.push(T);const id=S.tabs.length-1,opt=(sel)=>'<option value="-1">—</option>'+h.map((x,i)=>`<option value="${i}" ${i==sel?'selected':''}>${i+1}: ${x||('['+String((t.rows.find(r=>r[i]!==''&&r[i]!=null)||[])[i]??'').slice(0,12)+']')}</option>`).join('');
const gl=(a,b)=>{const i=guess(h,a);return i>=0?i:guess(h,b)},ZR=/zeraei|زراعی/i;const gs={st:guess(h,/station|ایستگاه|stn|^name|^id$|نام/i),lat:gl(/lat|عرض|^yt$/i,/^y$/i),lon:gl(/lon|طول|^xt$/i,/^x$/i),elev:guess(h,/elev|alt|height|ارتفاع/i),date:guess(h,/date|تاریخ/i),year:guess(h,/year|سال/i,ZR),month:guess(h,/month|mounth|ماه/i,ZR),day:guess(h,/day|روز/i,ZR)};
const typ=ptype;
const d=document.createElement('div');d.className='box';d.innerHTML=`<b>${name}</b> (${t.rows.length} ردیف)<br>`+['st:ایستگاه','lat:عرض','lon:طول','elev:ارتفاع','date:تاریخ','year:سال','month:ماه','day:روز'].map(x=>{const[k,l]=x.split(':');return`${l} <select id="m${id}_${k}">${opt(gs[k])}</select> `}).join('')+`<br>حالت تاریخ <select id="m${id}_mode"><option value="single">ستون تاریخ</option><option value="ymd">ستون‌های سال/ماه/(روز)</option><option value="matrix">ماتریس سال×۱۲ ماه (مثل آمار شمسی)</option></select> ماتریس: ستون سال <select id="m${id}_my">${opt(0)}</select> ستون اولین ماه <select id="m${id}_m0">${opt(2)}</select> ترتیب <select id="m${id}_ord"><option value="6">از مهر</option><option value="0">از فروردین</option></select> سال=<select id="m${id}_yt"><option value="ag">زراعی(شروع)</option><option value="sh">شمسی</option></select> نوع پارامتر ماتریس <select id="m${id}_mt">${Object.entries(TY).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select><br>ستون‌های مقدار:<br>`+h.map((x,i)=>`<label><input type="checkbox" id="m${id}_p${i}" ${(!/^(year|month|mounth|day)|zeraei|date|^سال|^ماه|^روز|تاریخ|^code|^کد|^ردیف|^row|^index/i.test(x)&&i!=gs.st&&i!=gs.lat&&i!=gs.lon&&i!=gs.elev&&i!=gs.date&&i!=gs.year&&i!=gs.month&&i!=gs.day&&t.rows.slice(0,20).filter(r=>!isNaN(num(r[i]))).length>10)?'checked':''}>${x}</label><select id="m${id}_t${i}">${Object.entries(TY).map(([k,v])=>`<option value="${k}" ${typ(x)==k?'selected':''}>${v}</option>`).join('')}</select> `).join('');$('maps').appendChild(d);if(t.smart){['lat','lon','elev','year','month','day'].forEach(k=>$(`m${id}_${k}`).value='-1');$(`m${id}_st`).value='0';$(`m${id}_date`).value='1';$(`m${id}_mode`).value='single';h.forEach((x,i)=>{if(i>=2){$(`m${id}_p${i}`).checked=true;$(`m${id}_t${i}`).value=ptype(x)}})}}
function mp(id,k){return +$(`m${id}_${k}`).value}
function monthParse(v,gr){if(typeof v=='number'||!isNaN(num(v)))return{n:num(v)-1};const s=String(v).trim().toLowerCase();let i=SH.findIndex(x=>s.includes(x));if(i>=0)return{sh:i};i=GRM.findIndex(x=>s.includes(x));if(i>=0)return{gr:i};i=EN.findIndex(x=>s.startsWith(x));return i>=0?{gr:i}:{n:NaN}}
function mkDate(y,m,d){if(!(y>0)||!(m>=0&&m<12)||!(d>=1&&d<=31))return null;if(y<1700){const g=j2g(y,m+1,d);return{t:Date.UTC(g[0],g[1]-1,g[2]),jy:y,jm:m,jd:d}}const j=g2j(y,m+1,d);return{t:Date.UTC(y,m,d),jy:j[0],jm:j[1]-1,jd:j[2]}}
function rowDate(r,id){const mode=$(`m${id}_mode`).value;let y,m,d=NaN,hasD=1;if(mode=='single'){let raw=r[mp(id,'date')];if(raw instanceof Date){const q9=new Date(raw.getTime()+432e5);y=q9.getFullYear();m=q9.getMonth();d=q9.getDate()}else{const a=(dig(raw).match(/\d+/g)||[]).map(Number);if(a.length<2)return null;if(a[0]>31||a.length==2){y=a[0];m=a[1]-1;d=a[2]}else{y=a[2];m=a[1]-1;d=a[0]}if(!d){d=15;hasD=0}}}else{y=num(r[mp(id,'year')]);const q=monthParse(r[mp(id,'month')]);m=q.sh??q.gr??q.n;if(q.gr!=null&&y<1700){const g=g2j(y,m+1,15);y=g[0];m=g[1]-1}d=mp(id,'day')>=0?num(r[mp(id,'day')]):15;if(isNaN(d)){d=15;hasD=0}if(mp(id,'day')<0)hasD=0}
const o=mkDate(y,m,d);if(o)o.hasD=hasD;return o}
function build(){S.st={};S.ser=[];const issues={};
S.tabs.forEach((T,id)=>{const get=(r,k)=>mp(id,k)>=0?r[mp(id,k)]:'',nm=stnName(T.name);const add=(sid,r,p,ty,dt,v)=>{const s=S.st[sid]=S.st[sid]||{id:sid,lat:NaN,lon:NaN,elev:NaN,raw:{}};if(isNaN(s.lat)){[s.lat,s.lon]=fixLL(num(get(r,'lat')),num(get(r,'lon')));s.elev=num(get(r,'elev'))}if(isNaN(s.lat)||isNaN(s.elev)){const q=lookup(sid);if(q){if(isNaN(s.lat)){s.lat=q[0];s.lon=q[1]}if(isNaN(s.elev)&&q[2]!=null)s.elev=q[2]}}const q=s.raw[p]=s.raw[p]||{type:ty,recs:[],bad:0};q.smart=q.smart||T.smart;if(!dt){q.bad++;return}q.recs.push([dt,v])};
T.t.rows.forEach(r=>{const sid=mp(id,'st')>=0?String(get(r,'st')):nm;if($(`m${id}_mode`).value=='matrix'){const y0=num(r[mp(id,'my')]);if(isNaN(y0))return;const c0=mp(id,'m0'),o=+$(`m${id}_ord`).value,ag=$(`m${id}_yt`).value=='ag',ty=$(`m${id}_mt`).value;for(let k=0;k<12;k++){const mi=(o+k)%12;let jy=y0+((ag&&mi<6)?1:0);if(!ag&&o==6&&mi<6)jy=y0;const dt=mkDate(jy,mi,15);dt&&(dt.hasD=0);add(sid,r,TY[ty],ty,dt,num(r[c0+k]))}}else{const dt=rowDate(r,id);T.t.headers.forEach((h,i)=>{if($(`m${id}_p${i}`)&&$(`m${id}_p${i}`).checked)add(sid,r,h,$(`m${id}_t${i}`).value,dt,num(r[i]))})}})});
const SENT=new Set([-9999,-999,9999,-99,99999,-999.9]);
for(const s of Object.values(S.st))for(const[p,q]of Object.entries(s.raw)){const R=q.recs;if(!R.length)continue;let unsorted=0;for(let i=1;i<R.length;i++)if(R[i][0].t<R[i-1][0].t)unsorted++;R.sort((a,b)=>a[0].t-b[0].t);const df=[];for(let i=1;i<R.length;i++)df.push((R[i][0].t-R[i-1][0].t)/864e5);const fq=(med(df)<=3&&R.some(x=>x[0].hasD))?'d':'m',key=d=>fq=='d'?Math.round(d.t/864e5):d.jy*12+d.jm;const i0=key(R[0][0]),n=key(R[R.length-1][0])-i0+1;if(n>2e6){log('سری خیلی بلند: '+s.id+' '+p);continue}const o={s,st:s.id,p,type:q.type,fq,i0,n,v:new Float64Array(n).fill(NaN),o:new Float64Array(n).fill(NaN),f:new Array(n).fill('M'),jy:new Int16Array(n),jm:new Int8Array(n),log:[],iss:{unsorted:q.smart?0:unsorted,bad:q.bad,dup:0,sent:0,gap:0,range:0,spike:0,stuck:0,spatial:0,swap:0}};
for(const[d,v]of R){const i=key(d)-i0;if(o.f[i]!='M'){o.iss.dup++;continue}if(SENT.has(v)){o.iss.sent++;o.f[i]='E';continue}o.v[i]=v;o.o[i]=v;o.f[i]=isNaN(v)?'M':''}
for(let i=0;i<n;i++){if(fq=='d'){const dd=new Date((i0+i)*864e5),j=g2j(dd.getUTCFullYear(),dd.getUTCMonth()+1,dd.getUTCDate());o.jy[i]=j[0];o.jm[i]=j[1]-1}else{o.jy[i]=Math.floor((i0+i)/12);o.jm[i]=(i0+i)%12}if(o.f[i]=='M'&&isNaN(o.o[i]))o.iss.gap++}
S.ser.push(o);s.sr=s.sr||{};s.sr[p]=o}
}
const LIM=s=>({P:[0,s.fq=='d'?700:3000],T:[-60,60],X:[-50,65],N:[-70,55],E:[0,s.fq=='d'?40:900],O:[-1e9,1e9]})[s.type];
function climo(s){s.mu=[];s.sg=[];for(let m=0;m<12;m++){const a=[];for(let i=0;i<s.n;i++)if(s.jm[i]==m&&!isNaN(s.v[i]))a.push(s.v[i]);s.mu[m]=mean(a);const md=med(a);s.sg[m]=1.4826*med(a.map(x=>Math.abs(x-md)))||sd(a)||1}}
const err=(s,i,why)=>{s.log.push([i,s.o[i],null,'E:'+why]);s.v[i]=NaN;s.f[i]='E';s.iss[why]++};
function qc(){for(const s of S.ser){const[lo,hi]=LIM(s);for(let i=0;i<s.n;i++){const x=s.v[i];if(!isNaN(x)&&(x<lo||x>hi))err(s,i,'range')}}
for(const s of S.ser){const sx=s.s.sr;if(s.type=='X'){const nn=Object.values(sx).find(o=>o.type=='N'&&o.fq==s.fq);if(nn)for(let i=0;i<s.n;i++){const j=s.i0+i-nn.i0;if(j>=0&&j<nn.n&&!isNaN(s.v[i])&&!isNaN(nn.v[j])&&s.v[i]<nn.v[j]){err(s,i,'swap');err(nn,j,'swap')}}}}
for(const s of S.ser){climo(s);if(s.type=='P'){const w=[];for(let i=0;i<s.n;i++)if(s.v[i]>0)w.push(s.v[i]);w.sort((a,b)=>a-b);if(w.length>50){const p99=w[Math.floor(w.length*.99)];for(let i=0;i<s.n;i++)if(s.v[i]>6*p99)err(s,i,'spike')}}else{const fl=s.fq=='d'?2:1;for(let i=0;i<s.n;i++){const x=s.v[i];if(!isNaN(x)&&Math.abs(x-s.mu[s.jm[i]])>5*Math.max(s.sg[s.jm[i]],fl))err(s,i,'spike')}if(s.fq=='d'&&s.type!='O'){let r=1;for(let i=1;i<=s.n;i++){if(i<s.n&&s.o[i]===s.o[i-1]&&!isNaN(s.o[i])&&s.o[i]!==0)r++;else{if(r>=6)for(let k=i-r+1;k<i;k++)if(!isNaN(s.v[k]))err(s,k,'stuck');r=1}}}}}
neigh();snap();for(const s of S.ser)if(s.type!='P'&&s.type!='O')for(let i=0;i<s.n;i++){if(isNaN(s.v[i]))continue;const e=est(s,i);if(!isNaN(e)&&Math.abs(s.v[i]-e)>5*Math.max(s.sg[s.jm[i]],s.fq=='d'?2:1)+2)err(s,i,'spatial')}
snap()}
function snap(){for(const s of S.ser){s.c=Float64Array.from(s.v);climo(s)}}
function neigh(){for(const s of S.ser)s.nb=S.ser.filter(o=>o!=s&&o.p==s.p&&o.fq==s.fq&&!isNaN(o.s.lat)&&!isNaN(s.s.lat)).map(o=>({o,d:hav(s.s,o.s)})).sort((a,b)=>a.d-b.d)}
function est(s,i,k=4){let a=0,w=0,c=0;const idx=s.i0+i,m=s.jm[i];for(const{o,d}of s.nb){const j=idx-o.i0;if(j<0||j>=o.n)continue;const x=o.c[j];if(isNaN(x))continue;let y;if(s.type=='P'){if(!(o.mu[m]>0))continue;y=x*s.mu[m]/o.mu[m]}else y=x+s.mu[m]-o.mu[m];if(isNaN(y))continue;const ww=1/Math.max(d,1)**2;a+=ww*y;w+=ww;if(++c>=k)break}return c?a/w:NaN}
function repair(){for(const s of S.ser){const lin=s.type!='P',miss=[];for(let i=0;i<s.n;i++)if(isNaN(s.v[i]))miss.push(i);let run=0;
if(lin)for(let i=0;i<s.n;i++){if(isNaN(s.c[i])){let j=i;while(j<s.n&&isNaN(s.c[j]))j++;const L=j-i;if(i>0&&j<s.n&&L<=3)for(let k=i;k<j;k++){const v=s.c[i-1]+(s.c[j]-s.c[i-1])*(k-i+1)/(L+1);rec(s,k,v,'I')}i=j}}
for(const i of miss){if(!isNaN(s.v[i]))continue;let e=est(s,i);if(!isNaN(e)){rec(s,i,s.type=='P'?Math.max(0,e):e,'S')}else if(lin&&!isNaN(s.mu[s.jm[i]]))rec(s,i,s.mu[s.jm[i]],'C');else s.f[i]='N'}}}
function rec(s,i,v,f){const prev=s.f[i];s.log.push([i,s.o[i],v,f+(prev=='E'?'(E)':'')]);s.v[i]=Math.round(v*100)/100;s.f[i]=f}
const idxDate=(s,i)=>{if(s.fq=='d'){const d=new Date((s.i0+i)*864e5);return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+String(d.getUTCDate()).padStart(2,'0')}return s.jy[i]+'/'+String(s.jm[i]+1).padStart(2,'0')};
$('brun').onclick=runAll;

