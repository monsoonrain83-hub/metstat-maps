// آزمون دودی: صفحه بدون خطای اجرا بالا بیاید و توابع اصلی تعریف باشند.  node smoke.js <مسیر index.html>
const { chromium } = require('playwright');
(async()=>{
  const file=require('path').resolve(process.argv[2]||'index.html');
  const b=await chromium.launch(process.env.CHROMIUM?{executablePath:process.env.CHROMIUM,args:['--no-proxy-server']}:{});
  const p=await b.newPage({viewport:{width:420,height:900}}); const errs=[];
  p.on('pageerror',e=>errs.push('pageerror: '+e.message));
  await p.addInitScript(()=>{ try{ localStorage.setItem('mmap.lang',JSON.stringify('fa')); }catch(e){} });
  await p.goto('file://'+file); await p.waitForTimeout(2500);
  const need=['openON','nvInit','nvCompBuild','niInit','cvAdd','wnAdd','ttsUnlock','ttsPlayUrl','switchMode','buildSite'].filter(n=>n!=='buildSite');
  const miss=await p.evaluate(n=>n.filter(f=>typeof window[f]!=='function'),need);
  const logo=await p.evaluate(()=>!!document.querySelector('img[alt*="MetStat"],.logo,header img'));
  const w=await p.evaluate(()=>document.body.scrollWidth);
  console.log(JSON.stringify({miss,logo,scrollWidth:w,errors:errs.length}));
  if(errs.length) console.log(errs.join('\n'));
  await b.close();
  if(errs.length||miss.length||w>430){ console.error('FAIL'); process.exit(1); } console.log('OK');
})();
