# ساخت نسخهٔ «چندتکه» برای آپلود آسان: index.html سبک + پوشهٔ assets (هر فایل زیر ۷ مگابایت)
import re,sys,os,hashlib
root=os.path.dirname(os.path.abspath(__file__)); S=root+'/src'
EXT=['wu_zoom_overlays','dem_iran','clim_db','tt_me_overlay']
def rd(p): return open(p,encoding='utf8').read()
out=sys.argv[1]; os.makedirs(out+'/assets',exist_ok=True)
t=rd(S+'/index.tpl.html')
t=re.sub(r'\{\{CSS:([^}]+)\}\}',lambda m:rd(f'{S}/css/{m.group(1)}'),t)
t=re.sub(r'\{\{JS:([^}]+)\}\}',lambda m:rd(f'{S}/js/{m.group(1)}'),t)
tags=[]
for n in EXT:
    b=rd(f'{S}/blobs/{n}.txt'); h=hashlib.md5(b.encode()).hexdigest()[:8]
    open(f'{out}/assets/{n}.js','w',encoding='utf8').write(b+'\n')
    tags.append(f'<script src="assets/{n}.js?v={h}"></script>')
    assert t.count('{{BLOB:'+n+'}}')==1, n
    t=t.replace('{{BLOB:'+n+'}}','')
t=re.sub(r'\{\{BLOB:([^}]+)\}\}',lambda m:rd(f'{S}/blobs/{m.group(1)}.txt'),t)
first=t.index('<script>')
t=t[:first]+'\n'.join(tags)+'\n'+t[first:]
open(out+'/index.html','w',encoding='utf8').write(t)
for f in ['index.html']+['assets/'+n+'.js' for n in EXT]: print(f, os.path.getsize(out+'/'+f)//1024,'KB')
