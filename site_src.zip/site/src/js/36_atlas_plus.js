/* =====================================================================
   اطلس اقلیمی — تحلیل‌های پیشرفته
   ۱) تحلیل چندشاخصی: همبستگی هم‌زمان چند شاخص (ENSO، QBO، AMO، …) با پارامتر، رگرسیون چندگانه
      (ضرایب استانداردشده، همبستگی جزئی، R² تعدیل‌شده، آزمون F، VIF) و ماتریس همبستگی شاخص‌ها؛ نقشهٔ R² و همبستگی جزئی
   ۲) آنالوگ: شرط روی چند شاخص (بازه، آستانه، فاز قوی) → سال‌های آنالوگ → ناهنجاری ترکیبی پارامتر نسبت به نرمال،
      احتمال بیش/کمتر از نرمال (سه‌دهک)، آزمون t ولش؛ نمودار ایستگاهی و نقشهٔ آنالوگ
   ۳) آمار تکمیلی: SPI، درصد از نرمال، صدک سال، دورهٔ بازگشت (GEV با گشتاورهای L و گامبل)، ضریب تغییرات،
      انحراف معیار، احتمال عبور از آستانه، مقدار صدک؛ نمودار توزیع، دورهٔ بازگشت، SPI، آزمون پتیت و همبستگی متحرک
   هیچ عدد خامی قابل دانلود نیست؛ فقط تصویر نمودار و نقشه.
   ===================================================================== */
const CAX_MT=new Set(["spi","pct","rank","rl","cv","sd","pexc","q","mr2","pcor","ana","anap"]);
// ---------- آمار پایه ----------
const caxMean=a=>a.reduce((s,x)=>s+x,0)/a.length;
const caxSd=a=>{ const m=caxMean(a); return Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/Math.max(1,a.length-1)); };
const caxQ=(a,q)=>{ const b=a.slice().sort((p,r)=>p-r); if(!b.length) return NaN; const t=(b.length-1)*q, i=Math.floor(t); return b[i]+(b[Math.min(b.length-1,i+1)]-b[i])*(t-i); };
function caxInvN(p){ // Acklam
  if(p<=0) return -Infinity; if(p>=1) return Infinity;
  const a=[-39.69683028665376,220.9460984245205,-275.9285104469687,138.3577518672690,-30.66479806614716,2.506628277459239], b=[-54.47609879822406,161.5858368580409,-155.6989798598866,66.80131188771972,-13.28068155288572],
        c=[-0.007784894002430293,-0.3223964580411365,-2.400758277161838,-2.549732539343734,4.374664141464968,2.938163982698783], d=[0.007784695709041462,0.3224671290700398,2.445134137142996,3.754408661907416];
  const pl=0.02425; let q,r;
  if(p<pl){ q=Math.sqrt(-2*Math.log(p)); return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5])/((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1); }
  if(p>1-pl){ q=Math.sqrt(-2*Math.log(1-p)); return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5])/((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1); }
  q=p-0.5; r=q*q; return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q/(((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1);
}
function caxGammaP(a,x){ if(x<=0) return 0; const gl=caLgamma(a);
  if(x<a+1){ let ap=a, sum=1/a, del=sum; for(let n=0;n<300;n++){ ap++; del*=x/ap; sum+=del; if(Math.abs(del)<Math.abs(sum)*1e-10) break; } return sum*Math.exp(-x+a*Math.log(x)-gl); }
  let b=x+1-a, c=1e300, d=1/b, h=d; for(let i=1;i<300;i++){ const an=-i*(i-a); b+=2; d=an*d+b; if(Math.abs(d)<1e-300) d=1e-300; c=b+an/c; if(Math.abs(c)<1e-300) c=1e-300; d=1/d; const del=d*c; h*=del; if(Math.abs(del-1)<1e-10) break; }
  return 1-Math.exp(-x+a*Math.log(x)-gl)*h; }
// SPI: برازش گاما (Thom) روی مقادیر مثبت + احتمال صفر
function caxSpiFit(vals){ const pos=vals.filter(v=>v>0), q=(vals.length-pos.length)/vals.length; if(pos.length<8) return null;
  const m=caxMean(pos), A=Math.log(m)-caxMean(pos.map(Math.log)); if(!(A>0)) return null; const al=(1+Math.sqrt(1+4*A/3))/(4*A), be=m/al;
  return v=>{ const H=q+(1-q)*(v>0?caxGammaP(al,v/be):0); return caxInvN(Math.min(0.9999,Math.max(0.0001,H))); }; }
// دورهٔ بازگشت: GEV با گشتاورهای L (Hosking) و گامبل گشتاوری
function caxGev(vals){ const x=vals.slice().sort((a,b)=>a-b), n=x.length; if(n<10) return null; let b0=0,b1=0,b2=0;
  for(let i=0;i<n;i++){ b0+=x[i]; b1+=x[i]*i/(n-1); b2+=x[i]*i*(i-1)/((n-1)*(n-2)); } b0/=n; b1/=n; b2/=n;
  const l1=b0, l2=2*b1-b0, l3=6*b2-6*b1+b0, t3=l3/l2, c=2/(3+t3)-Math.log(2)/Math.log(3), k=7.859*c+2.9554*c*c, G=Math.exp(caLgamma(1+k));
  const al=l2*k/((1-Math.pow(2,-k))*G), xi=l1-al*(1-G)/k;
  return {k, al, xi, q:T=>{ const F=1-1/T, y=-Math.log(F); return Math.abs(k)<1e-6 ? xi-al*Math.log(y) : xi+al/k*(1-Math.pow(y,k)); }}; }
function caxGumbel(vals){ if(vals.length<8) return null; const s=caxSd(vals), m=caxMean(vals), be=s*Math.sqrt(6)/Math.PI, mu=m-0.5772*be; return {mu,be,q:T=>mu-be*Math.log(-Math.log(1-1/T))}; }
// رگرسیون چندگانه (کمترین مربعات) با آزمون‌ها
function caxOLS(X, y){ const n=y.length, k=X[0].length; if(n<k+4) return null;
  const Z=X.map(r=>[1,...r]), p=k+1, A=[...Array(p)].map((_,i)=>[...Array(p)].map((_,j)=>Z.reduce((s,r)=>s+r[i]*r[j],0)));
  let Ai; try{ Ai=caInv(A); }catch(e){ return null; } if(!Ai || Ai.some(r=>r.some(v=>!isFinite(v)))) return null;
  const Xy=[...Array(p)].map((_,i)=>Z.reduce((s,r,t)=>s+r[i]*y[t],0)), b=Ai.map(r=>r.reduce((s,v,j)=>s+v*Xy[j],0));
  const fit=Z.map(r=>r.reduce((s,v,j)=>s+v*b[j],0)), my=caxMean(y), sst=y.reduce((s,v)=>s+(v-my)**2,0), sse=y.reduce((s,v,t)=>s+(v-fit[t])**2,0);
  const df=n-p, s2=sse/Math.max(1,df), R2=1-sse/(sst||1), aR2=1-(1-R2)*(n-1)/Math.max(1,df), F=(R2/k)/((1-R2)/Math.max(1,df));
  const pF=caIncBeta(df/(df+k*F), df/2, k/2);
  const sdy=Math.sqrt(sst/(n-1)), coef=[];
  for(let j=1;j<p;j++){ const se=Math.sqrt(s2*Ai[j][j]), t=b[j]/se, col=X.map(r=>r[j-1]), sdx=caxSd(col);
    coef.push({b:b[j], beta:b[j]*sdx/(sdy||1), t, p:caTp(Math.abs(t),df), pr:t/Math.sqrt(t*t+df)}); }
  return {n,k,R2,aR2,F,pF,coef,fit,b0:b[0]}; }
function caxVIF(X){ const k=X[0].length; if(k<2) return [1]; return [...Array(k)].map((_,j)=>{ const o=caxOLS(X.map(r=>r.filter((_,q)=>q!==j)), X.map(r=>r[j])); return o?1/Math.max(1e-6,1-o.R2):NaN; }); }
function caxWelch(a,b){ if(a.length<2||b.length<2) return NaN; const ma=caxMean(a), mb=caxMean(b), va=caxSd(a)**2/a.length, vb=caxSd(b)**2/b.length, t=(ma-mb)/Math.sqrt(va+vb||1e-12);
  const df=(va+vb)**2/((va*va)/(a.length-1)+(vb*vb)/(b.length-1)||1); return caTp(Math.abs(t),Math.max(1,df)); }
function caxPettitt(ys){ const n=ys.length; let K=0, at=0; for(let t=0;t<n-1;t++){ let U=0; for(let i=0;i<=t;i++) for(let j=t+1;j<n;j++) U+=Math.sign(ys[i]-ys[j]); if(Math.abs(U)>K){ K=Math.abs(U); at=t; } }
  return {at, K, p:Math.min(1,2*Math.exp(-6*K*K/(n*n*n+n*n)))}; }
// ---------- داده ----------
function caxVals(st, p, per, y0, y1){ const m=caAggSt(st,p,per,CA_P[p].agg); const out=new Map(); for(const [y,v] of m) if(y>=y0&&y<=y1&&v===v) out.set(y,v); return out; }
function caxIdxPer(){ const v=$("caxIper")?$("caxIper").value:"same"; return v==="same" ? caPerSel() : v; }
function caxIdx(name, lag){ const sh=+($("caxIyr")?$("caxIyr").value:0); const m=caIdxAgg(name, caxIdxPer(), lag), out=new Map(); for(const [y,v] of m) out.set(y+sh, v); return out; }
function caxIdxList(){ return [...document.querySelectorAll(".caxIdxChk:checked")].map(c=>c.value); }
// شرط‌های آنالوگ
function caxConds(){ return [...document.querySelectorAll(".caxCond")].map(r=>({idx:r.querySelector(".ci").value, op:r.querySelector(".co").value, a:parseFloat(r.querySelector(".ca").value), b:parseFloat(r.querySelector(".cb").value)})).filter(c=>c.idx); }
function caxAnalogYears(y0, y1){
  const C=caxConds(); if(!C.length) throw new Error(CA_T("دست‌کم یک شرط شاخص تعریف کنید","Define at least one index condition"));
  const lag=Math.max(0,Math.min(12,+$("caLag").value||0)); let yrs=null; const desc=[];
  for(const c of C){ const m=caxIdx(c.idx, lag), all=[...m.values()], mu=caxMean(all), sd=caxSd(all), ok=new Set();
    for(const [y,v] of m){ if(y<y0||y>y1) continue; const z=(v-mu)/(sd||1); let pass=false;
      if(c.op==="between") pass=v>=Math.min(c.a,c.b) && v<=Math.max(c.a,c.b); else if(c.op==="ge") pass=v>=c.a; else if(c.op==="le") pass=v<=c.a;
      else if(c.op==="pos") pass=z>=1; else if(c.op==="neg") pass=z<=-1; else if(c.op==="neu") pass=Math.abs(z)<0.5; else if(c.op==="zpos") pass=z>=0.5; else if(c.op==="zneg") pass=z<=-0.5;
      if(pass) ok.add(y); }
    yrs = yrs ? new Set([...yrs].filter(y=>ok.has(y))) : ok;
    const OPN={between:CA_T(`بین ${caF(Math.min(c.a,c.b),2)} و ${caF(Math.max(c.a,c.b),2)}`,`between ${Math.min(c.a,c.b)} and ${Math.max(c.a,c.b)}`), ge:`≥ ${caF(c.a,2)}`, le:`≤ ${caF(c.a,2)}`, pos:CA_T("فاز مثبت قوی (≥ +۱σ)","strong positive (≥ +1σ)"), neg:CA_T("فاز منفی قوی (≤ −۱σ)","strong negative (≤ −1σ)"), neu:CA_T("خنثی (|z|<۰٫۵)","neutral (|z|<0.5)"), zpos:CA_T("مثبت (z ≥ ۰٫۵)","positive (z ≥ 0.5)"), zneg:CA_T("منفی (z ≤ −۰٫۵)","negative (z ≤ −0.5)")};
    desc.push(`${caIdxName(c.idx)} ${OPN[c.op]}`); }
  return {years:[...yrs].sort((a,b)=>a-b), desc:desc.join(CA_T(" و "," & "))};
}
// ترکیب آنالوگ برای یک ایستگاه
function caxComposite(st, p, per, y0, y1, years){ const m=caxVals(st,p,per,y0,y1); if(m.size<10) return null;
  const all=[...m.values()], ys=years.filter(y=>m.has(y)); if(ys.length<2) return null; const an=ys.map(y=>m.get(y)), oth=[...m].filter(([y])=>!years.includes(y)).map(([,v])=>v);
  const nrm=caxMean(all), t1=caxQ(all,1/3), t2=caxQ(all,2/3), med=caxQ(all,0.5), isP=CA_P[p].kind==="p"||p==="evap";
  const mean=caxMean(an), anom=isP? (nrm>0?(mean-nrm)/nrm*100:NaN) : mean-nrm, sd=caxSd(all);
  const above=an.filter(v=>v>med).length/an.length, tb=an.filter(v=>v<t1).length/an.length, ta=an.filter(v=>v>t2).length/an.length;
  return {n:ys.length, years:ys, vals:an, mean, nrm, anom, z:(mean-nrm)/(sd||1), above, tb, tn:1-tb-ta, ta, p:caxWelch(an,oth), isP, per:ys.map(y=>isP?(nrm>0?(m.get(y)-nrm)/nrm*100:NaN):m.get(y)-nrm)}; }
// ---------- رسم ----------
function caxBars(title, sub, labels, vals, opt={}){
  const W=980, H=opt.H||580, [c,x]=caCanvas(W,H), L=78, R=W-30, T=96, B=H-(opt.foot?150:110), en=LANG==="en";
  caFrame(x,W,H,title,sub); const fin=vals.filter(v=>v===v); if(!fin.length) return null;
  let mn=Math.min(0,...fin), mx=Math.max(0,...fin); if(opt.ymin!=null) mn=opt.ymin; if(opt.ymax!=null) mx=opt.ymax; const pad=(mx-mn)*0.12||1;
  const A=caAxes(x,L,T,R,B,0,1,mn-(mn<0?pad:0),mx+(mx>0?pad:0),{zero:true,ylab:opt.ylab||""}); const n=labels.length, gw=(R-L)/n, bw=Math.min(46,gw*0.62);
  labels.forEach((lb,i)=>{ const cx=en? L+gw*(i+0.5) : R-gw*(i+0.5), v=vals[i]; if(v===v){ const col=opt.color?opt.color(v,i):(v>=0?"#2563eb":"#dc2626"); caBar3D(x,cx,bw,A.Y(v),A.Y(Math.max(A.y0,Math.min(0,A.y1))),col);
      const lab=opt.keepLab&&opt.vlab?opt.vlab(v,i):""; if(lab) txt(x,lab,cx,v>=0?A.Y(v)-9:A.Y(v)+16,`bold 11.5px ${FT.body}`,{align:"center",color:"#0f172a",dir:"ltr"}); }
    x.save(); x.translate(cx,B+12); x.rotate(n>10?-Math.PI/4:0); txt(x,String(lb),0,6,`12px ${FT.body}`,{align:n>10?(en?"right":"right"):"center",color:"#334155",dir:en?"ltr":"rtl"}); x.restore(); });
  if(opt.hline!=null){ x.setLineDash([6,4]); x.strokeStyle="#f59e0b"; x.lineWidth=1.4; for(const h of [].concat(opt.hline)){ x.beginPath(); x.moveTo(L,A.Y(h)); x.lineTo(R,A.Y(h)); x.stroke(); } x.setLineDash([]); }
  (opt.foot||[]).forEach((s,i)=>txt(x,s,en?40:W-40,H-118+i*19+(n>10?20:0),`12.5px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:W-80}));
  caBrand(x,W,H); return c; }
async function caxDrawMap(pts, ttl, sub, unit, kind, extra={}){
  if(pts.length<5) throw new Error(CA_T(`فقط ${FA(pts.length)} ایستگاه دادهٔ کافی دارد؛ دوره را بزرگ‌تر یا ایستگاه‌های بیشتری انتخاب کنید.`,`Only ${pts.length} stations have enough data.`));
  const cov=caCoverage(pts); let warn=null;
  if(cov<0.5){ const msg=CA_T(`پوشش داده ناکافی: فقط ${FA(Math.round(cov*100))}٪ از مساحت ایرانِ داخل کادر در شعاع ۱۰۰ کیلومتری ایستگاهی با دادهٔ کافی است.`,`Insufficient data coverage: only ${Math.round(cov*100)}% of Iran's area inside the frame lies within 100 km of a station with enough data.`);
    if(!$("caForce").checked) throw new Error(msg+CA_T(" نقشه ترسیم نشد؛ گزینهٔ «ترسیم حتی اگر…» را بزنید یا ایستگاه‌های بیشتری انتخاب کنید."," The map was not drawn."));
    warn="⚠ "+CA_T(`این نقشه مشکل دارد: ${msg.replace("پوشش داده ناکافی: ","")} مقادیر دور از ایستگاه‌ها قابل اعتماد نیستند.`,`This map is unreliable: ${msg}`); }
  caStatus(CA_T("درون‌یابی و ترسیم نقشه…","Interpolating and drawing the map…"),0.6); await new Promise(r=>setTimeout(r,20));
  const cv=await caMap({pts, title:ttl, sub, unit, kind, scheme:extra.scheme||null, center:extra.center!=null?extra.center:0, warn, method:$("caMeth").value, useElev:!!extra.useElev && pts.length>=8, breaks:extra.breaks, clampMin:extra.clampMin,
    note:extra.note||CA_T("خانه‌های دورتر از ۳۰۰ کیلومتر از نزدیک‌ترین ایستگاه و بیرون از ایران رنگ نمی‌گیرند.","Cells farther than 300 km from the nearest station, and outside Iran, are left blank.")});
  if(extra.rep) cv.__rep={...extra.rep, kind:"map", pts, cov, interp:cv.__interp, frac:cv.__frac, br:cv.__br};
  caCard(ttl, cv, extra.cardNote||""); }
// ---------- نقشه‌های تکمیلی ----------
async function caxMapDo(){
  if(CA.busy) return; CA.busy=true;
  try{ await caLoad(); await document.fonts.ready;
    const sts=caSelected().filter(s=>s.lat!=null), p=$("caPar").value, per=caPerSel(), y0=+$("caY0").value, y1=+$("caY1").value, P=CA_P[p], mt=$("caMapType").value, isP=P.kind==="p"||p==="evap";
    if(!sts.length) throw new Error(CA_T("دست‌کم یک ایستگاه انتخاب کنید","Select at least one station"));
    caStatus(CA_T("در حال محاسبه…","Computing…"),0.3); await new Promise(r=>setTimeout(r,20));
    const ay=+$("caAnY").value, T=+$("caxT").value||50, thr=parseFloat($("caxThr").value), qq=Math.min(99,Math.max(1,+$("caxQ").value||90))/100;
    const pts=[]; const per_=caPerName(per), U=CA_T(P.u,P.ue); let ttl="", unit="", kind=P.kind, breaks=null, clampMin=null, useElev=false, note=null, cardNote="";
    const base=s=>({lat:s.lat,lon:s.lon,elev:s.elev||0,name:caStName(s),uv:s.vs==="unverified"});
    if(mt==="ana"||mt==="anap"){
      const A=caxAnalogYears(y0,y1); if(A.years.length<2) throw new Error(CA_T(`فقط ${FA(A.years.length)} سال آنالوگ پیدا شد؛ شرط‌ها را بازتر کنید.`,`Only ${A.years.length} analog years found; relax the conditions.`));
      for(const s of sts){ if(!s.d[p]) continue; const c=caxComposite(s,p,per,y0,y1,A.years); if(!c || c.n<Math.max(2,A.years.length*0.5)) continue;
        pts.push({...base(s), v: mt==="ana" ? c.anom : c.ta*100 - c.tb*100, sig:c.p<0.1}); }
      if(mt==="ana"){ ttl=CA_T(`نقشهٔ آنالوگ ${P.fa} — ${per_}`,`Analog composite of ${P.en} — ${per_}`); unit=isP?CA_T("درصد اختلاف از نرمال در سال‌های آنالوگ (نقطهٔ سیاه: معنی‌دار ۱۰٪)","% departure from normal in analog years (black dot: significant at 10%)"):CA_T(`اختلاف از نرمال (${P.u}) در سال‌های آنالوگ`,`Departure from normal (${P.ue})`); kind=isP?"pdiv":"div"; }
      else { ttl=CA_T(`احتمال بیش از نرمال منهای کمتر از نرمال — ${P.fa} — ${per_}`,`P(above) − P(below normal) — ${P.en} — ${per_}`); unit=CA_T("درصد (سه‌دهک‌های اقلیمی؛ مثبت = گرایش به بیش از نرمال)","percent (climatological terciles; positive = tendency above normal)"); kind="pdiv"; breaks=[-100,-80,-60,-40,-20,-5,5,20,40,60,80,100]; }
      cardNote=CA_T(`شرط: ${A.desc} · سال‌های آنالوگ (${FA(A.years.length)}): ${A.years.map(FA).join("، ")}`,`Conditions: ${A.desc} · analog years (${A.years.length}): ${A.years.join(", ")}`);
      note=cardNote; }
    else if(mt==="mr2"||mt==="pcor"){
      const idx=caxIdxList(); if(!idx.length) throw new Error(CA_T("در بخش «تحلیل چندشاخصی» دست‌کم یک شاخص تیک بزنید","Tick at least one index in the multi-index panel")); const lag=Math.max(0,Math.min(12,+$("caLag").value||0)), I=idx.map(n=>caxIdx(n,lag));
      for(const s of sts){ if(!s.d[p]) continue; const m=caxVals(s,p,per,y0,y1), X=[], y=[]; for(const [yy,v] of m){ const r=I.map(M=>M.get(yy)); if(r.every(q=>q!==undefined)){ X.push(r); y.push(v); } }
        if(y.length<Math.max(12,idx.length+6)) continue; const o=caxOLS(X,y); if(!o) continue;
        if(mt==="mr2") pts.push({...base(s), v:Math.max(0,o.aR2), sig:o.pF<0.05}); else pts.push({...base(s), v:o.coef[0].pr, sig:o.coef[0].p<0.05}); }
      if(mt==="mr2"){ ttl=CA_T(`R² تعدیل‌شدهٔ رگرسیون ${P.fa} با ${idx.join("+")} — ${per_}`,`Adjusted R² of ${P.en} on ${idx.join("+")} — ${per_}`); unit=CA_T("سهم واریانس توضیح‌داده‌شده (نقطهٔ سیاه: آزمون F معنی‌دار ۵٪)","explained variance (black dot: F-test significant at 5%)"); kind="p"; breaks=[0,0.05,0.1,0.15,0.2,0.3,0.4,0.5,0.6,0.8,1]; }
      else { ttl=CA_T(`همبستگی جزئی ${P.fa} با ${caIdxName(idx[0])} (کنترل ${idx.slice(1).map(caIdxName).join("، ")||"—"}) — ${per_}`,`Partial correlation of ${P.en} with ${idx[0]} controlling ${idx.slice(1).join(", ")||"—"} — ${per_}`); unit=CA_T("همبستگی جزئی (نقطهٔ سیاه: معنی‌دار ۵٪)","partial r (black dot: significant at 5%)"); kind="corr"; }
      cardNote=CA_T(`تأخیر شاخص‌ها ${FA(lag)} ماه · دورهٔ شاخص: ${caPerName(caxIdxPer())}`,`Index lag ${lag} months · index period: ${caPerName(caxIdxPer())}`); }
    else for(const s of sts){ if(!s.d[p]) continue; const m=caxVals(s,p,per,y0,y1), vals=[...m.values()]; if(vals.length<Math.max(10,(y1-y0+1)*0.4)) continue; let v=NaN;
      if(mt==="spi"){ if(!m.has(ay)) continue; if(isP){ const f=caxSpiFit(vals); if(!f) continue; v=f(m.get(ay)); } else v=(m.get(ay)-caxMean(vals))/(caxSd(vals)||1); }
      else if(mt==="pct"){ if(!m.has(ay)) continue; const n=caxMean(vals); v=n>0?m.get(ay)/n*100:NaN; }
      else if(mt==="rank"){ if(!m.has(ay)) continue; const x=m.get(ay); v=vals.filter(q=>q<x).length/(vals.length-1)*100; }
      else if(mt==="rl"){ const g=caxGev(vals)||caxGumbel(vals); if(!g) continue; v=g.q(T); if(P.agg!=="mean"&&P.kind!=="t") v=Math.max(0,v); }
      else if(mt==="cv"){ const mu=caxMean(vals); v=mu?caxSd(vals)/Math.abs(mu)*100:NaN; }
      else if(mt==="sd") v=caxSd(vals);
      else if(mt==="pexc"){ if(!(thr===thr)) throw new Error(CA_T("آستانه را وارد کنید","Enter the threshold")); v=vals.filter(q=>q>=thr).length/vals.length*100; }
      else if(mt==="q") v=caxQ(vals,qq);
      if(v===v) pts.push({...base(s), v}); }
    if(!ttl){ const N={spi:CA_T(`شاخص استاندارد ${isP?"بارش (SPI)":"شده (ناهنجاری z)"} سال ${FA(ay)}`,`Standardized index ${isP?"(SPI)":"(z)"} ${ay}`), pct:CA_T(`درصد از نرمال سال ${FA(ay)}`,`Percent of normal ${ay}`), rank:CA_T(`صدک سال ${FA(ay)} در سری`,`Percentile of ${ay}`), rl:CA_T(`مقدار دورهٔ بازگشت ${FA(T)} ساله`,`${T}-year return level`), cv:CA_T("ضریب تغییرات","Coefficient of variation"), sd:CA_T("انحراف معیار","Standard deviation"), pexc:CA_T(`احتمال ≥ ${caF(thr,1)} ${P.u}`,`P(≥ ${thr} ${P.ue})`), q:CA_T(`صدک ${FA(Math.round(qq*100))}٪`,`${Math.round(qq*100)}th percentile`)}[mt];
      ttl=`${N} — ${CA_T(P.fa,P.en)} — ${per_}`;
      if(mt==="spi"){ unit=CA_T("بدون بعد (≤ −۲ خشکسالی بسیار شدید، ≥ +۲ ترسالی بسیار شدید)","dimensionless (≤ −2 extreme drought, ≥ +2 extremely wet)"); kind="pdiv"; breaks=[-3,-2,-1.5,-1,-0.5,0.5,1,1.5,2,3]; if(!isP) kind="div"; }
      else if(mt==="pct"){ unit=CA_T("درصد از نرمال دوره","% of period normal"); kind="pdiv"; breaks=[0,25,50,75,90,110,125,150,200,300]; }
      else if(mt==="rank"){ unit=CA_T("صدک (۰ = کمترین، ۱۰۰ = بیشترین سال دوره)","percentile (0 = lowest, 100 = highest)"); kind=isP?"pdiv":"div"; breaks=[0,10,20,33,45,55,67,80,90,100]; }
      else if(mt==="rl"){ unit=U+CA_T(` (GEV با گشتاورهای L؛ گامبل اگر GEV نشد) — ${FA(T)} ساله`,` (GEV by L-moments; Gumbel fallback) — ${T}-year`); useElev=P.elev; clampMin=(P.agg!=="mean"&&P.kind!=="t")?0:null; }
      else if(mt==="cv"){ unit=CA_T("درصد","percent"); kind="h"; clampMin=0; }
      else if(mt==="sd"){ unit=U; kind="h"; clampMin=0; }
      else if(mt==="pexc"){ unit=CA_T("درصد سال‌ها","% of years"); kind=isP?"p":"h"; breaks=[0,5,10,20,30,40,50,60,70,80,90,100]; }
      else { unit=U; useElev=P.elev; clampMin=(P.agg!=="mean"&&P.kind!=="t")?0:null; } }
    const pc=CA_T("٪","%"), uS={corr:"",pcor:"",mr2:"",spi:"",pct:pc,rank:pc,cv:pc,pexc:pc,anap:pc,ana:isP?pc:" "+U}[mt];
    const AN=(mt==="ana"||mt==="anap")?caxAnalogYears(y0,y1):null, idxs=(mt==="mr2"||mt==="pcor")?caxIdxList():null;
    const rep={mt, p, per, y0, y1, ay, T, thr, q:Math.round(qq*100), lag:Math.max(0,Math.min(12,+$("caLag").value||0)), idxs, desc:AN?AN.desc:"", years:AN?AN.years:[], unitShort: uS!==undefined?uS:" "+U};
    const mmP=(p==="prcp"||p==="pmax"), isT=P.kind==="t";
    const scheme={spi:isP?"panom":"tanom", pct:"panom", ana:isT?"tanom":isP?"panom":"tanom", anap:isT?"tanom":"panom", pcor:"tanom", rl:mmP?"wmp":isT?"wmt":null, q:mmP?"wmp":isT?"wmt":null}[mt]||null;
    const center=mt==="pct"?100:0;
    await caxDrawMap(pts, ttl, CA_T(`دورهٔ ${FA(y0)} تا ${FA(y1)}`,`${y0}–${y1}`), unit, kind, {breaks, clampMin, useElev, note, cardNote, rep, scheme, center});
    caStatus("",1);
  }catch(e){ console.error(e); caStatus("⚠ "+e.message,0); }
  CA.busy=false;
}
// ---------- نمودارهای تکمیلی ----------
async function caxChart(kind){
  if(CA.busy) return; CA.busy=true;
  try{ await caLoad(); await document.fonts.ready;
    const sts=caSelected(), p=$("caPar").value, per=caPerSel(), y0=+$("caY0").value, y1=+$("caY1").value, P=CA_P[p], en=LANG==="en", per_=caPerName(per), lag=Math.max(0,Math.min(12,+$("caLag").value||0));
    if(kind!=="imat" && !sts.length) throw new Error(CA_T("دست‌کم یک ایستگاه انتخاب کنید","Select at least one station"));
    caStatus(CA_T("در حال محاسبه…","Computing…"),0.3); await new Promise(r=>setTimeout(r,20));
    const s0=sts[0], nm=s0?caStName(s0):"";
    if(kind==="multi"){
      const idx=caxIdxList(); if(!idx.length) throw new Error(CA_T("دست‌کم یک شاخص تیک بزنید","Tick at least one index"));
      const I=idx.map(n=>caxIdx(n,lag)), m=caxVals(s0,p,per,y0,y1), X=[], y=[], yr=[];
      for(const [yy,v] of m){ const r=I.map(M=>M.get(yy)); if(r.every(q=>q!==undefined)){ X.push(r); y.push(v); yr.push(yy); } }
      if(y.length<idx.length+6) throw new Error(CA_T("سال‌های مشترک کافی نیست","Not enough common years"));
      const simple=idx.map((_,j)=>caPearson(X.map(r=>r[j]),y)), o=caxOLS(X,y), vif=caxVIF(X);
      const lab=idx, vals=simple.map(q=>q.r);
      const foot=[CA_T(`ستون: همبستگی ساده (r) هر شاخص · برچسب: r / همبستگی جزئی / بتای استاندارد · n = ${FA(y.length)} سال`,`Bars: simple r · labels: r / partial r / standardized β · n = ${y.length}`),
        o?CA_T(`رگرسیون چندگانه: R² = ${caF(o.R2,2)} · R² تعدیل‌شده = ${caF(o.aR2,2)} · F = ${caF(o.F,2)} (p = ${caF(o.pF,3)}) · ${o.pF<0.05?"مدل معنی‌دار":"مدل غیرمعنی‌دار"}`,`Multiple regression: R² = ${caF(o.R2,2)} · adj. R² = ${caF(o.aR2,2)} · F = ${caF(o.F,2)} (p = ${caF(o.pF,3)})`):"",
        CA_T(`هم‌خطی (VIF): ${idx.map((n,j)=>`${n} ${caF(vif[j],1)}`).join(" · ")} — VIF بیش از ۵ یعنی شاخص‌ها هم‌پوشانی زیادی دارند`,`Collinearity (VIF): ${idx.map((n,j)=>`${n} ${caF(vif[j],1)}`).join(" · ")} — VIF > 5 means strong overlap`),
        CA_T(`خط‌چین نارنجی: آستانهٔ معنی‌داری ۵٪ برای r (±${caF(caRcrit(y.length),2)})`,`Orange dashed: 5% significance for r (±${caF(caRcrit(y.length),2)})`)];
      const cv=caxBars(CA_T(`تحلیل چندشاخصی ${P.fa} — ${nm}`,`Multi-index analysis of ${P.en} — ${nm}`), CA_T(`${per_} · دورهٔ شاخص: ${caPerName(caxIdxPer())} · تأخیر ${FA(lag)} ماه · ${FA(yr[0])} تا ${FA(yr[yr.length-1])}`,`${per_} · index period ${caPerName(caxIdxPer())} · lag ${lag} · ${yr[0]}–${yr[yr.length-1]}`),
        lab, vals, {ymin:-1, ymax:1, ylab:"r", hline:[caRcrit(y.length),-caRcrit(y.length)], foot, H:640, color:(v,i)=>simple[i].p<0.05?(v>=0?"#1d4ed8":"#b91c1c"):(v>=0?"#93c5fd":"#fca5a5"),
          keepLab:true, vlab:(v,i)=>`${caF(v,2)} / ${o?caF(o.coef[i].pr,2):"—"} / ${o?caF(o.coef[i].beta,2):"—"}`});
      if(!cv) throw new Error("—"); cv.__rep={type:"multi", p, per, idxs:idx, o, vif}; caCard(CA_T("تحلیل چندشاخصی","Multi-index analysis")+" — "+nm, cv);
      // سری مشاهده و برازش رگرسیون
      if(o){ const W=980,H=520,[c2,x]=caCanvas(W,H), L=78, R=W-30, T=96, B=H-90; caFrame(x,W,H,CA_T(`مشاهده و برازش رگرسیون چندگانه — ${nm}`,`Observed vs multiple-regression fit — ${nm}`),CA_T(`${P.fa} · ${per_} · خط آبی: مشاهده، خط قرمز: برازش با ${idx.join("+")}`,`${P.en} · ${per_} · blue: observed, red: fitted (${idx.join("+")})`));
        const all=[...y,...o.fit], A=caAxes(x,L,T,R,B,0,1,Math.min(...all),Math.max(...all),{zero:true,ylab:CA_T(P.u,P.ue)}), X_=k=>en? L+(k+0.5)/y.length*(R-L) : R-(k+0.5)/y.length*(R-L);
        for(const [arr,col] of [[y,"#2563eb"],[o.fit,"#dc2626"]]){ x.strokeStyle=col; x.lineWidth=2; x.beginPath(); arr.forEach((v,k)=>k?x.lineTo(X_(k),A.Y(v)):x.moveTo(X_(k),A.Y(v))); x.stroke(); }
        const st=Math.max(1,Math.ceil(yr.length/14)); for(let k=0;k<yr.length;k+=st) txt(x,FA(yr[k]),X_(k),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"});
        caBrand(x,W,H); c2.__rep={type:"fit", p, o, y}; caCard(CA_T("برازش رگرسیون چندگانه","Multiple-regression fit")+" — "+nm, c2); } }
    else if(kind==="imat"){
      const idx=caxIdxList(); if(idx.length<2) throw new Error(CA_T("دست‌کم دو شاخص تیک بزنید","Tick at least two indices"));
      const I=idx.map(n=>caxIdx(n,lag)), ys=[...I[0].keys()].filter(y=>y>=y0&&y<=y1&&I.every(M=>M.has(y)));
      const n=idx.length, W=Math.max(640,120+n*70), H=Math.max(560,170+n*60), [c,x]=caCanvas(W,H); caFrame(x,W,H,CA_T("ماتریس همبستگی شاخص‌ها","Index correlation matrix"),CA_T(`${caPerName(caxIdxPer())} · ${FA(ys[0])} تا ${FA(ys[ys.length-1])} · ${FA(ys.length)} سال · ستاره: معنی‌دار ۵٪`,`${caPerName(caxIdxPer())} · ${ys[0]}–${ys[ys.length-1]} · ${ys.length} years · *: significant at 5%`));
      const pairs=[]; const cs=Math.min(70,(W-160)/n), X0=(W-cs*n)/2+40, Y0=100, pal=CA_PALS.div.map(hexRGB);
      for(let i=0;i<n;i++){ txt(x,idx[i],X0-8,Y0+cs*(i+0.5)+4,`bold 12px ${FT.body}`,{align:"right",color:"#0f172a",dir:"ltr"}); txt(x,idx[i],X0+cs*(i+0.5),Y0-8,`bold 12px ${FT.body}`,{align:"center",color:"#0f172a",dir:"ltr"});
        for(let j=0;j<n;j++){ const q=caPearson(ys.map(y=>I[i].get(y)),ys.map(y=>I[j].get(y))), k=Math.max(0,Math.min(pal.length-1,Math.round((q.r+1)/2*(pal.length-1)))), col=pal[k];
          if(j>i) pairs.push({a:idx[i],b:idx[j],r:q.r,p:q.p}); x.fillStyle=`rgb(${col})`; x.fillRect(X0+cs*j,Y0+cs*i,cs-2,cs-2); txt(x,caF(q.r,2)+(i!==j&&q.p<0.05?"*":""),X0+cs*(j+0.5),Y0+cs*(i+0.5)+4,`bold 12px ${FT.body}`,{align:"center",color:Math.abs(q.r)>0.55?"#fff":"#0f172a",dir:"ltr"}); } }
      caBrand(x,W,H); c.__rep={type:"imat", pairs}; caCard(CA_T("ماتریس همبستگی شاخص‌ها","Index correlation matrix"), c); }
    else if(kind==="analog"){
      const A=caxAnalogYears(y0,y1); if(A.years.length<2) throw new Error(CA_T(`فقط ${FA(A.years.length)} سال آنالوگ پیدا شد؛ شرط‌ها را بازتر کنید.`,`Only ${A.years.length} analog years; relax the conditions.`));
      const R=sts.slice(0,14).map(s=>({s, c:caxComposite(s,p,per,y0,y1,A.years)})).filter(o=>o.c);
      if(!R.length) throw new Error(CA_T("ایستگاه‌های انتخابی در سال‌های آنالوگ داده ندارند","Selected stations have no data in the analog years"));
      const isP=R[0].c.isP, st=v=>isP?(v>=10?CA_T("بیش از نرمال","above normal"):v<=-10?CA_T("کمتر از نرمال","below normal"):CA_T("نزدیک نرمال","near normal")):(v>=0.5?CA_T("گرم‌تر از نرمال","warmer"):v<=-0.5?CA_T("سردتر از نرمال","colder"):CA_T("نزدیک نرمال","near normal"));
      const foot=[CA_T(`شرط: ${A.desc}`,`Conditions: ${A.desc}`), CA_T(`سال‌های آنالوگ (${FA(A.years.length)}): ${A.years.map(FA).join("، ")}`,`Analog years (${A.years.length}): ${A.years.join(", ")}`),
        CA_T(`برچسب: ناهنجاری ترکیبی · احتمال بیش از نرمال (بالاتر از میانه) · p آزمون t ولش (آنالوگ در برابر سایر سال‌ها). رنگ پررنگ = معنی‌دار در سطح ۱۰٪`,`Label: composite anomaly · P(above median) · Welch t-test p. Dark = significant at 10%`)];
      const cv=caxBars(CA_T(`آنالوگ ${P.fa} — ${per_}`,`Analog composite of ${P.en} — ${per_}`), CA_T(`نرمال = میانگین ${FA(y0)} تا ${FA(y1)} · ${isP?"درصد اختلاف از نرمال":"اختلاف از نرمال ("+P.u+")"} · دورهٔ شاخص: ${caPerName(caxIdxPer())}`,`Normal = mean ${y0}–${y1} · ${isP?"% departure":"departure ("+P.ue+")"} · index period ${caPerName(caxIdxPer())}`),
        R.map(o=>caStName(o.s)), R.map(o=>o.c.anom), {ylab:isP?"%":CA_T(P.u,P.ue), foot, H:640, color:(v,i)=>R[i].c.p<0.1?(v>=0?(isP?"#1d4ed8":"#b91c1c"):(isP?"#b45309":"#1d4ed8")):(v>=0?(isP?"#93c5fd":"#fca5a5"):(isP?"#fcd34d":"#93c5fd")),
          vlab:(v,i)=>`${v>=0?"+":""}${caF(v,isP?0:1)}${isP?"٪":""} · ${FA(Math.round(R[i].c.above*100))}٪ · p ${caF(R[i].c.p,2)}`});
      if(cv) cv.__rep={type:"analog", p, per, desc:A.desc, years:A.years, R}; caCard(CA_T("آنالوگ","Analog")+" — "+CA_T(P.fa,P.en), cv);
      // ایستگاه اول: سال‌به‌سال و سه‌دهک
      const c=R[0].c; const cv2=caxBars(CA_T(`سال‌های آنالوگ — ${caStName(R[0].s)}`,`Analog years — ${caStName(R[0].s)}`), CA_T(`${P.fa} · ${per_} · وضعیت ترکیبی: ${st(c.anom)}`,`${P.en} · ${per_} · composite: ${st(c.anom)}`),
        c.years.map(FA), c.per, {ylab:isP?"%":CA_T(P.u,P.ue), hline:c.anom, H:600, foot:[CA_T(`احتمال سه‌دهک‌ها در سال‌های آنالوگ: کمتر از نرمال ${FA(Math.round(c.tb*100))}٪ · نزدیک نرمال ${FA(Math.round(c.tn*100))}٪ · بیش از نرمال ${FA(Math.round(c.ta*100))}٪ (اقلیم: هر کدام ۳۳٪)`,`Tercile probabilities in analog years: below ${Math.round(c.tb*100)}% · near ${Math.round(c.tn*100)}% · above ${Math.round(c.ta*100)}% (climatology 33% each)`),
          CA_T(`ناهنجاری استاندارد z = ${caF(c.z,2)} · خط‌چین: میانگین ترکیبی`,`z = ${caF(c.z,2)} · dashed: composite mean`)],
          color:v=>isP?(v>=0?"#2563eb":"#d97706"):(v>=0?"#dc2626":"#2563eb")});
      if(cv2){ cv2.__rep={type:"analog", p, per, desc:A.desc, years:A.years, R:[R[0]]}; } if(cv2) caCard(CA_T("سال‌های آنالوگ","Analog years")+" — "+caStName(R[0].s), cv2); }
    else if(kind==="dist"||kind==="rp"||kind==="spi"||kind==="pett"||kind==="rcor"){
      const m=caxVals(s0,p,per,y0,y1), ys=[...m.keys()].sort((a,b)=>a-b), vals=ys.map(y=>m.get(y)); if(vals.length<10) throw new Error(CA_T("دست‌کم ۱۰ سال داده لازم است","At least 10 years are needed"));
      const W=980,H=560,[c,x]=caCanvas(W,H), L=78, R=W-30, T=96, B=H-118, U=CA_T(P.u,P.ue); let REP={type:kind, p, per, vals};
      if(kind==="dist"){ const st=caStats(vals), q=[0.1,0.25,0.5,0.75,0.9].map(z=>caxQ(vals,z)), nb=Math.min(14,Math.max(6,Math.round(Math.sqrt(vals.length)))), lo=st.min, hi=st.max, w=(hi-lo)/nb||1, h=new Array(nb).fill(0);
        vals.forEach(v=>h[Math.min(nb-1,Math.floor((v-lo)/w))]++);
        caFrame(x,W,H,CA_T(`توزیع ${P.fa} — ${nm}`,`Distribution of ${P.en} — ${nm}`),CA_T(`${per_} · ${FA(ys[0])} تا ${FA(ys[ys.length-1])} · ${FA(vals.length)} سال`,`${per_} · ${ys[0]}–${ys[ys.length-1]} · ${vals.length} years`));
        const A=caAxes(x,L,T,R,B-60,0,1,0,Math.max(...h),{ylab:CA_T("تعداد سال","years")}), X_=v=>en? L+(v-lo)/(hi-lo||1)*(R-L) : R-(v-lo)/(hi-lo||1)*(R-L);
        h.forEach((k,i)=>{ if(k) caBar3D(x,X_(lo+(i+0.5)*w),Math.abs(X_(lo+w)-X_(lo))*0.8,A.Y(k),A.Y(0),"#2563eb"); });
        for(let i=0;i<=4;i++){ const v=lo+i*(hi-lo)/4; txt(x,caF(v,1),X_(v),B-42,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"}); }
        const by=B-14; x.strokeStyle="#0f172a"; x.lineWidth=1.5; x.beginPath(); x.moveTo(X_(q[0]),by); x.lineTo(X_(q[4]),by); x.stroke(); x.fillStyle="#bfdbfe"; x.fillRect(Math.min(X_(q[1]),X_(q[3])),by-9,Math.abs(X_(q[3])-X_(q[1])),18); x.strokeRect(Math.min(X_(q[1]),X_(q[3])),by-9,Math.abs(X_(q[3])-X_(q[1])),18);
        x.beginPath(); x.moveTo(X_(q[2]),by-9); x.lineTo(X_(q[2]),by+9); x.strokeStyle="#dc2626"; x.lineWidth=2.5; x.stroke();
        txt(x,CA_T(`نمودار جعبه‌ای: صدک‌های ۱۰، ۲۵، ۵۰، ۷۵ و ۹۰`,`Box plot: P10/25/50/75/90`),en?40:W-40,H-70,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:W-80}); }
      else if(kind==="rp"){ const g=caxGev(vals), gu=caxGumbel(vals), Ts=[2,5,10,25,50,100,200], srt=vals.slice().sort((a,b)=>b-a), n=srt.length;
        caFrame(x,W,H,CA_T(`دورهٔ بازگشت ${P.fa} — ${nm}`,`Return levels of ${P.en} — ${nm}`),CA_T(`${per_} · نقاط: مشاهده (موقعیت ترسیم ویبول) · قرمز: GEV (گشتاورهای L) · خط‌چین: گامبل`,`${per_} · dots: observed (Weibull) · red: GEV (L-moments) · dashed: Gumbel`));
        const lx=t=>Math.log(Math.log(t)+1e-9), xmin=lx(1.05), xmax=lx(250), allv=[...vals,...(g?Ts.map(g.q):[]),...(gu?Ts.map(gu.q):[])].filter(v=>isFinite(v));
        const A=caAxes(x,L,T,R,B,0,1,Math.min(...allv),Math.max(...allv),{zero:true,ylab:U}), X_=t=>{ const f=(lx(t)-xmin)/(xmax-xmin); return en? L+f*(R-L) : R-f*(R-L); };
        for(const t of Ts) { txt(x,FA(t),X_(t),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"}); }
        txt(x,CA_T("دورهٔ بازگشت (سال)","Return period (years)"),(L+R)/2,B+36,`12px ${FT.body}`,{align:"center",color:"#475569",dir:en?"ltr":"rtl"});
        const curve=(f,col,dash)=>{ if(!f) return; x.setLineDash(dash||[]); x.strokeStyle=col; x.lineWidth=2.2; x.beginPath(); let st_=false; for(let t=1.05;t<=250;t*=1.06){ const v=f.q(t); if(!isFinite(v)) continue; st_?x.lineTo(X_(t),A.Y(v)):x.moveTo(X_(t),A.Y(v)); st_=true; } x.stroke(); x.setLineDash([]); };
        curve(gu,"#64748b",[6,4]); curve(g,"#dc2626");
        srt.forEach((v,i)=>{ const t=(n+1)/(i+1); if(t<1.05) return; x.fillStyle="#1d4ed8"; x.beginPath(); x.arc(X_(t),A.Y(v),3.6,0,7); x.fill(); });
        const tb=Ts.map(t=>FA(t)).join(" · ");
        txt(x,CA_T(`دوره‌های بازگشت (${g?"GEV":"گامبل"}، سال) — ${tb}`,`Return periods (${g?"GEV":"Gumbel"}, years) — ${tb}`),en?40:W-40,H-62,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:W-80});
        REP={...REP, g, gu};
        if(g) txt(x,CA_T(`برازش GEV انجام شد · ${g.k<0?"دنبالهٔ سنگین (k<0)":"دنبالهٔ سبک (k≥0)"}`,`GEV fitted · ${g.k<0?"heavy tail (k<0)":"light tail (k≥0)"}`),en?40:W-40,H-42,`12px ${FT.body}`,{align:en?"left":"right",color:"#475569",dir:en?"ltr":"rtl",maxW:W-80}); }
      else if(kind==="spi"){ const isP=P.kind==="p", f=isP?caxSpiFit(vals):null, mu=caxMean(vals), sd=caxSd(vals), z=vals.map(v=>f?f(v):(v-mu)/(sd||1));
        caFrame(x,W,H,CA_T(`${isP?"SPI":"ناهنجاری استاندارد"} — ${nm}`,`${isP?"SPI":"Standardized anomaly"} — ${nm}`),CA_T(`${P.fa} · ${per_} · ${isP?"برازش گاما (Thom)، احتمال صفر جدا":"z = (x − میانگین) / انحراف معیار"}`,`${P.en} · ${per_}`));
        const A=caAxes(x,L,T,R,B,0,1,Math.min(-2.5,...z),Math.max(2.5,...z),{zero:true,ylab:isP?"SPI":"z"}), X_=k=>en? L+(k+0.5)/ys.length*(R-L) : R-(k+0.5)/ys.length*(R-L), bw=Math.max(3,(R-L)/ys.length*0.7);
        z.forEach((v,k)=>caBar3D(x,X_(k),bw,A.Y(v),A.Y(0), v<=-2?"#7f1d1d":v<=-1.5?"#b91c1c":v<=-1?"#f97316":v<0?"#fcd34d":v<1?"#86efac":v<1.5?"#22c55e":v<2?"#15803d":"#1e3a8a"));
        const step=Math.max(1,Math.ceil(ys.length/14)); for(let k=0;k<ys.length;k+=step) txt(x,FA(ys[k]),X_(k),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"});
        const dry=ys.filter((y,k)=>z[k]<=-1), wet=ys.filter((y,k)=>z[k]>=1); REP={...REP, z, ys, isP};
        txt(x,CA_T(`سال‌های خشک (≤ −۱): ${dry.map(FA).join("، ")||"—"}`,`Dry years (≤ −1): ${dry.join(", ")||"—"}`),en?40:W-40,H-70,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#b91c1c",dir:en?"ltr":"rtl",maxW:W-80});
        txt(x,CA_T(`سال‌های مرطوب (≥ +۱): ${wet.map(FA).join("، ")||"—"}`,`Wet years (≥ +1): ${wet.join(", ")||"—"}`),en?40:W-40,H-50,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#15803d",dir:en?"ltr":"rtl",maxW:W-80}); }
      else if(kind==="pett"){ const pt=caxPettitt(vals), cy=ys[pt.at], a=vals.slice(0,pt.at+1), b=vals.slice(pt.at+1), ma=caxMean(a), mb=caxMean(b); REP={...REP, pt, cy, ma, mb};
        caFrame(x,W,H,CA_T(`آزمون نقطهٔ تغییر پتیت — ${nm}`,`Pettitt change-point test — ${nm}`),CA_T(`${P.fa} · ${per_} · خط سبز: میانگین متحرک ۵ ساله · خط‌چین: میانگین پیش و پس از نقطهٔ تغییر`,`${P.en} · ${per_} · green: 5-yr moving mean · dashed: means before/after`));
        const A=caAxes(x,L,T,R,B,0,1,Math.min(...vals),Math.max(...vals),{zero:true,ylab:U}), X_=k=>en? L+(k+0.5)/ys.length*(R-L) : R-(k+0.5)/ys.length*(R-L);
        x.strokeStyle="#2563eb"; x.lineWidth=1.6; x.beginPath(); vals.forEach((v,k)=>k?x.lineTo(X_(k),A.Y(v)):x.moveTo(X_(k),A.Y(v))); x.stroke();
        x.strokeStyle="#059669"; x.lineWidth=2.4; x.beginPath(); let f=false; for(let k=2;k<vals.length-2;k++){ const v=caxMean(vals.slice(k-2,k+3)); f?x.lineTo(X_(k),A.Y(v)):x.moveTo(X_(k),A.Y(v)); f=true; } x.stroke();
        x.setLineDash([7,5]); x.strokeStyle="#dc2626"; x.lineWidth=2; x.beginPath(); x.moveTo(X_(0),A.Y(ma)); x.lineTo(X_(pt.at),A.Y(ma)); x.moveTo(X_(pt.at+1),A.Y(mb)); x.lineTo(X_(vals.length-1),A.Y(mb)); x.stroke(); x.setLineDash([]);
        const step=Math.max(1,Math.ceil(ys.length/14)); for(let k=0;k<ys.length;k+=step) txt(x,FA(ys[k]),X_(k),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"});
        txt(x,CA_T(`محتمل‌ترین نقطهٔ تغییر: پس از ${FA(cy)} · p = ${caF(pt.p,3)} (${pt.p<0.05?"تغییر معنی‌دار":"تغییر معنی‌دار نیست"})`,`Most likely change after ${cy} · p = ${caF(pt.p,3)}`),en?40:W-40,H-62,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:W-80}); }
      else if(kind==="rcor"){ const idx=$("caIdx").value, I=caxIdx(idx,lag), w=Math.max(9,Math.min(31,+$("caxWin").value||15)), pairs=ys.filter(y=>I.has(y)), r=[], yc=[];
        for(let k=0;k+w<=pairs.length;k++){ const yy=pairs.slice(k,k+w); r.push(caPearson(yy.map(y=>m.get(y)),yy.map(y=>I.get(y))).r); yc.push(yy[Math.floor(w/2)]); }
        if(r.length<3) throw new Error(CA_T("سال‌های مشترک برای پنجرهٔ متحرک کافی نیست","Not enough years for the moving window")); REP={...REP, idx, w, r, rc:caRcrit(w)};
        caFrame(x,W,H,CA_T(`همبستگی متحرک ${P.fa} با ${caIdxName(idx)} — ${nm}`,`Moving correlation of ${P.en} with ${idx} — ${nm}`),CA_T(`${per_} · پنجرهٔ ${FA(w)} ساله · خط‌چین: آستانهٔ معنی‌داری ۵٪ (±${caF(caRcrit(w),2)})`,`${per_} · ${w}-year window · dashed: 5% significance`));
        const A=caAxes(x,L,T,R,B,0,1,-1,1,{zero:true,ylab:"r"}), X_=k=>en? L+(k+0.5)/r.length*(R-L) : R-(k+0.5)/r.length*(R-L), rc=caRcrit(w);
        x.setLineDash([5,4]); x.strokeStyle="#f59e0b"; for(const s of [rc,-rc]){ x.beginPath(); x.moveTo(L,A.Y(s)); x.lineTo(R,A.Y(s)); x.stroke(); } x.setLineDash([]);
        x.strokeStyle="#7c3aed"; x.lineWidth=2.4; x.beginPath(); r.forEach((v,k)=>k?x.lineTo(X_(k),A.Y(v)):x.moveTo(X_(k),A.Y(v))); x.stroke();
        const step=Math.max(1,Math.ceil(yc.length/14)); for(let k=0;k<yc.length;k+=step) txt(x,FA(yc[k]),X_(k),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"});
        txt(x,CA_T("ناپایداری رابطه در زمان: اگر منحنی از آستانه بیرون و درون برود، اثر شاخص در همهٔ دوره‌ها یکسان نبوده است.","Instability of the relationship: crossings of the threshold mean the index effect varies over time."),en?40:W-40,H-62,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:W-80}); }
      caBrand(x,W,H); const TT={dist:CA_T("توزیع","Distribution"),rp:CA_T("دورهٔ بازگشت","Return levels"),spi:"SPI",pett:CA_T("نقطهٔ تغییر","Change point"),rcor:CA_T("همبستگی متحرک","Moving correlation")}[kind];
      c.__rep=REP; caCard(TT+" — "+nm, c); }
    caStatus("",1);
  }catch(e){ console.error(e); caStatus("⚠ "+e.message,0); }
  CA.busy=false;
}
// ---------- رابط کاربری ----------
function caxBuildUI(){
  const A=$("caAside"); if(!A || A.dataset.cax) return; A.dataset.cax=1;
  const idx=Object.keys(CLIM_META.idx.v), opt=idx.map(k=>`<option value="${k}">${caIdxName(k)}</option>`).join("");
  const perOpt=`<option value="same">${CA_T("همان دورهٔ پارامتر","Same as the parameter period")}</option>`+CA_PER.map(([v,f,e])=>`<option value="${v}">${CA_T(f,e)}</option>`).join("");
  const def=["NINO 3/4","ONI","QBO30","AMO","PDO","NAO","MEI v2","DMI"].filter(k=>idx.includes(k));
  const sec=document.createElement("div");
  sec.innerHTML=`
  <section class="panel"><h2>${CA_T("تحلیل چندشاخصی","Multi-index analysis")}</h2>
    <p class="hint">${CA_T("چند شاخص را هم‌زمان با پارامتر بسنجید: همبستگی ساده و جزئی، رگرسیون چندگانه و هم‌خطی شاخص‌ها. تأخیر از بخش «شاخص‌های اقلیمی» خوانده می‌شود.","Assess several indices together: simple and partial correlation, multiple regression and collinearity. The lag is taken from the Climate indices panel.")}</p>
    <div class="caxIdxBox">${idx.map(k=>`<label class="chk"><input type="checkbox" class="caxIdxChk" value="${k}" ${["NINO 3/4","QBO30","AMO"].includes(k)?"checked":""}> ${caIdxName(k)}</label>`).join("")}</div>
    <div class="row2"><label>${CA_T("دورهٔ شاخص","Index period")}<select id="caxIper">${perOpt}</select></label><label>${CA_T("سال شاخص","Index year")}<select id="caxIyr"><option value="0">${CA_T("همان سال پارامتر","Same year")}</option><option value="1">${CA_T("سال قبل (پیش‌نشانگر)","Previous year (predictor)")}</option></select></label></div>
    <div class="row2"><button class="btn main" type="button" id="caxBtnMulti">${CA_T("نمودار چندشاخصی","Multi-index chart")}</button><button class="btn" type="button" id="caxBtnImat">${CA_T("ماتریس همبستگی شاخص‌ها","Index correlation matrix")}</button></div></section>
  <section class="panel"><h2>${CA_T("آنالوگ (شرط روی شاخص‌ها)","Analogs (index conditions)")}</h2>
    <p class="hint">${CA_T("سال‌هایی که همهٔ شرط‌ها در آن‌ها برقرار بوده پیدا می‌شوند و وضعیت پارامتر در آن سال‌ها نسبت به نرمال (میانگین دورهٔ انتخابی) سنجیده می‌شود. دورهٔ شاخص و «سال قبل» از بخش بالا خوانده می‌شود.","Years in which all conditions hold are found and the parameter in those years is compared with the normal (period mean). Index period and “previous year” come from the panel above.")}</p>
    <div id="caxConds"></div>
    <button class="btn sm" type="button" id="caxAdd">${CA_T("+ افزودن شرط","+ Add condition")}</button>
    <div class="row2"><button class="btn main" type="button" id="caxBtnAn">${CA_T("نمودار آنالوگ ایستگاه‌ها","Station analog chart")}</button><button class="btn main" type="button" id="caxBtnAnMap">${CA_T("نقشهٔ آنالوگ","Analog map")}</button></div>
    <button class="btn" type="button" id="caxBtnAnP">${CA_T("نقشهٔ احتمال بیش/کمتر از نرمال","Above/below-normal probability map")}</button></section>
  <section class="panel"><h2>${CA_T("آمار تکمیلی ایستگاه","Further station statistics")}</h2>
    <p class="hint">${CA_T("برای اولین ایستگاه انتخابی و ماه/دورهٔ بالا.","For the first selected station and the period above.")}</p>
    <div class="row2"><button class="btn" type="button" data-cax="dist">${CA_T("توزیع و صدک‌ها","Distribution & percentiles")}</button><button class="btn" type="button" data-cax="rp">${CA_T("دورهٔ بازگشت (GEV/گامبل)","Return periods (GEV/Gumbel)")}</button></div>
    <div class="row2"><button class="btn" type="button" data-cax="spi">${CA_T("SPI / ناهنجاری استاندارد","SPI / standardized anomaly")}</button><button class="btn" type="button" data-cax="pett">${CA_T("نقطهٔ تغییر (پتیت)","Change point (Pettitt)")}</button></div>
    <div class="row2"><label>${CA_T("پنجرهٔ همبستگی متحرک (سال)","Moving-correlation window (years)")}<input type="number" id="caxWin" value="15" min="9" max="31"></label><button class="btn" type="button" data-cax="rcor">${CA_T("همبستگی متحرک با شاخص","Moving correlation with index")}</button></div></section>`;
  A.append(...sec.children);
  const addCond=(c={})=>{ const box=$("caxConds"); if(box.children.length>=5) return; const r=document.createElement("div"); r.className="caxCond";
    r.innerHTML=`<select class="ci">${opt}</select><select class="co"><option value="between">${CA_T("بین","between")}</option><option value="ge">≥</option><option value="le">≤</option><option value="pos">${CA_T("فاز مثبت قوی (≥ +۱σ)","strong + (≥ +1σ)")}</option><option value="neg">${CA_T("فاز منفی قوی (≤ −۱σ)","strong − (≤ −1σ)")}</option><option value="zpos">${CA_T("مثبت (z ≥ ۰٫۵)","positive (z ≥ 0.5)")}</option><option value="zneg">${CA_T("منفی (z ≤ −۰٫۵)","negative (z ≤ −0.5)")}</option><option value="neu">${CA_T("خنثی (|z| < ۰٫۵)","neutral (|z| < 0.5)")}</option></select><input class="ca" type="number" step="any" placeholder="${CA_T("از","from")}"><input class="cb" type="number" step="any" placeholder="${CA_T("تا","to")}"><button type="button" class="btn sm" title="${CA_T("حذف","Remove")}">×</button>`;
    r.querySelector(".ci").value=c.idx||def[box.children.length]||idx[0]; r.querySelector(".co").value=c.op||"between"; if(c.a!=null) r.querySelector(".ca").value=c.a; if(c.b!=null) r.querySelector(".cb").value=c.b;
    const upd=()=>{ const op=r.querySelector(".co").value; r.querySelector(".ca").hidden=!["between","ge","le"].includes(op); r.querySelector(".cb").hidden=op!=="between"; }; r.querySelector(".co").onchange=upd; upd();
    r.querySelector("button").onclick=()=>r.remove(); box.append(r); };
  addCond({idx:idx.includes("NINO 3/4")?"NINO 3/4":idx[0], op:"ge", a:0.5}); addCond({idx:idx.includes("QBO30")?"QBO30":idx[1], op:"zneg"});
  $("caxAdd").onclick=()=>addCond();
  $("caxBtnMulti").onclick=()=>caxChart("multi"); $("caxBtnImat").onclick=()=>caxChart("imat"); $("caxBtnAn").onclick=()=>caxChart("analog");
  $("caxBtnAnMap").onclick=()=>{ $("caMapType").value="ana"; $("caMapType").onchange(); caDo("map"); };
  $("caxBtnAnP").onclick=()=>{ $("caMapType").value="anap"; $("caMapType").onchange(); caDo("map"); };
  A.querySelectorAll("[data-cax]").forEach(b=>b.onclick=()=>caxChart(b.dataset.cax));
  // انواع نقشهٔ تکمیلی
  const sel=$("caMapType"); const og=document.createElement("optgroup"); og.label=CA_T("آمار تکمیلی","Further statistics");
  for(const [v,f,e] of [["spi","شاخص بارش استاندارد (SPI) / ناهنجاری استاندارد یک سال","SPI / standardized anomaly of one year"],["pct","درصد از نرمال یک سال","Percent of normal (one year)"],["rank","صدک (رتبه) یک سال در سری","Percentile rank of one year"],
    ["rl","مقدار دورهٔ بازگشت (GEV)","Return level (GEV)"],["q","مقدار صدک دلخواه","Chosen percentile value"],["pexc","احتمال عبور از آستانه","Probability of exceeding a threshold"],["cv","ضریب تغییرات","Coefficient of variation"],["sd","انحراف معیار","Standard deviation"]]){ const o=document.createElement("option"); o.value=v; o.textContent=CA_T(f,e); og.append(o); }
  const og2=document.createElement("optgroup"); og2.label=CA_T("چندشاخصی و آنالوگ","Multi-index & analogs");
  for(const [v,f,e] of [["mr2","R² رگرسیون چندگانه با شاخص‌های تیک‌خورده","Multiple-regression R² with ticked indices"],["pcor","همبستگی جزئی با اولین شاخص تیک‌خورده","Partial correlation with the first ticked index"],["ana","نقشهٔ آنالوگ (ناهنجاری ترکیبی)","Analog map (composite anomaly)"],["anap","احتمال بیش از نرمال منهای کمتر از نرمال (آنالوگ)","Analog P(above) − P(below)"]]){ const o=document.createElement("option"); o.value=v; o.textContent=CA_T(f,e); og2.append(o); }
  sel.append(og,og2);
  const row=document.createElement("div"); row.className="row2"; row.id="caxMapPar"; row.hidden=true;
  row.innerHTML=`<label id="caxTRow">${CA_T("دورهٔ بازگشت (سال)","Return period (years)")}<input type="number" id="caxT" value="50" min="2" max="500"></label><label id="caxThrRow">${CA_T("آستانه","Threshold")}<input type="number" id="caxThr" step="any" placeholder="${CA_T("مثلاً ۳۰","e.g. 30")}"></label><label id="caxQRow">${CA_T("صدک (٪)","Percentile (%)")}<input type="number" id="caxQ" value="90" min="1" max="99"></label>`;
  $("caAnYRow").after(row);
  const old=sel.onchange; sel.onchange=()=>{ const v=sel.value; if(old) old(); $("caAnYRow").hidden=!["anom","spi","pct","rank"].includes(v); row.hidden=!["rl","pexc","q"].includes(v);
    $("caxTRow").hidden=v!=="rl"; $("caxThrRow").hidden=v!=="pexc"; $("caxQRow").hidden=v!=="q"; };
}
{ const _cb=caBuildUI; caBuildUI=function(){ _cb(); try{ caxBuildUI(); }catch(e){ console.error("cax ui",e); } }; }
