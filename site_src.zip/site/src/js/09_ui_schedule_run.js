/* ---------- زمان‌بندی اجرا ---------- */
const timers={};
function schedule(_, delay=350, scope="all"){
  clearTimeout(timers[scope]); timers[scope]=setTimeout(()=>run(scope), delay);
}
function settings(){
  let initTxt = `اجرای ${FA($("initH").value)} UTC، ${faDate($("initD").value)}`;
  let from = "از " + faDate($("t0").value, true), to = "تا " + faDate($("t1").value, true);
  const A = !state.timeManual && aggregateTimes();
  // زمان از نقشه خوانده نشد و کاربر هم وارد نکرده: تاریخ پیش‌فرض ساختگی روی نقشه نمی‌آید
  if(!A && !state.timeManual && state.models.some(m=>m.ok)){ from=""; to=""; initTxt=""; }
  if(A){
    const mode=$("tzMode").value, off = mode==="src" ? A.offset : (mode==="ir" ? 210 : 0), suf=tzSuffix(off), V=curVar();
    if(V.accum){ from="از "+persianDT(A.start,off)+suf; to="تا "+persianDT(A.end,off)+suf; }
    else { const v0=new Date(Math.min(...A.ts.map(x=>+x.end))), v1=A.end;
      if(+v0===+v1){ from="معتبر برای "+persianDT(v1,off)+suf; to=""; } else { from="از "+persianDT(v0,off)+suf; to="تا "+persianDT(v1,off)+suf; } }
    if(A.inits.length===1){ const i=A.inits[0]; initTxt=`اجرای ${FA(String(i.getUTCHours()).padStart(2,"0"))} UTC، ${faDate(i.toISOString().slice(0,10))}`; }
    else if(A.inits.length>1){ const a=A.inits[0], b=A.inits[A.inits.length-1]; initTxt=`اجراهای ${FA(String(a.getUTCHours()).padStart(2,"0"))} UTC ${faDate(a.toISOString().slice(0,10))} تا ${FA(String(b.getUTCHours()).padStart(2,"0"))} UTC ${faDate(b.toISOString().slice(0,10))}`; }
    else initTxt="";
  }
  return {
    from, to,
    region: $("region").value.trim(), init: initTxt,
    gOff: Math.max(0, parseFloat($("gOff").value)||3),
    thr: [...new Set($("thr").value.split(/[,،;\s]+/).map(s=>parseFloat(s.replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace("٫",".").replace("−","-"))).filter(v=>Number.isFinite(v) && (!curVar().accum || v>0)))],
    sigma: Math.max(0, parseFloat($("sigma").value)||0), nep: parseFloat($("nep").value)||0, cap: P.useCap ? ((P.variant==="h24"||P.variant==="h1") ? ({400:200, 500:300}[$("cap").value] ?? Infinity) : +$("cap").value) : Infinity, barMode: $("barMode").value, borders: $("borders").value, grid: $("gridLines").value==="1", showBorders: $("showBorders").checked,
    brand: $("brand").value.trim(), handle: $("handle").value.trim(), logoImg: state.logoImg, ttZoom: store.get("tt.zoom","me")
  };
}

async function run(scope="all"){
  if(!P) return;
  if(state.busy){ state.pending = (state.pending && state.pending!==scope) ? "all" : scope; return; }
  let all = state.models.filter(m=>m.ok);
  if(!all.length){ $("grid").innerHTML=""; state.cards={}; state.order=[]; if(state.models.length) setStatus("هیچ نقشهٔ معتبری نیست",0); return; }
  state.busy=true; $("run").disabled=true;
  try{
    const S = settings();
    if(P.custom){
      if(P.dirty || !P.T){
        setStatus("تشخیص کادر، نوار رنگ و زمینه…", 0.02); await tick();
        const T = detectTemplate(all);
        const saved = store.get("tpl."+T.fp, null);
        if(saved && saved.rev){ T.colors.reverse(); T.segs.reverse(); T.segCenters.reverse(); }
        const g = guessScale(T.colors, T);
        let txt0 = (P.T && P.T.fp===T.fp) ? $("tplEdges").value : (g&&g.kind ? g.edges : saved ? saved.edges : (g ? g.edges : ""));
        state.edgeAuto=null;
        if(T.nwp) txt0=T.nwp.e;
        if(!txt0 && T.tt){ try{ if(!CV_OCR_T) await cvOcrFonts();
          if(T.segs.length>60){ const e=ttGradientEdges(all[0], T); if(e){ txt0=e; state.edgeAuto={txt:e}; } }
          else { const r=ttBarEdges(all[0], T); if(r){ txt0=r.txt; state.edgeAuto=r; } } }catch(e){ console.warn("tt edges", e); } }
        if(!txt0){ try{ if(!CV_OCR_T) await cvOcrFonts(); const rd=cvReadBar({data:all[0].data, w:all[0].w, h:all[0].h, prof:{T, segs:T.segs, bar:T.bar}}); if(rd){ txt0=rd.txt; state.edgeAuto=rd; } }catch(e){ console.warn("auto edges", e); } }
        $("tplEdges").value = txt0;
        const savedGeoOK = !!(saved && Array.isArray(saved.geo) && saved.geo.every(v=>v!==""&&v!=null&&isFinite(+v)));
        if(T.nwp){ const g=nwpGeoWESN(T.nwp.g); ["geoW","geoE","geoS","geoN"].forEach((id,k)=>$(id).value = +g[k].toFixed(4)); $("region").value=NWP_REG_FA[T.nwp.g]||"ایران"; }
        else if(savedGeoOK) ["geoW","geoE","geoS","geoN"].forEach((id,k)=>$(id).value = saved.geo[k]);
        else if(T.tt && T.tt.geo) ["geoW","geoE","geoS","geoN"].forEach((id,k)=>$(id).value = T.tt.geo[k]);
        else if(T.wm) ["geoW","geoE","geoS","geoN"].forEach((id,k)=>$(id).value = T.wm.geo[k]);
        if(T.wm) await wmLinesLoad();
        else if(T.tt && !T.tt.geo && !savedGeoOK) ["geoW","geoE","geoS","geoN"].forEach(id=>$(id).value="");   // فقط زوم ناشناخته: کاربر وارد می‌کند
        if(T.tt && T.tt.me && (!$("region").value.trim() || $("region").value.trim()==="ایران")) $("region").value="خاورمیانه";
        if(T.wx && (!$("region").value.trim() || $("region").value.trim()==="ایران")) $("region").value="خاورمیانه";
        state.ttNote = T.tt ? (T.tt.geo ? "نقشهٔ tropicaltidbits — زوم خاورمیانه شناسایی شد (۲۰ تا ۶۵ درجهٔ شرقی، ۱۲ تا ۴۲ درجهٔ شمالی)" : "نقشهٔ tropicaltidbits با زوم غیر از خاورمیانه؛ مختصات گوشه‌های کادر را در «قالب نقشه‌ها» وارد کنید تا برای این زوم ذخیره شود") : "";
        if(T.nwp) state.ttNote = nwpNote(T.nwp);
        if(T.wx) state.ttNote = "نقشهٔ WXCharts (MetDesk) شناسایی شد: "+T.wx.name;
        if(T.wm) state.ttNote = "نقشهٔ weathermodels.com شناسایی شد: "+T.wm.name+" — زمین‌مرجع خودکار (مرز ایران روی خطوط نقشه برازش شده)";
        applyCustom(T, txt0); P.rev = !!(saved && saved.rev);
        await useProfile("cu"); P.dirty = false; P.staticDirty = true;
        all.forEach(m=>{ m.mm=null; m.hit={}; m.rects=P.invalid(); });
        drawTemplatePanel(); detectVariable();
      }
      if(P.edges) await useProfile("cu");
      if(!P.edges){ setStatus("اعداد نوار رنگ را در «قالب نقشه‌ها» وارد یا تأیید کنید", 0); state.busy=false; $("run").disabled=false; drawTemplatePanel(); return; }
      if(P.staticDirty){
        setStatus("جداسازی مرزها و نوشته‌های ثابت…", 0.05); await tick();
        await useProfile("cu"); computeStatic(all); P.staticDirty=false; detectRegion("static"); S.region=$("region").value.trim();
        // tropicaltidbits: خطوط مرز از یک تصویر رنگ دادهٔ زیرشان را دارند؛ به خاکستری خنثی (سیاه برای مرز کشورها) برگردانده می‌شوند
        if(P.T && P.T.tt && P.ov && P.ov.bold){ const c=P.ov.bold.getContext("2d"), im=c.getImageData(0,0,P.W,P.H), d=im.data;
          for(let q=0;q<d.length;q+=4){ if(!d[q+3]) continue; const L=Math.min(d[q],d[q+1],d[q+2]), g=L<90?0:L<170?110:150; d[q]=d[q+1]=d[q+2]=g; d[q+3]=Math.max(d[q+3], g===0?230:170); }
          c.putImageData(im,0,0); }
        all.forEach(m=>{ m.mm=null; m.hit={}; }); drawTemplatePanel();
      }
    }
    // weather.us: مکان نقشه (ایران یا یک استان) از تطبیق مرزها؛ فقط برای مختصات CSV و NetCDF
    if(P.key==="wu" && state.geoFor!==all[0].file){
      state.geoFor=all[0].file; [P.ax,P.bx,P.ay,P.by]=WU_GEO; state.geoNote="";
      try{ setStatus("یافتن مکان نقشه…", 0.03); await tick();
        const r=await grLocate({maps:[all[0]], prof:P, tplGeo:WU_GEO, W:P.W, H:P.H, hint:null}, P.pal, []);
        if(r.ok){ [P.ax,P.bx,P.ay,P.by]=r.g; } else state.geoNote="مکان این نقشه با اطمینان پیدا نشد؛ مختصات CSV و NetCDF بر پایهٔ نقشهٔ ایران است.";
      }catch(e){ console.error(e); }
    }
    await document.fonts.ready;
    await Promise.all(["21px Titr","14px Ketab","14px Lalezar","27px Nastaliq"].map(f=>document.fonts.load(f,"آبAa1")));
    const todo = all.filter(m=>!m.mm || m.cap!==S.cap);
    for(let k=0;k<todo.length;k++){
      setStatus(`رقومی‌سازی و حذف مرزها: ${todo[k].name}`, k/(todo.length+2)); await tick();
      digitize(todo[k], S.cap); todo[k].cap = S.cap;
    }
    if(todo.length) drawModels();
    applyWeights();
    const MT=mtSettings(); let ACC=null;
    if(MT.sum){ ACC=mtAccumulate(all, MT); if(ACC){ all=ACC.models; } }
    const meanModels = all.filter(m=>m.weight>0);
    const probModels = linked() ? meanModels : all.map(m=>Object.assign(Object.create(m),{weight:1}));
    const pctTxt = ms => ms.map(m=>`${m.name} ${FA(round1(m.weight))}٪`).join("، ");
    const eqW = meanModels.every(m=>Math.abs(m.weight-meanModels[0].weight)<0.25) && meanModels.length===all.length;
    const V = curVar();
    if(ACC){ const hh=ACC.H ? `${FA(Math.round(ACC.H))} ساعته` : `از ${FA(ACC.used)} نقشه`; V.n=`${V.p||V.n} تجمعی ${hh}`; V.p=V.n;
      if(ACC.start && ACC.end){ S.from="از "+persianDT(new Date(ACC.start),210)+tzSuffix(210); S.to="تا "+persianDT(new Date(ACC.end),210)+tzSuffix(210); }
      setStatus(`جمع ${FA(ACC.used)} نقشه${ACC.skipped?`، ${FA(ACC.skipped)} نقشهٔ اول کنار گذاشته شد`:""}`, 0.1); }
    const base = [S.region, S.init].filter(Boolean).join("  |  ");
    const namesAll = all.map(m=>m.name);
    let jobs = [
      {key:"mean", kind:"mean", models:meanModels, title: eqW ? `میانگین ${V.n} مدل‌ها${V.u?` (${V.u})`:""}` : `میانگین وزنی ${V.n} مدل‌ها${V.u?` (${V.u})`:""}`,
       card: eqW ? "میانگین" : "میانگین وزنی", sub:"میانگین پیکسل به پیکسل؛ وزن هر مدل را پایین تنظیم کنید",
       info2: eqW ? `${FA(all.length)} مدل با وزن برابر: ${namesAll.join("، ")}` : `وزن‌ها: ${pctTxt(meanModels)}`},
      {key:"max", kind:"max", models:all, title:`بیشینهٔ ${V.n} مدل‌ها${V.u?` (${V.u})`:""}`, card:"بیشینه", sub:"بیشترین مقدار میان مدل‌ها در هر پیکسل", info2:`${FA(all.length)} مدل: ${namesAll.join("، ")}`},
      {key:"min", kind:"min", models:all, title:`کمینهٔ ${V.n} مدل‌ها${V.u?` (${V.u})`:""}`, card:"کمینه", sub:"کمترین مقدار میان مدل‌ها در هر پیکسل", info2:`${FA(all.length)} مدل: ${namesAll.join("، ")}`},
      ...S.thr.map(t=>({key:"prob_"+t, kind:"prob", thr:t, models:probModels, title:`احتمال ${V.p} بیش از ${FA(t)} ${V.u} بر اساس توافق مدل‌ها (درصد)`,
        card:`توافق مدل‌ها ≥ ${FA(t)} ${V.us}`, sub: linked() ? "با همان وزن‌های نقشهٔ میانگین" : `درصد مدل‌هایی که ${V.p} را از آستانه بیشتر می‌بینند`,
        info2: linked() && !eqW ? `وزن‌ها: ${pctTxt(meanModels)}` : `${FA(all.length)} مدل: ${namesAll.join("، ")}`})),
      ...(V.frost==="air" ? [{key:"frost", kind:"frost", ground:false, models:meanModels, title:`ریسک یخبندان (${V.n})`, card:"ریسک یخبندان", sub:"از دمای ۲ متری میانگین وزنی مدل‌ها و درصد مدل‌هایی که دما را صفر یا کمتر می‌بینند", info2:`${FA(meanModels.length)} مدل: ${meanModels.map(m=>m.name).join("، ")}`}] : []),
      ...(V.frost ? [{key:"gfrost", kind:"frost", ground:true, models:meanModels, title:"ریسک یخبندان سطح خاک", card:"ریسک یخبندان سطح خاک",
        sub: V.frost==="ground" ? "از دمای نزدیک سطح خاک" : `دمای سطح خاک هنگام طلوع ≈ دمای ۲ متری منهای ${FA(S.gOff)} درجه`,
        info2: V.frost==="ground" ? `دمای نزدیک سطح خاک  |  ${FA(meanModels.length)} مدل` : `دمای سطح خاک = دمای ۲ متری − ${FA(S.gOff)}°C (حدود طلوع آفتاب)  |  ${FA(meanModels.length)} مدل`}] : [])
    ];
    // ابزارهای نقشه: آستانه و اختلاف
    if(MT.thrMap) jobs.push({key:"thrmap", kind:"thr", src:MT.thrSrc, test:MT.thrMap, models:MT.thrSrc==="mean"?meanModels:all,
      title:`${({mean:"میانگین",max:"بیشینهٔ",min:"کمینهٔ"})[MT.thrSrc]} ${V.n}: فقط ${MT.thrMap.lab}${V.u?" "+V.u:""}`.replace(/\s+/g," ").trim(), card:`آستانه: ${MT.thrMap.lab}${V.us?" "+V.us:""}`,
      sub:"فقط نقاطی که شرط آستانه را دارند با همان رنگ‌های نوار ورودی؛ بقیه سفید", info2:`${FA(all.length)} مدل: ${namesAll.join("، ")}`});
    if(MT.diffA && MT.diffB && MT.diffA!==MT.diffB){
      const pick=v=> v==="__mean" ? {name:"میانگین", mm:null} : (()=>{ const m=state.models.filter(q=>q.ok)[+v.slice(1)]; return m?{name:m.name, mm:null, m}:null; })();
      const A=pick(MT.diffA), B=pick(MT.diffB);
      if(A && B) jobs.push({key:"diff", kind:"diff", A, B, models:meanModels, title:`اختلاف ${V.n}: ${A.name} منهای ${B.name}${V.u?` (${V.u})`:""}`, card:`اختلاف ${A.name} − ${B.name}`, sub:"مثبت: الف بیشتر · منفی: ب بیشتر", info2:""});
    }
    // چیدمان کارت‌ها (کارت‌های موجود حفظ می‌شوند تا کنترل وزن‌ها از دست نرود)
    const keys = jobs.map(j=>j.key);
    if(keys.join()!==state.order.join()){
      for(const k of Object.keys(state.cards)) if(!keys.includes(k)) delete state.cards[k];
      const grid=$("grid");
      keys.forEach(k=>{ if(!state.cards[k]) state.cards[k]=makeCard(k); grid.append(state.cards[k].card); });
      [...grid.children].forEach(ch=>{ if(!keys.some(k=>state.cards[k].card===ch)) ch.remove(); });
      state.order=keys;
      if(wPanel) state.cards.mean.slot.replaceChildren(wPanel); else buildWeightPanel();
    }
    if(scope==="mean") jobs = jobs.filter(j=>j.key==="mean");
    else if(scope==="prob") jobs = jobs.filter(j=>j.kind==="prob");
    const PAL0=PAL, CPAL=mtPalette(MT, V); if(CPAL){ PAL=CPAL; S.barMode="max"; }
    try{
    for(let k=0;k<jobs.length;k++){
      const J=jobs[k];
      if(scope==="all"){ setStatus(`ساخت نقشهٔ ${J.card}`, (todo.length+(k+1)/jobs.length*2)/(todo.length+2)); await tick(); }
      if(!J.models.length){ updateCard(J, null); continue; }
      if(J.kind==="frost"){ const field=frostRisk(J.models, J.ground && V.frost==="air" ? S.gOff : 0), st=stats(field);
        CUR_SCHEME=FROST_SCHEME;
        const cv = renderMap({field, kind:"prob", title:J.title, info1:`${base}  |  ${FROST_SCHEME.maxTxt(st.max)}`, info2:J.info2, S, max:st.max, info:[base, J.info2].filter(Boolean).join("  |  "), ref: all[0].data});
        CUR_SCHEME=null; updateCard(J, {cv, field, st, S}); continue; }
      if(J.kind==="thr"){ const field=combine(J.models, J.src), st=stats(field), blank=[255,255,255];
        let n=0, ok=0; for(let i=0;i<N;i++){ if(SM&&!SM[i]) continue; n++; if(field[i]===field[i] && J.test.test(field[i])) ok++; }
        const cv=renderMap({field, kind:"mm", colorFn:v=>(v===v && J.test.test(v)) ? PAL[classOf(v)] : blank, title:J.title, info1:`${base}  |  ${FA(Math.round(100*ok/Math.max(1,n)))}٪ کادر ${J.test.lab} ${V.u||""}`, info2:J.info2, S, max:st.max,
          maxText:`${FA(Math.round(100*ok/Math.max(1,n)))}٪ کادر ${J.test.lab} ${V.u||""}`, info:[base, J.info2].filter(Boolean).join("  |  "), ref: all[0].data});
        updateCard(J, {cv, field, st, S}); const o=state.cards[J.key]; if(o) o.sx.innerHTML=`<span>سهم کادر<b>${FA(Math.round(100*ok/Math.max(1,n)))}٪</b></span><span>شرط<b>${J.test.lab} ${V.us||""}</b></span>`; continue; }
      if(J.kind==="diff"){ const mmOf=X=> X.m ? (X.m.mm||(digitize(X.m,S.cap), X.m.mm)) : combine(meanModels,"mean");
        let a=mmOf(J.A), b=mmOf(J.B);
        if(ACC){ const fa=all.find(m=>J.A.m&&m.name===String(J.A.m.name).replace(/\s+[0-9۰-۹]+$/,"")), fb=all.find(m=>J.B.m&&m.name===String(J.B.m.name).replace(/\s+[0-9۰-۹]+$/,"")); if(fa) a=fa.mm; if(fb) b=fb.mm; }
        const field=new Float32Array(N); for(let i=0;i<N;i++) field[i]=a[i]-b[i];
        const sch=mtDiffScheme(V, field); CUR_SCHEME=sch; let mx=0; for(const v of field) if(v===v&&Math.abs(v)>mx) mx=Math.abs(v);
        const txtA=mtDiffText(field, J.A.name, J.B.name, V);
        const cv=renderMap({field, kind:"prob", title:J.title, info1:base, info2:"", S, max:mx, info:base, ref: all[0].data});
        CUR_SCHEME=null; updateCard(J, {cv, field, st:stats(field), S}); const o=state.cards[J.key]; if(o){ o.sx.innerHTML=`<span style="flex-basis:100%">${txtA}</span>`; } continue; }
      const field = J.kind==="prob" ? agreement(J.models, J.thr, S.sigma, S.nep) : combine(J.models, J.kind);
      const st = stats(field);
      const info1 = J.kind==="prob" ? `${base}  |  بیشینهٔ احتمال: ${FA(Math.round(st.max))}٪` : `${base}  |  بیشینه در کادر: ${fmt(st.max)} ${V.u}`;
      const cv = renderMap({field, kind:J.kind==="prob"?"prob":"mm", title:J.title, info1, info2:J.info2, S, max:st.max,
        info:[base, J.info2].filter(Boolean).join("  |  "), ref: all[0].data});
      updateCard(J, {cv, field, st, S});
    }
    } finally { PAL=PAL0; }
    setStatus(`${FA(state.order.length)} نقشه از ${FA(all.length)} مدل آماده است`, 1);
    try{ if(mrGeo()) dsBuiltinDEM().catch(()=>{}); }catch(e){}
  }catch(e){ console.error(e); setStatus("خطا: "+e.message, 0); }
  state.busy=false; $("run").disabled=false;
  if(state.pending){ const s=state.pending; state.pending=null; run(s); }
}
function fileBase(J){ return P.key+"_"+curVar().nc+"_"+J.key.replace(".","p")+"_"+($("t1").value||"").slice(0,10); }
function makeCard(key){
  const card=document.createElement("article"); card.className="card"+(key==="mean"?" wide":"");
  const hd=document.createElement("header"); hd.innerHTML=`<h3></h3><div class="sub"></div>`;
  const img=new Image(); img.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=img.src; d.showModal(); };
  const slot=document.createElement("div"); slot.className="slot";
  const sx=document.createElement("div"); sx.className="stats";
  const dl=document.createElement("div"); dl.className="dl";
  const o={card, hd, img, slot, sx, dl, data:null};
  const mk=(label, ext, make)=>{ const b=document.createElement("button"); b.className="btn"; b.type="button"; b.textContent=label;
    b.onclick=async()=>{ if(!o.data) return; b.disabled=true; await tick(); const blob=await make(o.data); const u=URL.createObjectURL(blob); state.urls.push(u);
      const a=document.createElement("a"); a.href=u; a.download=fileBase(o.data.J)+"."+ext; document.body.append(a); a.click(); a.remove(); b.disabled=false; };
    return b; };
  dl.append(
    mk("PNG","png", d=>exportPNG(d.cv)),
    mk("CSV","csv", d=>{ const V=curVar(); return toCSV(d.field, d.J.kind==="prob" ? "probability_percent" : `${V.nc}_${(V.us||"value").replace(/[^A-Za-z0-9]/g,"")||"value"}`); }),
    mk("NetCDF","nc", d=>{ const V=curVar(); return toNetCDF(d.field, d.J.kind==="prob"?"probability":V.nc, d.J.kind==="prob"?"percent":(V.us||"1"), d.J.title,
      [["title",d.J.title],["period",d.S.from+" "+d.S.to],["models",d.J.models.map(m=>m.name+":"+round1(m.weight)+(d.J.kind==="prob"&&!linked()?"":"%")).join(", ")],
       ["source", P.custom ? "Digitized from user-supplied precipitation maps (auto-detected template); static map elements masked before statistics" : P.key==="wb" ? "Digitized from WeatherBELL accumulated precipitation maps; base-map lines and labels masked before statistics, filled by neighbour-weighted inpainting, then the original lines overlaid"
                              : "Digitized from weather.us accumulated precipitation maps; borders/labels removed by neighbour-weighted inpainting"]]); })
  );
  if(key==="mean"){ const body=document.createElement("div"); body.className="split"; const left=document.createElement("div"); left.append(img, sx, dl); body.append(left, slot); card.append(hd, body); }
  else card.append(hd, img, sx, dl);
  return o;
}
function updateCard(J, r){
  const o=state.cards[J.key]; if(!o) return;
  o.hd.querySelector("h3").textContent=J.card; o.hd.querySelector(".sub").textContent=J.sub;
  if(!r){ o.data=null; o.img.removeAttribute("src"); o.sx.innerHTML=`<span>همهٔ وزن‌ها صفر است</span>`; return; }
  o.data={...r, J};
  o.img.alt=J.title; o.img.src=r.cv.toDataURL("image/png");
  const st=r.st, f=r.field;
  o.sx.innerHTML = J.kind==="prob"
    ? `<span>بیشینهٔ احتمال<b>${FA(Math.round(st.max))}٪</b></span><span>مساحت بالای ۵۰٪<b>${FA(Math.round(areaAbove(f,50)*100))}٪</b></span><span>مساحت دارای احتمال<b>${FA(Math.round(areaAbove(f,1)*100))}٪</b></span>`
    : (()=>{ const V=curVar(); return `<span>بیشینه<b>${fmt(st.max)} ${V.us}</b></span><span>میانگین کادر<b>${fmt(st.mean,2)} ${V.us}</b></span>` + (V.accum ? `<span>مساحت ${V.p==="بارش"?"بارشی":"دارای "+V.p}<b>${FA(Math.round(st.wet*100))}٪</b></span>` : ""); })();
}
function areaAbove(f,t){ let c=0; for(let i=0;i<N;i++) if(SM[i] && f[i]>=t) c++; return c/NS; }

