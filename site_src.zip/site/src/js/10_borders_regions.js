/* =====================================================================
   خواندن تاریخ و ساعت از متن خود نقشه‌ها (OCR آفلاین با الگوی ارقام همین سایت‌ها)
   ===================================================================== */
{{BLOB:ocr_templates}}
const BAR_TPL = [{"c": "0", "w": 5, "h": 11, "d": "AAD//wAA/wAA/wD/AAD//wAAAP//AAAA//8AAAD//wAAAP8A/wAA/wD/AAD/AP8AAP8AAP//AA=="}, {"c": "1", "w": 3, "h": 11, "d": "AAD/AP//////AAD/AAD/AAD/AAD/AAD/AAD/AAD/AAD/"}, {"c": "0", "w": 6, "h": 11, "d": "AAD//wAAAP8AAP8AAP8AAP8A/wAAAAD//wAAAAD//wAAAAD//wAAAAD/AP8AAP8AAP8AAP8AAP8AAP8AAAD//wAA"}, {"c": "5", "w": 5, "h": 11, "d": "/////wD/AAAAAP8AAAAA////AAD/AAD/AAAAAAD/AAAAAP8AAAAA//8AAAD//wAA/wAA//8AAA=="}, {"c": "2", "w": 6, "h": 11, "d": "AAD//wAAAP8AAP8AAP8AAP8AAP8AAP8AAAAAAP8AAAAA/wAAAAD/AAAAAAD/AAAAAP8AAAAAAP8AAAAA////////"}, {"c": "3", "w": 5, "h": 11, "d": "/////wAAAAD/AAAA/wAAAAD/AAAAAP//AAAAAP8AAAAAAP8AAAAA//8AAP8A/wAA/wAA//8AAA=="}, {"c": "7", "w": 5, "h": 11, "d": "//////8AAAAA/wAAAP8AAAAA/wAAAAD/AAAA/wAAAAD/AAAAAP8AAAAA/wAAAP8AAAAA/wAAAA=="}, {"c": "1", "w": 2, "h": 11, "d": "AP//////AP8A/wD/AP8A/wD/AP8A/w=="}, {"c": "0", "w": 5, "h": 11, "d": "AAD//wAA/wD/AP8AAAD//wAAAP//AAAA//8AAAD//wAAAP//AAAA//8AAAD/AP8A/wAAAP//AA=="}, {"c": "1", "w": 2, "h": 11, "d": "AP8A////AP8A/wD/AP8A/wD/AP8A/w=="}, {"c": "5", "w": 5, "h": 11, "d": "AP////8A/wAAAAD/AAAAAP///wAA/wAA/wAAAAD/AAAAAP8AAAAA//8AAAD/AP8AAP8AAP//AA=="}, {"c": "2", "w": 5, "h": 11, "d": "AAD//wAA/wD//wD/AAD/AP8AAP8AAAAA/wAAAP8AAAD/AAAAAP8AAAD/AAAAAP8AAAD//////w=="}, {"c": "2", "w": 5, "h": 11, "d": "AAD//wAA/wAA/wD/AAD/AP8AAP8AAAAA/wAAAP8AAAD/AAAAAP8AAAD/AAAAAP8AAAD//////w=="}, {"c": "5", "w": 5, "h": 11, "d": "/////wD/AAAAAP8AAAAA////AAD/AAD/AAAAAP8AAAAAAP8AAAAA//8AAP8A/wAA/wAA//8AAA=="}, {"c": "0", "w": 5, "h": 11, "d": "AAD/AAAA/wD/AP8AAAD//wAAAP//AAAA//8AAAD//wAAAP//AAAA//8AAAD/AP8A/wAAAP8AAA=="}, {"c": "3", "w": 5, "h": 11, "d": "//////8AAAD/AAAAAP8AAAD/AAAAAP//AAAAAAD/AAAAAP8AAAAA//8AAAD//wAA/wAA//8AAA=="}, {"c": "5", "w": 5, "h": 11, "d": "AP///wAA/wAAAP8AAAAA////AAD//wD/AAAAAAD/AAAAAP8AAAAA//8AAAD///8A/wAA//8AAA=="}, {"c": "4", "w": 5, "h": 11, "d": "AAAA/wAAAAD/AAAA//8AAAD//wAA/wD/AAD/AP8A/wAA/wD//////wAAAP8AAAAA/wAAAAD/AA=="}, {"c": "5", "w": 5, "h": 11, "d": "AP////8A/wAAAP8AAAAA/wD//wD//wD/AAAAAAD/AAAAAP8AAAAA//8AAAD///8A/wAAAP//AA=="}, {"c": "5", "w": 5, "h": 11, "d": "AP////8A/wAAAP8AAAAA/wD/AAD//wD/AAAAAAD/AAAAAP8AAAAA//8AAAD///8A/wAAAP8AAA=="}, {"c": "6", "w": 4, "h": 11, "d": "AP//AP8AAP//AAD//wAAAP//////AAD//wAA//8AAP//AAD//wAA/wD//wA="}, {"c": "0", "w": 5, "h": 11, "d": "AP//AAD/AAD/AP8AAP8A/wAAAP//AAAA//8AAAD//wAAAP//AAD/AP8AAP8A/wAA/wAA//8AAA=="}, {"c": "7", "w": 6, "h": 11, "d": "////////AAAAAAD/AAAAAP8AAAAAAP8AAAAAAP8AAAAA/wAAAAAA/wAAAAAA/wAAAAAA/wAAAAD/AAAAAAD/AAAA"}, {"c": "8", "w": 5, "h": 11, "d": "AP//AAD/AAD/AP8AAP8A/wAA/wAA////AP8AAP8A/wAA/wD/AAAA//8AAAD//wAA/wAA//8AAA=="}, {"c": "9", "w": 5, "h": 11, "d": "AP//AAAA/wD/AP8AAP8A/wAAAP//AAD///8AAP//AP////8AAAD/AP8AAP8A/wAA/wAA//8AAA=="}, {"c": "0", "w": 5, "h": 11, "d": "AAD//wAA/wD/AAD/AAD//wAAAP//AAAA//8AAAD//wAAAP8A/wAA/wD/AAD/AP8A/wAAAP//AA=="}, {"c": "2", "w": 5, "h": 11, "d": "AAD//wAA/wD///8AAAD//wAAAP8AAAAA/wAAAP8AAAD/AAAAAP8AAAD/AAAAAP8AAAD//////w=="}, {"c": "0", "w": 5, "h": 11, "d": "AP//AAAA/wD/AP8AAAD//wAAAP//AAAA//8AAAD//wAAAP//AAAA//8AAAD/AP8A/wAA//8AAA=="}, {"c": "3", "w": 6, "h": 11, "d": "AP////8AAAAA/wAAAAAA/wAAAAD/AAAAAAD///8AAAAAAP8AAAAAAAD/AAAAAAD//wAAAP8AAP8AAP8AAAD//wAA"}, {"c": "2", "w": 5, "h": 11, "d": "AP///wAA/wD///8AAAD//wAAAP8AAAAA/wAAAP8AAAD/AAAAAP8AAAD/AAAAAP8AAAD//////w=="}, {"c": "3", "w": 5, "h": 11, "d": "AP////8AAAD/AAAAAP8AAAD/AAAAAP///wAAAAD/AAAAAP8AAAAA//8AAAD///8A/wAAAP8AAA=="}, {"c": "5", "w": 6, "h": 11, "d": "AP////8AAP8AAAAAAP8AAAAAAP///wAAAP8AAP8AAAAAAP8AAAAAAAD/AAAAAAD//wAAAP8AAP8AAP8AAAD//wAA"}, {"c": "3", "w": 6, "h": 11, "d": "AP////8AAAAAAP8AAAAA/wAAAAAA/wAAAAAA//8AAAAAAP8AAAAAAAD/AAAAAAD//wAAAP8AAP8AAP8AAAD//wAA"}, {"c": "4", "w": 5, "h": 11, "d": "AAD/AAAAAP8AAAD//wAAAP//AAAA//8AAAD//wAA/wD/AAD//////wAA/wAAAAD/AAAAAP8AAA=="}, {"c": "6", "w": 5, "h": 11, "d": "AAD/AAAA/wD/AP8AAAD//wAAAAD/////AP8AAAD//wAAAP//AAAA//8AAAD/AP8A/wAAAP8AAA=="}, {"c": "8", "w": 5, "h": 11, "d": "AP//AAD/AAD/AP8AAAD//wAA//8A////AAD/AP8A/wAAAP//AAAA//8AAAD//wAA//8A//8AAA=="}, {"c": "9", "w": 5, "h": 11, "d": "AAD/AAAA/wD/AP8AAP8A/wAAAP//AAD///8AAP//AP////8AAAD/AP8AAP8AAP8A/wAA//8AAA=="}, {"c": "5", "w": 5, "h": 11, "d": "AP////8A/wAAAAD/AAAAAP///wAA/wD/AAAAAAD/AAAAAP8AAAAA//8AAAD/AP8A/wAAAP//AA=="}, {"c": "3", "w": 5, "h": 11, "d": "AP////8AAAD/AAAAAP8AAAD/AAAAAP///wAAAAD/AAAAAP8AAAAA//8AAAD/AP8AAP8AAP//AA=="}, {"c": "4", "w": 4, "h": 11, "d": "AP8AAAD/AAD//wAA//8AAAD/AAAA/wAAAP8AAP////8A/wAAAP8AAAD/AAA="}, {"c": "0", "w": 5, "h": 11, "d": "AP//AAAA/wD/AP8AAP8A/wAAAP//AAAA//8AAAD//wAAAP//AAD/AP8AAP8AAP8A/wAA//8AAA=="}, {"c": "0", "w": 8, "h": 8, "d": "AGPU1IwAAAAZ5AYAs04AAF2cAABZnwAAeIMAAD6+AAB4gwAAPrsAAFmfAABZnwAAE98GALNSDQAAWNTUkADAXw=="}, {"c": "2", "w": 5, "h": 8, "d": "d9TOwBlSAQBqpwAAAEW5AAAAql8AAHKuAABmtgEAZrYBAAD/1MrKyg=="}, {"c": "1", "w": 3, "h": 8, "d": "AIHfqnrfGQDfAADfAADfAADfAADfAADf"}, {"c": "5", "w": 5, "h": 8, "d": "zs7KyiLfAAAAAOQAAAAA88XOlgYAAACckwAAAEK+AQAAlIXKztSYAQ=="}, {"c": "7", "w": 6, "h": 8, "d": "csrKyt+5AAAAAJhdAAAAE98BAAAAgX0AAAAB5BMAAABmnwAAAADZKQAAAE7AAAAA"}, {"c": "5", "w": 5, "h": 8, "d": "itnKylihOwAAALYpAAAAu87OsCIAAABf1AAAAAH/EwAAUsXAzs65GQ=="}, {"c": "2", "w": 5, "h": 8, "d": "Y87Oyi9KBgBKxQAAACbZAAAAh4EAAFLFAQBKxQoARcUKAAD42crKyg=="}, {"c": "5", "w": 6, "h": 8, "d": "Ke/KyqcAPp8AAAAAUooAAAAAWeTKylkAAAAAGeQvAAAAAKVbEwAADd8kbs7KzlgA"}, {"c": "7", "w": 5, "h": 8, "d": "ysrKyv8AAAA6wAAAAK5OAAAe2QAAAJRuAAAN6AYAAHqMAAAB6B4AAA=="}, {"c": "2", "w": 5, "h": 8, "d": "CpzU1KMGTgAAqgAAAACHAAAABtkAAACwbgAApX0AAKN9AABf/crKyg=="}, {"c": "2", "w": 6, "h": 8, "d": "AWPOzsovZkoGAErFdwAAACbZIgAAAIeBAAAAUsUBAABKxQoAAEXFCgAAqvjZysrK"}, {"c": "3", "w": 8, "h": 8, "d": "HrDO1LYKIsoGHgAAn3K7UgAAAArARfMAADTK840Z6AAAAAABn5joAAAAAABFvvMAGQEAAJiHrlJS2c7UnAYZwA=="}, {"c": "0", "w": 3, "h": 8, "d": "zsAZAFKzAADzAADkAADkAAD4AFK5zsUe"}, {"c": "4", "w": 3, "h": 8, "d": "AGr/Kaf/wBP/QgD/AAD/39//AAD/AAD/"}, {"c": "0", "w": 6, "h": 8, "d": "ACLKzsAZALtSAFKzAPMAAADzE+gAAADkGegAAADk5PgAAAD4AK5SAFK5ABnAzsUe"}, {"c": "5", "w": 7, "h": 8, "d": "zs7KyiIiyt8AAAAAu1LkAAAAAPMA88XOlhnoAAAAAJyc6AAAAABCxfMAAQAAlIWuUsrO1JgBGcA="}, {"c": "7", "w": 5, "h": 8, "d": "csrKyt8AAAAAmAAAABPfAAAAgX0AAAHkEwAAZp8AAADZKQAATsAAAA=="}, {"c": "5", "w": 6, "h": 8, "d": "uWrfyspyXYFdAAAAAZRFAAAAAJzUzrs0AAAAAELrAAAAAADoABMAADTkAKPOzsAv"}, {"c": "0", "w": 5, "h": 8, "d": "IsrOwBm7UgBSs/MAAADz6AAAAOToAAAA5PMAAAD4rlIAUrkZwM7FHg=="}, {"c": "0", "w": 6, "h": 8, "d": "AJbU1FkAWbMABt8Tn1kAAJxduUIAAIF6uUIAAIF6nF0AAJxdTrMABuQZAIrU1F0A"}, {"c": "5", "w": 5, "h": 8, "d": "at/KynKBXQAAAJRFAAAAnNTOuzQAAABC6wAAAADoEwAANOSjzs7ALw=="}, {"c": "5", "w": 6, "h": 8, "d": "AWrfyspyZoFdAAAAd5RFAAAAIpzUzrs0AAAAAELrAAAAAADoABMAADTkp6POzsAv"}, {"c": "3", "w": 8, "h": 8, "d": "HrDO1LYKat8GHgAAn3KBXQAAAArARZRFADTK840AnNQAAAABn30AAAAAAABFuQAAGQEAAJiHEwBS2c7UnAajzg=="}, {"c": "5", "w": 3, "h": 8, "d": "yspyAAAAAAAAzrs0AELrAADoADTkzsAv"}, {"c": "4", "w": 4, "h": 8, "d": "AGr/ACmn/wDAE/8AQgD/AAAA/wDf3//fAAD/AAAA/wA="}, {"c": "5", "w": 5, "h": 8, "d": "at/KynKBXQAAAJRFAAAAnNTOuzQAAABC6x4AAADoEwAANOSjzs7ALw=="}];
// ماسک خشکی/دریا (Natural Earth 10m، ۰٫۰۲۵ درجه، ۱۰ تا ۵۰ شمالی و ۲۵ تا ۸۰ شرقی)
{{BLOB:landmask}}
// خط ساحل، مرز کشورها و مرز استان‌های ایران (Natural Earth 10m، ساده‌شده؛ مختصات × ۲۰۰)
{{BLOB:borders_data}}
function borderLines(){ if(BORDL) return BORDL; BORDL={};
  for(const k in BORDERS){ const b=b64u8(BORDERS[k]); let p=0; const rd=()=>{ let v=0, sh=0, c; do{ c=b[p++]; v+=(c&127)*Math.pow(2,sh); sh+=7; }while(c&128); return (v%2)?-(v+1)/2:v/2; };
    const L=[]; while(p<b.length){ const n=rd(); let x=0,y=0; const pts=new Float32Array(n*2); for(let i=0;i<n;i++){ x+=rd(); y+=rd(); pts[i*2]=x/200; pts[i*2+1]=y/200; } L.push(pts); } BORDL[k]=L; }
  return BORDL; }
// لایهٔ مرزهای برداری روی کادر نقشهٔ مرجع (به‌جای خطوطِ کپی‌شده از تصویر)
function vectorBorders(rp){
  const c=document.createElement("canvas"); c.width=rp.W; c.height=rp.H; const x=c.getContext("2d"), B=borderLines();
  x.save(); x.beginPath(); x.rect(rp.fx0, rp.fy0, rp.fx1-rp.fx0+1, rp.fy1-rp.fy0+1); x.clip(); x.lineJoin="round"; x.lineCap="round";
  const draw=(L,col,w)=>{ x.strokeStyle=col; x.lineWidth=w; x.beginPath(); for(const pts of L){ for(let i=0;i<pts.length;i+=2){ const X=rp.ax+rp.bx*pts[i], Y=rp.ay+rp.by*pts[i+1]; if(i) x.lineTo(X,Y); else x.moveTo(X,Y); } } x.stroke(); };
  const sc=Math.max(0.7, Math.min(1.6, Math.abs(rp.bx)/35));
  draw(B.prov, "rgba(70,70,70,.75)", 0.8*sc); draw(B.coast, "#111", 1.3*sc); draw(B.ctry, "#111", 1.5*sc);
  x.restore(); return c; }
function landMask(){ if(LANDM) return LANDM; const L=LANDMASK, b=b64u8(L.rle), a=new Uint8Array(L.w*L.h); let p=0;
  const rd=()=>{ let v=0, sh=0, c; do{ c=b[p++]; v|=(c&127)<<sh; sh+=7; }while(c&128); return v; };
  for(let y=0;y<L.h;y++){ const n=rd(); let x=0, val=0; for(let k=0;k<n;k++){ const r=rd(); if(val) a.fill(1, y*L.w+x, y*L.w+x+r); x+=r; val^=1; } }
  return LANDM=a; }
function landAt(lat, lon){ const L=LANDMASK, x=Math.floor((lon-L.lon0)/L.d), y=Math.floor((L.lat0-lat)/L.d); if(x<0||y<0||x>=L.w||y>=L.h) return -1; return landMask()[y*L.w+x]; }
function b64u8(s){ const bin=atob(s), a=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) a[i]=bin.charCodeAt(i); return a; }
const lumAt=(d,i)=>0.299*d[i]+0.587*d[i+1]+0.114*d[i+2];
function textLine(d, W, box, li){
  const [x0,y0,x1,y1]=box, rows=[];
  for(let y=y0;y<y1;y++){ let any=false; for(let x=x0;x<x1;x++) if(lumAt(d,(y*W+x)*4)<150){ any=true; break; } rows.push(any); }
  const lines=[]; let s=-1; for(let k=0;k<=rows.length;k++){ const r=k<rows.length&&rows[k]; if(r&&s<0) s=k; if(!r&&s>=0){ lines.push([y0+s,y0+k-1]); s=-1; } }
  if(li>=lines.length) return null;
  const [ya,yb]=lines[li], h=yb-ya+1, w=x1-x0, D=new Float32Array(w*h);
  for(let y=0;y<h;y++) for(let x=0;x<w;x++) D[y*w+x]=Math.min(1,Math.max(0,(255-lumAt(d,((ya+y)*W+x0+x)*4))/255));
  return {D,w,h,x0,ya};
}
function tokensOf(S, gap){
  const T=[]; let s=-1, last=-1;
  for(let x=0;x<S.w;x++){ let c=0; for(let y=0;y<S.h;y++) c+=S.D[y*S.w+x];
    if(c>0.12){ if(s<0) s=x; else if(x-last-1>=gap){ T.push([s,last+1]); s=x; } last=x; } }
  if(s>=0) T.push([s,last+1]); return T;
}
function vextS(S,x0,x1){ let t=-1,b=-1; for(let y=0;y<S.h;y++){ let m=0; for(let x=x0;x<x1;x++) m=Math.max(m,S.D[y*S.w+x]); if(m>0.3){ if(t<0) t=y; b=y; } } return [t,b]; }
function cropS(S,x0,x1,t,b){ x0=Math.max(0,x0); x1=Math.min(S.w,x1); const w=Math.max(1,x1-x0), h=Math.max(1,b-t+1), D=new Float32Array(w*h);
  for(let y=0;y<h;y++) for(let x=0;x<w;x++) D[y*w+x]=S.D[(t+y)*S.w+x0+x]; return {D,w,h}; }
// بردار نرمال‌شدهٔ یک رقم: برش تنگ، ارتفاع ۱۸، عرض حداکثر ۱۶، کمی محو، نرمال واحد
function normCell(C){
  let c0=-1,c1=-1; for(let x=0;x<C.w;x++){ let m=0; for(let y=0;y<C.h;y++) m=Math.max(m,C.D[y*C.w+x]); if(m>0.3){ if(c0<0) c0=x; c1=x; } }
  if(c0<0){ c0=0; c1=C.w-1; }
  const w=c1-c0+1, h=C.h, NH=18, tw=Math.max(1,Math.min(16,Math.round(w*NH/h))), img=new Float32Array(NH*16), ox=Math.floor((16-tw)/2);
  for(let y=0;y<NH;y++){ const sy=Math.min(h-1,Math.max(0,(y+0.5)*h/NH-0.5)), y0=Math.floor(sy), y1=Math.min(h-1,y0+1), fy=sy-y0;
    for(let x=0;x<tw;x++){ const sx=Math.min(w-1,Math.max(0,(x+0.5)*w/tw-0.5)), x0=Math.floor(sx), x1=Math.min(w-1,x0+1), fx=sx-x0;
      const g=(yy,xx)=>C.D[yy*C.w+c0+xx];
      img[y*16+ox+x]=(g(y0,x0)*(1-fx)+g(y0,x1)*fx)*(1-fy)+(g(y1,x0)*(1-fx)+g(y1,x1)*fx)*fy; } }
  const k=[-2,-1,0,1,2].map(v=>Math.exp(-v*v/(2*0.49))), ks=k.reduce((a,b)=>a+b,0);
  const t1=new Float32Array(NH*16), t2=new Float32Array(NH*16);
  for(let y=0;y<NH;y++) for(let x=0;x<16;x++){ let s=0; for(let q=-2;q<=2;q++){ const xx=x+q; if(xx>=0&&xx<16) s+=k[q+2]*img[y*16+xx]; } t1[y*16+x]=s/ks; }
  for(let y=0;y<NH;y++) for(let x=0;x<16;x++){ let s=0; for(let q=-2;q<=2;q++){ const yy=y+q; if(yy>=0&&yy<NH) s+=k[q+2]*t1[yy*16+x]; } t2[y*16+x]=s/ks; }
  let n=0; for(const v of t2) n+=v*v; n=Math.sqrt(n)||1; for(let i=0;i<t2.length;i++) t2[i]/=n; return t2;
}
const dot=(a,b)=>{ let s=0; for(let i=0;i<a.length;i++) s+=a[i]*b[i]; return s; };
function libFrom(list){ return list.map(e=>({c:e.c, proxy:!!e.proxy, v:normCell({D:Float32Array.from(b64u8(e.d),x=>x/255), w:e.w, h:e.h})})); }
let OCR_LIB=null;
function ocrLib(){
  if(OCR_LIB) return OCR_LIB;
  const learned=k=>store.get("ocr."+k, []);
  OCR_LIB = { wb: libFrom(OCR_TPL.wb.concat(learned("wb"))), wbMon: libFrom(OCR_TPL.wbMon), wu: libFrom(OCR_TPL.wu.concat(learned("wu"))).concat(libFrom(OCR_TPL.proxy.filter(e=>"478".includes(e.c)))) };
  return OCR_LIB;
}
function rankCell(C, lib, chars="0123456789"){
  const v=normCell(C), best={};
  for(const t of lib){ if(!chars.includes(t.c)) continue; const s=dot(v,t.v); if(!(t.c in best) || s>best[t.c]) best[t.c]=s; }
  return Object.entries(best).sort((a,b)=>b[1]-a[1]);
}
// همهٔ ترکیب‌های k برتر برای یک عدد چندرقمی
function numCands(ranks, k=3){
  let out=[{s:"",sc:0,mn:1}];
  for(const r of ranks){ const nx=[]; for(const o of out) for(const [c,s] of r.slice(0,k)) nx.push({s:o.s+c, sc:o.sc+s, mn:Math.min(o.mn,s)}); out=nx; }
  return out;
}
const MONTHS_EN=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const DAYMS=864e5;
function decodeWB(d){
  const S=textLine(d,984,[640,0,984,34],0); if(!S) return null;
  const T=tokensOf(S,3); if(T.length<8) return null;
  let ib=-1; for(let i=1;i<T.length;i++){ const [a,b]=T[i]; if(b-a<=7){ const [t,bb]=vextS(S,a,b); if(bb-t<0.6*S.h){ ib=i; break; } } }
  if(ib<0 || ib+2>T.length-5) return null;
  const L=ocrLib(), adv=8;
  const cellsR=(x0,x1,n)=>{ const [t,b]=vextS(S,x0,x1); return Array.from({length:n},(_,k)=>cropS(S,Math.round(x1-(n-k)*adv),Math.round(x1-(n-k-1)*adv),t,b)); };
  const nOf=(x0,x1)=>Math.max(1,Math.round((x1-x0+0.3*adv)/adv));
  const hx=[T[1][0],T[ib-1][1]], vx=[T[ib+2][0],T[T.length-5][1]], dayT=T[T.length-3], monT=T[T.length-2], yT=T[T.length-1];
  const Hc=cellsR(hx[0],hx[1],nOf(...hx)), hhc=cellsR(vx[0],vx[1],Math.max(2,nOf(...vx))).slice(0,-1), dc=cellsR(dayT[0],dayT[1],nOf(...dayT)), yc=cellsR(yT[0],yT[1],4);
  const R=cs=>cs.map(c=>rankCell(c,L.wb));
  const cH=numCands(R(Hc)), chh=numCands(R(hhc)), cd=numCands(R(dc)), cy=numCands(R(yc),2);
  // ماه با الگوی کلمه (اگر شناخته نشد، از نزدیکی به امروز)
  const [mt,mb]=vextS(S,monT[0],monT[1]); const mv=normCell(cropS(S,monT[0],monT[1],0,S.h-1)); let mon=null, ms=-1;
  for(const t of L.wbMon){ const s=dot(mv,t.v); if(s>ms){ ms=s; mon=t.c; } }
  const monIdx = ms>0.93 ? MONTHS_EN.indexOf(mon)+1 : 0;
  const now=new Date(), cands=[];
  for(const y of cy){ const yv=+y.s; if(Math.abs(yv-now.getUTCFullYear())>1) continue;
    for(const dd of cd){ const dv=+dd.s; if(dv<1||dv>31) continue;
      for(const hh of chh){ const hv=+hh.s; if(hv>23) continue;
        for(const H of cH){ const Hv=+H.s; if(Hv>400) continue;
          for(const m of (monIdx?[monIdx]:[1,2,3,4,5,6,7,8,9,10,11,12])){
            const valid=new Date(Date.UTC(yv,m-1,dv,hv)); if(valid.getUTCDate()!==dv) continue;
            const init=new Date(valid-Hv*36e5); if(![0,6,12,18].includes(init.getUTCHours())) continue;
            if(init < now-30*DAYMS || init > +now+DAYMS) continue;
            const sc=y.sc+dd.sc+hh.sc+H.sc-(monIdx?0:0.02*Math.abs(valid-now)/DAYMS);
            cands.push({sc, init, valid, H:Hv, mn:Math.min(y.mn,dd.mn,hh.mn,H.mn), str:{H:H.s, hh:hh.s, d:dd.s, y:y.s}}); } } } } }
  if(!cands.length) return null;
  cands.sort((a,b)=>b.sc-a.sc); const best=cands[0], second=cands.find(c=>+c.valid!==+best.valid || +c.init!==+best.init);
  const margin = second ? best.sc-second.sc : 9;
  return {src:"wb", offset:0, init:best.init, start:best.init, end:best.valid, valid:best.valid, H:best.H, conf: best.mn>=0.93 && margin>=0.05, minSim:best.mn,
          crop:[640+Math.max(0,T[0][0]-4), S.ya-3, 640+Math.min(S.w,T[T.length-1][1]+4), S.ya+S.h+3],
          learn:{cells:[...Hc,...hhc,...dc,...yc], str:best.str.H+best.str.hh+best.str.d+best.str.y}};
}
const WU_DATE_C=[3,10.5,18,26,38.5,46,58.5,66], WU_TIME_C=[2.5,10.5,22.5,29.5];
function cellAtS(S, x0tok, c, half=4.5){
  const a=Math.max(0,Math.floor(x0tok+c-half)), b=Math.min(S.w,Math.ceil(x0tok+c+half)), ext=[];
  for(let x=a;x<b;x++){ let t=-1,bb=-1; for(let y=0;y<S.h;y++) if(S.D[y*S.w+x]>0.25){ if(t<0) t=y; bb=y; } ext.push(t<0?0:bb-t+1); }
  const runs=[]; let s=-1; for(let i=0;i<=ext.length;i++){ const e=i<ext.length?ext[i]:0; if(e>0&&s<0) s=i; if(e===0&&s>=0){ runs.push([s,i]); s=-1; } }
  const ok=runs.filter(r=>Math.max(...ext.slice(r[0],r[1]))>=4); const mid=x0tok+c-a;
  const r = ok.length ? ok.reduce((p,q)=>Math.abs((q[0]+q[1])/2-mid)<Math.abs((p[0]+p[1])/2-mid)?q:p) : [0,b-a];
  return cropS(S, a+r[0], a+r[1], 0, S.h-1);
}
function decodeWU(d){
  const L=ocrLib(), lines=[], cellsAll=[];
  const one = decodeWUValid(d);
  for(const li of [0,1]){
    const S=textLine(d,760,[480,630,760,668],li); if(!S) return one;
    const T=tokensOf(S,3); if(T.length<5) return one;
    const cells=[...WU_DATE_C.map(c=>cellAtS(S,T[T.length-3][0],c)), ...WU_TIME_C.map(c=>cellAtS(S,T[T.length-2][0],c))];
    cellsAll.push(cells);
    const R=cells.map(c=>rankCell(c,L.wu)), now=new Date(), out=[];
    for(const y of numCands(R.slice(0,4),2)){ const yv=+y.s; if(Math.abs(yv-now.getUTCFullYear())>1) continue;
      for(const mo of numCands(R.slice(4,6))){ const mv=+mo.s; if(mv<1||mv>12) continue;
        for(const dd of numCands(R.slice(6,8))){ const dv=+dd.s; if(dv<1||dv>31) continue;
          for(const hh of numCands(R.slice(8,10))){ const hv=+hh.s; if(hv>23) continue;
            for(const mi of numCands(R.slice(10,12))){ const nv=+mi.s; if(nv>59) continue;
              const v=new Date(Date.UTC(yv,mv-1,dv,hv,nv)); if(v.getUTCDate()!==dv) continue;
              out.push({sc:y.sc+mo.sc+dd.sc+hh.sc+mi.sc, v, mn:Math.min(y.mn,mo.mn,dd.mn,hh.mn,mi.mn), s:y.s+mo.s+dd.s+hh.s+mi.s}); } } } } }
    out.sort((a,b)=>b.sc-a.sc); lines.push({out:out.slice(0,80), S});
  }
  const OFF=210, now=new Date(); let best=null, second=null;
  for(const a of lines[0].out){ const init=new Date(+a.v-OFF*6e4); if(init<now-30*DAYMS || init>+now+2*DAYMS) continue;
    for(const b of lines[1].out){ if(!(b.v>a.v && b.v-a.v<=16*DAYMS) || (b.v-a.v)%36e5 || a.v.getUTCMinutes()!==b.v.getUTCMinutes()) continue;
      const c={sc:a.sc+b.sc, a, b}; if(!best || c.sc>best.sc){ second=best; best=c; } else if(!second || c.sc>second.sc) second=c; } }
  if(!best) return one;
  const margin = second ? best.sc-second.sc : 9;
  // زمان‌ها «ساعت دیواری» نقشه‌اند (GMT+0330)؛ به UTC برده می‌شوند
  const start=new Date(+best.a.v-OFF*6e4), end=new Date(+best.b.v-OFF*6e4);
  const S0=lines[0].S;
  return {src:"wu", offset:OFF, init:start, start, end, conf: Math.min(best.a.mn,best.b.mn)>=0.93 && margin>=0.05, minSim:Math.min(best.a.mn,best.b.mn),
          crop:[480+Math.max(0,tokensOf(S0,3)[0][0]-4), S0.ya-3, 760, S0.ya+2*S0.h+8],
          learn:{cells:[...cellsAll[0],...cellsAll[1]], str:best.a.s+best.b.s}};
}
// نقشه‌های ۱ تا ۲۴ ساعتهٔ weather.us فقط یک زمان «Valid for» دارند؛ طول بازه ۲۴ ساعت فرض می‌شود
function decodeWUValid(d){
  const L=ocrLib(), OFF=210, now=new Date();
  for(const li of [1,0,2]){
    const S=textLine(d,760,[480,630,760,668],li); if(!S) continue;
    const T=tokensOf(S,3); if(T.length<3) continue;
    const cells=[...WU_DATE_C.map(c=>cellAtS(S,T[T.length-3][0],c)), ...WU_TIME_C.map(c=>cellAtS(S,T[T.length-2][0],c))];
    const R=cells.map(c=>rankCell(c,L.wu)); let best=null, second=null;
    for(const y of numCands(R.slice(0,4),2)){ const yv=+y.s; if(Math.abs(yv-now.getUTCFullYear())>1) continue;
      for(const mo of numCands(R.slice(4,6))){ const mv=+mo.s; if(mv<1||mv>12) continue;
        for(const dd of numCands(R.slice(6,8))){ const dv=+dd.s; if(dv<1||dv>31) continue;
          for(const hh of numCands(R.slice(8,10))){ const hv=+hh.s; if(hv>23) continue;
            for(const mi of numCands(R.slice(10,12))){ const nv=+mi.s; if(nv>59) continue;
              const v=new Date(Date.UTC(yv,mv-1,dv,hv,nv)); if(v.getUTCDate()!==dv) continue;
              const u=new Date(+v-OFF*6e4); if(u<now-40*DAYMS || u>+now+20*DAYMS) continue;
              const c={sc:y.sc+mo.sc+dd.sc+hh.sc+mi.sc, v, mn:Math.min(y.mn,mo.mn,dd.mn,hh.mn,mi.mn), s:y.s+mo.s+dd.s+hh.s+mi.s};
              if(!best||c.sc>best.sc){ second=best; best=c; } else if(!second||c.sc>second.sc) second=c; } } } } }
    if(!best) continue;
    const end=new Date(+best.v-OFF*6e4), start=new Date(+end-24*36e5), margin=second?best.sc-second.sc:9;
    return {src:"wu", offset:OFF, init:null, start, end, single:true, conf: best.mn>=0.93 && margin>=0.05, minSim:best.mn,
            crop:[480+Math.max(0,T[0][0]-4), S.ya-3, 760, S.ya+S.h+6], learn:{cells, str:best.s}};
  }
  return null;
}
// تاریخ از نام فایل (حالت آزاد): 20261001، 2026-10-01_12 و …
function dateFromName(fn){
  const m=/(20\d{2})[-_.]?([01]\d)[-_.]?([0-3]\d)(?:[-_.T ]?([0-2]\d)(?:[:._-]?([0-5]\d))?)?/.exec(fn||""); if(!m) return null;
  const v=new Date(Date.UTC(+m[1],+m[2]-1,+m[3],+(m[4]||0),+(m[5]||0))); return isNaN(v) ? null : {src:"name", offset:0, start:v, end:v, valid:v, conf:false, minSim:0};
}
function readTimes(m){
  { const j=nwpMeta(m); if(j) return nwpTimes(j); }
  if(m.w===984 && m.h===808) return decodeWB(m.data);
  if(m.w===760 && m.h===760) return decodeWU(m.data);
  return dateFromName(m.file && m.file.name);
}
// یادگیری: پس از تأیید کاربر، ارقام همین نقشه‌ها به الگوها افزوده می‌شوند
function learnTimes(){
  for(const m of state.models){ const t=m.times; if(!t || !t.learn) continue;
    const key = t.src, list = store.get("ocr."+key, []);
    t.learn.cells.forEach((c,k)=>{ const ch=t.learn.str[k]; if(!ch) return;
      const u8=new Uint8Array(c.w*c.h); for(let i=0;i<u8.length;i++) u8[i]=Math.round(c.D[i]*255);
      let bin=""; u8.forEach(v=>bin+=String.fromCharCode(v)); list.push({c:ch, w:c.w, h:c.h, d:btoa(bin)}); });
    store.set("ocr."+key, list.slice(-400)); }
  OCR_LIB=null;
}

