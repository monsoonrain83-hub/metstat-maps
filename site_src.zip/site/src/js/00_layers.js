// لایه‌های مرزی (کشور، استان، شهرستان، حوضه، دریا، جزیره) — مشترک بین اطلس اقلیمی و صفحه‌های دیگر
{{BLOB:data_layers_shapefile}}
try{ window.CQC_LAYERS=LAYERS; }catch(e){}
