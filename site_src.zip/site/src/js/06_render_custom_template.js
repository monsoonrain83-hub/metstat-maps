/* ---------- قالب آزاد: همان ابعاد و همان جای کادر و نوار رنگ تصویر ورودی ---------- */
function renderCU(opts){
  if(opts.barLayout){ const sv={segs:P.segs, bar:P.bar, barStart:P.barStart}; Object.assign(P, opts.barLayout); try{ return renderCU({...opts, barLayout:null}); } finally { Object.assign(P, sv); } }
  const {field, kind, title, S} = opts, sc=opts.scale||1;
  const cv=document.createElement("canvas"); cv.width=P.W*sc; cv.height=P.H*sc;
  const ctx=cv.getContext("2d"); ctx.scale(sc,sc); ctx.imageSmoothingQuality="high";
  ctx.fillStyle="#fff"; ctx.fillRect(0,0,P.W,P.H);
  const pc=SCH().colors.map(hexRGB), W1=[255,255,255];
  const colorOf = opts.colorFn || (kind==="prob" ? (v=>{ const c=SCH().cls(v); return c<0 ? W1 : pc[c]; }) : (v=>PAL[classOf(v)]));
  if(!(P.T && P.T.tt && typeof ttDrawFrame==="function" && ttDrawFrame(ctx, field, colorOf, sc, opts, S))){
  if(sc===1){ const img=ctx.createImageData(FW,FH);
    for(let i=0;i<N;i++){ const rgb=colorOf(field[i]); img.data[i*4]=rgb[0]; img.data[i*4+1]=rgb[1]; img.data[i*4+2]=rgb[2]; img.data[i*4+3]=255; }
    ctx.putImageData(img, P.fx0, P.fy0); }
  else { ctx.imageSmoothingEnabled=false; ctx.drawImage(hiField(field, colorOf, sc), P.fx0, P.fy0, FW, FH); ctx.imageSmoothingEnabled=true; }   // بدون ترکیب رنگ‌ها
  if(opts.overlay){ ctx.save(); ctx.beginPath(); ctx.rect(P.fx0,P.fy0,FW,FH); ctx.clip(); drawOv(ctx, opts.overlay, P.W, P.H); ctx.restore(); }
  else if(S.showBorders && P.ov) ctx.drawImage(P.ov.bold, 0, 0);
  }
  ctx.strokeStyle="#000"; ctx.lineWidth=1; ctx.strokeRect(P.fx0-0.5, P.fy0-0.5, FW+1, FH+1);
  const fw=FW, B=P.bar, R=P.fx1, L=P.fx0;

  // سربرگ: بالای کادر اگر جا هست، وگرنه نوار سفید داخل کادر
  const barAbove = B.rect[3] <= P.fy0;
  const per = `${S.from}  ${S.to}`;
  if(P.fy0>=24 && !barAbove){
    const fs=Math.min(20, P.fy0-8);
    ctx.font=`${fs*0.75}px ${FT.body}`; const pw=ctx.measureText(per).width;
    txt(ctx, title, R, P.fy0-6-Math.max(0,(P.fy0-fs-8)/2), `${fs}px ${FT.titr}`, {maxW: fw-pw-20});
    txt(ctx, per, L, P.fy0-7-Math.max(0,(P.fy0-fs-8)/2), `${fs*0.75}px ${FT.body}`, {align:"left", color:"#222"});
  } else {
    ctx.fillStyle="rgba(255,255,255,.88)"; ctx.fillRect(L, P.fy0, fw, 26);
    ctx.font=`13px ${FT.body}`; const pw=ctx.measureText(per).width;
    txt(ctx, title, R-6, P.fy0+19, `17px ${FT.titr}`, {maxW: fw-pw-30});
    txt(ctx, per, L+6, P.fy0+18, `13px ${FT.body}`, {align:"left", color:"#222"});
  }
  // لوگو: پایین چپِ داخل کادر
  const lb=Math.max(48, Math.min(84, FH/5)), lw=Math.min(180, fw/4);
  drawBrand(ctx, S, L+6, P.fy1-6-lb, lw, lb, {halo:true, fs:Math.round(Math.max(10, Math.min(13, lb/6)))});
  // کادر اطلاعات و بیشینه: پایین راستِ داخل کادر
  const mx = opts.maxText || (kind==="prob" ? SCH().maxTxt(opts.max) : `بیشینه: ${fmt(opts.max)} ${curVar().u}`);
  let info = tr(`${mx}  |  ${opts.info}`); ctx.font=`12.5px ${FT.body}`;
  const maxW = fw*0.62; while(ctx.measureText(info).width>maxW && info.length>12) info=info.slice(0,-3)+"…";
  const iw=ctx.measureText(info).width;
  ctx.fillStyle="rgba(255,255,255,.92)"; ctx.fillRect(R-iw-12, P.fy1-17, iw+12, 17);
  txt(ctx, info, R-6, P.fy1-5, `12.5px ${FT.body}`, {color:"#111"});

  // نوار رنگ در همان جای نوار رنگ ورودی
  const [bx0,by0,bx1,by1] = B.rect, h = B.orient==="h";
  const segs = P.segs, K = segs.length;
  ctx.clearRect; ctx.fillStyle="#fff"; ctx.fillRect(bx0, by0, bx1-bx0, by1-by0);
  const lo = Math.min(...segs.map(s=>s.a)), hi = Math.max(...segs.map(s=>s.b))+1;
  const c0 = h ? by0+1 : bx0+1, c1 = h ? by1-1 : bx1-1;
  let swatches, labels;
  if(kind==="prob"){
    const cols=["#ffffff",...SCH().colors], n=cols.length, w=(hi-lo)/n;
    swatches = cols.map((c,k)=>({a:lo+k*w, b:lo+(k+1)*w, col:c}));
    labels = cols.map((_,k)=>({p:lo+(k+0.5)*w, s: SCH().labs[k]}));
    if(!h) { swatches.reverse(); }
  } else {
    swatches = segs.map((s,k)=>({a:s.a, b:s.b+1, col:`rgb(${(opts.barCols?opts.barCols[k]:PAL[P.barStart+k])})`}));
    // مرز j بین خانهٔ j-1 و j
    const pos = j => { if(j===0) return h ? segs[0].a : (segs[0].a<segs[K-1].a ? segs[0].a : segs[0].b+1);
                       if(j===K) return h ? segs[K-1].b+1 : (segs[0].a<segs[K-1].a ? segs[K-1].b+1 : segs[K-1].a);
                       const p=segs[j-1], q=segs[j]; return p.b<q.a ? (p.b+1+q.a)/2 : (q.b+1+p.a)/2; };
    labels = []; for(let j=0;j<=K;j++){ const v=opts.barEdges?opts.barEdges[j]:EDGES[P.barStart+j]; if(isFinite(v)) labels.push({p:pos(j), s:FA(+(+v).toFixed(2))}); }
  }
  for(const s of swatches){ ctx.fillStyle=s.col; if(h) ctx.fillRect(Math.round(s.a), c0, Math.round(s.b)-Math.round(s.a), c1-c0); else ctx.fillRect(c0, Math.round(s.a), c1-c0, Math.round(s.b)-Math.round(s.a)); }
  ctx.strokeStyle="#000"; ctx.lineWidth=1;
  if(h) ctx.strokeRect(lo-0.5, c0-0.5, hi-lo+1, c1-c0+1); else ctx.strokeRect(c0-0.5, lo-0.5, c1-c0+1, hi-lo+1);
  // سمتی از نوار که جای بیشتری برای اعداد دارد
  if(h){
    const up = by0 - (by0>P.fy1 ? P.fy1+1 : 0), dn = (by1<P.fy0 ? P.fy0-1 : P.H) - by1;
    const fs = Math.max(9, Math.min(13, Math.max(up,dn)-4)), above = up>=dn;
    let last=-1e9; ctx.font=`${fs}px ${FT.lal}`;
    for(const l of labels){ const tw=ctx.measureText(l.s).width; if(l.p-tw/2 < last+4) continue;
      txt(ctx, l.s, Math.max(tw/2+2, Math.min(P.W-tw/2-2, l.p)), above ? c0-4 : c1+fs+2, `${fs}px ${kind==="prob"?FT.body:FT.lal}`, {align:"center", dir: kind==="prob"?"rtl":"ltr", color:"#222"}); last=l.p+tw/2; }
  } else {
    const lf = bx0 - (bx0>P.fx1 ? P.fx1+1 : 0), rt = (bx1<P.fx0 ? P.fx0-1 : P.W) - bx1;
    const right = rt>=lf, fs=11; let last=-1e9;
    for(const l of labels.slice().sort((a,b)=>a.p-b.p)){ if(l.p < last+fs+2) continue;
      txt(ctx, l.s, right ? c1+4 : c0-4, l.p+fs/2-1, `${fs}px ${kind==="prob"?FT.body:FT.lal}`, {align: right?"left":"right", dir: kind==="prob"?"rtl":"ltr", color:"#222"}); last=l.p; }
  }
  return cv;
}
/* ---------- قالب WeatherBELL: ۹۸۴×۸۰۸ با مرزهای اصلی ---------- */
function renderWB(opts){
  const {field, kind, title, S, ref} = opts;
  const cv=document.createElement("canvas"); cv.width=P.W; cv.height=P.H;
  const ctx=cv.getContext("2d");
  ctx.fillStyle="#fff"; ctx.fillRect(0,0,P.W,P.H);
  // ۱) دادهٔ آماری (بدون مرز)
  const img=ctx.createImageData(FW,FH), pc=SCH().colors.map(hexRGB);
  for(let i=0;i<N;i++){
    let rgb;
    if(opts.colorFn) rgb=opts.colorFn(field[i]);
    else if(kind==="prob"){ const c=SCH().cls(field[i]); rgb = c<0 ? [255,255,255] : pc[c]; }
    else rgb = PAL[classOf(field[i])];
    img.data[i*4]=rgb[0]; img.data[i*4+1]=rgb[1]; img.data[i*4+2]=rgb[2]; img.data[i*4+3]=255;
  }
  ctx.putImageData(img, P.fx0, P.fy0);
  // ۲) خطوط شبکه، سپس مرزها، ساحل و قاب — روی داده
  if(S.showBorders){
    if(S.grid) ctx.drawImage(P.ov.grid, 0, 0);
    ctx.drawImage(S.borders==="orig" ? P.ov.orig : P.ov.bold, 0, 0);
    if(S.borders==="roads" && WB_ROADS_IMG.complete && WB_ROADS_IMG.naturalWidth){ ctx.save(); ctx.imageSmoothingEnabled=false; ctx.drawImage(WB_ROADS_IMG, 0, 0, P.W, P.H); ctx.restore(); }
  } else { ctx.strokeStyle="#000"; ctx.lineWidth=1; ctx.strokeRect(P.fx0-0.5, P.fy0-0.5, FW+1, FH+1); }

  // ۳) سربرگ: عنوان (راست) و بازهٔ زمانی (چپ)
  const per = `${S.from}  ${S.to}`;
  ctx.font=`15px ${FT.body}`; const pw=ctx.measureText(per).width;
  txt(ctx, title, 975, 25, `20px ${FT.titr}`, {maxW: 965-pw-24});
  txt(ctx, per, 9, 24, `15px ${FT.body}`, {align:"left", color:"#222"});

  // ۴) لوگو روی جای لوگوی WeatherBELL
  drawBrand(ctx, S, 13, 672, 120, 80, {halo:true, fs:13});

  // ۵) کادر اطلاعات، جای متن منبع داده (پایین راست، داخل کادر)
  ctx.font=`12.5px ${FT.body}`;
  let info = tr(opts.info); let iw = ctx.measureText(info).width;
  while(iw>640 && info.length>10){ info = info.slice(0,-2); iw = ctx.measureText(info+"…").width; if(iw<=640) info+="…"; }
  iw = ctx.measureText(info).width;
  ctx.fillStyle="rgb(253,255,255)"; ctx.fillRect(975-iw-14, 742, iw+14, 17);
  txt(ctx, info, 968, 755, `12.5px ${FT.body}`, {color:"#111"});

  // ۶) نوار رنگ
  const segX = barSegments(ref);
  if(kind==="prob"){
    const cols=["#ffffff",...SCH().colors], labs=SCH().labs;
    const x0=23, x1=700, w=(x1-x0)/cols.length;
    ctx.fillStyle="#000"; ctx.fillRect(x0,778,x1-x0+1,15);
    cols.forEach((c,i)=>{ const a=Math.round(x0+i*w)+1, b=Math.round(x0+(i+1)*w); ctx.fillStyle=c; ctx.fillRect(a,779,b-a,13);
      txt(ctx, labs[i], (a+b)/2, 775, `13px ${FT.body}`, {align:"center"}); });
    txt(ctx, SCH().title, 712, 790, `13px ${FT.body}`, {align:"left", color:"#333"});
  } else if(S.barMode==="full" && ref){
    // عیناً همان نوار رنگ WeatherBELL، با اعداد فارسی
    const blk = new ImageData(new Uint8ClampedArray(680*17*4), 680, 17);
    for(let y=0;y<17;y++) for(let x=0;x<680;x++){ const s=((777+y)*P.W+22+x)*4, d=(y*680+x)*4; for(let q=0;q<4;q++) blk.data[d+q]=ref[s+q]; }
    ctx.putImageData(blk, 22, 777);
    for(let k=0;k<segX.length;k+=P.labelEvery) txt(ctx, FA(EDGES[k+1]), segX[k], 775, `12.5px ${FT.lal}`, {align:"center", dir:"ltr", color:"#222"});
  } else {
    // کشیده تا بیشینهٔ همین نقشه
    const kmax=Math.max(1, classOf(opts.max)), x0=39, x1=700, w=(x1-x0)/kmax;
    ctx.fillStyle="#000"; ctx.fillRect(23,778,x1-23+1,15);
    ctx.fillStyle="#fff"; ctx.fillRect(24,779,x0-24,13);
    for(let c=1;c<=kmax;c++){ const a=Math.round(x0+(c-1)*w), b=Math.round(x0+c*w); ctx.fillStyle=`rgb(${PAL[c]})`; ctx.fillRect(a,779,b-a+(c===kmax?0:0),13); }
    let lastX=-99; ctx.font=`12.5px ${FT.lal}`;
    for(let c=1;c<=kmax+1;c++){ const x=x0+(c-1)*w, s=FA(EDGES[c]); const tw=ctx.measureText(s).width;
      if(x-tw/2 < lastX+4 && c!==kmax+1) continue;
      txt(ctx, s, Math.min(x, P.W-6-tw/2), 775, `12.5px ${FT.lal}`, {align:"center", dir:"ltr", color:"#222"}); lastX=x+tw/2; }
  }
  // ۷) بیشینه، جای «Max»
  const mx = kind==="prob" ? SCH().maxTxt(opts.max) : `بیشینه: ${fmt(opts.max)} ${curVar().u}`;
  txt(ctx, mx, 975, 791, `16px ${FT.lal}`, {color:"#111"});
  return cv;
}
// مختصات x شروع هر کلاس روی نوار رنگ مرجع (به‌اضافهٔ انتهای نوار)
function barSegments(ref){
  const xs=[]; if(!ref) return xs; let prev=-1;
  for(let x=P.barX0;x<=P.barX1;x++){ const i=(P.barY*P.W+x)*4, k=(ref[i]<<16)|(ref[i+1]<<8)|ref[i+2]; if(k!==prev){ xs.push(x); prev=k; } }
  xs.push(P.barX1+1);
  // تصویر فشرده (JPEG): تعداد تکه‌ها با تعداد خانه‌های نوار نمی‌خواند → خانه‌ها با فاصلهٔ برابر
  const n=NC-P.barStart; if(xs.length!==n+1 && n>0){ xs.length=0; const w=(P.barX1-P.barX0+1)/n; for(let k=0;k<=n;k++) xs.push(Math.round(P.barX0+k*w)); }
  return xs;
}
