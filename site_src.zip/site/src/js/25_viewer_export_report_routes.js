// ---- پنجرهٔ ذخیره و اشتراک‌گذاری ----
function vDialog(id, cls){ let d=$(id); if(d) return d; d=document.createElement("dialog"); d.id=id; d.className="vdlg "+(cls||"");
  d.innerHTML=`<div class="vdh"><h3></h3><button class="hx" type="button" aria-label="بستن">×</button></div><div class="vdb"></div><div class="vdf"></div>`;
  d.querySelector(".hx").onclick=()=>d.close(); d.addEventListener("click",e=>{ if(e.target===d) d.close(); }); document.body.append(d); return d; }
function vExport(pg, mode="save"){
  const card=pg.sel; if(!card) return; const d=vDialog("expDlg","expdlg"); d.dir=LANG==="en"?"ltr":"rtl";
  d.querySelector("h3").textContent=(mode==="share"?"اشتراک‌گذاری — ":"ذخیرهٔ نقشه — ")+vTitle(card);
  const b=d.querySelector(".vdb"); b.replaceChildren(); d.querySelector(".vdf").replaceChildren();
  const dls=[...card.querySelectorAll(".dl button")];
  const grid=document.createElement("div"); grid.className="expgrid";
  const ico={PNG:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 16l5-5 4 4 3-3 6 6"/>', CSV:'<path d="M4 4h16v16H4z"/><path d="M4 10h16M4 15h16M10 4v16"/>', NetCDF:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>'};
  for(const o of dls){ const lab=o.textContent.trim(); const k=Object.keys(ico).find(x=>lab.toUpperCase().startsWith(x.toUpperCase()))||null;
    const x=document.createElement("button"); x.type="button"; x.className="expbtn"; x.innerHTML=svgIc(ico[k]||'<path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M4 17v3h16v-3"/>')+`<span></span>`; x.querySelector("span").textContent=lab;
    x.onclick=()=>{ o.click(); }; grid.append(x); }
  if(mode!=="share") b.append(grid);
  const sh=document.createElement("div"); sh.className="share"; sh.innerHTML=`<h4>اشتراک‌گذاری تصویر نقشه (PNG)</h4><div class="shbtns"></div><p class="hint" style="margin:6px 0 0"></p>`;
  const sb=sh.querySelector(".shbtns"), note=sh.querySelector("p");
  const pngBtn=dls.find(o=>/^PNG$/i.test(o.textContent.trim()))||dls.find(o=>/PNG/i.test(o.textContent));
  const getBlob=async()=>{ const im=card.querySelector("img")||pg.stage.querySelector(".svis img"); const cvs=im&&CANVAS_OF.get(vKey(im.dataset.lo||im.getAttribute("src")));
    if(cvs) return await exportPNG(cvs); const r=await fetch(im.src); return await r.blob(); };
  const title=vTitle(card)+" — MetStat (wtafkik.ir)";
  const native=document.createElement("button"); native.type="button"; native.className="shb main"; native.textContent="اشتراک‌گذاری (تلگرام، واتساپ، اینستاگرام، …)";
  native.onclick=async()=>{ try{ const blob=await getBlob(); const f=new File([blob],"metstat_map.png",{type:"image/png"});
      if(navigator.canShare && navigator.canShare({files:[f]})){ await navigator.share({files:[f], title, text:title}); return; }
      note.textContent="این مرورگر اشتراک مستقیم تصویر را پشتیبانی نمی‌کند؛ تصویر دانلود شد، آن را در برنامهٔ مورد نظر بفرستید."; if(pngBtn) pngBtn.click(); }catch(e){ if(e.name!=="AbortError") note.textContent="اشتراک‌گذاری انجام نشد: "+e.message; } };
  sb.append(native);
  const site=location.protocol.startsWith("http")?location.href:"https://wtafkik.ir";
  const links=[["X / Twitter",`https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(site)}`],["Telegram",`https://t.me/share/url?url=${encodeURIComponent(site)}&text=${encodeURIComponent(title)}`],["WhatsApp",`https://wa.me/?text=${encodeURIComponent(title+" "+site)}`],["Facebook",`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(site)}`]];
  for(const [n,u] of links){ const a=document.createElement("a"); a.className="shb"; a.href=u; a.target="_blank"; a.rel="noopener"; a.textContent=n; a.setAttribute("data-noi18n",""); sb.append(a); }
  const ig=document.createElement("button"); ig.type="button"; ig.className="shb"; ig.textContent="Instagram"; ig.setAttribute("data-noi18n","");
  ig.onclick=()=>native.click(); sb.append(ig);
  note.textContent="روی گوشی، دکمهٔ اشتراک‌گذاری خود تصویر نقشه را مستقیم به برنامه‌ها می‌فرستد. پیوندهای X، تلگرام، واتساپ و فیسبوک فقط عنوان و نشانی سایت را می‌فرستند.";
  if(mode==="share") b.append(sh); d.showModal();
}
// ---- گزارش و تحلیل ----
function vReportSource(pg){
  if(pg.key==="main"){ try{ return mainReportSource(pg); }catch(e){ console.warn("report",e); return null; } }
  if(pg.key==="ds"){ const c=pg.sel; const q=sel=>(c&&c.querySelector(sel))||pg.msb.querySelector(sel)||pg.stage.querySelector(sel); const pre=c&&q(".dsrep pre"), rel=c&&q(".dsrel"); if(!pre&&!rel) return null;
    const lines=[]; if(rel) lines.push(...rel.innerText.split("\n").filter(Boolean)); if(pre) lines.push("ℹ️ "+(LANG==="en"?"Processing details":"جزئیات پردازش"), ...pre.textContent.split("\n"));
    return {title:vTitle(c), paras:[lines.join("\n")], tables:[], imgs:[c.querySelector("img")||pg.stage.querySelector(".svis img")].filter(Boolean)}; }
  const rep=pg.cards.querySelector("article.cvrep"); if(!rep) return null;
  const paras=[...rep.querySelectorAll(".paras > p")].map(p=>p.textContent);
  const tables=[...rep.querySelectorAll(".paras table")];
  const all=vEntries(pg), pick=all.slice(0, pg.key==="cv"?2:1).map(c=>c.querySelector("img")||pg.stage.querySelector(".svis img")).filter(Boolean);
  if(pg.key==="cv"){ const h=all.find(c=>/تگرگ|Hail/i.test(vTitle(c))); if(h){ const im=h.querySelector("img")||(pg.sel===h?pg.stage.querySelector(".svis img"):null); if(im) pick.push(im); } }
  return {title:rep.querySelector("h3").textContent, paras, tables, imgs:pick};
}
const RTL_CH=/[؀-ۿ]/;
// هر سطر: عنوان (شروع با نشانهٔ سطح یا ⚠️/📋/ℹ️)، بند فهرست (▪)، زیرسطر (📍🕒⚡👥🌾🚗🏗️) یا متن عادی
function vBlocks(paras){
  const out=[];
  for(const p of paras){ const ls=p.split("\n").map(s=>s.trim()).filter(Boolean);
    ls.forEach((l,i)=>{ let t="p";
      if(/^(⚠️|📋|ℹ️|🔴|🟠|🟡)/u.test(l) && (i===0 || /^(🔴|🟠|🟡|📋)/u.test(l))) t = /^(🔴|🟠|🟡)/u.test(l)?"h2":"h1";
      else if(/^▪/.test(l)) t="li"; else if(/^(📍|🕒|⚡)/u.test(l)) t="sub"; else if(/^(👥|🌾|🚗|🏗️)/u.test(l)) t="adv";
      if(t==="h1" && /^ℹ️/u.test(l) && l.length>60){ const k=l.indexOf(":"); if(k>0 && k<40){ out.push({t:"h1",s:l.slice(0,k)}); out.push({t:"p",s:l.slice(k+1).trim()}); return; } t="p"; }
      if(t==="h1" && l.length>90 && !/^(⚠️)/u.test(l)){ t="p"; }
      out.push({t,s:l}); });
    out.push({t:"gap"}); }
  return out;
}
// متن‌های لاتین درون سطر فارسی جدا (LTR) نگه داشته می‌شوند تا ترتیب جمله به هم نریزد
function vBidi(el, s){ const en=LANG==="en"; el.dir=en?"ltr":"rtl"; if(!en && typeof bidiMath==="function") s=bidiMath(s);
  const parts=s.split(/([A-Za-z][A-Za-z0-9.,%°/·:+\-–()² ]*[A-Za-z0-9%°)²]|[A-Za-z])/);
  for(const x of parts){ if(!x) continue; if(!en && /^[A-Za-z]/.test(x)){ const b=document.createElement("bdi"); b.dir="ltr"; b.textContent=x; el.append(b); } else el.append(document.createTextNode(x)); } }
function vReport(pg){ const src=vReportSource(pg); if(src) vReportShow(src); }
function vReportShow(src){
  const d=vDialog("repDlg","repdlg"); const en=LANG==="en"; d.dir=en?"ltr":"rtl";
  d.querySelector("h3").textContent=src.title; const b=d.querySelector(".vdb"); b.replaceChildren(); b.className="vdb rep "+(en?"en":"fa");
  const blocks=vBlocks(src.paras.map(p=>src.noTr?p:trText(p)));
  let ul=null;
  for(const k of blocks){ if(k.t==="gap"){ ul=null; continue; }
    let e; if(k.t==="h1"){ e=document.createElement("h2"); ul=null; } else if(k.t==="h2"){ e=document.createElement("h3"); e.className="lvh"+(/^🔴/u.test(k.s)?" r":/^🟠/u.test(k.s)?" o":" y"); ul=null; }
    else if(k.t==="li"){ if(!ul){ ul=document.createElement("ul"); b.append(ul); } e=document.createElement("li"); vBidi(e, k.s.replace(/^▪\s*/,"")); ul.append(e); continue; }
    else if(k.t==="sub"){ const host=ul&&ul.lastElementChild; e=document.createElement("div"); e.className="rsub"; vBidi(e,k.s); (host||b).append(e); continue; }
    else if(k.t==="adv"){ e=document.createElement("p"); e.className="radv"; ul=null; }
    else { e=document.createElement("p"); ul=null; }
    vBidi(e, k.s); b.append(e); }
  for(const t of src.tables){ const c=t.cloneNode(true); c.classList.add("rtab"); b.append(c); }
  const f=d.querySelector(".vdf"); f.replaceChildren();
  const txt=blocks.filter(k=>k.t!=="gap").map(k=>k.s).join("\n");
  const cp=document.createElement("button"); cp.type="button"; cp.className="btn main"; cp.textContent="Copy";
  cp.onclick=async()=>{ try{ await navigator.clipboard.writeText(txt); }catch(e){ const t=document.createElement("textarea"); t.value=txt; document.body.append(t); t.select(); document.execCommand("copy"); t.remove(); } cp.textContent=en?"Copied ✓":"کپی شد ✓"; setTimeout(()=>cp.textContent="Copy",1500); };
  const pdf=document.createElement("button"); pdf.type="button"; pdf.className="btn main"; pdf.textContent="PDF";
  pdf.onclick=async()=>{ pdf.disabled=true; try{ const blob=await vPdf(src, blocks); const u=URL.createObjectURL(blob), a=document.createElement("a"); a.href=u; a.download=(ROUTES[store.get("mode","")]||"report")+"_report.pdf"; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),5000); }catch(e){ console.error(e); alert(e.message); } pdf.disabled=false; };
  cp.setAttribute("data-noi18n",""); pdf.setAttribute("data-noi18n",""); f.append(cp, pdf);
  if(typeof ttsAttach==="function") ttsAttach(d, b, en?"en":"fa");
  d.showModal(); if(typeof ttsAuto==="function") ttsAuto(d);
}
// ---- PDF گزارش: صفحهٔ A4، یک‌سوم بالای صفحهٔ اول برای نقشه‌ها و سپس متن ----
async function vPdf(src, blocks){
  const en=LANG==="en", W=1240, H=1754, M=88, pages=[]; await document.fonts.ready;
  const FONT=w=>`${w} ${en?"":""}`; const fam='"Ketab"';
  let cv, x, y;
  const newPage=()=>{ cv=document.createElement("canvas"); cv.width=W; cv.height=H; x=cv.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,W,H); x.direction=en?"ltr":"rtl"; x.textAlign=en?"left":"right"; pages.push(cv); y=M;
    // پانویس
    x.save(); x.font=`400 18px ${fam}`; x.fillStyle="#7a8699"; x.textAlign="center"; x.fillText("MetStat — wtafkik.ir", W/2, H-40); x.restore(); };
  newPage();
  // سربرگ
  try{ const lg=state.logoImg; if(lg && lg.naturalWidth){ const h=70, w=lg.naturalWidth*h/lg.naturalHeight; x.drawImage(lg, en?W-M-w:M, y-10, w, h); } }catch(e){}
  x.fillStyle="#15233b"; x.font=`700 34px ${fam}`; x.fillText(trText(src.title), en?M:W-M, y+30); y+=60;
  x.fillStyle="#d5dce7"; x.fillRect(M, y, W-2*M, 3); y+=18;
  // نقشه‌ها: یک‌سوم ارتفاع صفحه
  const imgs=[]; for(const im of src.imgs){ try{ const i=new Image(); i.src=im.src; await i.decode(); imgs.push(i); }catch(e){} }
  if(imgs.length){ const boxH=Math.round(H/3), gap=16, bw=(W-2*M-gap*(imgs.length-1))/imgs.length;
    imgs.forEach((im,k)=>{ const s=Math.min(bw/im.naturalWidth, boxH/im.naturalHeight), w=im.naturalWidth*s, h=im.naturalHeight*s; const bx=M+k*(bw+gap)+(bw-w)/2;
      x.drawImage(im, bx, y+(boxH-h)/2, w, h); x.strokeStyle="#d5dce7"; x.lineWidth=1; x.strokeRect(bx, y+(boxH-h)/2, w, h); });
    y+=boxH+28; }
  const wrap=(s, font, maxW)=>{ x.font=font; const words=s.split(/\s+/), lines=[]; let cur="";
    for(const w of words){ const t=cur?cur+" "+w:w; if(x.measureText(t).width>maxW && cur){ lines.push(cur); cur=w; } else cur=t; } if(cur) lines.push(cur); return lines; };
  const STY={h1:{f:`700 30px ${fam}`, lh:46, c:"#0a3d8f", pre:16, post:6}, h2:{f:`700 27px ${fam}`, lh:42, c:"#15233b", pre:18, post:4}, p:{f:`400 22px ${fam}`, lh:38, c:"#1d2433", pre:4, post:6},
    li:{f:`600 23px ${fam}`, lh:38, c:"#15233b", pre:8, post:0, ind:24}, sub:{f:`400 21px ${fam}`, lh:34, c:"#3b475a", pre:0, post:0, ind:56}, adv:{f:`400 21.5px ${fam}`, lh:36, c:"#1d2433", pre:6, post:4, ind:0}};
  const LVC={"🔴":"#e01b1b","🟠":"#ff8c00","🟡":"#ffd21f"};
  for(const k of blocks){ if(k.t==="gap"){ y+=10; continue; }
    const st=STY[k.t]||STY.p; let s=k.s; if(k.t==="li") s=s.replace(/^▪\s*/,"• ");
    const lines=wrap(s, st.f, W-2*M-(st.ind||0)-(k.t==="h2"?18:0));
    y+=st.pre; if(y+st.lh*Math.min(2,lines.length)>H-90){ newPage(); }
    if(k.t==="h2"){ const em=(s.match(/^(🔴|🟠|🟡)/u)||[])[1]; x.fillStyle=LVC[em]||"#999"; x.fillRect(en?M:W-M-8, y+6, 8, st.lh*lines.length-6); }
    x.font=st.f; x.fillStyle=st.c;
    for(const l of lines){ if(y+st.lh>H-80){ newPage(); x.font=st.f; x.fillStyle=st.c; }
      const off=(st.ind||0)+(k.t==="h2"?18:0); x.fillText(l, en?M+off:W-M-off, y+st.lh*0.75); y+=st.lh; }
    y+=st.post; }
  return pdfFromCanvases(pages);
}
function pdfFromCanvases(pages){
  const enc=new TextEncoder(), chunks=[], offs=[]; let len=0;
  const push=b=>{ if(typeof b==="string") b=enc.encode(b); chunks.push(b); len+=b.length; };
  const obj=(n, body)=>{ offs[n]=len; push(`${n} 0 obj\n`); if(Array.isArray(body)) body.forEach(push); else push(body); push("\nendobj\n"); };
  push("%PDF-1.4\n%\xE2\xE3\xCF\xD3\n");
  const np=pages.length, kids=[]; let n=3;
  const imgs=pages.map(cv=>{ const u=cv.toDataURL("image/jpeg",0.9), bin=atob(u.split(",")[1]), a=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++) a[i]=bin.charCodeAt(i); return a; });
  const pw=595.28, ph=841.89;
  const objs=[];
  pages.forEach((cv,i)=>{ const pn=n++, cn=n++, im=n++; kids.push(pn); objs.push([pn,cn,im,cv,imgs[i]]); });
  obj(1, "<< /Type /Catalog /Pages 2 0 R >>");
  obj(2, `<< /Type /Pages /Count ${np} /Kids [${kids.map(k=>k+" 0 R").join(" ")}] >>`);
  for(const [pn,cn,im,cv,data] of objs){
    obj(pn, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /XObject << /Im${im} ${im} 0 R >> >> /Contents ${cn} 0 R >>`);
    const cs=`q ${pw} 0 0 ${ph} 0 0 cm /Im${im} Do Q`;
    obj(cn, `<< /Length ${cs.length} >>\nstream\n${cs}\nendstream`);
    obj(im, [`<< /Type /XObject /Subtype /Image /Width ${cv.width} /Height ${cv.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${data.length} >>\nstream\n`, data, "\nendstream"]);
  }
  const xref=len; let xr=`xref\n0 ${n}\n0000000000 65535 f \n`; for(let i=1;i<n;i++) xr+=String(offs[i]).padStart(10,"0")+" 00000 n \n";
  push(xr); push(`trailer\n<< /Size ${n} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
  return new Blob(chunks,{type:"application/pdf"});
}
// ---- پرسش‌های یادگیری (پس از بارگذاری) در پنجرهٔ بازشو ----
function vAsk(){
  const k=vPageKey(); if(!k) return; const d=vDialog("askDlg","askdlg"); d.dir=LANG==="en"?"ltr":"rtl"; const b=d.querySelector(".vdb");
  const items=[];
  if(k==="main"){ const ta=$("timeAuto"); if(ta && !ta.hidden && !ta.dataset.asked) items.push(["time", ta]); }
  if(k==="cv"||k==="wn"){ const list=(k==="cv"?cv.maps:wn.maps).filter(m=>!m.bad && !m.v && !m.askDone); if(list.length) items.push(["edges", list]); }
  if(!items.length || d.open) return;
  d.querySelector("h3").textContent="پرسش‌های یادگیری"; b.replaceChildren(); const f=d.querySelector(".vdf"); f.replaceChildren();
  const back=[];
  for(const [t,v] of items){
    if(t==="time"){ const h=document.createElement("h4"); h.textContent="تاریخ و ساعت خوانده‌شده از نقشه درست است؟"; b.append(h); const ph=document.createComment("ta"); v.replaceWith(ph); b.append(v); back.push(()=>ph.replaceWith(v)); v.dataset.asked="1"; }
    if(t==="edges"){ const h=document.createElement("h4"); h.textContent="اعداد نوار رنگ این نقشه‌ها خوانده نشد؛ یک بار وارد کنید تا برای دفعه‌های بعد یاد گرفته شود:"; b.append(h);
      for(const m of v){ m.askDone=true; const row=document.createElement("label"); row.className="askrow"; const nm=document.createElement("b"); nm.textContent=m.file.name; nm.dir="ltr";
        const inp=document.createElement("input"); inp.dir="ltr"; inp.placeholder=`${FA(m.prof.T.colors.length+1)} عدد: حد پایین هر رنگ و حد بالای آخرین`;
        inp.onchange=()=>{ const lst=k==="cv"?$("cvList"):$("wnList"); const idx=(k==="cv"?cv.maps:wn.maps).indexOf(m); const rows=[...lst.querySelectorAll(".cvrow")]; const ed=rows[idx]&&rows[idx].querySelector("input.ed"); if(ed){ ed.value=inp.value; ed.dispatchEvent(new Event("change")); } };
        row.append(nm, inp); b.append(row); } } }
  const ok=document.createElement("button"); ok.type="button"; ok.className="btn main"; ok.textContent="تأیید"; ok.onclick=()=>d.close(); f.append(ok);
  d.onclose=()=>{ back.forEach(fn=>fn()); d.onclose=null; };
  d.showModal();
}
setInterval(()=>{ try{ if(V.off) return; const k=vPageKey(); if(!k) return; const busy=k==="main"?state.busy:k==="cv"?cv.busy:k==="wn"?wn.busy:false; if(!busy) vAsk(); }catch(e){} }, 1500);
// ---- آدرس هر صفحه (wtafkik.ir/alertmaps و …) ----
// حالت پیش‌فرض: آدرس با # (wtafkik.ir/#/alertmaps) که روی هر سرور بدون تنظیم و بدون خطای «صفحه موجود نیست» کار می‌کند.
// اگر سرور مسیرها را به index.html برگرداند، با <meta name="metstat-routes" content="path"> آدرس تمیز (wtafkik.ir/alertmaps) فعال می‌شود.
// آدرس مستقیم (بدون #) به‌صورت خودکار: اگر سرور /online-maps را به index.html برگرداند (فایل .htaccess) فعال می‌شود؛ وگرنه حالت # می‌ماند.
let ROUTE_PATH=location.protocol.startsWith("http") && (!!document.querySelector('meta[name="metstat-routes"][content="path"]') || store.get("routes.path",0)===1 || Object.values(ROUTES).includes(location.pathname.replace(/\/+$/,"").split("/").pop()));
if(ROUTE_PATH && /\/$/.test(location.pathname) && location.pathname.length>1){ try{ history.replaceState(history.state,"",location.pathname.replace(/\/+$/,"")+location.search+location.hash); }catch(e){} }
function routeOf(){ const slugs=Object.values(ROUTES); const h=location.hash.replace(/^#\/?/,"").replace(/\/+$/,"").split("/").pop();
  const p=location.pathname.replace(/\/+$/,"").split("/").pop(); const slug=slugs.includes(h)?h:slugs.includes(p)?p:""; return Object.keys(ROUTES).find(k=>ROUTES[k]===slug)||""; }
function setRoute(mode, replace){ const slug=mode?ROUTES[mode]:""; try{
  const f=(replace?history.replaceState:history.pushState).bind(history);
  if(ROUTE_PATH){ const base=location.pathname.replace(new RegExp("/("+Object.values(ROUTES).join("|")+")/?$"),"").replace(/\/[^/]*\.html?$/,""); const url=(base||"")+"/"+slug; if(location.pathname!==url) f({mode},"",url); }
  else { const base=location.pathname.replace(new RegExp("/("+Object.values(ROUTES).join("|")+")/?$"),"/"); const want=slug?"#/"+slug:""; if(location.hash!==want || base!==location.pathname) f({mode},"",base+location.search+want); } }catch(e){} }
function openMode(m){ if(!m) return showLanding(); return m==="wm"?openWM():m==="on"?openON():m==="ci"?openCI():m==="cqc"?openCQC():m==="ca"?openCA():m==="ds"?openDS():m==="cv"?openCV():m==="lt"?openLT():m==="wn"?openWN():switchMode(m); }
window.addEventListener("popstate", ()=>{ V.nav=true; try{ openMode(routeOf()); } finally{ V.nav=false; } });
// عنوان صفحه، دکمهٔ بازگشت و آدرس با هر تغییر صفحه به‌روز می‌شود
function vOnPage(){ const m=store.get("mode",""), land=!$("landing").hidden, k=vPageKey();
  $("pgName").textContent = land ? "" : (PAGE_NAME[m]||"");
  $("pgName").hidden = land; $("backBtn").hidden = land;
  { const sub=$("subtitle"); if(sub){ if(V.sub0==null) V.sub0=sub.textContent; sub.textContent = tr((!land && PAGE_SUB[m]) || V.sub0); } }
  if(!V.nav) setRoute(land?"":m);
  if(V.off) return;
  if(k && !V.pages[k]) vBuild(k);
  if(k){ const pg=V.pages[k]; pg.stage.querySelector(".brdMode").value=brdMode(); vSync(pg); } }
{ const mo=new MutationObserver(()=>{ clearTimeout(V.pt); V.pt=setTimeout(vOnPage,30); }); for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp","ciApp"]) if($(id)) mo.observe($(id),{attributes:true, attributeFilter:["hidden"]}); }
$("backBtn").onclick=()=>{ showLanding(); };
// پیش‌فرض مرزبندی: MetStat
if(store.get("brd.mode",null)===null) setBrdMode("metstat"); else { const v=brdMode(); document.querySelectorAll(".brdMode").forEach(s=>s.value=v); }
{ const m=routeOf(); if(m){ V.nav=true; Promise.resolve(openMode(m)).finally(()=>{ V.nav=false; }); } }
if(location.protocol.startsWith("http")){ fetch(location.origin+"/"+ROUTES.on,{method:"HEAD",cache:"no-store"}).then(r=>{
  const ok=r.ok && /html/i.test(r.headers.get("content-type")||""); store.set("routes.path",ok?1:0);
  if(ok!==ROUTE_PATH){ ROUTE_PATH=ok; try{ const m=routeOf(); setRoute(m,true); }catch(e){} } }).catch(()=>{}); }
// برچسب دکمه‌های انتخاب نقشه با عنوان کارت‌ها هماهنگ می‌ماند (عنوان‌ها پس از ساخت نقشه پر می‌شوند)
setInterval(()=>{ const k=vPageKey(); const pg=k&&V.pages[k]; if(!pg) return; const ents=vEntries(pg), bs=[...pg.tabs.querySelectorAll(".mtab")];
  if(bs.length!==ents.length){ vSync(pg); return; } bs.forEach((b,i)=>{ const t=vTitle(ents[i]); if(b.textContent!==t) b.textContent=t; }); }, 700);

/* ---- زبان ---- */
$("langBtn").onclick=()=>setLang(LANG==="en"?"fa":"en");
document.addEventListener("langchange", ()=>{
  try{ if(typeof wuzRefresh==="function") wuzRefresh(); }catch(e){}
  for(const id of ["run","dsRun","cvRun","ltRun","wnRun"]){ const b=$(id); if(b && b.offsetParent!==null && !b.disabled){ try{ b.click(); }catch(e){ console.warn(e); } } }
});
i18nStart();
