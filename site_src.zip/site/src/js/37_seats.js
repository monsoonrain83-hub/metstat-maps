/* =====================================================================
   نقاط مراکز شهرستان‌ها روی نقشه‌های خروجی (روشن/خاموش)
   ۴۸۰ مرکز شهرستان از لایهٔ نقاط مراکز جمعیتی (GNS) و مرز شهرستان‌ها استخراج شده است.
   نقطهٔ ریز سیاه با حلقهٔ سفید: سیاهِ توپر و ترکیب سیاه‌وسفید در هیچ‌کدام از نوارهای رنگ بارش و دما نیست و
   روی هر رنگی دیده می‌شود. اندازه از مقیاس هر قالب (پیکسل در هر درجه) گرفته می‌شود تا روی WeatherBELL،
   weather.us، weathermodels، tropicaltidbits، حالت آزاد و زوم‌های استانی یکسان و کوچک بماند.
   ===================================================================== */
{{BLOB:county_seats}}
function seatsOn(){ return store.get("seats.on", false); }
function setSeats(on){
  store.set("seats.on", !!on);
  document.querySelectorAll(".seatSel").forEach(s=>s.value=on?"1":"0");
  for(const id of ["seatsChk","caSeats"]){ const e=$(id); if(e) e.checked=!!on; }
  const k=typeof vPageKey==="function"?vPageKey():null;
  try{ if(k==="main") schedule(); else if(k==="wn" && wn.res) wnSchedule(50); else if(k==="cv" && cv.res) cvSchedule(50); }catch(e){}
}
// رسم روی بوم: proj(lat,lon) → [x,y] در مختصات منطقی بوم؛ clip = [x0,y0,x1,y1]؛ pxPerDeg برای اندازهٔ نقطه
function seatsDraw(ctx, proj, clip, pxPerDeg){
  const r=Math.max(1.25, Math.min(2.3, pxPerDeg*0.042)), ring=Math.max(0.45, r*0.28);
  ctx.save(); if(clip){ ctx.beginPath(); ctx.rect(clip[0],clip[1],clip[2]-clip[0],clip[3]-clip[1]); ctx.clip(); }
  const P_=[]; for(const [,la,lo] of SEATS){ const [x,y]=proj(la,lo); if(!isFinite(x)||!isFinite(y)) continue; if(clip && (x<clip[0]||y<clip[1]||x>clip[2]||y>clip[3])) continue; P_.push([x,y]); }
  ctx.fillStyle="rgba(255,255,255,.85)"; ctx.beginPath(); for(const [x,y] of P_){ ctx.moveTo(x+r+ring,y); ctx.arc(x,y,r+ring,0,7); } ctx.fill();
  ctx.fillStyle="#000000"; ctx.beginPath(); for(const [x,y] of P_){ ctx.moveTo(x+r,y); ctx.arc(x,y,r,0,7); } ctx.fill();
  ctx.restore(); return P_.length;
}
// نقشه‌های قالبی (WeatherBELL، weather.us، حالت آزاد/weathermodels/tropicaltidbits با زمین‌مرجع)
function seatsOverlay(cv){
  try{ if(!seatsOn() || !P || typeof mrGeo!=="function" || !mrGeo()) return; const s=cv.width/P.W, ctx=cv.getContext("2d");
    ctx.save(); ctx.setTransform(s,0,0,s,0,0);
    seatsDraw(ctx, (la,lo)=>[P.ax+P.bx*lo, P.ay+P.by*la], [P.fx0,P.fy0,P.fx1+1,P.fy1+1], Math.abs(P.bx));
    ctx.restore(); }catch(e){ console.warn("seats",e); }
}
{ const _cu=renderCU, _wb=renderWB, _wu=renderWU;
  renderCU=function(o){ const cv=_cu(o); if(!o.barLayout) seatsOverlay(cv); return cv; };
  renderWB=function(o){ const cv=_wb(o); seatsOverlay(cv); return cv; };
  renderWU=function(o){ const cv=_wu(o); seatsOverlay(cv); return cv; }; }
// کنترل‌ها: چک‌باکس در تنظیمات صفحه
document.addEventListener("DOMContentLoaded",()=>{});
(function(){ const row=$("bordersChkRow"); if(row && !$("seatsChk")){ const l=document.createElement("label"); l.className="chk"; l.id="seatsRow";
    l.innerHTML=`<input type="checkbox" id="seatsChk"> نقاط مراکز شهرستان‌ها روی نقشهٔ نهایی (نقطهٔ ریز سیاه با حلقهٔ سفید)`; row.after(l);
    const c=$("seatsChk"); c.checked=seatsOn(); c.onchange=()=>setSeats(c.checked); } })();
