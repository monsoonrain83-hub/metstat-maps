/* ---------- نمایش‌های کمکی ---------- */
function dsDiv(t){
  const A=[[140,81,10],[216,179,101],[245,245,245],[90,180,172],[1,102,94]];
  const u=(Math.max(-1,Math.min(1,t))+1)/2*4, i=Math.min(3,Math.floor(u)), f=u-i;
  return A[i].map((c,k)=>Math.round(c+(A[i+1][k]-c)*f));
}
const DS_ELEV=[[244,239,230],[217,199,167],[169,138,95],[109,82,48],[58,42,23]];
function dsElevCol(c){ const u=Math.min(Math.max(c,0),1)*4, k=Math.min(3,Math.floor(u)), f=u-k; return DS_ELEV[k].map((v,j)=>Math.round(v+(DS_ELEV[k+1][j]-v)*f)); }
function dsGray(m){ const c=document.createElement("canvas"); c.width=m.w; c.height=m.h; const cx=c.getContext("2d"), im=cx.createImageData(m.w,m.h), o=im.data, s=m.data;
  for(let i=0;i<m.w*m.h;i++){ const L=0.3*s[i*4]+0.59*s[i*4+1]+0.11*s[i*4+2], v=Math.round(150+L*0.4); o[i*4]=o[i*4+1]=o[i*4+2]=v; o[i*4+3]=255; } return {c,cx,im}; }
function dsFieldView(r, kind){
  const g=r.geo, {c:cv, cx, im}=dsGray(r.m), o=im.data, src=r.m.data, st=r.st;
  let lim=1;
  if(kind==="diff"){ const a=[]; for(let i=0;i<r.P0.length;i++) if(r.demOK[i]) a.push(Math.abs(r.Pc[i]-r.P0[i])); lim=Math.max(dsPct(a,99.5)||0,r.isTemp?0.5:0.5); }
  const lmin=Math.log(r.cfg.minF), lmax=Math.log(r.cfg.maxF);
  for(let y=0;y<g.FH;y++){ const gy=Math.min(r.GH-1,Math.floor(y/st)); for(let x=0;x<g.FW;x++){ const i=gy*r.GW+Math.min(r.GW-1,Math.floor(x/st)); if(!r.demOK[i]) continue;
    const q=((y+g.fy0)*g.W+x+g.fx0)*4; let col;
    if(kind==="factor"){ if(r.isTemp) col=dsDiv(-(r.gamma[i]-DS_GSTD)/4); else { const l=Math.log(r.f[i]); col=dsDiv(l>=0 ? l/lmax : -l/lmin); } }
    else if(kind==="diff") col=dsDiv((r.Pc[i]-r.P0[i])/lim);
    else col=dsElevCol(r.Z[i]/3500);
    o[q]=col[0]; o[q+1]=col[1]; o[q+2]=col[2]; } }
  for(let y=0;y<g.FH;y++) for(let x=0;x<g.FW;x++){ if(r.clsFull[y*g.FW+x]>=0) continue; const q=((y+g.fy0)*g.W+x+g.fx0)*4, L=0.3*src[q]+0.59*src[q+1]+0.11*src[q+2]; if(L<110){ o[q]=o[q+1]=o[q+2]=40; } }
  cx.putImageData(im,0,0);
  const sc=Math.max(1,g.W/900), bw=200*sc, bh=12*sc, bx=g.fx0+12*sc, by=g.fy1-46*sc;
  cx.fillStyle="rgba(255,255,255,.92)"; cx.fillRect(bx-6*sc,by-24*sc,bw+12*sc,bh+44*sc);
  for(let k=0;k<bw;k++){ const col = kind==="elev" ? dsElevCol(k/(bw-1)) : dsDiv(k/(bw-1)*2-1); cx.fillStyle=`rgb(${col})`; cx.fillRect(bx+k,by,1,bh); }
  cx.fillStyle="#15233b"; cx.font=`700 ${Math.round(12*sc)}px "Ketab", Tahoma, sans-serif`; cx.textBaseline="alphabetic"; cx.direction="rtl"; cx.textAlign="center";
  cx.fillText(kind==="factor" ? (r.isTemp?"آهنگ کاهش دمای محلی (°C/km)":"ضریب اصلاح توپوگرافی") : kind==="diff" ? (r.isTemp?"اختلاف: اصلاح‌شده − ورودی (°C)":"اختلاف: اصلاح‌شده − ورودی (mm)") : "ارتفاع (متر)", bx+bw/2, by-8*sc);
  cx.font=`${Math.round(12*sc)}px "Ketab", Tahoma, sans-serif`;
  const lab = kind==="factor" ? (r.isTemp?[fmt(DS_GSTD-4,1), fmt(DS_GSTD,1), fmt(DS_GSTD+4,1)]:[fmt(r.cfg.minF,2), "۱", fmt(r.cfg.maxF,2)]) : kind==="diff" ? ["−"+fmt(lim,1), "۰", "+"+fmt(lim,1)] : ["۰", FA(1750), FA(3500)];
  cx.textAlign="left"; cx.fillText(lab[0], bx, by+bh+14*sc); cx.textAlign="center"; cx.fillText(lab[1], bx+bw/2, by+bh+14*sc); cx.textAlign="right"; cx.fillText(lab[2], bx+bw, by+bh+14*sc);
  return cv;
}
// مکان نقشه: مرزهای مرجع با زمین‌مرجع پیدا‌شده روی نقشهٔ ورودی (قرمز)
function dsGeoView(m){
  const c=document.createElement("canvas"); c.width=m.w; c.height=m.h; const cx=c.getContext("2d");
  const im=new ImageData(new Uint8ClampedArray(m.data), m.w, m.h), o=im.data;
  for(let i=0;i<o.length;i+=4){ o[i]=Math.round(o[i]*0.55+115); o[i+1]=Math.round(o[i+1]*0.55+115); o[i+2]=Math.round(o[i+2]*0.55+115); }
  const pr=m.prof, R=GR.ref, g=m.geo || m.geoTry;
  if(R && g){ const r=Math.max(1, Math.round(m.w/700));
    for(let k=0;k<R.lon.length;k++){ const x=Math.round(g[0]+g[1]*R.lon[k]), y=Math.round(g[2]+g[3]*R.lat[k]);
      if(x<pr.fx0||x>pr.fx1||y<pr.fy0||y>pr.fy1) continue;
      for(let dy=0;dy<r;dy++) for(let dx=0;dx<r;dx++){ const q=((y+dy)*m.w+x+dx)*4; if(q<o.length){ o[q]=220; o[q+1]=20; o[q+2]=40; } } } }
  cx.putImageData(im,0,0);
  cx.strokeStyle="#0a69d8"; cx.lineWidth=Math.max(1,m.w/600); cx.strokeRect(pr.fx0+0.5,pr.fy0+0.5,pr.fx1-pr.fx0,pr.fy1-pr.fy0);
  return c;
}

function dsChart(r){
  const W=480, H=580, cv=document.createElement("canvas"); cv.width=W*2; cv.height=H*2;
  const c=cv.getContext("2d"); c.scale(2,2); c.fillStyle="#fff"; c.fillRect(0,0,W,H);
  const ink="#15233b", mut="#6b7686", grid="#e6e9ef";
  const panel=(y0,h,title)=>{ c.fillStyle=ink; c.font='700 15px "Titr","Ketab",Tahoma,sans-serif'; c.direction="rtl"; c.textAlign="right"; c.fillText(title, W-14, y0+18); return {x0:58, x1:W-18, y0:y0+30, y1:y0+h-34}; };
  const axes=(A, xs, ys, xl, yl, ylog)=>{
    c.strokeStyle=grid; c.lineWidth=1; c.font='12px "Ketab",Tahoma,sans-serif'; c.fillStyle=mut;
    for(const v of xs.t){ const X=xs.f(v); c.beginPath(); c.moveTo(X,A.y0); c.lineTo(X,A.y1); c.stroke(); c.textAlign="center"; c.direction="ltr"; c.fillText(FA(v), X, A.y1+15); }
    for(const v of ys.t){ const Y=ys.f(v); c.beginPath(); c.moveTo(A.x0,Y); c.lineTo(A.x1,Y); c.stroke(); c.textAlign="right"; c.direction="ltr"; c.fillText(ylog?FA(+v.toFixed(2)):FA(+v.toFixed(1)), A.x0-6, Y+4); }
    c.direction="rtl"; c.textAlign="center"; c.fillText(xl, (A.x0+A.x1)/2, A.y1+30);
    c.save(); c.translate(14,(A.y0+A.y1)/2); c.rotate(-Math.PI/2); c.fillText(yl,0,0); c.restore();
  };
  // پنل ۱: منحنی پاسخ ارتفاعی
  const A=panel(0, 310, "پاسخ بارش به ارتفاع (GAM)");
  if(r.G){
    const G=r.G, z0=Math.max(0,G.zlo), z1=G.zhi, K=160, zz=[], hh=[], se=[];
    for(let k=0;k<K;k++){ const z=z0+(z1-z0)*k/(K-1); const [h,s]=dsH(G,z,true); zz.push(z); hh.push(h); se.push(s); }
    let lo=Math.min(...hh.map((h,k)=>h-2*se[k])), hi=Math.max(...hh.map((h,k)=>h+2*se[k]));
    for(const t of r.tiles) if(t.used==="local" && t.M){ for(let k=0;k<K;k+=8){ const h=dsH(t.M, zz[k]); lo=Math.min(lo,h); hi=Math.max(hi,h); } }
    lo=Math.max(lo,Math.log(0.25)); hi=Math.min(hi,Math.log(4)); if(hi-lo<0.2){ lo-=0.1; hi+=0.1; }
    const xs={f:v=>A.x0+(v-z0)/(z1-z0)*(A.x1-A.x0), t:[]}; for(let v=Math.ceil(z0/1000)*1000; v<=z1; v+=1000) xs.t.push(v);
    const ys={f:v=>A.y1-(Math.log(v)-lo)/(hi-lo)*(A.y1-A.y0), t:[0.5,0.67,0.8,1,1.25,1.5,2,3].filter(v=>Math.log(v)>=lo&&Math.log(v)<=hi)};
    axes(A, xs, ys, "ارتفاع (متر)", "پاسخ نسبی بارش (×)", true);
    c.save(); c.beginPath(); c.rect(A.x0,A.y0,A.x1-A.x0,A.y1-A.y0); c.clip();
    c.fillStyle="rgba(181,84,28,.16)"; c.beginPath();
    zz.forEach((z,k)=>{ const X=xs.f(z), Y=ys.f(Math.exp(hh[k]+2*se[k])); k?c.lineTo(X,Y):c.moveTo(X,Y); });
    for(let k=K-1;k>=0;k--) c.lineTo(xs.f(zz[k]), ys.f(Math.exp(hh[k]-2*se[k]))); c.fill();
    c.strokeStyle="rgba(120,150,185,.55)"; c.lineWidth=0.8;
    for(const t of r.tiles) if(t.used==="local" && t.M && t.rel && t.rel.sig){ c.beginPath(); zz.forEach((z,k)=>{ const X=xs.f(z), Y=ys.f(Math.exp(dsH(t.M,z))); k?c.lineTo(X,Y):c.moveTo(X,Y); }); c.stroke(); }
    c.strokeStyle="#b5541c"; c.lineWidth=2.4; c.beginPath(); zz.forEach((z,k)=>{ const X=xs.f(z), Y=ys.f(Math.exp(hh[k])); k?c.lineTo(X,Y):c.moveTo(X,Y); }); c.stroke();
    c.setLineDash([4,4]); c.strokeStyle=mut; c.lineWidth=1; c.beginPath(); c.moveTo(A.x0,ys.f(1)); c.lineTo(A.x1,ys.f(1)); c.stroke();
    const zm = r.rel.key==="peak" ? r.rel.zmax : r.rel.key==="u" ? r.rel.zmin : null;
    if(zm!==null){ c.strokeStyle="#b5541c"; c.beginPath(); c.moveTo(xs.f(zm),A.y0); c.lineTo(xs.f(zm),A.y1); c.stroke(); }
    c.setLineDash([]); c.restore();
    if(zm!==null){ c.fillStyle="#b5541c"; c.font='700 13px "Ketab",Tahoma,sans-serif'; c.direction="rtl"; c.textAlign="right"; c.fillText((r.rel.key==="peak"?"بیشینه ≈ ":"کمینه ≈ ")+FA(Math.round(zm))+" متر", Math.min(xs.f(zm)-6+120, A.x1-4), A.y0+14); }
    // راهنما
    c.font='12.5px "Ketab",Tahoma,sans-serif'; c.direction="rtl"; c.textAlign="right";
    const lg=[["#b5541c",2.4,"منحنی کلی"],["rgba(120,150,185,.8)",1,"منحنی‌های محلی"],["rgba(181,84,28,.35)",8,"±۲ خطای معیار"]];
    lg.forEach(([col,lw,t],k)=>{ const y=A.y1-12-k*17; c.strokeStyle=col; c.lineWidth=lw; c.beginPath(); c.moveTo(A.x1-26,y-4); c.lineTo(A.x1-6,y-4); c.stroke(); c.fillStyle=ink; c.fillText(t, A.x1-32, y); });
  } else { c.fillStyle=mut; c.font='14px "Ketab",Tahoma,sans-serif'; c.textAlign="center"; c.fillText("سلول بارانی کافی برای برآورد رابطه نیست", W/2, 160); }
  // پنل ۲: نیمرخ ارتفاعی قبل و بعد
  const B=panel(316, 264, "میانگین بارش پیکسل‌های بارانی در هر طبقهٔ ارتفاعی");
  const zs=[], p0=[], p1=[]; const N_=r.P0.length;
  for(let i=0;i<N_;i++) if(r.demOK[i] && r.P0[i]>=r.cfg.thr){ zs.push(r.Z[i]); p0.push(r.P0[i]); p1.push(r.Pc[i]); }
  if(zs.length>200){
    const z0=Math.max(0,dsPct(zs,0.5)), z1=dsPct(zs,99.5), nb=22, s0=new Float64Array(nb), s1=new Float64Array(nb), cn=new Float64Array(nb);
    zs.forEach((z,k)=>{ const b=Math.floor((z-z0)/(z1-z0)*nb); if(b>=0&&b<nb){ s0[b]+=p0[k]; s1[b]+=p1[k]; cn[b]++; } });
    const pts=[]; for(let b=0;b<nb;b++) if(cn[b]>=30) pts.push([z0+(b+0.5)*(z1-z0)/nb, s0[b]/cn[b], s1[b]/cn[b]]);
    if(pts.length>1){
      const ymax=Math.max(...pts.map(p=>Math.max(p[1],p[2])))*1.1;
      const xs={f:v=>B.x0+(v-z0)/(z1-z0)*(B.x1-B.x0), t:[]}; for(let v=Math.ceil(z0/1000)*1000; v<=z1; v+=1000) xs.t.push(v);
      const st=ymax>40?10:ymax>15?5:ymax>6?2:1, ys={f:v=>B.y1-v/ymax*(B.y1-B.y0), t:[]}; for(let v=0; v<=ymax; v+=st) ys.t.push(v);
      axes(B, xs, ys, "ارتفاع DEM (متر)", "میلی‌متر", false);
      for(const [k,col] of [[1,"#7a7a7a"],[2,"#1f6fb2"]]){ c.strokeStyle=col; c.fillStyle=col; c.lineWidth=2; c.beginPath(); pts.forEach((p,j)=>{ const X=xs.f(p[0]), Y=ys.f(p[k]); j?c.lineTo(X,Y):c.moveTo(X,Y); }); c.stroke();
        pts.forEach(p=>{ c.beginPath(); c.arc(xs.f(p[0]), ys.f(p[k]), 2.6, 0, 7); c.fill(); }); }
      c.font='12.5px "Ketab",Tahoma,sans-serif'; c.direction="rtl"; c.textAlign="right";
      [["#7a7a7a","نقشهٔ ورودی"],["#1f6fb2","اصلاح‌شده"]].forEach(([col,t],k)=>{ const y=B.y0+12+k*17; c.fillStyle=col; c.fillRect(B.x1-24,y-8,18,4); c.fillStyle=ink; c.fillText(t,B.x1-30,y); });
    }
  }
  return cv;
}

/* ---------- گزارش، CSV، NetCDF ---------- */
const DS_TYPE_EN={flat:"nearly independent of elevation", peak:"single-peaked (increase up to an elevation, then decrease)", u:"U-shaped (minimum at middle elevations)", up:"increasing with elevation", down:"decreasing with elevation"};
function dsReport(r){
  const s=r.stats, G=r.G, rel=r.rel||{}, f2=v=>(+v).toFixed(2), f3=v=>(+v).toFixed(3), pc=v=>(v*100).toFixed(1)+"%";
  const L=[];
  L.push("TERRAIN-AWARE STATISTICAL DOWNSCALING — REPORT  |  گزارش اصلاح توپوگرافی بارش");
  L.push("=".repeat(70));
  L.push(`Model / مدل              : ${r.m.name}`);
  L.push(`Input map                : ${r.m.file.name}  (${r.geo.name}, ${r.geo.W}x${r.geo.H} px, frame ${r.geo.FW}x${r.geo.FH}${r.st>1?`, working grid ${r.GW}x${r.GH}`:""})`);
  { const b=grBounds(r.m.geo, r.m.prof); L.push(`Georeference             : ${r.m.geoSrc} (match score ${r.m.geoScore.toFixed(3)}); frame lon ${b.W.toFixed(3)}..${b.E.toFixed(3)}, lat ${b.S.toFixed(3)}..${b.N.toFixed(3)}`); }
  if(r.m.period) L.push(`Period / دوره            : ${r.m.period}`);
  L.push(`Effective NWP resolution : ${r.m.res} deg x factor ${r.cfg.eff} = ${(r.m.res*r.cfg.eff).toFixed(3)} deg`);
  L.push(`Map pixel                : ${(Math.abs(r.lon[1]-r.lon[0])).toFixed(4)} deg (~${r.dxk.toFixed(2)} x ${r.dyk.toFixed(2)} km)`);
  L.push(`DEM                      : ${ds.dem.label}`);
  L.push(`CRS                      : EPSG:4326 (WGS84 lon/lat) for map georeference and DEM`);
  L.push("");
  L.push("PRECIPITATION inside DEM        before      after   (mm)");
  for(const [k,lab] of [["min","minimum"],["mean","mean"],["p95","95th percentile"],["max","maximum"]]) L.push(`  ${lab.padEnd(28)}${f2(s.before[k]||0).padStart(9)}  ${f2(s.after[k]||0).padStart(9)}`);
  for(const t of [1,5,10,25,50]) L.push(`  area >= ${String(t).padEnd(20)}${pc(s.before["a"+t]||0).padStart(9)}  ${pc(s.after["a"+t]||0).padStart(9)}`);
  L.push("");
  L.push("CORRECTION FACTOR (P >= threshold)");
  L.push(`  mean ${f3(s.fMean)}   min ${f3(s.fMin)}   max ${f3(s.fMax)}   5-95% ${f3(s.fP05)}..${f3(s.fP95)}`);
  L.push(`  share at bounds ${pc(s.atBounds)}  (bounds ${r.cfg.minF}..${r.cfg.maxF})`);
  L.push(`  domain mean ratio ${s.ratio.toFixed(4)}   pattern correlation ${s.corr.toFixed(4)}`);
  L.push(`  artificial cells (>=5 mm where input < threshold): ${s.art}`);
  L.push(`  map pixels that changed colour class: ${s.changed}`);
  L.push("");
  L.push("ELEVATION RELATIONSHIP (GAM, P-splines, GCV)");
  if(G){
    L.push(`  wet NWP-scale cells ${G.n}, edf ${G.edf.toFixed(1)}, R2 ${G.r2.toFixed(2)}, lambda_z ${G.lz}, lambda_xy ${G.lt}`);
    L.push(`  residual autocorrelation ${G.rho.toFixed(2)} -> SE x${Math.sqrt(G.infl).toFixed(2)}`);
    L.push(`  type: ${DS_TYPE_EN[rel.key]||rel.type}   (effect x${(rel.factor||1).toFixed(2)}, elevation ${Math.round(rel.z5)}..${Math.round(rel.z95)} m)`);
    L.push(`  elevation of maximum response: ${rel.key==="peak" ? Math.round(rel.zmax)+" m" : rel.sig ? "no interior maximum" : "none (no significant effect)"}`);
    if(rel.key==="u") L.push(`  elevation of minimum response: ${Math.round(rel.zmin)} m`);
    L.push(`  exposure: ${r.expo.sig ? "wettest slopes face "+Math.round(r.expo.facing)+" deg from north" : "not significant (not applied)"}`);
    const loc=r.tiles.filter(t=>t.used==="local"), cnt={};
    loc.forEach(t=>{ const ty=DS_TYPE_EN[t.rel.key]||t.rel.type; cnt[ty]=(cnt[ty]||0)+1; });
    L.push(`  local windows: ${r.tiles.length} (${loc.length} with their own curve)`);
    for(const [k,v] of Object.entries(cnt)) L.push(`     ${String(v).padStart(3)} x ${k}`);
    const zm=loc.filter(t=>t.rel.key==="peak").map(t=>t.rel.zmax);
    if(zm.length) L.push(`     local maxima at ${Math.round(Math.min(...zm))}..${Math.round(Math.max(...zm))} m`);
  } else L.push("  not estimated — map unchanged");
  L.push("");
  L.push(`Valid (inside DEM) pixels: ${s.nInside}   NoData pixels: ${s.nOut}`);
  L.push("Warnings: " + (r.warns.length ? "" : "none")); r.warns.forEach(w=>L.push("  - "+w));
  L.push("");
  L.push("Settings: " + JSON.stringify(r.cfg));
  L.push("");
  L.push("NOTE: statistical terrain-aware downscaling. The NWP field gives the precipitation pattern; the DEM only");
  L.push("redistributes it inside each model cell (ridges/valleys). Without rain-gauge observations an improvement");
  L.push("of the forecast cannot be claimed.");
  return L.join("\n")+"\n";
}
function dsNetCDF(r, attrs){
  const FWn=r.GW, FHn=r.GH, Nn=FWn*FHn, enc=new TextEncoder(), chunks=[]; let len=0;
  const pad4=n=>(4-n%4)%4, push=u=>{ chunks.push(u); len+=u.length; };
  const i32=v=>{ const b=new DataView(new ArrayBuffer(4)); b.setInt32(0,v); push(new Uint8Array(b.buffer)); };
  const name=s=>{ const b=enc.encode(s); i32(b.length); push(b); push(new Uint8Array(pad4(b.length))); };
  const attText=(k,v)=>{ name(k); i32(2); const b=enc.encode(String(v)); i32(b.length); push(b); push(new Uint8Array(pad4(b.length))); };
  const attList=list=>{ if(!list.length){ i32(0); i32(0); return; } i32(12); i32(list.length); list.forEach(([k,v])=>attText(k,v)); };
  const fields= r.isTemp ? [["temperature_corrected","degC","elevation-corrected temperature",r.Pc],["temperature_input","degC","temperature digitised from the input map",r.P0],["lapse_rate","degC/km","local lapse rate",r.gamma],["elevation","m","DEM elevation",r.Z]]
    : [["precipitation_corrected","mm","terrain-corrected precipitation",r.Pc],["precipitation_input","mm","precipitation digitised from the input map",r.P0],
    ["correction_factor","1","terrain correction factor",r.f],["elevation","m","DEM elevation (pixel mean)",r.Z]];
  push(enc.encode("CDF")); push(new Uint8Array([1])); i32(0);
  i32(10); i32(2); name("lat"); i32(FHn); name("lon"); i32(FWn);
  attList(attrs);
  i32(11); i32(2+fields.length);
  const vars=[{n:"lat",dims:[0],type:6,size:FHn*8,atts:[["units","degrees_north"],["standard_name","latitude"]]},
              {n:"lon",dims:[1],type:6,size:FWn*8,atts:[["units","degrees_east"],["standard_name","longitude"]]},
              ...fields.map(([n,u,l])=>({n,dims:[0,1],type:5,size:Nn*4,atts:[["units",u],["long_name",l]]}))];
  const pos=[];
  for(const v of vars){ name(v.n); i32(v.dims.length); v.dims.forEach(d=>i32(d)); attList(v.atts); i32(v.type); i32(v.size); pos.push(chunks.length); i32(0); }
  let off=len; vars.forEach((v,k)=>{ const b=new DataView(new ArrayBuffer(4)); b.setInt32(0,off); chunks[pos[k]]=new Uint8Array(b.buffer); off+=v.size; });
  const dLat=new DataView(new ArrayBuffer(FHn*8)); for(let j=0;j<FHn;j++) dLat.setFloat64(j*8, r.lat[FHn-1-j]); push(new Uint8Array(dLat.buffer));
  const dLon=new DataView(new ArrayBuffer(FWn*8)); for(let i=0;i<FWn;i++) dLon.setFloat64(i*8, r.lon[i]); push(new Uint8Array(dLon.buffer));
  for(const [,,,arr] of fields){ const dv=new DataView(new ArrayBuffer(Nn*4));
    for(let j=0;j<FHn;j++){ const y=FHn-1-j; for(let i=0;i<FWn;i++){ const v=arr[y*FWn+i]; dv.setFloat32((j*FWn+i)*4, v===v ? v : -9999); } }
    push(new Uint8Array(dv.buffer)); }
  return new Blob(chunks, {type:"application/x-netcdf"});
}
function dsCSV(r){
  const parts=[r.isTemp?"lat,lon,temp_input_C,temp_corrected_C,lapse_rate_C_per_km,elevation_m\n":"lat,lon,precip_input_mm,precip_corrected_mm,correction_factor,elevation_m\n"];
  for(let y=0;y<r.GH;y++){ const row=[]; const la=r.lat[y].toFixed(4);
    for(let x=0;x<r.GW;x++){ const i=y*r.GW+x; row.push(`${la},${r.lon[x].toFixed(4)},${(+r.P0[i]).toFixed(2)},${(+r.Pc[i]).toFixed(2)},${(+r.f[i]).toFixed(3)},${r.Z[i]===r.Z[i]?Math.round(r.Z[i]):""}`); }
    parts.push(row.join("\n")+"\n"); }
  return new Blob(parts,{type:"text/csv"});
}

// ===== گزارش پیشرفته: درصد مساحت در بازه‌های دما/بارش و توزیع در پهنه‌های اقلیمی ایران =====
const DS_ZONES=[["nw","شمال‌غرب","North-west"],["casp","سواحل خزر","Caspian coast"],["alb","البرز","Alborz"],["ne","شمال‌شرق","North-east"],["w","غرب","West"],["zag","زاگرس","Zagros"],["sw","جنوب‌غرب (خوزستان)","South-west (Khuzestan)"],["s","جنوب و سواحل خلیج فارس","South and Persian Gulf coast"],["se","جنوب‌شرق","South-east"],["e","شرق","East"],["c","مرکز (فلات مرکزی)","Centre (central plateau)"]];
function dsZoneOf(lat, lon, z){
  if(lat>=36.2 && lat<38.6 && lon>=48.6 && lon<55.8 && z<400) return "casp";
  if(lat>=35.6 && lon<49.0) return "nw";
  if(lat>=36.6 && lon>=49.0 && lon<55.8 && z<150) return "casp";
  if(lat>=35.3 && lon>=49.0 && lon<56.0) return "alb";
  if(lon>=56.0 && lat>=34.3) return "ne";
  if(lon<48.5 && lat>=32.6) return "w";
  if(lon<51.0 && lat<32.6 && z<450) return "sw";
  if(lat<28.6 && lon>=50.0 && lon<58.5 && z<900) return "s";
  if(lon>=58.0 && lat<31.0) return "se";
  if(lon>=57.0 && lat>=30.0) return "e";
  if(lon>=46.0 && lon<53.5 && lat>=28.5 && lat<35.3 && z>=1100) return "zag";
  return "c";
}
function dsAreaStats(r){
  const en=typeof LANG!=="undefined" && LANG==="en", T=(a,b)=>en?b:a, P=r.Pc, W=r.GW, H=r.GH, temp=!!r.isTemp;
  const bins = temp ? [[-Infinity,0,"≤ ۰ (یخبندان)","≤ 0 (frost)"],[0,10,"۰ تا ۱۰","0–10"],[10,20,"۱۰ تا ۲۰","10–20"],[20,30,"۲۰ تا ۳۰","20–30"],[30,40,"۳۰ تا ۴۰","30–40"],[40,50,"۴۰ تا ۵۰","40–50"],[50,Infinity,"≥ ۵۰","≥ 50"]]
                    : [[1,Infinity,"≥ ۱","≥ 1"],[5,Infinity,"≥ ۵","≥ 5"],[10,Infinity,"≥ ۱۰","≥ 10"],[20,Infinity,"≥ ۲۰","≥ 20"],[30,Infinity,"≥ ۳۰","≥ 30"],[50,Infinity,"≥ ۵۰","≥ 50"],[100,Infinity,"≥ ۱۰۰","≥ 100"]];
  const acc=bins.map(()=>0), Z={}; let tot=0;
  for(let y=0;y<H;y++){ const lat=r.lat[y], w=Math.cos(lat*Math.PI/180);
    for(let x=0;x<W;x++){ const i=y*W+x, v=P[i], z=r.Z?r.Z[i]:0; if(!(v===v) || !(z===z)) continue; const lon=r.lon[x];
      if(typeof landAt==="function" && landAt(lat,lon)===0) continue;
      tot+=w; bins.forEach((b,k)=>{ if(v>b[0] && v<=b[1] || (temp && k===0 && v<=0) || (!temp && v>=b[0])) acc[k]+=w; });
      const zk=dsZoneOf(lat,lon,z), o=Z[zk]||(Z[zk]={w:0,s:0,mx:-Infinity,mn:Infinity,hot:0,cold:0,wet:0,vwet:0}); o.w+=w; o.s+=v*w; if(v>o.mx) o.mx=v; if(v<o.mn) o.mn=v;
      if(temp){ if(v<=0) o.cold+=w; if(v>=40) o.hot+=w; } else { if(v>=10) o.wet+=w; if(v>=30) o.vwet+=w; } } }
  if(!tot) return null;
  const PS=T("٪","%"), pc=a=>FA((Math.round(1000*a/tot)/10))+PS, pz=(a,b)=>FA(Math.round(1000*a/b)/10)+PS, u=temp?"°C":(T("میلی‌متر","mm"));
  const head=temp?T("درصد مساحت خشکی در بازه‌های دما (پس از اصلاح ارتفاعی)","Share of land area by temperature range (after elevation correction)"):T("درصد مساحت خشکی با بارش بیش از آستانه (پس از اصلاح ارتفاعی)","Share of land area above precipitation thresholds (after elevation correction)");
  const rows=bins.map((b,k)=>`<tr><td>${T(b[2],b[3])} ${u}</td><td><b>${pc(acc[k])}</b></td></tr>`).join("");
  const zr=DS_ZONES.filter(([k])=>Z[k] && Z[k].w>0.01*tot).map(([k,fa,enN])=>{ const o=Z[k];
    return `<tr><td>${T(fa,enN)}</td><td>${FA(Math.round(10*o.s/o.w)/10)}</td><td>${FA(Math.round(10*(temp?o.mn:o.mx))/10)}</td><td>${temp?pz(o.cold,o.w):pz(o.wet,o.w)}</td><td>${temp?pz(o.hot,o.w):pz(o.vwet,o.w)}</td></tr>`; }).join("");
  const zh = temp ? [T("میانگین","Mean"),T("کمینه","Min"),T("یخبندان (≤۰)","Frost (≤0)"),T("≥ ۴۰ درجه","≥ 40 °C")] : [T("میانگین","Mean"),T("بیشینه","Max"),T("≥ ۱۰ میلی‌متر","≥ 10 mm"),T("≥ ۳۰ میلی‌متر","≥ 30 mm")];
  // جمع‌بندی متنی: کدام پهنه‌ها بیشترین سهم را دارند
  const rank=DS_ZONES.filter(([k])=>Z[k]&&Z[k].w>0.01*tot).map(([k,fa,enN])=>({n:T(fa,enN), a: temp ? Z[k].cold/Z[k].w : Z[k].wet/Z[k].w, b: temp ? Z[k].hot/Z[k].w : Z[k].vwet/Z[k].w})).filter(o=>o.a>0.02||o.b>0.02);
  const top=(f,lab)=>{ const s=rank.slice().sort((p,q)=>f(q)-f(p)).filter(o=>f(o)>0.02).slice(0,3); return s.length ? lab+" "+s.map(o=>`${o.n} (${FA(Math.round(100*f(o)))}${PS})`).join(T("، ",", ")) : ""; };
  const sum = temp ? [top(o=>o.a,T("بیشترین گستردگی یخبندان:","Most widespread frost:")), top(o=>o.b,T("بیشترین گستردگی دمای ۴۰ درجه و بیشتر:","Most widespread ≥ 40 °C:"))].filter(Boolean).join(T("؛ ","; "))
                   : [top(o=>o.a,T("بیشترین گستردگی بارش ۱۰ میلی‌متر و بیشتر:","Most widespread ≥ 10 mm:")), top(o=>o.b,T("بارش ۳۰ میلی‌متر و بیشتر:","≥ 30 mm:"))].filter(Boolean).join(T("؛ ","; "));
  const html=`<div class="dsarea" data-noi18n><h4 style="margin:10px 0 4px">${head}</h4><table class="cvref"><tbody>${rows}</tbody></table>
    <h4 style="margin:10px 0 4px">${T("توزیع در پهنه‌های اقلیمی ایران","Distribution across Iran's climatic regions")}</h4>
    <table class="cvref"><thead><tr><th>${T("پهنه","Region")}</th>${zh.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${zr}</tbody></table>${sum?`<p style="margin:6px 0 0">${sum}.</p>`:""}</div>`;
  const txt=[head, ...bins.map((b,k)=>`  ${b[3].padEnd(14)} ${(Math.round(1000*acc[k]/tot)/10).toFixed(1)}%`), "Regions: "+zh.join(" | "),
    ...DS_ZONES.filter(([k])=>Z[k]&&Z[k].w>0.01*tot).map(([k,fa,enN])=>{ const o=Z[k]; return `  ${enN.padEnd(30)} mean ${(o.s/o.w).toFixed(1)}  ${temp?"min "+o.mn.toFixed(1):"max "+o.mx.toFixed(1)}  ${temp?(100*o.cold/o.w).toFixed(1)+"% frost  "+(100*o.hot/o.w).toFixed(1)+"% >=40":(100*o.wet/o.w).toFixed(1)+"% >=10mm  "+(100*o.vwet/o.w).toFixed(1)+"% >=30mm"}`; })].join("\n");
  return {html, txt};
}
