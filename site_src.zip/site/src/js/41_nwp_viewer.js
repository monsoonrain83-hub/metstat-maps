/* ===== نمایشگر نقشه‌های مدل (کادر وسط، منوهای آبشاری، زوم و جابه‌جایی، مرزها، نوار رنگ) =====
   کاشی‌های «خاورمیانه» را برنامهٔ nwp_maps.py می‌سازد (فقط لایهٔ رنگیِ گسسته + لایهٔ خطوط)؛ این‌جا رسم می‌شوند.
   • هیچ عدد خام یا جدولی نمایش داده یا دانلود نمی‌شود؛ فقط تصویر نقشه و نمودار.
   • بزرگ‌نمایی: کلاس‌های رنگی دقیقاً همان رنگ‌های نوار می‌مانند (بدون رنگ واسطه)؛ مرز کلاس‌ها با درون‌یابی شمارهٔ کلاس صاف می‌شود. */
const NV_BOX=[20,65,12,42], NV_TW=1440, NV_TH=960, NV_PXD=32;
const NV_TC=[["daily","روزانه (میان‌مدت، روز به روز)"],["weekly","هفتگی"],["monthly","ماهانه"],["seasonal","فصلی (بلندمدت)"]];
// مدل‌های بلندمدت برنامه‌ریزی‌شده (داده‌های باز GRIB/NetCDF)؛ تا ساخته‌شدن نقشه‌هایشان به‌صورت «به‌زودی» نشان داده می‌شوند
const NV_PLANNED={
  weekly:["GEFS (NOAA) — انومالی هفتگی بارش و دما، ۳۵ روزه","CFSv2 (NOAA) — میانگین هفتگی","ECMWF هفتگی (۴۶ روزه؛ دادهٔ باز ندارد)"],
  monthly:["NMME — میانگین چندمدلی ماهانه","CFSv2 — ماهانه","CanSIPS (ECCC)","ECMWF ماهانه (۴۶ روزه؛ دادهٔ باز ندارد)"],
  seasonal:["NMME — فصلی (CFSv2، CanCM4i، GEM5-NEMO، NASA، GFDL، NCAR)","CanSIPS (ECCC)","CFSv2 (۹ ماهه)","ECMWF SEAS5 / C3S (نیازمند کلید Copernicus)"] };
const NV_CAPITALS=["تهران","مشهد","اصفهان","شیراز","تبریز","اهواز","کرمان","رشت","یزد","زاهدان","بندرعباس","ارومیه","همدان","کرمانشاه","ساری","گرگان","بوشهر","ایلام","سنندج","زنجان","قزوین","قم","اراک","خرم‌آباد","شهرکرد","بیرجند","سمنان","یاسوج","اردبیل","بجنورد"];
const NV={ s:Object.assign({tc:"daily",m:"",reg:"iran",cat:"",p:"",fr:"",alt:true,brd:true,cnty:true,city:true},store.get("nv.s",{})),
  view:null, entry:null, tok:0, cache:new Map(), paths:null, regs:null, cw:0, ch:0, d:1, anim:null, drag:null, raf:0, sharp:0, built:false };
const nvSave=()=>store.set("nv.s",NV.s);
const nvScale=sc=>ON.man&&ON.man.scales&&ON.man.scales[sc]||null;
const nvPar=id=>(ON.man&&ON.man.params||[]).find(p=>p.id===id)||null;

/* ---------- داده‌ها و منوها ---------- */
function nvMeItems(m){ return (ON.man?ON.man.items:[]).filter(i=>i.r==="me" && (!m||i.m===m) && !/L$/.test(i.p)); }
function nvModelsOf(tc){ const M=ON.man&&ON.man.models||{}; return Object.entries(M).filter(([k,o])=>((o.info&&o.info.tclass)||"daily")===tc && nvMeItems(k).length); }
function nvAltSet(){ return new Set((ON.man&&ON.man.params||[]).map(p=>p.alt).filter(Boolean)); }
function nvParamsOf(m){ const have=new Set(nvMeItems(m).map(i=>i.p)), alts=nvAltSet(); return (ON.man.params||[]).filter(p=>have.has(p.id)&&!alts.has(p.id)); }
function nvRegions(){
  if(NV.regs) return NV.regs;
  const R=[["me","خاورمیانه",NV_BOX],["iran","ایران",[42.2,64.8,23.4,40.9]]];
  try{ const L=(window.CQC_LAYERS||LAYERS).ostan||[], pv=[];
    for(const f of L){ let w=1e9,e=-1e9,s=1e9,n=-1e9; for(const poly of f.g) for(const ring of poly) for(const [lo,la] of ring){ if(lo<w)w=lo; if(lo>e)e=lo; if(la<s)s=la; if(la>n)n=la; }
      const mx=Math.max((e-w)*0.12,0.25), my=Math.max((n-s)*0.12,0.25); pv.push(["p:"+f.p.name,f.p.name,[w-mx,e+mx,s-my,n+my]]); }
    pv.sort((a,b)=>a[1].localeCompare(b[1],"fa")); R.push(...pv); }catch(e){ console.warn("nv regions",e); }
  return NV.regs=R;
}
const nvRegBox=id=>(nvRegions().find(r=>r[0]===id)||nvRegions()[1])[2];
function nvFill(sel, opts, want){ const s=$(sel); const keep=want!=null?want:s.value; s.innerHTML=opts.map(o=>`<option value="${o[0]}"${o[2]?" disabled":""}>${o[1]}</option>`).join(""); if(opts.some(o=>o[0]===keep&&!o[2])) s.value=keep; else { const f=opts.find(o=>!o[2]); if(f) s.value=f[0]; } return s.value; }
function nvAsideHTML(){
  return `<section class="card" id="nvMenus"><h3>نقشه‌های مدل</h3>
    <div id="nvWx" class="wx"></div>
    <details class="nvLegacy"><summary>منوهای کلاسیک و گزینه‌های نمایش</summary>
    <label>نوع مدل (بازهٔ زمانی) <select id="nvTc"></select></label>
    <label>مدل <select id="nvM"></select></label>
    <label>اجرای مدل (Run) <select id="nvRun"></select></label>
    <label>منطقه (زوم) <select id="nvReg"></select></label>
    <label>دستهٔ پارامتر <select id="nvCat"></select></label>
    <label>زیردستهٔ پارامتر <select id="nvP"></select></label>
    <label>فریم زمانی <select id="nvFr"></select></label>
    <label class="chk" id="nvAltL"><input type="checkbox" id="nvAlt"> اصلاح ارتفاعی دما (DEM ایران)</label>
    <label class="chk"><input type="checkbox" id="nvBrd"> مرزها (کشورها، استان‌ها)</label>
    <label class="chk"><input type="checkbox" id="nvCnty"> مرز شهرستان‌ها (در زوم ایران و استان‌ها)</label>
    <label class="chk"><input type="checkbox" id="nvCity"> نام شهرها</label>
    <div class="hint" id="nvInfo"></div>
    <div class="hint" id="nvRunInfo"></div></details>
    <button class="btn sm" type="button" id="onReload">↻ به‌روزرسانی فهرست</button></section>`;
}
function nvViewerHTML(){
  return `<article class="card wide nvCard"><header><h3 id="nvTitle">—</h3><div class="sub" id="nvSub"></div></header>
   <div class="nvTools"><button class="btn sm" id="nvZi" title="بزرگ‌نمایی">＋</button><button class="btn sm" id="nvZo" title="کوچک‌نمایی">－</button><button class="btn sm" id="nvZr" title="بازگشت به منطقهٔ انتخابی">⌂</button>
    <span class="nvGap"></span><button class="btn sm" id="nvPrev" title="فریم قبل">◀</button><button class="btn sm" id="nvPlay">▶ پخش</button><button class="btn sm" id="nvNext" title="فریم بعد">▶</button>
    <input type="range" id="nvSl" min="0" max="0" value="0"><span class="nvGap"></span>
    <button class="btn sm" id="nvPng">دانلود PNG</button><button class="btn sm" id="nvAn" title="ارسال همین نقشه به صفحهٔ تحلیل">تحلیل</button></div>
   <div class="nvStage" id="nvStage"><canvas id="nvCv"></canvas><div class="nvBusy" id="nvBusy" hidden><span class="spn"></span> در حال بارگذاری نقشه…</div></div>
   <canvas id="nvLg" class="nvLg"></canvas><div class="nvOv" id="nvOv"></div>
   <div class="wxBar" id="nvBar"></div>
   <div class="hint nvHint" id="nvHint"></div></article>`;
}
function nvInit(){
  const stage=$("nvStage"); if(!stage) return;
  NV.regs=null; NV.built=true;
  const tcOpts=NV_TC.map(([k,f])=>[k, f+(nvModelsOf(k).length?"":" — به‌زودی")]);
  $("nvTc").innerHTML=tcOpts.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join(""); $("nvTc").value=NV.s.tc;
  $("nvReg").innerHTML=nvRegions().map((r,i)=>(i===2?`<optgroup label="استان‌ها">`:"")+`<option value="${r[0]}">${r[1]}</option>`).join("")+`</optgroup>`; $("nvReg").value=NV.s.reg; if($("nvReg").value!==NV.s.reg) $("nvReg").value="iran";
  for(const [id,k] of [["nvAlt","alt"],["nvBrd","brd"],["nvCnty","cnty"],["nvCity","city"]]){ $(id).checked=!!NV.s[k]; $(id).onchange=()=>{ NV.s[k]=$(id).checked; nvSave(); if(k==="alt") nvFillFr(); else nvDraw(); }; }
  $("nvTc").onchange=()=>{ NV.s.tc=$("nvTc").value; nvFillModels(); };
  $("nvM").onchange=()=>{ NV.s.m=$("nvM").value; nvFillRun(); };
  $("nvRun").onchange=()=>nvFillCat();
  $("nvReg").onchange=()=>{ NV.s.reg=$("nvReg").value; nvSave(); nvFitReg(); nvDraw(); try{ nvWx(); }catch(e){} };
  $("nvCat").onchange=()=>{ NV.s.cat=$("nvCat").value; nvFillSub(); };
  $("nvP").onchange=()=>{ NV.s.p=$("nvP").value; nvFillFr(); };
  $("nvFr").onchange=()=>{ NV.s.fr=$("nvFr").value; $("nvSl").value=$("nvFr").selectedIndex; nvSave(); nvResolve(); };
  $("nvSl").oninput=()=>{ $("nvFr").selectedIndex=+$("nvSl").value; $("nvFr").onchange(); };
  const go=d=>{ const s=$("nvFr"); if(!s.options.length) return; s.selectedIndex=(s.selectedIndex+d+s.options.length)%s.options.length; $("nvSl").value=s.selectedIndex; s.onchange(); };
  $("nvPrev").onclick=()=>go(-1); $("nvNext").onclick=()=>go(1);
  $("nvPlay").onclick=()=>{ if(NV.anim){ clearInterval(NV.anim); NV.anim=null; $("nvPlay").textContent="▶ پخش"; } else { NV.anim=setInterval(()=>{ if(!NV.busy) go(1); },750); $("nvPlay").textContent="⏸ توقف"; } };
  $("nvZi").onclick=()=>nvZoom(1.5); $("nvZo").onclick=()=>nvZoom(1/1.5); $("nvZr").onclick=()=>{ nvFitReg(); nvDraw(); };
  $("nvPng").onclick=()=>nvExport(); $("nvAn").onclick=()=>nvToAnalysis().catch(e=>{ onStatus("⚠ "+e.message,0); alert("تحلیل انجام نشد: "+e.message); });
  nvBindStage(stage); nvWxBind();
  new ResizeObserver(()=>{ nvResize(); nvDraw(); }).observe(stage);
  nvResize(); nvFillModels();
}
function nvRefreshMenus(){ if(!NV.built||!$("nvTc")) return; const cur=$("nvTc").value;
  $("nvTc").innerHTML=NV_TC.map(([k,f])=>`<option value="${k}">${f+(nvModelsOf(k).length?"":" — به‌زودی")}</option>`).join(""); $("nvTc").value=cur; nvFillModels(); try{ nvWx(); }catch(e){} }
function nvFillModels(){
  const ms=nvModelsOf(NV.s.tc), planned=(NV_PLANNED[NV.s.tc]||[]).filter(t=>!ms.some(([k])=>t.toLowerCase().startsWith(k==="nmme"?"nmme":k==="cfsvtwo"?"cfsv2":"\u0000")));
  const opts=ms.map(([k,o])=>[k,`${o.name||o.fa}${o.info&&o.info.res?" — "+o.info.res:""}`]).concat(planned.map((t,i)=>["~"+i,t+" (به‌زودی)",true]));
  if(!opts.length) opts.push(["","— مدلی موجود نیست —",true]);
  NV.s.m=nvFill("nvM",opts,NV.s.m); nvFillRun();
}
function nvFillRun(){
  const o=ON.man&&ON.man.models&&ON.man.models[NV.s.m];
  const run=o?o.run:""; nvFill("nvRun", run?[[run,onFmtRun(run)+(o.status==="complete"?"":" (در حال ساخت)")]]:[["","—",true]]); nvFillCat();
}
function nvFillCat(){
  const m=NV.s.m, cats=((ON.man&&ON.man.cats)||[]).slice().sort((a,b)=>a.o-b.o), ps=m?nvParamsOf(m):[];
  const opts=cats.filter(c=>ps.some(p=>p.cat===c.id)).map(c=>[c.id,c.fa]); if(!opts.length) opts.push(["","— پارامتری موجود نیست —",true]);
  NV.s.cat=nvFill("nvCat",opts,NV.s.cat); nvFillSub();
}
function nvFillSub(){
  const ps=NV.s.m?nvParamsOf(NV.s.m).filter(p=>p.cat===NV.s.cat).sort((a,b)=>a.o-b.o):[];
  NV.s.p=nvFill("nvP",ps.length?ps.map(p=>[p.id,p.fa]):[["","—",true]],NV.s.p); nvFillFr();
}
function nvPid(){ const p=nvPar(NV.s.p); return p && p.alt && !NV.s.alt ? p.alt : NV.s.p; }
const NV_MONTH=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",month:"long",timeZone:"UTC"});
const NV_GM=new Intl.DateTimeFormat("fa-IR-u-ca-gregory",{year:"numeric",month:"long",timeZone:"UTC"}), NV_PM=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{month:"long",timeZone:"UTC"}), NV_PY=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",timeZone:"UTC"});
function nvSpan(){ const t=((ON.man&&ON.man.models[NV.s.m]||{}).info||{}).tclass; return t==="seasonal"?3:1; }
const NV_PD=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{day:"numeric",timeZone:"UTC"});
/* اصلاح تاریخ ماه پیش‌بینی (مدل‌های ماهانه/فصلی): اگر ماه اعتبار با ماه اجرا نمی‌خواند (مثلاً سال ۲۰۸۹ به‌خاطر واحد محور target)،
   ماه‌ها به‌ترتیب از ماه اجرا شمرده می‌شوند. نام فایل‌ها (v اصلی) دست‌نخورده می‌ماند و فقط برچسب نمایشی اصلاح می‌شود. */
const NV_VFIX={};
function nvFixMonths(){ const M=(ON.man&&ON.man.models)||{}; for(const k in NV_VFIX) delete NV_VFIX[k];
  for(const [k,o] of Object.entries(M)){ const tc=(o.info&&o.info.tclass)||"daily"; if(tc!=="monthly"&&tc!=="seasonal") continue;
    const run=o.run||""; if(run.length<8) continue; const idx=v=>+v.slice(0,4)*12+ +v.slice(4,6)-1, rm=idx(run);
    const vs=[...new Set((ON.man.items||[]).filter(i=>i.m===k).map(i=>String(i.v)))].sort(); if(!vs.length) continue;
    if(vs.every(v=>{const d=idx(v)-rm; return d>=-1&&d<=14})) continue;
    vs.forEach((v,j)=>{ const t=rm+j; NV_VFIX[k+"|"+v]=Math.floor(t/12)+String(t%12+1).padStart(2,"0")+"0100"; }); } }
function nvMonthLab(v,n){ n=n||nvSpan(); const d=onDate(NV_VFIX[NV.s.m+"|"+v]||v), e=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+n,0)); /* اولین و آخرین روز بازه، طبق تقویم دقیق همان ماه و سال */
  const y1=NV_PY.format(d), y2=NV_PY.format(e), g=n>1?`${NV_GM.format(d)} تا ${NV_GM.format(e)}`:NV_GM.format(d);
  return `${g} (${NV_PD.format(d)} ${NV_PM.format(d)}${y1!==y2?" "+y1:""} تا ${NV_PD.format(e)} ${NV_PM.format(e)} ${y2})`; }
function nvFrLab(i){ const tc=(ON.man.models[NV.s.m].info||{}).tclass||"daily";
  if(tc==="monthly"||tc==="seasonal") return nvMonthLab(i.v);
  return `${i.s>=0?FA(i.s)+" ساعت — ":""}${persianDT(onDate(i.v),210)}`; }
function nvFillFr(){
  const p=nvPar(NV.s.p), hasAlt=!!(p&&p.alt);
  $("nvAlt").disabled=!hasAlt; $("nvAltL").title=hasAlt?"":"برای این پارامتر اصلاح ارتفاعی تعریف نشده است (فقط دما)";
  const it=(NV.s.m&&NV.s.p?nvMeItems(NV.s.m).filter(i=>i.p===nvPid()):[]).sort((a,b)=>a.s-b.s);
  NV.items=it; const run=ON.man&&ON.man.models&&ON.man.models[NV.s.m];
  $("nvFr").innerHTML=it.map(i=>`<option value="${i.v}">${nvFrLab(i)}</option>`).join("")||`<option value="">—</option>`;
  const want=NV.s.fr; if(it.some(i=>i.v===want)) $("nvFr").value=want; else { const f=it.find(i=>i.s>=3)||it[0]; if(f) $("nvFr").value=f.v; }
  NV.s.fr=$("nvFr").value; $("nvSl").max=Math.max(0,it.length-1); $("nvSl").value=$("nvFr").selectedIndex; nvSave();
  const info=run&&run.info||{}; $("nvInfo").textContent=[info.res&&("رزولوشن مدل: "+info.res), info.cyc&&("اجراها: "+info.cyc+"Z"), info.prov&&("منبع: "+info.prov+" · Open-Meteo (CC BY 4.0)")].filter(Boolean).join(" · ");
  $("nvRunInfo").innerHTML=ON.man&&ON.man.models?Object.values(ON.man.models).map(o=>`${o.name||o.fa}: ${onFmtRun(o.run)} · ${o.status==="complete"?"کامل":"در حال ساخت"} · ${FA(o.done||0)} نقشه`).join("<br>"):"";
  nvResolve(); try{ nvWx(); }catch(e){ console.warn(e); }
}
const onDate=v=>new Date(Date.UTC(+v.slice(0,4),+v.slice(4,6)-1,+v.slice(6,8),+v.slice(8,10)));

/* ---------- بارگذاری کاشی ---------- */
function nvImg(url){
  if(NV.cache.has(url)) return NV.cache.get(url);
  const p=new Promise(res=>{ const im=new Image(); im.onload=()=>res(im); im.onerror=()=>res(null); im.src=url; });
  NV.cache.set(url,p); if(NV.cache.size>60){ const k=NV.cache.keys().next().value; NV.cache.delete(k); } return p;
}
async function nvResolve(){
  const tok=++NV.tok, it=NV.items||[], cur=it.find(i=>i.v===NV.s.fr);
  if(!cur){ NV.entry=null; $("nvTitle").textContent=ON.man&&ON.man.items&&ON.man.items.length?"نقشه‌ای برای این انتخاب نیست":"—"; $("nvSub").textContent=""; nvDraw(); return; }
  NV.busy=true; $("nvBusy").hidden=false;
  const P0=nvPar(nvPid())||nvPar(NV.s.p), url=ON.base+cur.f, lurl=P0&&P0.ln?url.replace(/\/([a-zA-Z0-9]+)_(\d{10}\.webp)$/,"/$1L_$2"):null;
  const [img,lay]=await Promise.all([nvImg(url), lurl?nvImg(lurl):null]);
  if(tok!==NV.tok) return;
  NV.busy=false; $("nvBusy").hidden=true;
  NV.entry={item:cur, img, lay, par:P0, sc:P0&&nvScale(P0.sc), idx:null};
  nvTitle(); if(!img) $("nvSub").textContent="⚠ تصویر نقشه از هاست بارگذاری نشد"; nvLegend(); nvDraw();
  const k=it.findIndex(i=>i.v===cur.v), nx=it[k+1]; if(nx&&P0) nvImg(ON.base+nx.f);       // فریم بعدی از پیش گرفته می‌شود
}
function nvIsLong(){ const t=((ON.man.models[NV.s.m]||{}).info||{}).tclass||"daily"; return t==="monthly"||t==="seasonal"; }
function nvTitle(){
  const e=NV.entry; if(!e) return; const M=ON.man.models[NV.s.m], reg=nvRegions().find(r=>r[0]===NV.s.reg), mu=e.par&&(e.par.mu||e.par.unit)||"";
  $("nvTitle").textContent=`${e.par?e.par.fa:""}${nvIsLong()?" — "+nvMonthLab(e.item.v):""}`;
  $("nvSub").textContent=`${M?(M.name||M.fa):""} · ${onFmtRun(ON.man.models[NV.s.m].run)} · ${nvIsLong()?"ماه پیش‌بینی: "+nvMonthLab(e.item.v):"اعتبار: "+onFmtValid(e.item.v)+" · "+FA(e.item.s)+" ساعت پس از شروع اجرا"} · ${reg?reg[1]:""}${mu?` · واحد: ${mu}`:""}`;
  const ov=$("nvOv"); if(ov){ const lng=nvIsLong(); ov.innerHTML=`<b>${e.par?e.par.fa:""}</b><span>${M?(M.name||M.fa):""} · ${lng?"ماه پیش‌بینی: "+nvMonthLab(e.item.v):"اعتبار: "+onFmtValid(e.item.v)}</span><span>${onFmtRun(M.run)}${reg?" · "+reg[1]:""}</span>`; }
  $("nvHint").textContent="با کشیدن جابه‌جا کنید، با چرخ ماوس یا دو انگشت بزرگ‌نمایی کنید. فقط تصویر نقشه نمایش داده می‌شود؛ داده‌های عددی مدل در دسترس نیست.";
}

/* ---------- کادر و دوربین ---------- */
function nvResize(){ const st=$("nvStage"), cv=$("nvCv"); if(!st||!cv) return; const r=st.getBoundingClientRect(); if(!r.width) return;
  NV.d=Math.min(2,window.devicePixelRatio||1); NV.cw=r.width; NV.ch=r.height; cv.width=Math.round(r.width*NV.d); cv.height=Math.round(r.height*NV.d);
  if(!NV.view) nvFitReg(); else nvClamp(); }
function nvFitBox(box){ const [w,e,s,n]=box, k=Math.min(NV.cw/(e-w), NV.ch/(n-s)); NV.view={k, x0:(w+e)/2-NV.cw/2/k, y0:(s+n)/2+NV.ch/2/k}; nvClamp(); }
function nvFitReg(){ if(NV.cw) nvFitBox(nvRegBox(NV.s.reg)); }
function nvClamp(){ const v=NV.view; if(!v) return; const kmin=Math.max(NV.cw/(NV_BOX[1]-NV_BOX[0]), NV.ch/(NV_BOX[3]-NV_BOX[2])); v.k=Math.max(kmin,Math.min(2400,v.k));
  const vw=NV.cw/v.k, vh=NV.ch/v.k; v.x0=Math.max(NV_BOX[0],Math.min(NV_BOX[1]-vw,v.x0)); v.y0=Math.max(NV_BOX[2]+vh,Math.min(NV_BOX[3],v.y0)); }
function nvZoom(f,cx,cy){ const v=NV.view; if(!v) return; cx=cx==null?NV.cw/2:cx; cy=cy==null?NV.ch/2:cy;
  const lon=v.x0+cx/v.k, lat=v.y0-cy/v.k; v.k*=f; nvClamp(); v.x0=lon-cx/v.k; v.y0=lat+cy/v.k; nvClamp(); nvDraw(true); nvSharpLater(); }
function nvBindStage(st){
  const pts=new Map(); let last=null;
  const pos=e=>{ const r=st.getBoundingClientRect(); return [e.clientX-r.left, e.clientY-r.top]; };
  st.addEventListener("pointerdown",e=>{ st.setPointerCapture(e.pointerId); pts.set(e.pointerId,pos(e)); last=null; st.classList.add("drag"); });
  st.addEventListener("pointermove",e=>{ if(!pts.has(e.pointerId)) return; const p=pos(e), o=pts.get(e.pointerId); pts.set(e.pointerId,p); const v=NV.view; if(!v) return;
    if(pts.size===1){ v.x0-= (p[0]-o[0])/v.k; v.y0+= (p[1]-o[1])/v.k; nvClamp(); nvDraw(true); nvSharpLater(); }
    else if(pts.size===2){ const [a,b]=[...pts.values()], dd=Math.hypot(a[0]-b[0],a[1]-b[1]), c=[(a[0]+b[0])/2,(a[1]+b[1])/2]; if(last){ nvZoom(dd/last.d,c[0],c[1]); v.x0-=(c[0]-last.c[0])/v.k; v.y0+=(c[1]-last.c[1])/v.k; nvClamp(); } last={d:dd,c}; } });
  const up=e=>{ pts.delete(e.pointerId); last=null; if(!pts.size) st.classList.remove("drag"); };
  st.addEventListener("pointerup",up); st.addEventListener("pointercancel",up);
  st.addEventListener("wheel",e=>{ e.preventDefault(); const [x,y]=pos(e); nvZoom(e.deltaY<0?1.25:0.8,x,y); },{passive:false});
  st.addEventListener("dblclick",e=>{ const [x,y]=pos(e); nvZoom(2,x,y); });
}

/* ---------- لایه‌های برداری (مرزها) ---------- */
function nvPaths(){
  if(NV.paths) return NV.paths; const P={ctry:new Path2D(),coast:new Path2D(),prov:new Path2D(),cnty:new Path2D(),ostan:new Path2D()};
  try{ const B=borderLines(); for(const [k,L] of [["ctry",B.ctry],["coast",B.coast],["prov",B.prov]]) for(const pts of (L||[])){ for(let i=0;i<pts.length;i+=2){ if(i) P[k].lineTo(pts[i],pts[i+1]); else P[k].moveTo(pts[i],pts[i+1]); } } }catch(e){ console.warn("nv borders",e); }
  try{ const LY=window.CQC_LAYERS||LAYERS;
    for(const [k,arr] of [["cnty",LY.county],["ostan",LY.ostan]]) for(const f of (arr||[])) for(const poly of f.g) for(const ring of poly){ ring.forEach((q,i)=>i?P[k].lineTo(q[0],q[1]):P[k].moveTo(q[0],q[1])); if(k==="ostan") P.hasO=true; } }catch(e){ console.warn("nv layers",e); }
  return NV.paths=P;
}
function nvCities(){ if(NV.cities) return NV.cities; try{ NV.cities=SEATS.map(([n,la,lo])=>({n,la,lo,cap:NV_CAPITALS.includes(n)})); }catch(e){ NV.cities=[]; } return NV.cities; }

/* ---------- شمارهٔ کلاس برای بزرگ‌نمایی بدون رنگ واسطه ---------- */
function nvIndex(e){
  if(e.idx!==undefined && e.idx!==null) return e.idx; if(!e.img||!e.sc||e.sc.lab){ return e.idx=false; }
  try{ const c=document.createElement("canvas"); c.width=NV_TW; c.height=NV_TH; const x=c.getContext("2d",{willReadFrequently:true}); x.drawImage(e.img,0,0); const d=x.getImageData(0,0,NV_TW,NV_TH).data;
    const map=new Map(); e.sc.c.forEach((h,i)=>map.set((parseInt(h.slice(1,3),16)<<16)|(parseInt(h.slice(3,5),16)<<8)|parseInt(h.slice(5,7),16), i));
    const I=new Int16Array(NV_TW*NV_TH); let miss=0;
    for(let p=0,q=0;p<I.length;p++,q+=4){ const k=(d[q]<<16)|(d[q+1]<<8)|d[q+2]; const v=map.get(k); if(v===undefined){ I[p]=-1; miss++; } else I[p]=v; }
    e.idx = miss>I.length*0.6 ? false : I;                // اگر رنگ‌ها با مقیاس نمی‌خواند، درون‌یابی نمی‌شود
  }catch(err){ e.idx=false; } return e.idx; }
function nvPal32(sc){ if(sc.__p32) return sc.__p32; const a=new Uint32Array(sc.c.length); sc.c.forEach((h,i)=>{ a[i]=(255<<24)|(parseInt(h.slice(5,7),16)<<16)|(parseInt(h.slice(3,5),16)<<8)|parseInt(h.slice(1,3),16); }); return sc.__p32=a; }
function nvPaintTile(x, W, H, k, x0, y0, e, fast){
  const dx=(NV_BOX[0]-x0)*k, dy=(y0-NV_BOX[3])*k, dw=(NV_BOX[1]-NV_BOX[0])*k, dh=(NV_BOX[3]-NV_BOX[2])*k, f=k/NV_PXD;
  x.save(); x.fillStyle="#fff"; x.fillRect(0,0,W,H); x.imageSmoothingEnabled=false;
  const I=(!fast && f>1.25)?nvIndex(e):null;
  if(I && !e.sc.lab){
    const ax=Math.max(0,Math.floor(dx)), ay=Math.max(0,Math.floor(dy)), bx=Math.min(W,Math.ceil(dx+dw)), by=Math.min(H,Math.ceil(dy+dh)), w=bx-ax, h=by-ay;
    if(w>0&&h>0){ const out=new ImageData(w,h), o32=new Uint32Array(out.data.buffer), pal=nvPal32(e.sc), n=pal.length, W0=NV_TW, H0=NV_TH, WHITE=0xFFFFFFFF;
      for(let py=0;py<h;py++){ const v=(ay+py+0.5-dy)/f-0.5, j0=Math.max(0,Math.min(H0-1,Math.floor(v))), j1=Math.min(H0-1,j0+1), fy=Math.max(0,Math.min(1,v-j0)), r0=j0*W0, r1=j1*W0;
        for(let px=0;px<w;px++){ const u=(ax+px+0.5-dx)/f-0.5, i0=Math.max(0,Math.min(W0-1,Math.floor(u))), i1=Math.min(W0-1,i0+1), fx=Math.max(0,Math.min(1,u-i0));
          const a=I[r0+i0], b=I[r0+i1], c=I[r1+i0], d=I[r1+i1]; let val;
          if(a===b&&b===c&&c===d) val=a;
          else if(a<0||b<0||c<0||d<0){ const q=I[(fy>0.5?r1:r0)+(fx>0.5?i1:i0)]; val=q; }
          else val=Math.round((a*(1-fx)+b*fx)*(1-fy)+(c*(1-fx)+d*fx)*fy);
          o32[py*w+px]= val>=0&&val<n ? pal[val] : WHITE; } }
      x.putImageData(out,ax,ay); }
  } else if(e.img) x.drawImage(e.img,0,0,NV_TW,NV_TH,dx,dy,dw,dh);
  if(e.lay){ x.imageSmoothingEnabled=true; x.imageSmoothingQuality="high"; x.drawImage(e.lay,0,0,NV_TW,NV_TH,dx,dy,dw,dh); }
  x.restore();
}
function nvPaintVec(x, W, H, k, x0, y0, S, scale){
  const P=nvPaths(), kc=k/scale, w=px=>px*scale/k;                       // kc: پیکسل CSS در هر درجه
  x.save(); x.setTransform(k,0,0,-k,-x0*k,y0*k); x.lineJoin="round"; x.lineCap="round";
  if(S.cnty && kc>=26){ x.strokeStyle="rgba(60,60,60,.40)"; x.lineWidth=w(0.7); x.stroke(P.cnty); }
  if(S.brd){ x.strokeStyle="rgba(40,40,40,.80)"; x.lineWidth=w(kc>=26?1.3:0.9); x.stroke(P.hasO?P.ostan:P.prov); }
  if(S.brd){ x.strokeStyle="#111"; x.lineWidth=w(1.2); x.stroke(P.coast); x.lineWidth=w(1.7); x.stroke(P.ctry); }
  if(S.reg && S.reg.indexOf("p:")===0){ try{ const f=(window.CQC_LAYERS||LAYERS).ostan.find(q=>"p:"+q.p.name===S.reg); if(f){ x.strokeStyle="#c1121f"; x.lineWidth=w(2.6); const pp=new Path2D(); for(const poly of f.g) for(const ring of poly) ring.forEach((q,i)=>i?pp.lineTo(q[0],q[1]):pp.moveTo(q[0],q[1])); x.stroke(pp); } }catch(e){} }
  x.restore();
  if(S.city && kc>=24){
    x.save(); x.textAlign="center"; x.textBaseline="bottom"; x.direction="rtl"; const fs=(kc>=70?12:11)*scale; let n=0;
    for(const c of nvCities()){ if(kc<70 && !c.cap) continue; const X=(c.lo-x0)*k, Y=(y0-c.la)*k; if(X<-20||Y<-20||X>W+20||Y>H+20) continue; if(++n>140) break;
      x.fillStyle="#111"; x.beginPath(); x.arc(X,Y,2.2*scale,0,6.2832); x.fill(); x.font=`600 ${fs}px ${FT.body}`; x.lineWidth=3*scale; x.strokeStyle="rgba(255,255,255,.85)"; x.strokeText(c.n,X,Y-3*scale); x.fillStyle="#111"; x.fillText(c.n,X,Y-3*scale); }
    x.restore(); }
}
function nvDraw(fast){
  const cv=$("nvCv"); if(!cv||!NV.view||!cv.width) return; const x=cv.getContext("2d"), v=NV.view, k=v.k*NV.d;
  const e=NV.entry; if(e&&e.img) nvPaintTile(x,cv.width,cv.height,k,v.x0,v.y0,e,!!fast); else { x.fillStyle="#fff"; x.fillRect(0,0,cv.width,cv.height); }
  nvPaintVec(x,cv.width,cv.height,k,v.x0,v.y0,Object.assign({},NV.s),NV.d);
}
function nvSharpLater(){ clearTimeout(NV.sharp); NV.sharp=setTimeout(()=>nvDraw(false),140); }

/* ---------- نوار رنگ ---------- */
function nvLegendDraw(c, W, sc, unit){
  const x=c.getContext("2d"), n=sc.c.length, H=c.height, s=W/760, bar=Math.round(20*s), top=Math.round(6*s);
  x.fillStyle="#fff"; x.fillRect(0,0,W,H); const bx0=Math.round(8*s), bw=W-bx0*2;
  for(let j=0;j<n;j++){ const a=Math.round(bx0+bw*j/n), b=Math.round(bx0+bw*(j+1)/n); x.fillStyle=sc.c[j]; x.fillRect(a,top,b-a,bar); }
  x.strokeStyle="#000"; x.lineWidth=Math.max(1,s); x.strokeRect(bx0,top,bw,bar);
  x.fillStyle="#111"; x.font=`${Math.round(11*s)}px sans-serif`; x.textAlign="center"; x.textBaseline="top"; x.direction="ltr"; let lastR=-1e9;
  const fmt=v=>Math.abs(v-Math.round(v))<1e-9?String(Math.round(v)):(+v.toFixed(2)).toString();
  for(let j=0;j<n;j++){ let lab=null, cx;
    if(sc.lab){ lab=sc.lab[j]; cx=bx0+bw*(j+0.5)/n; x.font=`${Math.round(8*s)}px sans-serif`; }
    else if(j>=1 && sc.e[j]!=null){ lab=fmt(sc.e[j]); cx=bx0+bw*j/n; }
    if(lab==null) continue; const w=x.measureText(lab).width; if(cx-w/2<lastR+3*s) continue; x.fillText(lab,cx,top+bar+3*s); lastR=cx+w/2; if(sc.lab) x.font=`${Math.round(11*s)}px sans-serif`; }
  if(unit){ x.textAlign="right"; x.font=`${Math.round(11*s)}px sans-serif`; x.fillStyle="#333"; x.fillText(unit,W-bx0,top+bar+Math.round(16*s)); }
}
function nvLegend(){ const c=$("nvLg"), e=NV.entry; if(!c) return; const w=Math.max(300,Math.round($("nvStage").getBoundingClientRect().width*(NV.d||1))); c.width=w; c.height=Math.round(w/760*52); c.style.height=(c.height/(NV.d||1))+"px";
  if(e&&e.sc) nvLegendDraw(c,w,e.sc,e.par&&(e.par.mu||e.par.unit)); else c.getContext("2d").clearRect(0,0,w,c.height); }

/* ---------- خروجی PNG و ارسال به تحلیل ---------- */
function nvCanvas(){
  const e=NV.entry; if(!e||!e.img){ return null; } const W=1800, mapH=Math.round(W*NV.ch/NV.cw), hd=96, lg=Math.round(W/760*52), ft=46, c=document.createElement("canvas"); c.width=W; c.height=hd+mapH+lg+ft;
  const x=c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height);
  const sub=document.createElement("canvas"); sub.width=W; sub.height=mapH; const k=NV.view.k*W/NV.cw;
  nvPaintTile(sub.getContext("2d"),W,mapH,k,NV.view.x0,NV.view.y0,e,false); nvPaintVec(sub.getContext("2d"),W,mapH,k,NV.view.x0,NV.view.y0,Object.assign({},NV.s),W/NV.cw);
  x.drawImage(sub,0,hd); x.strokeStyle="#000"; x.lineWidth=2; x.strokeRect(1,hd,W-2,mapH);
  const M=ON.man.models[NV.s.m], reg=nvRegions().find(r=>r[0]===NV.s.reg);
  txt(x, e.par.fa, W-24, 40, `34px ${FT.titr}`, {maxW:W-300});
  txt(x, `${M.name||M.fa} · ${onFmtRun(M.run)} · ${nvIsLong()?"ماه پیش‌بینی: "+nvMonthLab(e.item.v):"اعتبار: "+onFmtValid(e.item.v)+" · "+FA(e.item.s)+" ساعت"} · ${reg?reg[1]:""}`, W-24, 78, `22px ${FT.body}`, {color:"#222", maxW:W-48});
  const l=document.createElement("canvas"); l.width=W; l.height=lg; nvLegendDraw(l,W,e.sc,e.par.mu||e.par.unit); x.drawImage(l,0,hd+mapH);
  txt(x, `داده: ${(M.info&&M.info.prov)||M.name} · Open-Meteo.com (CC BY 4.0) · MetStat — wtafkik.ir`, W-24, hd+mapH+lg+30, `17px ${FT.body}`, {color:"#555"});
  try{ drawBrand(x,{brand:$("brand")?$("brand").value.trim():"",handle:$("handle")?$("handle").value.trim():"",logoImg:state.logoImg},14,hd+mapH+lg+4,230,ft-4,{side:true,align:"left"}); }catch(err){}
  return c;
}
function nvExport(){ const c=nvCanvas(), e=NV.entry; if(!c) return; c.toBlob(b=>onSave(b,`metstat_${NV.s.m}_${nvPid()}_${e.item.v}_${NV.s.reg.replace(/[^a-z]/g,"")||"reg"}.png`)); }
async function nvToAnalysis(){
  const e=NV.entry; if(!e) return; const P0=nvPar(NV.s.p);
  const it=(ON.man.items||[]).filter(i=>i.r==="iran"&&i.m===NV.s.m&&i.p===(P0&&P0.id)&&i.v===e.item.v);
  let files;
  if(it.length) files=await onFiles(it);
  else { const c=nvCanvas(); if(!c) throw new Error("نقشه هنوز بارگذاری نشده است");          // ماهانه/فصلی: نسخهٔ ۷۶۰ ایران نداریم → همین نقشهٔ نمایش‌داده‌شده (با تیتر و لجند) ارسال می‌شود
    const b=await new Promise(r=>c.toBlob(r,"image/png")); files=[new File([b],`metstat_${NV.s.m}_${nvPid()}_${e.item.v}.png`,{type:"image/png"})]; } onStatus("ارسال به صفحهٔ تحلیل…",0.6); await switchMode("wu"); try{ CLEAR.main(); }catch(err){} await addFiles(files);
}
function nvLeave(){ if(NV.anim){ clearInterval(NV.anim); NV.anim=null; } try{ nvCompClear(); }catch(e){} }

/* ===================== نقشه‌های ترکیبی خودکار (همرفت، هشدار) ===================== */
const NC_PROD=[{id:"conv",fa:"همرفت: احتمال وقوع و شدت بالقوهٔ توفان تندری، تگرگ و ...",op:"conv"},{id:"warn",fa:"هشدارهای جوی خودکار (بارش، باد، دما، برف، رعدوبرق و ...)",op:"warn"}];
const NCP={tok:0,res:null};
function nvCompHTML(){
  return `<section class="card" id="ncBox"><h3>نقشه‌های ترکیبی خودکار</h3>
    <label>محصول <select id="ncP">${NC_PROD.map(p=>`<option value="${p.id}">${p.fa}</option>`).join("")}</select></label>
    <label>مدل <select id="ncM"></select></label>
    <label>زمان معتبر <select id="ncV"></select></label>
    <div class="hint" id="ncPs"></div>
    <p class="hint">با هر تغییر منو، نقشه همان لحظه از ترکیب پارامترهای موجود با همان منطق و رنگ صفحه‌های همرفت و هشدار ساخته و در کادر زیر همین بخش نشان داده می‌شود. با بستن صفحه یا تازه‌سازی، این نقشه‌ها پاک می‌شوند.</p></section>`;
}
function ncOp(){ return ON_OPS.find(o=>o.id===$("ncP").value); }
function ncInit(){
  if(!$("ncP")) return;
  $("ncP").onchange=()=>ncFillM(true); $("ncM").onchange=()=>ncFillV(true); $("ncV").onchange=()=>ncFillInfo(true); ncFillM(false);
}
function ncFillM(u){
  const op=ncOp(), its=(ON.man?ON.man.items:[]).filter(i=>i.r==="iran"&&op.ps.includes(i.p)), ms=[...new Set(its.map(i=>i.m))].filter(m=>new Set(its.filter(i=>i.m===m).map(i=>i.p)).size>=op.min);
  nvFill("ncM",ms.length?ms.map(m=>[m,onModelFa(m)]):[["","— مدلی با پارامتر کافی نیست —",true]]); ncFillV(u);
}
function ncFillV(u){
  const op=ncOp(), m=$("ncM").value, vs=[...new Set((ON.man?ON.man.items:[]).filter(i=>i.r==="iran"&&i.m===m&&op.ps.includes(i.p)&&!/^(p24|pacc|snow24|snowacc)$/.test(i.p)).map(i=>i.v))].sort();
  $("ncV").innerHTML=vs.map(v=>`<option value="${v}">${onFmtValid(v)}</option>`).join("")||`<option value="">—</option>`; ncFillInfo(u);
}
function ncPick(op,m,v){ const it=(ON.man?ON.man.items:[]).filter(i=>i.r==="iran"&&i.m===m&&op.ps.includes(i.p)), out=[];
  for(const p of op.ps){ const c=it.filter(i=>i.p===p); if(!c.length) continue; let x=c.find(i=>i.v===v); if(!x&&/^(p24|snow24)$/.test(p)) x=c.filter(i=>i.v>=v).sort((a,b)=>a.v.localeCompare(b.v))[0]; if(x) out.push(x); } return out; }
function ncFillInfo(u){ const op=ncOp(), fs=ncPick(op,$("ncM").value,$("ncV").value); $("ncPs").textContent="پارامترهای موجود: "+(fs.map(i=>onPar(i.p).fa).join("، ")||"—"); clearTimeout(NCP.t); if(u) NCP.t=setTimeout(()=>nvCompBuild().catch(e=>{ console.error(e); ncMsg("⚠ "+e.message); }),500); }
function ncMsg(t){ const b=$("onComp"); if(!b) return; b.hidden=!t; if(t) b.innerHTML=`<article class="card wide"><div class="hint">${t}</div></article>`; }
function nvCompClear(){ NCP.tok++; NCP.res=null; const b=$("onComp"); if(b){ b.innerHTML=""; b.hidden=true; } try{ CLEAR.cv(); }catch(e){} try{ CLEAR.wn(); }catch(e){} }
const ncWait=(fn,ms)=>new Promise((ok,bad)=>{ const t0=Date.now(); const t=setInterval(()=>{ const r=fn(); if(r){ clearInterval(t); ok(r); } else if(Date.now()-t0>ms){ clearInterval(t); bad(new Error("ساخت نقشهٔ ترکیبی زمان زیادی برد")); } },300); });
async function nvCompBuild(){
  const op=ncOp(), m=$("ncM").value, v=$("ncV").value; if(!op||!m||!v){ ncMsg(""); return; }
  const tok=++NCP.tok, items=ncPick(op,m,v); if(items.length<op.min){ ncMsg("پارامتر کافی برای این ترکیب نیست"); return; }
  ncMsg(`<span class="spn"></span> در حال ساخت نقشهٔ ترکیبی…`);
  const files=await onFiles(items); if(tok!==NCP.tok) return;
  const isCv=op.kind==="conv", box=$(isCv?"cvCards":"wnCards");
  try{ CLEAR[isCv?"cv":"wn"](); }catch(e){}
  if(isCv){ await cvAdd(files);
    const all=(ON.man.items||[]).filter(i=>i.r==="iran"&&i.m===m), cmp=["p3","p6","p1","p24"].map(p=>all.find(i=>i.p===p&&i.v===v)||all.filter(i=>i.p===p&&i.v>=v).sort((x,y)=>x.v.localeCompare(y.v))[0]).find(Boolean);
    if(cmp){ await cvAdd(await onFiles([cmp]),"cmp"); } try{ cvThrPanel(); }catch(e){} }
  else await wnAdd(files);
  if(tok!==NCP.tok) return;
  const st=isCv?cv:wn;
  const got=await ncWait(()=>{ if(tok!==NCP.tok) return true; if(!st.res||st.busy) return null; const cs=[...box.querySelectorAll("article.card")].filter(c=>c.querySelector("img")); return cs.length&&cs.every(c=>{ const i=c.querySelector("img"); return i.complete&&i.naturalWidth; })?cs:null; },150000);
  if(tok!==NCP.tok||got===true) return;
  const out=$("onComp"); out.hidden=false; out.innerHTML=`<article class="card wide ncOut"><header><h3>${op.fa}</h3><div class="sub">${onModelFa(m)} · ${onFmtValid(v)}</div></header><div class="ncTabs" id="ncTabs"></div><div id="ncFrame"></div></article>`;
  const tabs=$("ncTabs"), frame=$("ncFrame"), cards=got.map(c=>{ const h=c.querySelector("h3"), im=c.querySelector("img"); return {t:h?h.textContent:"نقشه", sub:(c.querySelector(".sub")||{}).textContent||"", src:im.src, w:im.naturalWidth}; });
  NCP.res=cards; const show=k=>{ const c=cards[k]; [...tabs.children].forEach((b,i)=>b.classList.toggle("on",i===k)); frame.innerHTML=`<div class="sub">${c.sub}</div><img alt="" style="width:100%;height:auto;display:block;cursor:zoom-in">`; const im=frame.querySelector("img"); im.src=c.src; im.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=im.src; d.showModal(); }; };
  cards.forEach((c,k)=>{ const b=document.createElement("button"); b.className="btn sm"; b.type="button"; b.textContent=c.t; b.onclick=()=>show(k); tabs.append(b); }); show(0);
  onStatus("",1); try{ CLEAR[isCv?"cv":"wn"](); }catch(e){}        // نتیجه در کادر همین صفحه است؛ حافظهٔ صفحهٔ اصلی آزاد می‌شود
}


/* ===================== نمودار شاخص‌های اقلیمی (ENSO، QBO، NAO، DMI ...) ===================== */
const NI={idx:null,tok:0};
function nvIdxHTML(){
  return `<section class="card" id="niBox"><h3>شاخص‌های اقلیمی (ENSO، QBO، NAO، IOD و ...)</h3>
    <label>گروه <select id="niG"></select></label>
    <label>شاخص <select id="niI"></select></label>
    <label>دورهٔ نمودار <select id="niP"></select></label>
    <div class="hint" id="niInfo">در حال دریافت فهرست شاخص‌ها…</div>
    <p class="hint">فقط تصویر نمودار نشان داده می‌شود؛ داده‌های عددی منتشر نمی‌شود. به‌روزرسانی خودکار با برنامهٔ indices.py در GitHub Actions انجام می‌شود.</p></section>`;
}
async function niInit(){
  if(!$("niG")) return; const info=$("niInfo");
  try{ const r=await fetch(ON.base+"data/idx/index.json?"+Date.now(),{cache:"no-store"}); if(!r.ok) throw 0; NI.idx=await r.json(); }catch(e){ NI.idx=null; }
  const it=NI.idx&&NI.idx.items||{}, ids=Object.keys(it);
  if(!ids.length){ nvFill("niG",[["","—",true]]); nvFill("niI",[["","—",true]]); nvFill("niP",[["","—",true]]); info.textContent="هنوز نمودار شاخصی روی هاست نیست (workflow «metstat-indices» را اجرا کنید)."; return; }
  const gs=[...new Set(ids.map(i=>it[i].grp))]; nvFill("niG",gs.map(g=>[g,g]));
  $("niG").onchange=()=>niFillI(); $("niI").onchange=()=>niFillP(); $("niP").onchange=()=>niShow(); niFillI();
}
function niFillI(){ const it=NI.idx.items; nvFill("niI",Object.keys(it).filter(i=>it[i].grp===$("niG").value).map(i=>[i,it[i].fa])); niFillP(); }
function niFillP(){ const e=NI.idx.items[$("niI").value]||{per:{}}; nvFill("niP",Object.entries(e.per).map(([k,v])=>[k,v])); niShow(); }
function niShow(){
  const id=$("niI").value, per=$("niP").value, e=NI.idx.items[id], box=$("onIdx"); if(!e||!per){ if(box) box.hidden=true; return; }
  $("niInfo").textContent=`${e.en} · منبع: ${e.src} · آخرین ماه داده: ${e.last} · به‌روزرسانی: ${e.upd}`+(NI.idx.updated?` · آخرین اجرا: ${NI.idx.updated.slice(0,16).replace("T"," ")} UTC`:"");
  box.hidden=false; box.innerHTML=`<article class="card wide"><header><h3>${e.fa}</h3><div class="sub">${e.grp} · ${e.per[per]}</div></header><img alt="${e.en}" style="width:100%;height:auto;display:block;cursor:zoom-in"></article>`;
  const im=box.querySelector("img"); im.src=ON.base+`data/idx/${id}_${per}.png?`+(NI.idx.updated||""); im.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=im.src; d.showModal(); };
}


/* =====================================================================
   رابط سبک weather.us برای تحلیل آنلاین: بخش‌های جمع‌شونده («تغییر نقشه / پارامتر / مدل و ران / تاریخ»)،
   دکمه‌های چیپ برای مدل، ران، ساعت پیش‌بینی و نوار مدل‌ها زیر نقشه. منوهای قدیمی (select) حالت‌نگه‌دار
   باقی می‌مانند و همهٔ منطق قبلی دست‌نخورده است؛ چیپ‌ها فقط مقدار select را عوض و رویداد را صدا می‌زنند.
   ===================================================================== */
const NVW={open:{reg:false,par:false,mod:false,time:true}, ptab:"used", ivl:0};
const NVW_USED=["p24","p6","p3","p1","pt","t2m","t2","tmax","tmin","z500","w10","gust","mslp","snow","tot","sigw","cape"];
const wxFA=n=>{ try{ return FA(n); }catch(e){ return String(n); } };
function wxChip(label,on,attr,dis){ return `<button type="button" class="wxChip${on?" on":""}"${dis?" disabled":""} ${attr}>${label}</button>`; }
function wxSec(key,title,body){ const o=NVW.open[key]; return `<div class="wxSec"><button type="button" class="wxHd${o?" on":""}" data-tg="${key}">${o?"▾ پنهان کردن":"▸ تغییر"} ${title}</button>${o?`<div class="wxBody">${body}</div>`:""}</div>`; }
function wxMirror(id){ const s=$(id); return `<select class="wxSel" data-mirror="${id}">${s.innerHTML}</select>`; }
function wxModelChips(){ const ms=nvModelsOf(NV.s.tc); return ms.map(([k,o])=>wxChip(o.short||o.name||o.fa||k,k===NV.s.m,`data-m="${k}"`)).join("")||'<span class="hint">مدلی موجود نیست</span>'; }
function nvWx(){
  const box=$("nvWx"); if(!box||!ON.man) return;
  const tools=`<div class="wxTools"><button type="button" class="wxTb" data-act="reload" title="به‌روزرسانی فهرست">↻</button><button type="button" class="wxTb" data-act="home" title="بازگشت به منطقهٔ انتخابی">📍</button><button type="button" class="wxTb" data-act="zoom" title="بزرگ‌نمایی">🔍</button><button type="button" class="wxTb${NV.s.city?" on":""}" data-act="city" title="نام شهرها">${NV.s.city?"شهر":"<s>شهر</s>"}</button><button type="button" class="wxTb info" data-act="info" title="اطلاعات مدل">ℹ</button></div><div class="hint wxInfo" id="wxInfo" hidden></div>`;
  // منطقه
  const regs=nvRegions(); const quick=regs.slice(0,2);
  const reg=`<div class="wxRow">${quick.map(r=>wxChip(r[1],NV.s.reg===r[0],`data-reg="${r[0]}"`)).join("")}</div><label class="wxLb">استان‌ها${wxMirror("nvReg")}</label>
    <div class="wxRow">${[["brd","مرزها"],["cnty","مرز شهرستان‌ها"]].map(([k,t])=>wxChip(t,!!NV.s[k],`data-tgl="${k}"`)).join("")}</div>`;
  // پارامتر
  let par="";
  const cats=((ON.man.cats)||[]).slice().sort((a,b)=>a.o-b.o), ps=NV.s.m?nvParamsOf(NV.s.m):[];
  const tabs=[["used","پرکاربرد"],["all","همه"],["info","اطلاعات مدل"]].map(([k,t])=>wxChip(t,NVW.ptab===k,`data-ptab="${k}"`)).join("");
  if(NVW.ptab==="info") par=`<div class="hint">${$("nvInfo").textContent||"—"}</div>`;
  else if(NVW.ptab==="all") par=cats.filter(c=>ps.some(p=>p.cat===c.id)).map(c=>`<div class="wxCat">${c.fa}</div><div class="wxRow">${ps.filter(p=>p.cat===c.id).sort((a,b)=>a.o-b.o).map(p=>wxChip(p.fa,NV.s.p===p.id,`data-p="${p.id}" data-c="${p.cat}"`)).join("")}</div>`).join("");
  else { let u=ps.filter(p=>NVW_USED.includes(p.id)); if(!u.length) u=ps.slice(0,14); par=`<div class="hint">پارامترهایی که بیشتر استفاده می‌شوند؛ بقیه در زبانهٔ «همه».</div><div class="wxRow">${u.map(p=>wxChip(p.fa,NV.s.p===p.id,`data-p="${p.id}" data-c="${p.cat}"`)).join("")}</div>`; }
  par=`<div class="wxRow tabs">${tabs}</div>`+par;
  // مدل و ران
  const tcs=NV_TC.map(([k,t])=>wxChip(t.split(" ")[0],NV.s.tc===k,`data-tc="${k}"`,!nvModelsOf(k).length)).join("");
  const run=ON.man.models&&ON.man.models[NV.s.m];
  const mod=`<div class="wxRow tabs">${tcs}</div><div class="wxCat">مدل</div><div class="wxRow">${wxModelChips()}</div><div class="wxCat">اجرای مدل (Run)</div><div class="wxRow">${run?wxChip(onFmtRun(run.run)+(run.status==="complete"?"":" (در حال ساخت)"),true,"disabled"):"—"}</div>`;
  // زمان
  const it=NV.items||[], sv=it.map(i=>i.s).filter(x=>x>=0);
  const ivs=[0,1,3,6,12,24].filter(n=>n===0||sv.some(x=>x%n===0&&x>0)).map(n=>wxChip(n?`${wxFA(n)} ساعته`:"همه",NVW.ivl===n,`data-ivl="${n}"`)).join("");
  const fl=it.filter(i=>!NVW.ivl||i.s<0||i.s%NVW.ivl===0);
  const LONG=nvIsLong(), frs=fl.map(i=>wxChip(LONG?nvMonthLab(i.v):i.s>=0?"+"+wxFA(String(i.s).padStart(3,"0")):nvFrLab(i),i.v===NV.s.fr,`data-fr="${i.v}"`)).join("");
  const time=`<div class="wxNav"><button type="button" class="wxArr" data-act="prev">◀</button>${wxMirror("nvFr")}<button type="button" class="wxArr" data-act="next">▶</button></div>${LONG?"":`<div class="wxCat">بازهٔ نمایش ساعت‌ها</div><div class="wxRow">${ivs}</div>`}<div class="wxCat">${LONG?(nvSpan()>1?"بازهٔ ۳ ماهه":"ماه پیش‌بینی"):"ساعت پیش‌بینی"}</div><div class="wxRow fr">${frs}</div>`;
  box.innerHTML=tools+wxSec("reg","نقشه و منطقه",reg)+wxSec("par","پارامتر",par)+wxSec("mod","مدل و ران",mod)+wxSec("time",nvIsLong()?"ماه پیش‌بینی":"تاریخ و ساعت پیش‌بینی",time);
  box.querySelectorAll("select[data-mirror]").forEach(m=>{ m.value=$(m.dataset.mirror).value; });
  const bar=$("nvBar"); if(bar) bar.innerHTML=wxModelChips();
}
function wxSet(id,v){ const s=$(id); if(!s) return; s.value=v; if(s.onchange) s.onchange(); }
function nvWxBind(){
  const box=$("nvWx"); if(!box||box.__bound) return; box.__bound=1;
  const bar=$("nvBar");
  const pickModel=k=>{ NV.s.m=k; $("nvM").value=k; nvFillRun(); };
  const click=e=>{ const b=e.target.closest("button"); if(!b||b.disabled) return; const d=b.dataset;
    if(d.tg){ NVW.open[d.tg]=!NVW.open[d.tg]; return nvWx(); }
    if(d.reg){ wxSet("nvReg",d.reg); return; }
    if(d.tgl){ NV.s[d.tgl]=!NV.s[d.tgl]; const cb=$(d.tgl==="brd"?"nvBrd":"nvCnty"); cb.checked=!!NV.s[d.tgl]; nvSave(); nvDraw(); return nvWx(); }
    if(d.ptab){ NVW.ptab=d.ptab; return nvWx(); }
    if(d.p){ NV.s.cat=d.c; NV.s.p=d.p; nvFillCat(); return; }
    if(d.tc){ NV.s.tc=d.tc; $("nvTc").value=d.tc; nvFillModels(); return; }
    if(d.m){ pickModel(d.m); return; }
    if(d.ivl!==undefined){ NVW.ivl=+d.ivl; return nvWx(); }
    if(d.fr){ wxSet("nvFr",d.fr); return; }
    if(d.act==="prev") return $("nvPrev").click(); if(d.act==="next") return $("nvNext").click();
    if(d.act==="reload") return $("onReload").click(); if(d.act==="home") return $("nvZr").click(); if(d.act==="zoom") return nvZoom(1.5);
    if(d.act==="city"){ NV.s.city=!NV.s.city; $("nvCity").checked=NV.s.city; nvSave(); nvDraw(); return nvWx(); }
    if(d.act==="info"){ const i=$("wxInfo"); i.hidden=!i.hidden; i.textContent=$("nvInfo").textContent+" — "+($("nvRunInfo").textContent||""); } };
  box.addEventListener("click",click);
  box.addEventListener("change",e=>{ const m=e.target.dataset&&e.target.dataset.mirror; if(m) wxSet(m,e.target.value); });
  if(bar) bar.addEventListener("click",e=>{ const b=e.target.closest("button[data-m]"); if(b) pickModel(b.dataset.m); });
}
