/* ---------- قالب weather.us: ۷۶۰×۷۶۰ بدون مرز ---------- */
function renderWU(opts){
  const {field, kind, title, info1, info2, S} = opts, sc=opts.scale||1;
  const cv=document.createElement("canvas"); cv.width=P.W*sc; cv.height=P.H*sc;
  const ctx=cv.getContext("2d"); ctx.scale(sc,sc); ctx.imageSmoothingQuality="high";
  ctx.fillStyle="#fff"; ctx.fillRect(0,0,P.W,P.H);
  // کادر داده
  const pc=SCH().colors.map(hexRGB), W1=[255,255,255];
  const colorOf = opts.colorFn || (kind==="prob" ? (v=>{ const c=SCH().cls(v); return c<0 ? W1 : pc[c]; }) : (v=>PAL[classOf(v)]));
  if(sc===1){ const img=ctx.createImageData(FW,FH);
    for(let i=0;i<N;i++){ const rgb=colorOf(field[i]); img.data[i*4]=rgb[0]; img.data[i*4+1]=rgb[1]; img.data[i*4+2]=rgb[2]; img.data[i*4+3]=255; }
    ctx.putImageData(img, P.fx0, P.fy0); }
  else { ctx.imageSmoothingEnabled=false; ctx.drawImage(hiField(field, colorOf, sc), P.fx0, P.fy0, FW, FH); ctx.imageSmoothingEnabled=true; }   // بدون ترکیب رنگ‌ها
  if(opts.overlay){ ctx.save(); ctx.beginPath(); ctx.rect(P.fx0,P.fy0,FW,FH); ctx.clip(); drawOv(ctx, opts.overlay, P.W, P.H); ctx.restore(); }
  else if(S.showBorders!==false && typeof brdMode==="function" && brdMode()==="src"){ const so=wuSrcOv(opts.models); if(so){ ctx.save(); ctx.beginPath(); ctx.rect(P.fx0,P.fy0,FW,FH); ctx.clip(); ctx.imageSmoothingEnabled=false; ctx.drawImage(so,0,0,P.W,P.H); ctx.restore(); } }
  ctx.fillStyle="#000";
  ctx.fillRect(0,0,P.W,P.fy0); ctx.fillRect(0,P.fy1+1,P.W,3); ctx.fillRect(0,0,P.fx0,P.fy1+4); ctx.fillRect(P.fx1+1,0,P.W-P.fx1-1,P.fy1+4);

  const R=742, L=18;
  // عنوان (راست) و بازهٔ زمانی (چپ)
  ctx.font=`15px ${FT.body}`; const dw = Math.max(ctx.measureText(S.from).width, ctx.measureText(S.to).width);
  txt(ctx, title, R, 653, `21px ${FT.titr}`, {maxW: R-L-dw-24});
  txt(ctx, S.from, L, 643, `15px ${FT.body}`, {align:"left", color:"#222"});
  txt(ctx, S.to,   L, 661, `15px ${FT.body}`, {align:"left", color:"#222"});

  // نوار رنگ
  const by0=671, bh=18, bx0=30, bx1=742;
  ctx.lineWidth=1; ctx.strokeStyle="#000";
  if(kind==="prob"){
    const cols=["#ffffff",...SCH().colors], labs=SCH().labs;
    const w=(bx1-bx0+12)/cols.length;
    cols.forEach((c,i)=>{ const x=bx0-12+i*w; ctx.fillStyle=c; ctx.fillRect(x,by0,w,bh); ctx.strokeRect(x+.5,by0+.5,w,bh);
      txt(ctx, labs[i], x+w/2, by0+bh+18, `16px ${FT.body}`, {align:"center"}); });
  } else {
    const kmax = Math.max(1, classOf(opts.max));
    const n=kmax, w=(bx1-bx0)/n;
    // مثلث «کمتر از ۰٫۱»
    ctx.beginPath(); ctx.moveTo(4,by0+bh/2); ctx.lineTo(bx0,by0); ctx.lineTo(bx0,by0+bh); ctx.closePath();
    ctx.fillStyle="rgb(240,240,240)"; ctx.fill(); ctx.stroke();
    for(let c=1;c<=kmax;c++){ const x=bx0+(c-1)*w, p=PAL[c]; ctx.fillStyle=`rgb(${p})`; ctx.fillRect(x,by0,w,bh); }
    ctx.strokeRect(bx0+.5,by0+.5,bx1-bx0,bh);
    for(let c=2;c<=kmax;c++){ const x=Math.round(bx0+(c-1)*w)+.5; ctx.beginPath(); ctx.moveTo(x,by0); ctx.lineTo(x,by0+bh); ctx.strokeStyle="rgba(0,0,0,.25)"; ctx.stroke(); }
    ctx.strokeStyle="#000";
    const fs = n>20 ? 13 : (n>14 ? 14.5 : 16);
    let lastX=-99;
    for(let c=1;c<=kmax+1;c++){
      const v = EDGES[c]; if(!isFinite(v)) continue;
      const x=bx0+(c-1)*w; const s=FA(v);
      ctx.font=`${fs}px ${FT.body}`; const tw=ctx.measureText(s).width;
      if(x-tw/2 < lastX+3 && c!==kmax+1) continue;
      txt(ctx, s, Math.min(x, P.W-6-tw/2), by0+bh+17, `${fs}px ${FT.body}`, {align:"center", dir:"ltr"}); lastX=x+tw/2;
      ctx.beginPath(); ctx.moveTo(Math.round(x)+.5,by0+bh); ctx.lineTo(Math.round(x)+.5,by0+bh+3); ctx.stroke();
    }
  }

  // پایین: اطلاعات (چپ) و لوگو (راست، جای پرچم)
  txt(ctx, info1, L, 731, `16px ${FT.body}`, {align:"left", color:"#111", maxW:470});
  txt(ctx, info2, L, 751, `14px ${FT.body}`, {align:"left", color:"#333", maxW:470});
  const lx0=520, ly0=714, lw=R-lx0, lh=42;
  drawBrand(ctx, S, lx0, ly0-4, lw, lh+6, {side:true, align:"right", fs:14});
  return cv;
}

/* ------------------------- خروجی CSV و NetCDF ------------------------- */
function toCSV(field, name){
  if(P.custom && !P.geo){
    const parts=[`y,x,${name}\n`], row=[];
    for(let y=0;y<FH;y++){ row.length=0; for(let x=0;x<FW;x++) row.push(y+","+x+","+(+field[y*FW+x].toFixed(2))); parts.push(row.join("\n")+"\n"); }
    return new Blob(parts, {type:"text/csv"});
  }
  const parts=[`lat,lon,${name}\n`], row=[];
  for(let y=0;y<FH;y++){
    const la=latOf(y+P.fy0).toFixed(4); row.length=0;
    for(let x=0;x<FW;x++) row.push(la+","+lonOf(x+P.fx0).toFixed(4)+","+(+field[y*FW+x].toFixed(2)));
    parts.push(row.join("\n")+"\n");
  }
  return new Blob(parts, {type:"text/csv"});
}
// NetCDF-3 کلاسیک (CDF-1)، big-endian؛ lat صعودی
function toNetCDF(field, vname, units, longName, attrs){
  const enc = new TextEncoder(), chunks=[]; let len=0;
  const pad4 = n => (4 - n%4) % 4;
  const i32 = v => { const b=new DataView(new ArrayBuffer(4)); b.setInt32(0,v); push(new Uint8Array(b.buffer)); };
  const push = u => { chunks.push(u); len+=u.length; };
  const name = s => { const b=enc.encode(s); i32(b.length); push(b); push(new Uint8Array(pad4(b.length))); };
  const attText = (k,v) => { name(k); i32(2); const b=enc.encode(v); i32(b.length); push(b); push(new Uint8Array(pad4(b.length))); };
  const attList = list => { if(!list.length){ i32(0); i32(0); return; } i32(12); i32(list.length); list.forEach(([k,v])=>attText(k,v)); };
  const lats = new Float64Array(FH), lons = new Float64Array(FW), pix = P.custom && !P.geo;
  for(let j=0;j<FH;j++) lats[j] = pix ? j : latOf(P.fy1 - j);
  for(let i=0;i<FW;i++) lons[i] = pix ? i : lonOf(P.fx0 + i);
  const dn = pix ? ["y","x"] : ["lat","lon"];
  // سرآیند
  push(enc.encode("CDF")); push(new Uint8Array([1])); i32(0);
  i32(10); i32(2); name(dn[0]); i32(FH); name(dn[1]); i32(FW);
  attList(attrs);
  i32(11); i32(3);
  const vars = [
    {n:dn[0], dims:[0], type:6, size:FH*8, atts: pix ? [["units","pixel"],["long_name","row from bottom of map frame"]] : [["units","degrees_north"],["standard_name","latitude"]]},
    {n:dn[1], dims:[1], type:6, size:FW*8, atts: pix ? [["units","pixel"],["long_name","column from left of map frame"]] : [["units","degrees_east"],["standard_name","longitude"]]},
    {n:vname, dims:[0,1], type:5, size:N*4, atts:[["units",units],["long_name",longName]]}
  ];
  const beginPos = [];
  for(const v of vars){ name(v.n); i32(v.dims.length); v.dims.forEach(d=>i32(d)); attList(v.atts); i32(v.type); i32(v.size); beginPos.push(chunks.length); i32(0); }
  let off = len;
  vars.forEach((v,k)=>{ const b=new DataView(new ArrayBuffer(4)); b.setInt32(0,off); chunks[beginPos[k]] = new Uint8Array(b.buffer); off += v.size; });
  const dLat=new DataView(new ArrayBuffer(FH*8)); lats.forEach((v,i)=>dLat.setFloat64(i*8,v)); push(new Uint8Array(dLat.buffer));
  const dLon=new DataView(new ArrayBuffer(FW*8)); lons.forEach((v,i)=>dLon.setFloat64(i*8,v)); push(new Uint8Array(dLon.buffer));
  const dv=new DataView(new ArrayBuffer(N*4));
  for(let j=0;j<FH;j++){ const y=FH-1-j; for(let i=0;i<FW;i++) dv.setFloat32((j*FW+i)*4, field[y*FW+i]); }
  push(new Uint8Array(dv.buffer));
  return new Blob(chunks, {type:"application/x-netcdf"});
}

/* ------------------------- وضعیت برنامه و رابط ------------------------- */
const state = { models:[], logoImg:null, busy:false, pending:null, urls:[], w:{}, cards:{}, order:[] };
const inputs = ["t0","t1","initD","initH","region","thr","sigma","nep","cap","barMode","borders","gridLines","gOff"];
inputs.forEach(id=>{ const v=store.get(id,null); if(v!==null) $(id).value=v; });
const savedW = store.get("wpct", {});

function ribbon(el, pal){ el.replaceChildren(...pal.slice(1).map(c=>{ const i=document.createElement("i"); i.style.background=`rgb(${c})`; return i; })); }
ribbon($("ribbon"), WB_PAL);
document.querySelectorAll(".ch-rib").forEach(el=>{
  if(el.dataset.pal==="wn"){ el.replaceChildren(...["#ffffff","#fff8b0","#ffde00","#d6ac00","#ffd6a8","#ff8c00","#c85c00","#ffb0b0","#e81414","#800000"].flatMap(c=>[0,1,2].map(()=>{ const i=document.createElement("i"); i.style.background=c; return i; }))); }
  else if(el.dataset.pal==="lt"){ el.replaceChildren(...["#9e9e9e","#1e90ff","#ffd400","#ff8c00","#ff0000"].flatMap(c=>[0,1,2,3,4,5].map(()=>{ const i=document.createElement("i"); i.style.background=c; return i; }))); }
  else if(el.dataset.pal==="cv"){ el.replaceChildren(...["#ffffff","#3f8ee8","#ffe128","#ff8c14","#d7191c","#ff69b4"].flatMap(c=>[0,1,2,3,4].map(()=>{ const i=document.createElement("i"); i.style.background=c; return i; }))); }
  else if(el.dataset.pal==="dem"){ const A=[[244,239,230],[217,199,167],[169,138,95],[109,82,48],[58,42,23]]; el.replaceChildren(...Array.from({length:30},(_,k)=>{ const i=document.createElement("i"); const u=k/29*4, j=Math.min(3,Math.floor(u)), f=u-j; i.style.background=`rgb(${A[j].map((v,q)=>Math.round(v+(A[j+1][q]-v)*f))})`; return i; })); }
  else if(el.dataset.pal==="cu"){ el.replaceChildren(...Array.from({length:30},(_,k)=>{ const i=document.createElement("i"); i.style.background=`hsl(${210-k*10},${k%3?75:55}%,${55-k/3}%)`; return i; })); }
  else if(el.dataset.pal==="cqc"){ el.replaceChildren(...Array.from({length:30},(_,k)=>{ const i=document.createElement("i"); i.style.background=`hsl(${205-k*2},${45+k}%,${38+k/3}%)`; return i; })); }
  else if(el.dataset.pal==="ds"){ const A=["#2c7bb6","#00a6ca","#00ccbc","#90eb9d","#ffff8c","#f9d057","#f29e2e","#e76818","#d7191c"]; el.replaceChildren(...A.flatMap(c=>[0,1,2].map(()=>{ const i=document.createElement("i"); i.style.background=c; return i; }))); }
  else if(PROFILES[el.dataset.pal]) ribbon(el, PROFILES[el.dataset.pal].pal);
});

