/* ------------------------- ترکیب مدل‌ها ------------------------- */
function combine(models, kind){
  const out = new Float32Array(N), W = models.reduce((a,m)=>a+m.weight,0);
  // مدلی که این پیکسل را فقط «حدس» زده (دور از دادهٔ واقعی خودش؛ m.far) کنار گذاشته می‌شود، مگر همهٔ مدل‌ها حدسی باشند
  if(!models.some(m=>m.far)){
    if(kind==="mean"){ for(const m of models){ const w=m.weight/W, a=m.mm; for(let i=0;i<N;i++) out[i]+=w*a[i]; } }
    else if(kind==="max"){ out.fill(-Infinity); for(const m of models){ const a=m.mm; for(let i=0;i<N;i++) if(a[i]>out[i]) out[i]=a[i]; } }
    else { out.fill(Infinity); for(const m of models){ const a=m.mm; for(let i=0;i<N;i++) if(a[i]<out[i]) out[i]=a[i]; } }
    return out;
  }
  const n=models.length;
  for(let i=0;i<N;i++){
    let any=false; for(let k=0;k<n;k++){ const f=models[k].far; if(!f||!f[i]){ any=true; break; } }
    let s=0, w=0, mx=-Infinity, mn=Infinity;
    for(let k=0;k<n;k++){ const m=models[k]; if(any && m.far && m.far[i]) continue; const v=m.mm[i];
      s+=m.weight*v; w+=m.weight; if(v>mx) mx=v; if(v<mn) mn=v; }
    out[i] = kind==="mean" ? (w? s/w : 0) : kind==="max" ? mx : mn;
  }
  return out;
}
function gauss(src, sigma){
  const r = Math.max(1, Math.floor(4*sigma+0.5)), k=[]; let s=0;
  for(let i=-r;i<=r;i++){ const w=Math.exp(-0.5*(i/sigma)**2); k.push(w); s+=w; }
  for(let i=0;i<k.length;i++) k[i]/=s;
  const refl=(j,n)=> j<0 ? -j-1 : (j>=n ? 2*n-j-1 : j);
  const tmp=new Float32Array(N), out=new Float32Array(N);
  for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ let a=0; for(let t=-r;t<=r;t++) a+=k[t+r]*src[y*FW+refl(x+t,FW)]; tmp[y*FW+x]=a; }
  for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ let a=0; for(let t=-r;t<=r;t++) a+=k[t+r]*tmp[refl(y+t,FH)*FW+x]; out[y*FW+x]=a; }
  return out;
}
// ریسک یخبندان: ۰ بدون ریسک، ۱ کم، ۲ متوسط، ۳ زیاد، ۴ خیلی زیاد؛ از دمای میانگین وزنی و درصد مدل‌هایی که دما را ≤ ۰ می‌بینند
function frostRisk(models, off){
  const W=models.reduce((a,m)=>a+m.weight,0)||1, out=new Float32Array(N);
  for(let i=0;i<N;i++){ let mean=0, p0=0; for(const m of models){ const v=m.mm[i]-off, w=m.weight/W; mean+=w*v; if(v<=0) p0+=w; }
    out[i] = (mean<=-2 || (p0>=0.75 && mean<=0)) ? 4 : (mean<=0 || p0>=0.5) ? 3 : (mean<=2 || p0>=0.25) ? 2 : (mean<=4 || p0>0) ? 1 : 0; }
  return out;
}
const FROST_SCHEME={colors:["#a9d4ff","#1f3fae","#7b2cbf","#dcb8ff"], cls:v=>v<0.5?-1:Math.min(3,Math.round(v)-1), labs:["بدون ریسک","کم","متوسط","زیاد","خیلی زیاد"], title:"ریسک یخبندان",
  maxTxt:v=>`بیشترین ریسک: ${["بدون ریسک","کم","متوسط","زیاد","خیلی زیاد"][Math.max(0,Math.min(4,Math.round(v)))]}`};
// همان منطق agreement_probability اسکریپت پایتون، روی شبکهٔ پیکسلی خودِ نقشه‌ها
function agreement(models, thr, sigma, nep=0){
  const W = models.reduce((a,m)=>a+m.weight,0), raw = new Float32Array(N);
  // احتمال همسایگی: سهم پیکسل‌های بالای آستانهٔ هر مدل در همسایگی گاوسی هر نقطه (Schwartz & Sobash 2017)
  const ns = nep>0 ? Math.max(1.5, nep*Math.max(FW,FH)) : 0;
  const anyFar=models.some(m=>m.far), wsum=anyFar?new Float32Array(N):null;
  for(const m of models){ let h=hitField(m,thr);
    if(ns){ const key="nep:"+thr+"@"+ns.toFixed(2); h = m.hit[key] || (m.hit[key]=gauss(h, ns)); }
    const w=m.weight/W*100;
    if(!anyFar){ for(let i=0;i<N;i++) raw[i]+=w*h[i]; }
    else { const f=m.far; for(let i=0;i<N;i++){ if(f&&f[i]) continue; raw[i]+=w*h[i]; wsum[i]+=w; } } }
  // پیکسل‌هایی که بعضی مدل‌ها فقط حدس زده‌اند: سهم بر مدل‌های دارای دادهٔ واقعی تقسیم می‌شود (اگر هیچ‌کدام نبود، همه)
  if(anyFar){ let fb=null; for(let i=0;i<N;i++){ const s=wsum[i]; if(s>=99.99) continue; if(s>0.01) raw[i]*=100/s; else { if(!fb){ fb=new Float32Array(N); for(const m of models){ const h=hitField(m,thr), w=m.weight/W*100; for(let j=0;j<N;j++) fb[j]+=w*h[j]; } } raw[i]=fb[i]; } } }
  let p = raw;
  if(ns){ p = sigma>0 ? gauss(raw, sigma) : Float32Array.from(raw); }
  else if(sigma>0){
    p = gauss(raw, sigma);
    let near = new Uint8Array(N); for(let i=0;i<N;i++) near[i] = raw[i]>0.01 ? 1 : 0;
    const it = Math.max(1, Math.round(sigma*1.5));
    for(let k=0;k<it;k++){
      const nn = Uint8Array.from(near);
      for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x; if(near[i]) continue;
        if((x>0&&near[i-1])||(x<FW-1&&near[i+1])||(y>0&&near[i-FW])||(y<FH-1&&near[i+FW])) nn[i]=1; }
      near = nn;
    }
    for(let i=0;i<N;i++) if(!near[i]) p[i]=0;
  } else p = Float32Array.from(raw);
  for(let i=0;i<N;i++){ if(p[i]>PROB_MAX) p[i]=PROB_MAX; if(p[i]<ZERO_BELOW) p[i]=0; }
  return p;
}
const classOf = v => { if(!(v>=EDGES[1])) return 0; let c=1; while(c<NC-1 && v>=EDGES[c+1]) c++; return c; };
const PROB_SCHEME = {colors:PROB_COLORS, cls:v=>probClass(v), labs:["۰",...PROB_EDGES.slice(0,-1).map((a,i)=>`${FA(a+1)} تا ${FA(PROB_EDGES[i+1])}`)], title:"احتمال (درصد)", maxTxt:v=>`بیشینهٔ احتمال: ${FA(Math.round(v))}٪`};
let CUR_SCHEME = null; const SCH = () => CUR_SCHEME || PROB_SCHEME;
function probClass(v){ if(!(v>=ZERO_BELOW)) return -1; for(let k=1;k<PROB_EDGES.length;k++) if(v<=PROB_EDGES[k]+1e-6) return k-1; return PROB_COLORS.length-1; }
function stats(f){
  let mx=-Infinity, s=0, wet=0; for(let i=0;i<N;i++){ if(!SM[i]) continue; const v=f[i]; if(v>mx) mx=v; s+=v; if(v>=EDGES[1]) wet++; }
  return {max:mx, mean:s/NS, wet:wet/NS};
}

/* ------------------------- رسم نقشهٔ نهایی ------------------------- */
const FT = { titr:'"Titr","Ketab",sans-serif', body:'"Ketab","Lalezar",sans-serif', lal:'"Lalezar","Ketab",sans-serif', nas:'"Nastaliq","Ketab",serif' };
// عبارت‌های ریاضی (≤ −۲، ≥ +۱σ، < ۰٫۰۵ …) در متن راست‌به‌چپ جدا و چپ‌به‌راست نگه داشته می‌شوند تا علامت آینه‌ای و جای منفی جابه‌جا نشود
const BIDI_NUM="([−\\-+]?\\s?[0-9۰-۹][0-9۰-۹٫.,]*(?:\\s?σ)?)";
const BIDI_RULES=[[new RegExp("≤\\s*"+BIDI_NUM,"g")," $1 و کمتر"],[new RegExp("≥\\s*"+BIDI_NUM,"g")," $1 و بیشتر"],[new RegExp("<\\s*"+BIDI_NUM,"g")," کمتر از $1"],[new RegExp(">\\s*"+BIDI_NUM,"g")," بیشتر از $1"]];
function bidiMath(s){ if(typeof s!=="string" || !/[؀-ۿ]/.test(s)) return s; for(const [re,r] of BIDI_RULES) s=s.replace(re,r); return s.replace(/ {2,}/g," ").replace(/\( /g,"("); }
function txt(ctx, s, x, y, font, {color="#000", align="right", base="alphabetic", maxW, dir="rtl"}={}){
  if(dir==="rtl") s=bidiMath(s);
  ctx.font=font; ctx.fillStyle=color; ctx.textAlign=align; ctx.textBaseline=base; ctx.direction=dir;
  if(maxW){ let sz=parseFloat(/(\d+(\.\d+)?)px/.exec(font)[1]); while(ctx.measureText(s).width>maxW && sz>8){ sz-=0.5; ctx.font=font.replace(/\d+(\.\d+)?px/, sz+"px"); } }
  ctx.fillText(s, x, y);
}
function hexRGB(h){ return [1,3,5].map(i=>parseInt(h.slice(i,i+2),16)); }
function txtHalo(ctx, s, x, y, font, o={}){
  ctx.save(); ctx.font=font; ctx.textAlign=o.align||"left"; ctx.textBaseline="alphabetic"; ctx.direction=o.dir||"rtl";
  ctx.lineJoin="round"; ctx.lineWidth=Math.max(1.2,(o.halo||4)*0.5); ctx.strokeStyle="rgba(255,255,255,.82)"; ctx.strokeText(s,x,y);
  ctx.fillStyle=o.color||"#000"; ctx.fillText(s,x,y); ctx.restore();
}
// لوگوی ثابت سایت + نشانی زیر/کنار آن، روی همهٔ نقشه‌ها
{{BLOB:logo_src}}
function drawBrand(ctx, S, x, y, w, h, o={}){
  const im=S.logoImg, url=SITE_URL, fs=o.fs||12;
  if(!im || !im.width){ (o.halo?txtHalo:txt)(ctx, url, o.align==="right"?x+w:x, y+h-4, `bold ${fs+4}px ${FT.lal}`, o.halo?{color:"#0a3d8f", halo:4, dir:"ltr", align:o.align||"left"}:{color:"#0a3d8f", dir:"ltr", align:o.align||"left"}); return; }
  ctx.save(); ctx.font=`bold ${fs}px ${FT.lal}`; ctx.direction="ltr"; const uw=ctx.measureText(url).width; ctx.restore();
  if(o.side){ // نشانی کنار لوگو (برای نوار پایین)
    const s=Math.min(h/im.height, (w-uw-8)/im.width), lw=im.width*s, lh=im.height*s, ly=y+(h-lh)/2;
    const lx = o.align==="right" ? x+w-lw : x; ctx.drawImage(im, lx, ly, lw, lh);
    const ux = o.align==="right" ? lx-6 : lx+lw+6;
    txt(ctx, url, ux, y+h/2+fs*0.36, `bold ${fs}px ${FT.lal}`, {color:"#0a3d8f", dir:"ltr", align:o.align==="right"?"right":"left"});
    return; }
  const ih=h-fs-3, s=Math.min(ih/im.height, w/im.width), lw=im.width*s, lh=im.height*s;
  const lx = o.align==="right" ? x+w-lw : x; ctx.drawImage(im, lx, y+ih-lh, lw, lh);
  const cx=lx+lw/2; (o.halo?txtHalo:txt)(ctx, url, cx, y+h-1, `bold ${fs}px ${FT.lal}`, o.halo?{color:"#0a3d8f", halo:3, dir:"ltr", align:"center"}:{color:"#0a3d8f", dir:"ltr", align:"center"});
}
function renderMap(opts){
  if(opts.overlay===undefined && !opts.noOverlay && isWUsize()) opts={...opts, overlay: wuOverlay(opts.zoom)};
  const cv = P.key==="wb" ? renderWB(opts) : (P.custom ? renderCU(opts) : renderWU(opts));
  if(opts.icons && typeof hzRender==="function") try{ hzRender(cv, opts.icons, opts.iconLegend); }catch(e){ console.warn("icons",e); }
  cv.__re={prof:P.key, sch:CUR_SCHEME, opts, pal:PAL, tt:!!(P.T&&P.T.tt&&P.T.tt.geo)}; return cv;
}
const isWUsize=()=>P && P.W===760 && P.H===760 && P.key!=="wb";
// زوم‌های weather.us با مرزبندی اختصاصی (PNG شفاف هم‌اندازهٔ کل تصویر ۷۶۰×۷۶۰)
{{BLOB:wu_zoom_overlays}}
// نقشهٔ راه‌های ایران هم‌تراز با نقشه‌های WeatherBELL (لایهٔ اختیاری روی مرزها)
const WB_ROADS_IMG=new Image();   // نقشهٔ راه‌ها فعلاً حذف شده است
// نقشهٔ راه‌ها با رنگ‌های گسسته (بدون رنگ واسطه): بدون درون‌یابی رسم می‌شود و برای نمایش ۱ برابر نسخهٔ ۷۶۰ پیکسلی همان به کار می‌رود
const WU_ROADS_S=new Image();
function drawOv(ctx, img, w, h){
  if(img===WU_ZOOM_IMG[WU_ROADS_KEY]){ const sc=ctx.getTransform().a; const im=(sc<1.5 && WU_ROADS_S.complete && WU_ROADS_S.naturalWidth)?WU_ROADS_S:img;
    ctx.save(); ctx.imageSmoothingEnabled=false; ctx.drawImage(im,0,0,w,h); ctx.restore(); return; }
  ctx.drawImage(img,0,0,w,h); }
function wbBorders(){ const v=store.get("wb.borders", ($("borders")&&$("borders").value)||"bold"); return v==="roads"?"bold":v; }
for(const k in WU_ZOOMS){ const im=new Image(); im.src=WU_ZOOMS[k]; WU_ZOOM_IMG[k]=im; }
const WUZ={ get auto(){ const v=$("regionSel")&&$("regionSel").value; return WU_ZOOMS[v]?v:null; }, autoCv:null, autoWn:null, get on(){ return store.get("wuz.on", true); }, get sel(){ return store.get("wuz.sel", "auto"); } };
function wuZoomName(z){ const sel=WUZ.sel; if(sel && sel!=="auto") return sel; return z || WUZ.auto || null; }
function wuOverlay(z){ if(!WUZ.on) return null; const n=wuZoomName(z); const im=n&&WU_ZOOM_IMG[n]; return im && im.complete && im.naturalWidth ? im : null; }
async function wuZoomsReady(){ await Promise.all(Object.values(WU_ZOOM_IMG).map(im=>im.decode().catch(()=>{}))); }
// رنگ پیکسل بالا-دقت: نمونه‌برداری دوخطی از میدان و سپس رده‌بندی رنگ
// مرز رنگ‌ها با دقت تا ۵ برابر محاسبه می‌شود؛ بزرگ‌تر از آن با نزدیک‌ترین پیکسل بزرگ می‌شود (رنگ‌ها گسسته می‌مانند و ذخیرهٔ ۸۰۰۰ پیکسلی چند برابر سریع‌تر است)
function hiField(field, colorOf, s){
  s=Math.min(s,5); s=Math.max(1,Math.round(s));
  const W=FW*s, H=FH*s, c=document.createElement("canvas"); c.width=W; c.height=H; const x=c.getContext("2d"), im=x.createImageData(W,H), d=im.data;
  for(let Y=0;Y<H;Y++){ const fy=Math.min(FH-1,Math.max(0,(Y+0.5)/s-0.5)), y0=Math.floor(fy), y1=Math.min(FH-1,y0+1), ty=fy-y0;
    for(let X=0;X<W;X++){ const fx=Math.min(FW-1,Math.max(0,(X+0.5)/s-0.5)), x0=Math.floor(fx), x1=Math.min(FW-1,x0+1), tx=fx-x0;
      const a=field[y0*FW+x0], b=field[y0*FW+x1], c_=field[y1*FW+x0], e=field[y1*FW+x1]; let v;
      if(a===a&&b===b&&c_===c_&&e===e) v=(a*(1-tx)+b*tx)*(1-ty)+(c_*(1-tx)+e*tx)*ty;
      else v=field[(ty<0.5?y0:y1)*FW+(tx<0.5?x0:x1)];
      const rgb=colorOf(v), q=(Y*W+X)*4; d[q]=rgb[0]; d[q+1]=rgb[1]; d[q+2]=rgb[2]; d[q+3]=255; } }
  x.putImageData(im,0,0); return c;
}
// دانلود PNG: نقشه‌های weather.us با دقت ۴ برابر (۳۰۴۰×۳۰۴۰) و در صورت روشن بودن، با مرزبندی زوم

// ===== مرز پیش‌فرض weather.us: لایهٔ ثابت از خودِ نقشه‌های ورودی =====
// پیکسل‌هایی که در بیشتر نقشه‌های ورودی رنگ داده نیستند (مرز کشور و استان، ساحل، مربع و نام شهرها) با همان رنگ اصلی
let _wuSrcOv=null, _wuSrcKey="";
function wuSrcOv(models){
  models=(models||(typeof state!=="undefined"?state.models:[])).filter(m=>m&&m.ok&&m.data&&m.w===P.W&&m.h===P.H);
  if(!models.length) return null;
  const key=P.key+"|"+models.map(m=>m.file&&m.file.name+":"+m.data.length).join("|"); if(key===_wuSrcKey && _wuSrcOv) return _wuSrcOv;
  const W=P.W, H=P.H, n=models.length, need=n>=2?Math.max(2,Math.ceil(n*0.6)):1, pal=PAL;
  const memo=new Map(), isData=(r,g,b)=>{ const k=(r<<16)|(g<<8)|b; let v=memo.get(k); if(v===undefined){ v=false; for(const p of pal){ if(Math.abs(r-p[0])+Math.abs(g-p[1])+Math.abs(b-p[2])<=24){ v=true; break; } } memo.set(k,v); } return v; };
  const inv=(P.invalid?P.invalid():[]).concat(P.topStrip?[[0,0,W,P.fy0+20]]:[]);
  const c=document.createElement("canvas"); c.width=W; c.height=H; const x=c.getContext("2d"), im=x.createImageData(W,H), o=im.data;
  for(let y=P.fy0;y<=P.fy1;y++) for(let X=P.fx0;X<=P.fx1;X++){
    let skip=false; for(const r of inv) if(X>=r[0]&&X<r[2]&&y>=r[1]&&y<r[3]){ skip=true; break; } if(skip) continue;
    const i=(y*W+X)*4; let cnt=0, R=[], G=[], B=[];
    for(const m of models){ const d=m.data; if(!isData(d[i],d[i+1],d[i+2])){ cnt++; R.push(d[i]); G.push(d[i+1]); B.push(d[i+2]); } }
    if(cnt>=need){ const md=a=>a.sort((p,q)=>p-q)[a.length>>1]; o[i]=md(R); o[i+1]=md(G); o[i+2]=md(B); o[i+3]=255; }
  }
  x.putImageData(im,0,0); _wuSrcOv=c; _wuSrcKey=key; return c;
}
// PNG اصلی مرزهای MetStat (۴۰۰۰ تا ۱۰۰۰۰ پیکسل) روی هاست، در پوشهٔ overlays کنار index.html: خروجی ذخیره‌شده هم‌اندازهٔ همین PNG می‌شود
const WU_OV_HI={"ایران":"wu_iran.png","فارس":"wu_fars.png","خوزستان":"wu_khuzestan.png","هرمزگان":"wu_hormozgan.png","تهران":"wu_tehran.png","گیلان":"wu_gilan.png",
  "آذربایجان‌ها و اردبیل":"wu_azarbaijan.png","شرق فارس":"wu_fars_east.png","شمال فارس":"wu_fars_north.png","شمال‌غرب فارس":"wu_fars_northwest.png","جنوب‌غرب فارس":"wu_fars_southwest.png",
  "جنوب‌شرق فارس":"wu_fars_southeast.png","فارس (با جزئیات، کهگیلویه و بوشهر)":"wu_fars_big.png"};
const _wuHi=new Map();
async function wuHiOverlay(z){
  if(!WUZ.on || !/^https?:/.test(location.protocol) || window.MS_SAFE) return null;
  const n=wuZoomName(z), f=n&&WU_OV_HI[n]; if(!f) return null;
  if(_wuHi.has(f)) return _wuHi.get(f);
  const im=new Image(); im.src="overlays/"+encodeURIComponent(f);
  const ok=await im.decode().then(()=>true).catch(()=>false); const r=ok&&im.naturalWidth>=1000?im:null; _wuHi.set(f,r); return r;
}
async function exportPNG(cv, scale=4){
  if(cv.__lt){ await wuZoomsReady(); const o=cv.__lt, z=(WUZ.sel!=="auto"?WUZ.sel:o.zoom); const big=renderLT({...o, scale, overlay: wuOverlay(z)}); return new Promise(r=>big.toBlob(r,"image/png")); }
  const re=cv.__re;
  // tropicaltidbits: خروجی هم‌اندازهٔ PNG مرزهای خاورمیانه (۳٫۶۶ برابر)
  if(re && re.tt && P && P.custom && P.T && P.T.tt && typeof TT_OV_IMG!=="undefined" && TT_OV_IMG.naturalWidth){ const k=TT_OV_IMG.naturalWidth/P.W; const prevS=CUR_SCHEME; let palS=null;
    try{ CUR_SCHEME=re.sch; if(re.pal){ palS=PAL; PAL=re.pal; } const big=renderCU({...re.opts, scale:Math.min(6,k)}); if(re.opts.icons) hzRender(big, re.opts.icons, re.opts.iconLegend); return await new Promise(r=>big.toBlob(r,"image/png")); }
    catch(e){ console.warn("tt hi-res",e); } finally{ if(palS) PAL=palS; CUR_SCHEME=prevS; } }
  if(!re || !PROFILES[re.prof] || !(PROFILES[re.prof].W===760 && PROFILES[re.prof].H===760)) return new Promise(r=>cv.toBlob(r,"image/png"));
  const prev=P?P.key:null, prevS=CUR_SCHEME; await wuZoomsReady();
  let palS=null;
  let hi=null; try{ hi=await wuHiOverlay(re.opts.zoom); }catch(e){}
  if(hi){ const sMax=8192/760; scale=Math.min(sMax, hi.naturalWidth/760); }
  try{ await useProfile(re.prof); CUR_SCHEME=re.sch; if(re.pal){ palS=PAL; PAL=re.pal; } const o={...re.opts, scale, overlay: hi || wuOverlay(re.opts.zoom)};
    let big; try{ big = P.custom ? renderCU(o) : renderWU(o); }catch(e){ if(scale<=4) throw e; console.warn("big export failed, 4x",e); big = P.custom ? renderCU({...o, scale:4, overlay:wuOverlay(re.opts.zoom)}) : renderWU({...o, scale:4, overlay:wuOverlay(re.opts.zoom)}); }
    if(re.opts.icons) try{ hzRender(big, re.opts.icons, re.opts.iconLegend); }catch(e){}
    return await new Promise(r=>big.toBlob(r,"image/png")); }
  finally{ if(palS) PAL=palS; CUR_SCHEME=prevS; if(prev && PROFILES[prev]) await useProfile(prev); }
}
