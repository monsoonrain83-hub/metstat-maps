/* ===== tropicaltidbits.com: تشخیص قالب (کادر سیاه، نوار رنگ عمودی سمت راست، اعداد با OCR) و زوم خاورمیانه =====
   زوم خاورمیانه: ۲۰ تا ۶۵ درجهٔ شرقی، ۱۲ تا ۴۲ درجهٔ شمالی (از روی خطوط تیک نقشه‌ها). زوم‌های دیگر: کادر و نوار رنگ خوانده می‌شود
   ولی مختصات را کاربر در «قالب نقشه‌ها» وارد می‌کند (برنامه آن را برای همان اثر انگشت به خاطر می‌سپارد). */
const TT_ME_GEO=[20,65,12,42];
const TT_ME_REF="QQGYAcHAAIAOYAy0gIAGH/4wOAPAH8d+gGb8BsAbhyf/AAP/g/9mARgAHwDy9+eAAAAACMQcD8AACAY+P/AAAAAAQwBwQAAAYGF/wAAAAAADmAQDgAABAgw1AAAAAAAH5yAcAAAOGD04AAAAAAB/6QBgAAAY49HgAAAA4Ap+8AOAAABzH54AAIAPgEgHgBQAAAD//HgAAABwBEAMACDgAAH/88AAAACABsAgATzAAAc/3gAAABwAEgGACwPgAA3veAAAAEB/2AcAcAGABHZ98EABDj+OAAYOAAYAIeP/4+H/3zgYAB/wAB4BA4Y98RhxAQBAAAAAABA4DADGB4McCAPAAAAAAIeAGAgAAzBAQA4AAAAABiAA/8AB8IACACAAAAAAfwAD+AAfhAAQAwAAAAADAAAAAABwMAGAEAAAAAAwAAAAAAADwDgggAAAAAGAAAAAAAAcBwGMAAAAAAgAAAAAAAHAYAAwAAAAAGAAAAAAAA4OAADAAAAAAwAPgAAAAPHQAwcAAAAAEAHCAAAAB9iACA4AAAAAwAgeAAAAO4YAABAAAAACAAAeAAADwe4AAMAAAAAQAAA/gPweOBwABgAAAADAEAEHjn/xgDgAIAAAAAMAgAgHgeWGAGAHgAAAAAgAAEAAACgQAYAGwAAAAMAAAgAAIcGABwD3gAAADAAAEAABBjgADAX0AAAAYAAAgAAcIwAAMGwQAAAD/4AEAABh8AAA/2HAAAAMAAAgAAOYAAAADQIAAAAgAAEAAAzAAAAAPBgAAAHAAAgAAHcAAAAAIEAAAAMAAEAAAfwAAAABg8AAAAgAAgAABiAAAAAPAwAAAEAAEAAAIYAAAAAYDA4AAwAAgAAAhgAAAABgPegACAAEAAAEEAAAAAEAf0ADwAAgAAAwwAAAAA8BGgAwAAEAAACGAAAAAHwL3AEAAAgAAAY4AAAAA+AaP8h4AEAAABBAAAAADQCwA/7AAgAAAMIAAAAAeAnAAAAAEAAAAggAAAAB18oAAAAAgAAECDAAAAAD/NgAAAAEAABgQMAAAAAYBDwAAAAgAAMCAgAAAABgYDAAAAEAABgQGAAAAAGCAMAAAAgAA4DgQAAAAAfwAwAAAEAAOAGCAAAAAADACAAAA/////wQAAAAAAIAQAAAEAAQACCAAAAAABAGAAwAgAAAAIQAAAAAAIBgADAEAAAABDAAAAAADAIAAOAgAAAAIIAAAAAAQHAAAcEAAAABBwAAAAACB4AAA7gAAAAIDAAAAABwKAAABwAAAABAMAAAAA4BAAAACAAAAAIAgAAAA8AIAAAAQAAAAAgGAAAD8AHAAAACAAAAAGAQAAPxABgAAAAQAAAAAYDAADAMAIAAAACAAAAABgIAAwAgPAAAAAQAAAAAeBmAMAEDgAAAACAAAAAGQG/9AAQQAAAAAQAAAABiB0A4AC+AAAAACAAAAAYQPgAAA8AAAAAAQAAAADCAIAAAMAAAAAACAAAAAQOBAAABAAAAAADwAAAACBwIAAAYAAAAAAQAAAAAwGDAAAOAAAAAAGAAAAAMQ4IAAPAAAAAABgAAAABv/xAAGAAAAAAAEAAAAAHgfIABgAAAAAABgAAAAAgAtgB4AAAAAAAIAAAAAEAG8D4AAAAAAADAAAAABgAKhwAAAAAAAAYAAAAAIABu4AAAAAAAADgAAAADAAH8AAAPAAAAAEAAABwwAA0AAAPwAAAA";

// ===== مرزهای MetStat روی زوم خاورمیانهٔ tropicaltidbits و «زوم روی ایران» =====
// PNG شفاف کاربر (۳۷۵۰×۲۸۰۵ = ۳٫۶۶ برابر تصویر ۱۰۲۴×۷۶۶)؛ کادر نقشه در آن: x ۳۴…۹۷۰ و y ۴۵…۷۴۶ (برابر خطوط کادر سیاه). همهٔ اندازه‌ها (۷۶۶، ۷۷۲، ۷۵۱) همان ۲۰ تا ۶۵ شرقی و ۱۲ تا ۴۲ شمالی‌اند.
{{BLOB:tt_me_overlay}}
const TT_OV_IMG=new Image(); TT_OV_IMG.src=TT_OV_SRC;
// نمای ایران: نسبت ابعاد همان کادر (۴۵°×۳۰° → ۲۴°×۱۶°)
const TT_IRAN_VIEW=[41,65,24.5,40.5];
function ttZoomSel(){ return store.get("tt.zoom","me"); }
function ttDrawFrame(ctx, field, colorOf, sc, opts, S){
  const T=P.T&&P.T.tt, F=T&&T.frame; if(!T||!T.geo||!F) return false;
  if((S.ttZoom||ttZoomSel())!=="iran") return false;          // زوم خاورمیانه: همان کادر اصلی، بدون PNG مرزها
  const view=TT_IRAN_VIEW, G=T.geo, fw=F.x1-F.x0, fh=F.y1-F.y0, kx=(G[1]-G[0])/(view[1]-view[0]), ky=(G[3]-G[2])/(view[3]-view[2]);
  const xw=F.x0+(view[0]-G[0])/(G[1]-G[0])*fw, yn=F.y0+(G[3]-view[3])/(G[3]-G[2])*fh;
  ctx.save(); ctx.beginPath(); ctx.rect(P.fx0,P.fy0,FW,FH); ctx.clip();
  ctx.translate(F.x0,F.y0); ctx.scale(kx,ky); ctx.translate(-xw,-yn);
  const s2=Math.max(1, Math.min(12, Math.ceil(sc*Math.max(kx,ky))));
  ctx.imageSmoothingEnabled=false; ctx.drawImage(hiField(field,colorOf,s2), P.fx0,P.fy0,FW,FH); ctx.imageSmoothingEnabled=true;   // رنگ‌های گسسته، بدون ترکیب
  // مرزهای خود tropicaltidbits در بزرگ‌نمایی ضخیم و پله‌ای می‌شوند؛ کم‌رنگ زیر مرزهای MetStat
  if(S.showBorders && P.ov){ ctx.globalAlpha = brdMode()==="metstat" ? 0.4 : 0.8; ctx.drawImage(P.ov.bold,0,0); ctx.globalAlpha=1; }
  if(S.showBorders && brdMode()==="metstat" && TT_OV_IMG.complete && TT_OV_IMG.naturalWidth){ const k=TT_OV_IMG.naturalWidth/1024; ctx.drawImage(TT_OV_IMG, 34*k,45*k,936*k,701*k, F.x0,F.y0,fw,fh); }
  ctx.restore(); return true;
}
function setTTZoom(v){ store.set("tt.zoom", v); try{ const r=$("region"), cur=r.value.trim(); if(v==="iran" && (!cur||cur==="خاورمیانه")) r.value="ایران"; else if(v==="me" && (!cur||cur==="ایران")) r.value="خاورمیانه"; }catch(e){} document.querySelectorAll(".ttZoom").forEach(s=>s.value=v); try{ schedule(); }catch(e){} }
const TT_GX=117, TT_GY=88;
let _ttRef=null;
function ttRef(){ if(_ttRef) return _ttRef; const b=atob(TT_ME_REF), r=new Uint8Array(TT_GX*TT_GY); for(let i=0;i<r.length;i++) r[i]=(b.charCodeAt(i>>3)>>(7-(i&7)))&1; return _ttRef=r; }
// کادر: سطرها و ستون‌های دارای خط سیاه پیوستهٔ بلند
function ttFrame(d, W, H){
  const dark=(x,y)=>{ const i=(y*W+x)*4; return d[i]<70&&d[i+1]<70&&d[i+2]<70; };
  const runRow=y=>{ let best=0,cur=0,bs=0; for(let x=0;x<W;x++){ if(dark(x,y)){ cur++; if(cur>best){ best=cur; bs=x-cur+1; } } else cur=0; } return [best,bs]; };
  const rows=[]; for(let y=0;y<H;y++){ const [n,s]=runRow(y); if(n>0.7*W) rows.push([y,n,s]); }
  if(rows.length<2) return null;
  const top=rows[0], bot=rows[rows.length-1]; if(bot[0]-top[0]<0.5*H) return null;
  let colOK=x=>{ let c=0; for(let y=top[0];y<=bot[0];y++) if(dark(x,y)) c++; return c>0.9*(bot[0]-top[0]); };
  let x0=top[2], x1=top[2]+top[1]-1;
  let k=0; while(k<4 && !colOK(x0)){ x0++; k++; } while(x1>x0+W/2 && !colOK(x1)) x1--;
  if(!colOK(x0)||!colOK(x1)||x1>W-30) return null;            // جا برای نوار رنگ سمت راست
  return {x0, x1, y0:top[0], y1:bot[0]};
}
function ttIsME(d, W, F){
  const g=new Uint8Array(TT_GX*TT_GY), w=F.x1-F.x0-3, h=F.y1-F.y0-3;
  for(let y=F.y0+2;y<F.y1-1;y++) for(let x=F.x0+2;x<F.x1-1;x++){ const i=(y*W+x)*4, L=(d[i]+d[i+1]+d[i+2])/3, S=Math.max(d[i],d[i+1],d[i+2])-Math.min(d[i],d[i+1],d[i+2]);
    if(L<60&&S<40){ const gx=Math.min(TT_GX-1,Math.floor((x-F.x0-2)*TT_GX/w)), gy=Math.min(TT_GY-1,Math.floor((y-F.y0-2)*TT_GY/h)); g[gy*TT_GX+gx]=1; } }
  const R=ttRef(); let inter=0, nr=0, ng=0; for(let i=0;i<R.length;i++){ if(R[i]) nr++; if(g[i]) ng++; if(R[i]&&g[i]) inter++; }
  const rec=inter/Math.max(1,nr), prec=inter/Math.max(1,ng);
  return {me: rec>=0.85 || (prec>=0.85 && rec>=0.4), rec, prec};
}
function ttDetect(m){
  const d=m.data, W=m.w, H=m.h; if(W<700 || W>1400) return null;
  const F=ttFrame(d,W,H); if(!F) return null;
  // نوار رنگ: ستون‌های رنگی بلافاصله سمت راست کادر
  const colored=x=>{ let c=0; for(let y=F.y0+1;y<F.y1;y++){ const i=(y*W+x)*4; if(!(d[i]>=250&&d[i+1]>=250&&d[i+2]>=250)) c++; } return c/(F.y1-F.y0-1); };
  let bx0=-1, bx1=-1; for(let x=F.x1+2;x<Math.min(W,F.x1+40);x++){ if(colored(x)>0.6){ if(bx0<0) bx0=x; bx1=x; } else if(bx0>=0) break; }
  if(bx0<0 || bx1-bx0<6) return null;
  const cx=Math.round((bx0+bx1)/2), same=(i,j)=>Math.abs(d[i]-d[j])+Math.abs(d[i+1]-d[j+1])+Math.abs(d[i+2]-d[j+2])<=3;
  // خانه‌ها: رشته‌های هم‌رنگ (≥۳ پیکسل) در ستون وسط نوار؛ سطرهای جداکننده حذف می‌شوند
  let ya=F.y0+1, yb=F.y1-1; const runs=[]; let s=ya;
  for(let y=ya+1;y<=yb+1;y++){ if(y<=yb && same((y*W+cx)*4,((y-1)*W+cx)*4)) continue; if(y-s>=3){ const i=(((s+y-1)>>1)*W+cx)*4; runs.push({a:s,b:y-1,c:[d[i],d[i+1],d[i+2]]}); } s=y; }
  // سفیدِ بالا/پایین بیرون از نوار (حاشیه) حذف؛ سفیدِ وسط (بازهٔ صفر) نگه داشته می‌شود
  while(runs.length && runs[0].c.every(v=>v>=250) && runs[0].b-runs[0].a>30) runs.shift();
  while(runs.length && runs[runs.length-1].c.every(v=>v>=250) && runs[runs.length-1].b-runs[runs.length-1].a>30) runs.pop();
  if(runs.length<4) return null;
  const segs=runs.slice().reverse();                  // پایین (کم) به بالا (زیاد)
  const colors=segs.map(s=>s.c);
  const fx0=F.x0+1, fx1=F.x1-1, fy0=F.y0+1, fy1=F.y1-1;
  // زمینه: پرتکرارترین رنگ داخل کادر
  const hist=new Map(); for(let y=fy0;y<=fy1;y+=3) for(let x=fx0;x<=fx1;x+=3){ const i=(y*W+x)*4, k=(d[i]<<16)|(d[i+1]<<8)|d[i+2]; hist.set(k,(hist.get(k)||0)+1); }
  let bk=0,bn=-1; for(const [k,v] of hist) if(v>bn){ bn=v; bk=k; } const bg=[(bk>>16)&255,(bk>>8)&255,bk&255];
  let bgIdx=-1, bmin=1e9; colors.forEach((c,k)=>{ const dd=cdist(c,bg); if(dd<bmin){ bmin=dd; bgIdx=k; } });
  const bgSep=bmin>12;
  // خط دور نوار و تیک‌های کنار برچسب‌ها (matplotlib) جزو نوار حساب می‌شوند تا تیک با علامت منفی اشتباه نشود
  let bxr=bx1; for(let x=bx1+1;x<Math.min(W,bx1+12);x++){ let c=0; for(let y=F.y0;y<=F.y1;y++){ const i=(y*W+x)*4; if(d[i]<110&&d[i+1]<110&&d[i+2]<110) c++; } if(c>=5) bxr=x; else break; }
  const barRect=[bx0, F.y0, bxr+1, F.y1+1];
  const segCenters=segs.map(s=>[cx, Math.round((s.a+s.b)/2)]);
  const exact=new Set([bg,...colors].map(c=>keyOf(c[0],c[1],c[2]))); let ex=0, tot=0;
  for(let y=fy0;y<=fy1;y+=3) for(let x=fx0;x<=fx1;x+=3){ const i=(y*W+x)*4; tot++; if(exact.has(keyOf(d[i],d[i+1],d[i+2]))) ex++; }
  const me=ttIsME(d,W,F);
  const fp=`tt:${W}x${H}:${colors.length}:`+colors.map(c=>c.map(v=>v>>4).join(".")).join("|");
  return {W,H, tol: ex/tot>=0.5?6:14, exactShare:ex/tot, fx0,fx1,fy0,fy1, bg, bgSep, bgIdx:bgSep?0:bgIdx, colors, segs, segCenters,
    bar:{orient:"v", c0:bx0, c1:bx1, rect:barRect}, inv:[], fp, tt:{me:me.me, rec:me.rec, prec:me.prec, geo: me.me ? TT_ME_GEO : null, frame:F}};
}

// اعداد نوار رنگ پیوسته (خانه‌های ریز، مثل دمای سطح): از جای عمودی برچسب‌ها، مقدار هر مرز خانه با درون‌یابی خطی
function ttGradientEdges(m, T){
  const K=T.segs.length; window.CV_VALS=[];
  try{ const step=19, a=T.bar.rect[1]+1, b=T.bar.rect[3]-1, fake=[]; for(let y=b;y-step>=a;y-=step) fake.push({a:y-step+1,b:y,c:[0,0,0]});
    cvReadBar({data:m.data, w:m.w, h:m.h, prof:{T:{...T, segs:fake}, segs:fake, bar:T.bar}}); }catch(e){ console.warn(e); }
  const all=(window.CV_VALS||[]).filter(r=>r.rg===0); window.CV_VALS=null;
  if(!all.length) return null;
  let vals=all.sort((p,q)=>q.vals.length-p.vals.length)[0].vals.slice().sort((p,q)=>p.pos-q.pos);
  // زنجیرهٔ یکنوا (مقدار با پایین رفتن کم می‌شود)
  const n=vals.length, len=Array(n).fill(1), prv=Array(n).fill(-1);
  for(let i=0;i<n;i++) for(let k=0;k<i;k++) if(vals[k].v>vals[i].v && len[k]+1>len[i]){ len[i]=len[k]+1; prv[i]=k; }
  let bi=0; for(let i=1;i<n;i++) if(len[i]>len[bi]) bi=i; const seq=[]; for(let i=bi;i>=0;i=prv[i]) seq.unshift(vals[i]);
  if(seq.length<3) return null;
  const at=y=>{ let k=0; while(k<seq.length-2 && y>seq[k+1].pos) k++; const p=seq[k], q=seq[k+1]; return p.v+(q.v-p.v)*(y-p.pos)/(q.pos-p.pos); };
  // segs پایین به بالا: مرز پایین خانهٔ k = b+1 آن
  const e=T.segs.map(s=>at(s.b+0.5)); e.push(at(T.segs[K-1].a-0.5));
  const nice=v=>Math.abs(v)>=10?Math.round(v*10)/10:Math.round(v*100)/100;
  return e.map(nice).map((v,k)=> k===0 ? "-inf" : k===K ? "+" : String(v)).join(", ");
}
function ttVar(T){
  const has=c=>T.colors.some(q=>cdist(q,c)<=12);
  if(has([0,220,0]) && has([255,222,0]) && has([138,0,0])) return "panom";     // سبز/قهوه‌ای واگرا = ناهنجاری بارش
  return null;
}// اعداد نوار رنگ tropicaltidbits: برچسب‌ها روی مرز خانه‌ها؛ علامت منفیِ اشتباه (تیک یا خط) با جای خانهٔ سفیدِ صفر اصلاح می‌شود
function ttBarEdges(m, T){
  const S=T.segs, K=S.length; window.CV_VALS=[];
  try{ cvReadBar({data:m.data, w:m.w, h:m.h, prof:{T, segs:S, bar:T.bar}}); }catch(e){ console.warn(e); }
  const regs=(window.CV_VALS||[]).filter(r=>r.rg===0); window.CV_VALS=null; if(!regs.length) return null;
  // بهترین خوانش (بیشترین برچسب)، یکتا بر اساس جای عمودی
  const byPos=new Map(); for(const r of regs) for(const v of r.vals){ const k=Math.round(v.pos/3); if(!byPos.has(k)) byPos.set(k,{pos:v.pos, cand:[]}); byPos.get(k).cand.push(v.v); }
  let vals=[...byPos.values()].map(o=>{ const cnt=new Map(); for(const c of o.cand) cnt.set(c,(cnt.get(c)||0)+1); let bv=o.cand[0], bn=0; for(const [v,n] of cnt) if(n>bn){ bn=n; bv=v; } return {pos:o.pos, v:bv}; });
  // مرزها (پایین به بالا)
  const B=[]; for(let j=0;j<=K;j++) B.push(j===0 ? S[0].b+0.5 : j===K ? S[K-1].a-0.5 : (S[j-1].a+S[j].b)/2);
  const step=Math.abs(B[K]-B[0])/K;
  // خانهٔ سفید وسط = صفر
  const white=S.map(s=>s.c.every(v=>v>=248)); let zy=null;
  { const idx=white.map((w,k)=>w?k:-1).filter(k=>k>0&&k<K-1); if(idx.length){ const lo=Math.min(...idx), hi=Math.max(...idx); zy=(S[lo].b+S[hi].a)/2; } }
  if(zy!==null){ const nNeg=vals.filter(v=>v.pos>zy && v.v<0).length, nPos=vals.filter(v=>v.pos<zy && v.v>0).length;
    if(nNeg+nPos>=2) vals=vals.map(v=> Math.abs(v.pos-zy)<step*0.6 ? v : {pos:v.pos, v: v.pos<zy ? Math.abs(v.v) : -Math.abs(v.v)}); }
  const known=Array(K+1).fill(null), kd=Array(K+1).fill(1e9);
  for(const v of vals){ let bj=-1, bd=1e9; B.forEach((b,j)=>{ const dd=Math.abs(b-v.pos); if(dd<bd){ bd=dd; bj=j; } }); if(bd<=0.45*step && bd<kd[bj]){ known[bj]=v.v; kd[bj]=bd; } }
  // زنجیرهٔ صعودی
  const arr=known.map((v,j)=>v===null?null:{j,v}).filter(Boolean); const n=arr.length; if(n<3) return null;
  const len=Array(n).fill(1), prv=Array(n).fill(-1); for(let i=0;i<n;i++) for(let k=0;k<i;k++) if(arr[k].v<arr[i].v && len[k]+1>len[i]){ len[i]=len[k]+1; prv[i]=k; }
  let bi=0; for(let i=1;i<n;i++) if(len[i]>len[bi]) bi=i; const seq=[]; for(let i=bi;i>=0;i=prv[i]) seq.unshift(arr[i]);
  if(seq.length<Math.max(3,0.6*n)) return null;
  const val=Array(K+1).fill(null); for(const a of seq) val[a.j]=a.v;
  for(let q=0;q<seq.length-1;q++){ const a=seq[q], b=seq[q+1]; for(let j=a.j+1;j<b.j;j++) val[j]=a.v+(b.v-a.v)*(j-a.j)/(b.j-a.j); }
  const f0=seq[0].j, fl=seq[seq.length-1].j;
  const fmt=v=>String(+v.toFixed(Math.abs(v)<1?3:2));
  // دو سر بی‌برچسب: با همان گام برچسب‌های کنار برون‌یابی؛ خانهٔ آخر باز (-inf / +)
  const st0=(val[seq[1].j]-val[f0])/(seq[1].j-f0), stl=(val[fl]-val[seq[seq.length-2].j])/(fl-seq[seq.length-2].j);
  for(let j=f0-1;j>=1;j--) val[j]=val[j+1]-st0; for(let j=fl+1;j<K;j++) val[j]=val[j-1]+stl;
  const e=val.map((v,j)=> (j===0 && f0>0) ? "-inf" : (j===K && fl<K) ? "+" : fmt(v));
  return {txt:ttSnapKnown(e.join(", ")), n:seq.length, of:K+1};
}
// مقیاس‌های کامل tropicaltidbits که در نمونه‌ها همهٔ برچسب‌هایشان دیده شده (برای نقشه‌هایی که فقط یک‌درمیان برچسب دارند، مثل NMME)
const TT_KNOWN_EDGES=[
  "-inf, -500, -450, -400, -350, -300, -250, -200, -150, -125, -100, -75, -50, -40, -30, -20, -10, -5, 5, 10, 20, 30, 40, 50, 75, 100, 125, 150, 200, 250, 300, 350, 400, 450, 500, +",
  "-inf, -140, -120, -100, -80, -70, -60, -50, -40, -35, -30, -25, -20, -15, -10, -7.5, -5, -2.5, 2.5, 5, 7.5, 10, 15, 20, 25, 30, 37.5, 45, 52.5, 60, 70, 80, 100, 120, 140, +"
];
function ttSnapKnown(txt){
  const v=parseEdges(txt); if(!v) return txt;
  for(const s of TT_KNOWN_EDGES){ const k=parseEdges(s); if(k.length!==v.length) continue;
    // برچسب‌های خوانده‌شده (اعداد گرد) باید با مقیاس آشنا بخوانند
    let ok=0, bad=0; v.forEach((x,j)=>{ if(!isFinite(x)) return; if(Math.abs(x-k[j])<1e-6) ok++; else if(Number.isInteger(x) && Math.abs(x)%5===0) bad++; });
    if(ok>=0.4*v.length && bad===0) return s; }
  return txt;
}
// نقشه‌های tropicaltidbits با اندازهٔ متفاوت (CanSIPS ۷۶۶، CFSv2 ۷۷۲، NMME ۷۵۱ پیکسل) ولی همان زوم خاورمیانه:
// هر پیکسل کادر نقشهٔ مرجع از روی طول و عرض جغرافیایی، با نزدیک‌ترین پیکسل (بدون هموارسازی رنگ) از نقشهٔ دیگر برداشته می‌شود
function ttWarpTo(m, ref){
  const Ts=m.ttT||(m.ttT=ttDetect(m)), Tr=ref.ttT||(ref.ttT=ttDetect(ref));
  if(!Ts||!Tr||!Ts.tt.geo||!Tr.tt.geo) return null;
  const Fs=Ts.tt.frame, Fr=Tr.tt.frame, [w,e,s,n]=TT_ME_GEO;
  const out=new Uint8ClampedArray(ref.data);            // بیرون کادر (عنوان، نوار رنگ) از نقشهٔ مرجع
  const W=ref.w, Ws=m.w;
  for(let y=Fr.y0+1;y<Fr.y1;y++){ const lat=n-(y-Fr.y0)/(Fr.y1-Fr.y0)*(n-s), ys=Math.round(Fs.y0+(n-lat)/(n-s)*(Fs.y1-Fs.y0));
    if(ys<=Fs.y0||ys>=Fs.y1) continue;
    for(let x=Fr.x0+1;x<Fr.x1;x++){ const lon=w+(x-Fr.x0)/(Fr.x1-Fr.x0)*(e-w), xs=Math.round(Fs.x0+(lon-w)/(e-w)*(Fs.x1-Fs.x0));
      if(xs<=Fs.x0||xs>=Fs.x1) continue; const i=(y*W+x)*4, j=(ys*Ws+xs)*4; out[i]=m.data[j]; out[i+1]=m.data[j+1]; out[i+2]=m.data[j+2]; out[i+3]=255; } }
  // رنگ‌های نوار باید یکی باشد (پس از یکی‌کردن خانه‌های سفید)
  const uniq=T=>{ const c=[]; for(const q of T.colors) if(!c.length||cdist(c[c.length-1],q)>3) c.push(q); return c; };
  const cs=uniq(Ts), cr=uniq(Tr); const sameBar = cs.length===cr.length && cs.every((c,k)=>cdist(c,cr[k])<=12);
  return {data:out, sameBar};
}
