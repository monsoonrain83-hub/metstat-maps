// ---- خواندن خودکار اعداد نوار رنگ (برچسب‌های کنار نوار) ----
function cvGlyphVec(C0){
  const C={D:Float32Array.from(C0.D, v=>v>=0.42?1:(v<=0.18?0:(v-0.18)/0.24)), w:C0.w, h:C0.h};
  let c0=-1,c1=-1; for(let x=0;x<C.w;x++){ let m=0; for(let y=0;y<C.h;y++) m=Math.max(m,C.D[y*C.w+x]); if(m>0.3){ if(c0<0) c0=x; c1=x; } }
  if(c0<0){ c0=0; c1=C.w-1; }
  const w=c1-c0+1, h=C.h, NH=16, NW=14, tw=Math.max(1,Math.min(NW,Math.round(w*NH/h))), ox=Math.floor((NW-tw)/2), img=new Float32Array(NH*NW);
  for(let y=0;y<NH;y++) for(let x=0;x<tw;x++){
    const ya=y*h/NH, yb=(y+1)*h/NH, xa=c0+x*w/tw, xb=c0+(x+1)*w/tw; let a=0, n=0;
    for(let yy=Math.floor(ya); yy<Math.ceil(yb); yy++) for(let xx=Math.floor(xa); xx<Math.ceil(xb); xx++){ const wy=Math.min(yy+1,yb)-Math.max(yy,ya), wx=Math.min(xx+1,xb)-Math.max(xx,xa); if(wy>0&&wx>0){ a+=wy*wx*C.D[Math.min(h-1,yy)*C.w+Math.min(C.w-1,xx)]; n+=wy*wx; } }
    img[y*NW+ox+x]=n?a/n:0; }
  const t=new Float32Array(NH*NW); for(let y=0;y<NH;y++) for(let x=0;x<NW;x++){ let a=0,n=0; for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ const yy=y+dy, xx=x+dx; if(yy<0||xx<0||yy>=NH||xx>=NW) continue; const k=(dy||dx)?0.25:1; a+=k*img[yy*NW+xx]; n+=k; } t[y*NW+x]=a/n; }
  let mu=0; for(const v of t) mu+=v; mu/=t.length; let q=0; for(let i=0;i<t.length;i++){ t[i]-=mu; q+=t[i]*t[i]; } q=Math.sqrt(q)||1; for(let i=0;i<t.length;i++) t[i]/=q;
  return t;
}
let CV_DIG_T=null;
function cvDigitTemplates(){
  if(CV_DIG_T) return CV_DIG_T;
  const out=[]; try{ for(const e of [...OCR_TPL.wu, ...OCR_TPL.wb]) if("0123456789".includes(e.c)) out.push({ch:e.c, src:"lib", g:"lib", v:cvGlyphVec({D:Float32Array.from(b64u8(e.d),x=>x/255), w:e.w, h:e.h})}); }catch(e){ console.warn(e); }
  const c=document.createElement("canvas"); c.width=70; c.height=70; const x=c.getContext("2d",{willReadFrequently:true});
  for(const ch of "0123456789") for(const f of cvOcrFams()) for(const wt of ["400","700"]) for(const sz of [10,11,12,14,17,22,34]){
    x.fillStyle="#fff"; x.fillRect(0,0,70,70); x.fillStyle="#000"; x.font=`${wt} ${sz}px ${f}`; x.textBaseline="alphabetic"; x.fillText(ch,15,50);
    const d=x.getImageData(0,0,70,70).data, D=new Float32Array(70*70); let X0=70,X1=-1,Y0=70,Y1=-1;
    for(let i=0;i<70*70;i++){ const v=(255-(0.299*d[i*4]+0.587*d[i*4+1]+0.114*d[i*4+2]))/255; D[i]=v; if(v>0.3){ const xx=i%70, yy=(i/70)|0; if(xx<X0)X0=xx; if(xx>X1)X1=xx; if(yy<Y0)Y0=yy; if(yy>Y1)Y1=yy; } }
    if(X1<0) continue; const w=X1-X0+1, h=Y1-Y0+1, C={D:new Float32Array(w*h), w, h};
    for(let yy=0;yy<h;yy++) for(let xx=0;xx<w;xx++) C.D[yy*w+xx]=D[(Y0+yy)*70+X0+xx];
    out.push({ch, src:f+wt+"/"+sz, g:f+wt, v:cvGlyphVec(C)});
  }
  return CV_DIG_T=out;
}
function cvCrop(dark, W, x0, y0, w, h){ const C={D:new Float32Array(w*h), w, h}; for(let y=0;y<h;y++) for(let x=0;x<w;x++) C.D[y*w+x]=dark[(y0+y)*W+x0+x]; return C; }
let CV_FONT=null, CV_GL=null, CV_MODE='soft', CV_ACC=null, CV_REC=null; const CV_CHMEMO=new Map();
function cvGlyphCrop(dark, W, x0, y0, w, h){
  let ya=-1,yb=-1; for(let y=y0;y<y0+h;y++){ let m=0; for(let x=x0;x<x0+w;x++) m=Math.max(m,dark[y*W+x]); if(m>0.3){ if(ya<0) ya=y; yb=y; } }
  if(ya<0) return null; const qh=yb-ya+1, Q=new Uint8Array(w*qh); for(let y=0;y<qh;y++) for(let x=0;x<w;x++) Q[y*w+x]=Math.round(Math.min(1,dark[(ya+y)*W+x0+x])*255);
  return {w, h:qh, Q};
}
const u8b64=a=>{ let s=""; for(let i=0;i<a.length;i++) s+=String.fromCharCode(a[i]); return btoa(s); };
function cvLearnedGlyphs(){ return BAR_TPL.concat(store.get("ocr.bar",[])); }
// یادگیری شکل ارقام از نقشه‌ای که اعداد نوارش معلوم است (پس از اصلاح دستی کاربر)
function cvLearnBar(m, edgesTxt, persist=true){
  const raw=String(edgesTxt).replace(/[۰-۹]/g,d=>"۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/٫/g,".").split(/[,،;\s]+/).filter(Boolean);
  if(raw.length!==m.prof.T.colors.length+1) return 0;
  CV_REC=[]; try{ cvReadBarCore(m); }catch(e){} const rec=CV_REC; CV_REC=null;
  const cand=[], hit=[0,0];
  for(const r of rec){ let bj=0, bd=1e9; r.B.forEach((p,j)=>{ const d=Math.abs(p-r.pos); if(d<bd){ bd=d; bj=j; } }); if(bd>0.2*r.step) continue;
    const digits=(raw[bj]||"").replace(/[^0-9]/g,""); const gl=r.glyphs.filter(Boolean); if(!digits || digits.length!==gl.length) continue;
    hit[r.rg]=(hit[r.rg]||0)+1; cand.push({r, digits, gl}); }
  const rg=(hit[1]||0)>(hit[0]||0)?1:0, seen=new Set(), learned=[];
  for(const {r,digits,gl} of cand){ if(r.rg!==rg) continue; gl.forEach((g,k)=>{ const e={c:digits[k], w:g.w, h:g.h, d:u8b64(g.Q)}, key=e.c+e.d; if(!seen.has(key)){ seen.add(key); learned.push(e); } }); }
  if(persist && learned.length){ const old=store.get("ocr.bar",[]), all=old.concat(learned); store.set("ocr.bar", all.slice(-600)); for(const k in CV_NAT) if(k.startsWith("lrn#")) delete CV_NAT[k]; }
  return learned;
}

// قالب ارقام در همان ارتفاع پیکسلیِ رقم پرسیده‌شده (بدون تغییر مقیاس → دقیق برای قلم‌های ریز)
const CV_NAT={}; let CV_NATC=null;
function cvNatGroups(){ return [...cvOcrFams().flatMap(f=>["400","700"].map(w=>f+"|"+w)), "lib", "lrn"]; }
function cvNatTemplates(g, h){
  const key=g+"#"+h; if(CV_NAT[key]) return CV_NAT[key];
  const out=[];
  if(g==="lrn"){
    for(const e of cvLearnedGlyphs()){ if(Math.abs(e.h-h)>1) continue; const D=Float32Array.from(b64u8(e.d),x=>x/255); out.push({ch:e.c,w:e.w,h:e.h,D,P:cvPrep(D,e.w,e.h)}); }
    return CV_NAT[key]=out;
  }
  if(g==="lib"){
    for(const e of [...OCR_TPL.wu, ...OCR_TPL.wb]) if("0123456789".includes(e.c)){
      const D=Float32Array.from(b64u8(e.d),x=>x/255); let y0=-1,y1=-1,x0=e.w,x1=-1; for(let y=0;y<e.h;y++) for(let x=0;x<e.w;x++) if(D[y*e.w+x]>0.35){ if(y0<0) y0=y; y1=y; if(x<x0)x0=x; if(x>x1)x1=x; }
      if(y1<0) continue; const th=y1-y0+1, tw=x1-x0+1; if(Math.abs(th-h)>1) continue;
      const C=new Float32Array(tw*th); for(let y=0;y<th;y++) for(let x=0;x<tw;x++) C[y*tw+x]=D[(y0+y)*e.w+x0+x]; out.push({ch:e.c,w:tw,h:th,D:C,P:cvPrep(C,tw,th)}); }
    return CV_NAT[key]=out;
  }
  const [f,wt]=g.split("|"); if(!CV_NATC){ CV_NATC=document.createElement("canvas"); CV_NATC.width=120; CV_NATC.height=120; }
  const x=CV_NATC.getContext("2d",{willReadFrequently:true});
  x.font=`${wt} 100px ${f}`; const mt=x.measureText("0"), H100=(mt.actualBoundingBoxAscent+mt.actualBoundingBoxDescent)||72;
  for(const fsAdj of [0,-0.5,0.5]){
    const fs=Math.max(4, h*100/H100 + fsAdj);
    for(const ch of "0123456789") for(const ox of [0,0.33,0.66]){
      x.fillStyle="#fff"; x.fillRect(0,0,120,120); x.fillStyle="#000"; x.font=`${wt} ${fs}px ${f}`; x.textBaseline="alphabetic"; x.fillText(ch,10+ox,60);
      const d=x.getImageData(0,0,60,80).data; let y0=-1,y1=-1,x0=60,x1=-1; const D=new Float32Array(60*80);
      for(let i=0;i<60*80;i++){ const v=(255-(0.299*d[i*4]+0.587*d[i*4+1]+0.114*d[i*4+2]))/255; D[i]=v; if(v>0.3){ const xx=i%60, yy=(i/60)|0; if(yy<y0||y0<0) y0=y0<0?yy:Math.min(y0,yy); if(yy>y1) y1=yy; if(xx<x0) x0=xx; if(xx>x1) x1=xx; } }
      if(y1<0) continue; const th=y1-y0+1, tw=x1-x0+1; if(Math.abs(th-h)>1) continue;
      const C=new Float32Array(tw*th); for(let yy=0;yy<th;yy++) for(let xx=0;xx<tw;xx++) C[yy*tw+xx]=D[(y0+yy)*60+x0+xx];
      out.push({ch,w:tw,h:th,D:C,P:cvPrep(C,tw,th)});
    }
  }
  return CV_NAT[key]=out;
}
// دودویی + محو سبک: ضخامت خط و نرم‌کردن لبهٔ قلم‌ها بی‌اثر می‌شود
function cvPrep(D, w, h){ const B=Float32Array.from(D, v=>v>=0.45?1:0), o=new Float32Array(w*h);
  for(let y=0;y<h;y++) for(let x=0;x<w;x++){ let a=0,n=0; for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ const yy=y+dy, xx=x+dx; if(yy<0||xx<0||yy>=h||xx>=w) continue; const k=(dy||dx)?((dy&&dx)?0.15:0.3):1; a+=k*B[yy*w+xx]; n+=k; } o[y*w+x]=a/n; }
  return o; }
// همبستگی نرمال روی کادر مشترک با جابه‌جایی‌های کوچک
function cvNcc(Q, qw, qh, T){
  const W=Math.max(qw,T.w)+2, H=Math.max(qh,T.h); let best=-1;
  for(let dx=-1;dx<=1;dx++) for(let dy=(qh===T.h?0:-1);dy<=(qh===T.h?0:1);dy++){
    let sq=0,st=0,sqq=0,stt=0,sqt=0,n=0;
    const ox=Math.floor((W-T.w)/2)+dx, qx=Math.floor((W-qw)/2), oy=dy<0?0:dy, qy=dy<0?-dy:0;
    for(let y=0;y<H+1;y++) for(let x=0;x<W;x++){
      const a=(x-qx>=0&&x-qx<qw&&y-qy>=0&&y-qy<qh)?Q[(y-qy)*qw+x-qx]:0, b=(x-ox>=0&&x-ox<T.w&&y-oy>=0&&y-oy<T.h)?T.D[(y-oy)*T.w+x-ox]:0;
      sq+=a; st+=b; sqq+=a*a; stt+=b*b; sqt+=a*b; n++; }
    const cov=sqt-sq*st/n, va=sqq-sq*sq/n, vb=stt-st*st/n; const r=cov/Math.sqrt(Math.max(1e-9,va*vb)); if(r>best) best=r; }
  return best;
}
function cvClassChar(dark, W, x0, y0, w, h){
  // برش تنگ عمودی همین رقم
  let ya=-1,yb=-1; for(let y=y0;y<y0+h;y++){ let m=0; for(let x=x0;x<x0+w;x++) m=Math.max(m,dark[y*W+x]); if(m>0.3){ if(ya<0) ya=y; yb=y; } }
  if(ya<0) return {ch:"?",s:0};
  const qh=yb-ya+1, Q0=new Float32Array(w*qh); for(let y=0;y<qh;y++) for(let x=0;x<w;x++){ const v=dark[(ya+y)*W+x0+x]; Q0[y*w+x]=v>=0.6?1:v; } const Q=cvPrep(Q0,w,qh);
  const gs = CV_FONT ? [CV_FONT] : cvNatGroups();
  // حافظهٔ نتیجه: همان شکل رقم (همان پیکسل‌ها) در نقشه‌های یک سایت بارها تکرار می‌شود
  let hk=CV_MODE+"|"+(CV_FONT||"*")+"|"+w+"x"+qh+"|"; for(let i=0;i<Q0.length;i++) hk+=String.fromCharCode(48+Math.round(Q0[i]*20));
  const hit=CV_CHMEMO.get(hk);
  if(hit){ if(CV_GL) CV_GL.push(hit.per); if(CV_ACC){ CV_ACC.s+=hit.best.s; CV_ACC.n++; } return hit.best; }
  const per={};
  let best={ch:"?",s:-1};
  for(const g of gs){ for(const T of cvNatTemplates(g, qh)){ if(Math.abs(T.w-w)>Math.max(2,0.35*w)) continue; const s = CV_MODE==='prep' ? cvNcc(Q,w,qh,{w:T.w,h:T.h,D:T.P}) : cvNcc(Q0,w,qh,T); if(!per[g]||s>per[g].s) per[g]={ch:T.ch,s}; if(s>best.s) best={ch:T.ch,s}; } }
  if(CV_GL) CV_GL.push(per);
  if(CV_ACC){ CV_ACC.s+=best.s; CV_ACC.n++; }
  if(CV_CHMEMO.size>20000) CV_CHMEMO.clear(); CV_CHMEMO.set(hk,{best,per});
  return best;
}
// همهٔ برچسب‌های یک نوار با یک قلم‌اند: اول قلمِ سازگارتر با همهٔ ارقام پیدا می‌شود، بعد فقط با همان خوانده می‌شود
function cvReadBar(m){
  let best=null;
  for(const mode of ["soft","prep"]){ CV_MODE=mode; let r=null; try{ r=cvReadBarMode(m); }catch(e){ console.warn(e); }
    if(r && (!best || r.score>best.score+0.02)) best=r; }
  CV_MODE="soft"; return best;
}
function cvReadBarMode(m){
  CV_FONT=null; CV_GL=[]; let r1=null; try{ r1=cvReadBarCore(m); } finally { }
  const gl=CV_GL; CV_GL=null; if(gl.length<3) return r1;
  let bg=null, bs=-1e9;
  for(const g of cvNatGroups()){ let tot=0; for(const per of gl) tot += per[g] ? per[g].s : -0.3; if(tot>bs){ bs=tot; bg=g; } }
  CV_FONT=bg; CV_ACC={s:0,n:0}; let r2=null; try{ r2=cvReadBarCore(m); } finally { CV_FONT=null; }
  if(r2){ r2.font=bg; r2.conf=CV_ACC.n?CV_ACC.s/CV_ACC.n:0; } CV_ACC=null; if(r1 && r1.conf===undefined) r1.conf=0;
  return r2 && (!r1 || r2.score>=r1.score-0.15) ? r2 : r1;
}
// یک مؤلفهٔ پهن (ارقام چسبیده): بهترین برش در دره‌های جوهر؛ منفیِ چسبیده هم جدا می‌شود
function cvSplitDigits(dark, W, c, y0, y1, Hd){
  let s="", x0=c.x0; const h=y1-y0+1, colInk=x=>{ let t=0; for(let y=y0;y<=y1;y++) t+=dark[y*W+x]; return t; };
  const colRows=x=>{ let a=-1,b=-1; for(let y=y0;y<=y1;y++) if(dark[y*W+x]>0.35){ if(a<0) a=y-y0; b=y-y0; } return [a,b]; };
  let k=x0, run=0; while(k<=c.x1){ const [a,b]=colRows(k); if(a>=0 && a>=0.3*h && b<=0.72*h) { run++; k++; } else break; }
  if(run>=2 && k<=c.x1 && (c.x1-k+1)>=0.3*Hd){ s+="-"; x0=k; while(x0<=c.x1 && colInk(x0)<0.3) x0++; }
  const w=c.x1-x0+1; if(w<=0) return {s, sc:1, boxes:[]};
  let best=null;
  let meanInk=0; for(let x=x0;x<=c.x1;x++) meanInk+=colInk(x); meanInk/=Math.max(1,w);
  for(let n=1;n<=5;n++){ if(n>1 && w/n<0.45*Hd) continue; if(w/n>1.05*Hd) continue;
    const cuts=[x0]; for(let q=1;q<n;q++){ const nom=x0+Math.round(q*w/n); let bx=nom, bv=1e9; for(let x=Math.max(x0+1,nom-2);x<=Math.min(c.x1-1,nom+2);x++){ const v=colInk(x); if(v<bv){ bv=v; bx=x; } } cuts.push(bx); } cuts.push(c.x1+1);
    let str="", sum=0, pen=0; for(let q=0;q<n;q++){ const g=cvClassChar(dark,W,cuts[q],y0,Math.max(1,cuts[q+1]-cuts[q]),h); str+=g.ch; sum+=g.s; }
    for(let q=1;q<n;q++) if(colInk(cuts[q])>0.75*meanInk) pen+=0.08;
    const sc=sum/n - 0.04*(n-1) - pen; if(!best||sc>best.sc) best={str,sc,boxes:cuts.slice(0,-1).map((a,q)=>[a,cuts[q+1]-a])}; }
  if(!best) best={str:cvClassChar(dark,W,x0,y0,w,h).ch, sc:0.5, boxes:[[x0,w]]};
  return {s:s+best.str, sc:best.sc, boxes:best.boxes};
}
function cvReadBarCore(m){
  const T=m.prof.T, W=m.w, H=m.h, d=m.data, hz=T.bar.orient==="h", r=T.bar.rect, th=Math.max(4, hz?r[3]-r[1]:r[2]-r[0]);
  const segs=T.segs, K=segs.length; if(K<2) return null;
  const fwd = segs[K-1].a > segs[0].a;
  const B=[], C=segs.map(s=>(s.a+s.b)/2);
  for(let j=0;j<=K;j++){ if(j===0) B.push(fwd?segs[0].a:segs[0].b+1); else if(j===K) B.push(fwd?segs[K-1].b+1:segs[K-1].a); else B.push(fwd?(segs[j-1].b+1+segs[j].a)/2:(segs[j].b+1+segs[j-1].a)/2); }
  const step=[...segs.map(s=>s.b-s.a+1)].sort((a,b)=>a-b)[K>>1];
  const ext=Math.max(34, th*3.5), side=Math.max(80, th*8);
  const regions = hz ? [[r[0]-30, r[3], r[2]+30, r[3]+ext], [r[0]-30, r[1]-ext, r[2]+30, r[1]]]
                     : [[r[2], r[1]-20, r[2]+side, r[3]+20], [r[0]-side, r[1]-20, r[0], r[3]+20]];
  let best=null;
  for(const rg0 of regions){
    const X0=Math.max(0,Math.round(rg0[0])), Y0=Math.max(0,Math.round(rg0[1])), X1=Math.min(W,Math.round(rg0[2])), Y1=Math.min(H,Math.round(rg0[3]));
    const RW=X1-X0, RH=Y1-Y0; if(RW<8||RH<6) continue;
    const L=new Float32Array(RW*RH), S=new Uint8Array(RW*RH), hist=[];
    for(let y=0;y<RH;y++) for(let x=0;x<RW;x++){ const i=((y+Y0)*W+x+X0)*4, R=d[i],G=d[i+1],Bb=d[i+2]; L[y*RW+x]=0.299*R+0.587*G+0.114*Bb; S[y*RW+x]=Math.max(R,G,Bb)-Math.min(R,G,Bb); if(((x+y)&3)===0) hist.push(L[y*RW+x]); }
    hist.sort((a,b)=>a-b); const bgL=hist[hist.length>>1], darkTxt=bgL>=128;
    const dark=new Float32Array(RW*RH), fg=new Uint8Array(RW*RH);
    for(let i=0;i<RW*RH;i++){ const v = darkTxt ? (bgL-L[i])/Math.max(40,bgL) : (L[i]-bgL)/Math.max(40,255-bgL); dark[i]=Math.max(0,v); if(v>0.32 && S[i]<90) fg[i]=1; }
    // مؤلفه‌ها
    const lab=new Int32Array(RW*RH).fill(-1), comps=[], st=[];
    for(let i0=0;i0<RW*RH;i0++){ if(!fg[i0]||lab[i0]>=0) continue; let cx0=RW,cx1=-1,cy0=RH,cy1=-1,n=0; st.push(i0); lab[i0]=comps.length;
      while(st.length){ const i=st.pop(), x=i%RW, y=(i/RW)|0; n++; if(x<cx0)cx0=x; if(x>cx1)cx1=x; if(y<cy0)cy0=y; if(y>cy1)cy1=y;
        for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ const xx=x+dx, yy=y+dy; if(xx<0||yy<0||xx>=RW||yy>=RH) continue; const j=yy*RW+xx; if(fg[j]&&lab[j]<0){ lab[j]=comps.length; st.push(j); } } }
      comps.push({x0:cx0,x1:cx1,y0:cy0,y1:cy1,n,w:cx1-cx0+1,h:cy1-cy0+1}); }
    const big=comps.filter(c=>c.h>=5 && c.h<=40 && c.w<=6*c.h);
    if(big.length<2) continue;
    // ارتفاع رقم از سطرِ نزدیک‌ترین به نوار (نه کل ناحیه؛ نوشته‌های پانویس ارتفاع دیگری دارند)
    let Hd;
    { const rl=[]; for(const c of big.slice().sort((a,b)=>a.y0-b.y0)){ const l=rl.find(l=>Math.min(l.y1,c.y1)-Math.max(l.y0,c.y0)>0.4*Math.min(c.h,l.y1-l.y0+1)); if(l){ l.cs.push(c); l.y0=Math.min(l.y0,c.y0); l.y1=Math.max(l.y1,c.y1); l.x0=Math.min(l.x0,c.x0); l.x1=Math.max(l.x1,c.x1); } else rl.push({cs:[c],y0:c.y0,y1:c.y1,x0:c.x0,x1:c.x1}); }
      const barLen = hz ? r[2]-r[0] : r[3]-r[1];
      let cand;
      if(hz){ const below = Y0>=r[3]-1, dist=l=> below ? l.y0 : (RH-1-l.y1);
        cand = rl.filter(l=>l.cs.length>=2 && (l.x1-l.x0)>=0.25*barLen).sort((a,b)=>dist(a)-dist(b))[0] || rl.sort((a,b)=>dist(a)-dist(b))[0]; }
      else { const right = X0>=r[2]-1, dx=c=> right ? c.x0 : (RW-1-c.x1); const near=big.slice().sort((a,b)=>dx(a)-dx(b)); const x0=dx(near[0]); cand={cs:near.filter(c=>dx(c)<=x0+3*Math.max(...near.slice(0,3).map(q=>q.h)))}; }
      const hs=cand.cs.map(c=>c.h).sort((a,b)=>a-b); Hd=hs[Math.floor(hs.length*0.7)];
      if(hz){ const keep=new Set(cand.cs); for(let k=big.length-1;k>=0;k--) if(!keep.has(big[k]) && !(big[k].y1>=cand.y0-2 && big[k].y0<=cand.y1+2)) big.splice(k,1); } }
    const digs=big.filter(c=>c.h>=0.7*Hd && c.h<=1.35*Hd);
    // سطرها
    const lines=[];
    for(const c of digs.sort((a,b)=>a.y0-b.y0)){ const ln=lines.find(l=>Math.min(l.y1,c.y1)-Math.max(l.y0,c.y0)>0.5*Hd); if(ln){ ln.cs.push(c); ln.y0=Math.min(ln.y0,c.y0); ln.y1=Math.max(ln.y1,c.y1); } else lines.push({cs:[c],y0:c.y0,y1:c.y1}); }
    if(window.CVDBG) CVDBG.push('REG'+JSON.stringify([X0,Y0,X1,Y1])+' Hd='+Hd+' lines='+lines.map(l=>l.y0+'-'+l.y1+':'+l.cs.length).join(','));
    const toks=[];
    for(const ln of lines){
      const extra=comps.filter(c=>c.h<0.7*Hd && c.y0>=ln.y0-2 && c.y1<=ln.y1+3 && c.n>=1);
      const all=[...ln.cs, ...extra].sort((a,b)=>a.x0-b.x0);
      const gapT = hz ? 0.42*Hd : 0.9*Hd; let cur=null;
      for(const c of all){ if(cur && c.x0-cur.x1<=gapT){ cur.cs.push(c); cur.x1=Math.max(cur.x1,c.x1); } else { if(cur) toks.push(cur); cur={cs:[c],x0:c.x0,x1:c.x1,ln}; } }
      if(cur) toks.push(cur);
    }
    const vals=[];
    for(const t of toks){
      let s="", ok=true, hasDig=false; const glyphs=[]; let prevBig=null;
      const faintDot=(xa,xb)=>{ xa++; xb--; if(xb<xa) return false; let low=false;
        for(let x=xa;x<=xb;x++) for(let y=t.ln.y0;y<=Math.min(RH-1,t.ln.y1+1);y++){ const v=dark[y*RW+x]; if(v<=0.12) continue; if(y<t.ln.y1-0.3*Hd) return false; low=true; }
        return low; };
      for(const c of t.cs){
        if(c.h>=0.7*Hd && prevBig && !/[.]$/.test(s) && c.x0-prevBig.x1>=2 && faintDot(prevBig.x1+1, c.x0-1)) s+=".";
        if(c.h>=0.7*Hd) prevBig=c;
        if(c.h>=0.7*Hd){
          const g=cvSplitDigits(dark,RW,c,t.ln.y0,t.ln.y1,Hd);
          if(CV_REC) for(const [bx,bw] of g.boxes) glyphs.push(cvGlyphCrop(dark,RW,bx,t.ln.y0,bw,t.ln.y1-t.ln.y0+1));
          if(g.sc<0.55 && !CV_REC){ ok=false; break; } s+=g.s; hasDig=true;
        } else {
          const mid=(c.y0+c.y1)/2, lnMid=(t.ln.y0+t.ln.y1)/2;
          if(c.w>=1.3*c.h && Math.abs(mid-lnMid)<0.3*Hd && c.w<0.9*Hd) s+="-";
          else if(c.h<=0.3*Hd+1 && c.w<=0.35*Hd+1 && c.y1>=t.ln.y1-0.2*Hd) s+=".";
          else if(c.h<=0.45*Hd && c.y1>=t.ln.y1-0.1*Hd && c.y0>lnMid) s+=".";      // ویرگول اعشار
        }
      }
      if(window.CVDBG && (!ok||!hasDig)) CVDBG.push('X['+s+']@'+Math.round(hz ? X0+(t.x0+t.x1)/2 : Y0+(t.ln.y0+t.ln.y1)/2));
      if(!ok||!hasDig) continue;
      if(CV_REC){ const pos0 = hz ? X0+(t.x0+t.x1)/2 : Y0+(t.ln.y0+t.ln.y1)/2; CV_REC.push({pos:pos0, glyphs, B, C, step, rg:regions.indexOf(rg0)}); }
      s=s.replace(/^\++/,"").replace(/\+/g,"");
      if(!/^-?\d+(\.\d+)?$/.test(s)) continue;
      const pos = hz ? X0+(t.x0+t.x1)/2 : Y0+(t.ln.y0+t.ln.y1)/2;
      vals.push({v:parseFloat(s), pos, s});
      if(window.CVDBG) CVDBG.push(s+'@'+Math.round(pos));
    }
    if(vals.length<2) continue;
    if(window.CV_VALS) CV_VALS.push({rg:regions.indexOf(rg0), vals:vals.map(v=>({v:v.v,pos:v.pos}))});
    // برچسب‌ها روی مرز رنگ‌ها یا وسط آنها؟
    const fit=(P)=>{ let e=0; const as=vals.map(t=>{ let bj=0, bd=1e9; P.forEach((p,j)=>{ const dd=Math.abs(p-t.pos); if(dd<bd){ bd=dd; bj=j; } }); e+=bd/step; return {j:bj,d:bd,v:t.v}; }); return {as, err:e/vals.length}; };
    for(const [mode,P] of [["b",B],["c",C]]){
      const f=fit(P); if(f.err>0.38) continue;
      // هر جایگاه یک عدد (نزدیک‌ترین)، سپس بلندترین زنجیرهٔ یکنوا
      const byJ=new Map(); for(const a of f.as) if(a.d<=0.5*step && (!byJ.has(a.j)||byJ.get(a.j).d>a.d)) byJ.set(a.j,a);
      const arr=[...byJ.values()].sort((a,b)=>a.j-b.j);
      const lis=(cmp)=>{ const n=arr.length, len=Array(n).fill(1), prv=Array(n).fill(-1); for(let i=0;i<n;i++) for(let k=0;k<i;k++) if(cmp(arr[k].v,arr[i].v)&&len[k]+1>len[i]){ len[i]=len[k]+1; prv[i]=k; } let bi=0; for(let i=1;i<n;i++) if(len[i]>len[bi]) bi=i; const o=[]; for(let i=bi;i>=0;i=prv[i]) o.unshift(arr[i]); return o; };
      const up=lis((a,b)=>b>a), dn=lis((a,b)=>b<a), seq=up.length>=dn.length?up:dn, asc=seq===up;
      if(seq.length<2 || seq.length<0.6*arr.length) continue;
      const n=mode==="b"?K+1:K, known=Array(n).fill(null); for(const a of seq) known[a.j]=a.v;
      const ks=known.map((v,j)=>v===null?-1:j).filter(j=>j>=0);
      const val=known.slice();
      for(let q=0;q<ks.length-1;q++){ const a=ks[q], b=ks[q+1]; for(let j=a+1;j<b;j++) val[j]=known[a]+(known[b]-known[a])*(j-a)/(b-a); }
      const f0=ks[0], fl=ks[ks.length-1];
      const st0 = ks.length>1 ? (val[ks[1]]-val[f0])/(ks[1]-f0) : 1, stl = ks.length>1 ? (val[fl]-val[ks[ks.length-2]])/(fl-ks[ks.length-2]) : 1;
      for(let j=f0-1;j>=0;j--) val[j]=val[j+1]-st0; for(let j=fl+1;j<n;j++) val[j]=val[j-1]+stl;
      let edges;
      if(mode==="b"){ edges=val; if(f0>0) edges[0]= asc?-Infinity:Infinity; if(fl<K) edges[K]= asc?Infinity:-Infinity; }
      else { edges=[]; for(let j=0;j<=K;j++) edges.push(j===0 ? val[0]-(val[1]-val[0])/2 : j===K ? val[K-1]+(val[K-1]-val[K-2])/2 : (val[j-1]+val[j])/2); }
      const fmtE=v=> v===Infinity?"+" : v===-Infinity?"-inf" : String(+v.toFixed(Math.abs(v)<1?3:2));
      const score = seq.length/(mode==="b"?K+1:K) - f.err*0.5;
      if(!best || score>best.score) best={txt:edges.map(fmtE).join(", "), mode, n:seq.length, of:n, score, interp: mode==="b" ? known.filter((v,j)=>v===null && isFinite(edges[j])).length : known.filter(v=>v===null).length};
    }
  }
  return best;
}
// قالب هر نقشه (همیشه تشخیص خودکار؛ نوار رنگ شاخص‌ها با نقشهٔ بارش فرق دارد)

// گزارش فارسی: مقدمه، وضعیت کلی، شرح جداگانهٔ هر شاخص در بخش‌های منطقه، و مقایسه با بارش مدل‌ها
const cvList=a=>a.length<=1?(a[0]||""):a.slice(0,-1).join("، ")+" و "+a[a.length-1];
function cvFmtV(v, ix){ if(!isFinite(v)) return "—"; const a=Math.abs(v);
  const r = a>=1000 ? Math.round(v/50)*50 : a>=100 ? Math.round(v/10)*10 : a>=10 ? Math.round(v) : a>=1 ? Math.round(v*10)/10 : Math.round(v*100)/100; return FA(r); }

// نقشه‌های احتمال و شدت برای «همهٔ مدل‌ها» یا یک مدل (با حافظهٔ موقت)
function cvRenderPI(RC, PI, key){
  if(RC.cache[key]) return RC.cache[key];
  const d=PI[key], tag = key==="all" ? (Object.keys(PI).length>1?" — همهٔ مدل‌ها":"") : " — "+key;
  let pmx=0, imx=0; for(let i=0;i<N;i++){ if(d.P[i]>pmx) pmx=d.P[i]; if(d.I[i]>imx) imx=d.I[i]; }
  const info2 = key==="all" ? RC.info2 : `مدل: ${key}  |  شاخص‌ها: ${(d.names||[]).join("، ")}`;
  CUR_SCHEME=PROB_SCHEME;
  const cvP=renderMap({field:d.P, kind:"prob", title:"احتمال وقوع همرفت (درصد)"+tag, info1:info2, info2, S:RC.S, max:pmx, info:info2, ref:RC.refData, zoom:RC.zoom});
  const cvI=renderMap({field:d.I, kind:"prob", title:"شدت بالقوهٔ همرفت (درصد)"+tag, info1:info2, info2:`${info2}  |  فقط جایی که احتمال ≥ ${FA(RC.pmin)}٪`, S:RC.S, max:imx, info:`${info2}  |  احتمال ≥ ${FA(RC.pmin)}٪`, ref:RC.refData, zoom:RC.zoom});
  CUR_SCHEME=null;
  return (RC.cache[key]={cvP, cvI, pmx, imx});
}
// نقشهٔ آماری یک شاخص (میانگین یا بیشینه/کمینهٔ همهٔ ساعت‌ها) با نوار رنگ خودِ همان شاخص
function cvRenderStat(RC, st, kind){
  const key=`st_${st.type}_${st.model}_${kind}`; if(RC.cache[key]) return RC.cache[key];
  const m=st.rep, ix=CV_IDX[st.type], cols=m.prof.T.colors, v=m.v, K=cols.length, desc=v[K]<v[0];
  const bg=m.prof.T.bgSep ? m.prof.T.bg : null, sc=ix.units ? (ix.units[m.unit]||1) : 1;
  const ev=v.map(x=>x*sc*(ix.abs?Math.sign(x)||1:1));   // مرزها در یکای تحلیل
  const E = ix.abs ? v.map(x=>Math.abs(x)*sc) : ev, asc = E[K]>E[0];
  const colorFn = val=>{ if(!(val===val)) return [235,235,235];
    for(let k=0;k<K;k++){ const a=E[k], b=E[k+1], lo=Math.min(a,b), hi=Math.max(a,b); if(val>=lo && val<hi) return cols[k]; }
    const below = asc ? val<E[0] : val>E[0]; if(bg) return (below!==!!m.bgAbove) ? bg : cols[below?0:K-1]; return cols[below?0:K-1]; };
  const field=st[kind==="mean"?"mean":"ext"]; let mx=-Infinity, mn=Infinity; for(let i=0;i<N;i++){ const x=field[i]; if(x===x){ if(x>mx) mx=x; if(x<mn) mn=x; } }
  const what = kind==="mean" ? "میانگین" : (st.low ? "کمینه (مساعدترین مقدار)" : "بیشینه");
  const title = `${what} ${ix.n.replace(/\s*\(.*\)/,"")} — ${st.all && st.model==="همهٔ مدل‌ها" ? "همهٔ مدل‌ها" : st.model}`;
  const unit = (ix.units?Object.keys(ix.units)[0]:ix.u)||"";
  const info = `${FA(st.n)} نقشه${st.hours>1?` در ${FA(st.hours)} ساعت`:""}  |  بازه: ${fmt(mn)} تا ${fmt(mx)} ${unit}`;
  const cvx=renderMap({field, kind:"idx", barLayout:(m.w===P.W&&m.h===P.H)?{segs:m.prof.segs, bar:m.prof.bar, barStart:m.prof.barStart}:null, title, info1:info, info2:info, info, S:RC.S, max:mx, maxText:`${st.low&&kind!=="mean"?"کمینه":"بیشینه"}: ${fmt(st.low&&kind!=="mean"?mn:mx)} ${unit}`, ref:RC.refData, zoom:RC.zoom, colorFn, barCols:cols, barEdges:ix.abs?v.map(x=>Math.abs(x)):v});
  return (RC.cache[key]=cvx);
}

// پاراگراف‌های زمان (ساعت محتمل همرفت) و مقایسهٔ مدل‌ها در گزارش
function cvReportExtra(paras, o){
  const {warm, slots, perModel, fields, sea} = o, FA1=v=>FA(Math.round(v));
  const hh=h=>FA(String(Math.floor(h)).padStart(2,"0"))+":"+FA(String(Math.round((h%1)*60)).padStart(2,"0"));
  const dayN=d=>["یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"][d.getUTCDay()];
  let t = warm
    ? "زمان وقوع: تاریخ نقشه‌ها در فصل گرم (اواخر فروردین تا نیمهٔ آبان) است؛ در این فصل همرفت عمدتاً با گرمایش روزانه شکل می‌گیرد و رشد توده‌های تندری بیشتر بین ساعت ۱۱ صبح تا ۸ شب به وقت ایران رخ می‌دهد، به همین دلیل نقشه‌های معتبر برای این بازه وزن بیشتری گرفتند (نقشه‌های خارج از این بازه با ضریب ۰٫۶)."
    : "زمان وقوع: تاریخ نقشه‌ها در فصل سرد است؛ در این فصل همرفت بیشتر تابع سامانه‌های همدیدی (ناوه، جبهه و رودباد) است و اگر شرایط فراهم باشد در هر ساعت از شبانه‌روز ممکن است رخ دهد، بنابراین ساعت نقشه‌ها در وزن‌دهی اثری نداشت.";
  const ws=fields.filter(f=>f.loc), inW=ws.filter(f=>f.loc.h>=11&&f.loc.h<20).length;
  if(warm && ws.length) t+= inW===ws.length ? " همهٔ نقشه‌ها در همین بازهٔ اوج روزانه‌اند." : inW===0 ? " هیچ‌کدام از نقشه‌ها در بازهٔ اوج روزانه نیستند و نتیجه برای ساعات شب و صبح است؛ احتمال واقعی در بعدازظهر می‌تواند بیشتر باشد." : ` ${FA(inW)} از ${FA(ws.length)} نقشه در بازهٔ اوج روزانه‌اند.`;
  if(slots && slots.length>1){
    const sorted=slots.slice().sort((a,b)=>b.mean-a.mean), b=sorted[0], w=sorted[sorted.length-1];
    const lab=x=>`${dayN(x.d)} ساعت ${hh(x.h)}`;
    t+=` در میان ساعت‌هایی که نقشهٔ شاخص ناپایداری دارند، بیشترین احتمال مربوط به ${lab(b)} است (میانگین ${FA1(b.mean)}٪، بیشینه ${FA1(b.max)}٪) و کمترین به ${lab(w)} (میانگین ${FA1(w.mean)}٪)؛`;
    t+= warm && !(b.h>=11&&b.h<20) ? " با این حال چون این ساعت بیرون از بازهٔ اوج روزانه است، احتمال واقعیِ رشد توده‌ها در بعدازظهرِ همان روز بیشتر خواهد بود." : ` بنابراین همرفت در حدود ${lab(b)} محتمل‌تر است.`;
    t+=` (مقایسه فقط بین ساعت‌هایی است که دست‌کم دو شاخص دارند: ${sorted.map(x=>`${hh(x.h)}: ${x.names.join("، ")}`).join(" | ")}.)`;
  } else if(ws.length){ const h=ws.map(f=>f.loc.h); t+=` نقشه‌ها برای ساعت ${hh(Math.min(...h))}${Math.max(...h)-Math.min(...h)>0.5?` تا ${hh(Math.max(...h))}`:""} به وقت ایران معتبرند.`; }
  paras.splice(1,0,t);
  if(perModel && perModel.length>1){
    const GN={inst:"ناپایداری", moist:"رطوبت", trig:"بازدارندگی/عامل صعود", sig:"نشانهٔ همرفت در خروجی مدل"};
    const st=perModel.map(pm=>{ let s_=0,n_=0,mx=0,a20=0; for(let i=0;i<N;i+=3){ if(sea&&sea[i]) continue; s_+=pm.P2[i]; n_++; if(pm.P2[i]>mx) mx=pm.P2[i]; if(pm.P2[i]>=20) a20++; } return {md:pm.model, n:pm.n, mean:n_?s_/n_:0, mx, a20:n_?a20/n_:0, missing:pm.missing}; }).sort((a,b)=>b.mean-a.mean);
    let m="به تفکیک مدل: "+st.map(x=>`${x.md} (${FA(x.n)} نقشه) بیشینهٔ احتمال ${FA1(x.mx)}٪ و ${FA1(100*x.a20)}٪ خشکی‌ها بالای ۲۰٪`).join("؛ ")+".";
    const inc=st.filter(x=>x.missing.length); if(inc.length) m+=" "+inc.map(x=>`برای ${x.md} نقشهٔ ${x.missing.map(g=>GN[g]||g).join("، ")} وجود ندارد، پس احتمال این مدل بیش‌برآورد است و مقایسه با مدل‌های دیگر دقیق نیست.`).join(" ");
    if(!inc.length) m+= st[0].mean-st[st.length-1].mean>5 ? ` شاخص‌های ${st[0].md} شرایط مساعدتری نسبت به ${st[st.length-1].md} نشان می‌دهند.` : " شاخص‌های مدل‌ها شرایط نزدیک به هم نشان می‌دهند.";
    paras.splice(2,0,m);
  }
  return paras;
}
function cvReport(o){
  const {P, I, GF, sea, rp, from, idxStats, comps, regionFa, tSpread, nIdx, SEC, secOK} = o, FA1=v=>FA(Math.round(v)), land=i=>!(sea&&sea[i]);
  const where = regionFa || "منطقه", paras=[];
  let pmx=0, ib=-1; for(let i=0;i<N;i++) if(P[i]>pmx){ pmx=P[i]; ib=i; }
  let nL=0, a20=0, a50=0; for(let i=0;i<N;i++) if(land(i)){ nL++; if(P[i]>=20) a20++; if(P[i]>=50) a50++; }
  const pct=v=>{ const q=nL?100*v/nL:0; return q>0&&q<1?"کمتر از ۱":FA1(q); };
  const lp=[]; for(let i=0;i<N;i+=3) if(land(i)) lp.push(P[i]); lp.sort((a,b)=>a-b); const p99=lp.length?lp[Math.floor(lp.length*0.99)]:0;
  const lvl = p99>=60?"زیاد":p99>=35?"متوسط":p99>=12?"کم":"بسیار کم";
  // ۱) مقدمه و جمع‌بندی
  let intro=`شرایط همرفت ${regionFa?"در "+regionFa+" ":""}${from?from+" ":""}با ${FA(nIdx)} شاخص همرفتی بررسی شد${tSpread>3?` (زمان اعتبار نقشه‌ها تا ${FA1(tSpread)} ساعت با هم فاصله دارد و نتیجه تقریبی است)`:""}. `;
  intro+=`پتانسیل وقوع همرفت در ${where} در مجموع ${lvl} است${(lvl==="کم"||lvl==="بسیار کم")&&pmx>=40?" و احتمال فقط به‌صورت نقطه‌ای":" و بیشینهٔ احتمال"} به حدود ${FA1(pmx)}٪ می‌رسد.`;
  if(pmx>=10){
    const thr=Math.max(15, Math.min(0.6*pmx, Math.max(0.8*p99, 25))); let sx=0, sy=0, n=0, Is=0;
    for(let i=0;i<N;i++) if(P[i]>=thr && land(i)){ sx+=i%FW; sy+=(i/FW)|0; n++; Is+=I[i]; }
    const secOf=i=>Math.min(2,Math.floor(3*((i/FW)|0)/FH))*3+Math.min(2,Math.floor(3*(i%FW)/FW)), hs=new Array(9).fill(0);
    for(let i=0;i<N;i++) if(P[i]>=thr && land(i)) hs[secOf(i)]++;
    const top=hs.map((c,k)=>[k,c]).filter(a=>a[1]>=0.2*n && a[1]>0).sort((a,b)=>b[1]-a[1]).slice(0,3).map(a=>a[0]);
    let wh = top.length ? cvList(top.map(k=>SEC[k]==="مرکز"?"بخش‌های مرکزی":SEC[k])) : "مرکز";
    let near=[]; if(rp.geo){ for(const [nm,la,lo] of CV_CITIES){ const X=Math.round(rp.ax+rp.bx*lo)-rp.fx0, Y=Math.round(rp.ay+rp.by*la)-rp.fy0; if(X<2||Y<2||X>=FW-2||Y>=FH-2) continue;
        if(!top.includes(secOf(Y*FW+X))) continue;
        let m=0; for(let dy=-3;dy<=3;dy++) for(let dx=-3;dx<=3;dx++){ const xx=X+dx, yy=Y+dy; if(xx>=0&&yy>=0&&xx<FW&&yy<FH) m=Math.max(m,P[yy*FW+xx]); } if(m>=thr) near.push([nm,m]); }
      near=near.sort((a,b)=>b[1]-a[1]).slice(0,5).map(a=>a[0]); }
    const im=n?Is/n:0, sv=im>=70?"بسیار شدید":im>=50?"شدید":im>=30?"متوسط":im>=10?"ضعیف":"خیلی ضعیف";
    intro+=` هسته‌های اصلی در ${wh==="مرکز"?"بخش‌های مرکزی":wh} ${where}${near.length?`، حوالی ${cvList(near)}`:""} قرار دارند؛ احتمال در ${pct(a20)}٪ از خشکی‌ها بیش از ۲۰٪ و در ${pct(a50)}٪ بیش از ۵۰٪ است و شدت بالقوه در صورت وقوع ${sv} برآورد می‌شود.`;
  }
  const gn={inst:"ناپایداری ناکافی", moist:"کمبود رطوبت", trig:"بازدارندگی (CIN) یا نبود عامل صعود", sig:"نبود نشانهٔ همرفت در خروجی مدل"}, gm=[];
  for(const g in GF){ let s_=0, c=0; for(let i=0;i<N;i++){ const v=GF[g][i]; if(v===v && land(i)){ s_+=v; c++; } } if(c) gm.push([g, s_/c]); }
  if(gm.length>=2){ gm.sort((a,b)=>a[1]-b[1]); if(gm[0][1]<0.5) intro+=` عامل محدودکنندهٔ اصلی در بیشتر نقاط ${gn[gm[0][0]]||"—"} است.`; }
  paras.push(intro);
  // ۲) هر شاخص جداگانه
  const order={inst:0, moist:1, trig:2, sig:3, org:4};
  const CL=["خیلی مساعد","مساعد","ضعیف","نامساعد"], CLo=["سازمان‌یافتگی قوی","سازمان‌یافتگی متوسط","سازمان‌یافتگی ضعیف","بدون سازمان‌یافتگی"];
  for(const st of idxStats.slice().sort((a,b)=>(order[a.ix.g]??9)-(order[b.ix.g]??9))){
    const ix=st.ix, unit=ix.rel?"٪ مقیاس":(ix.u||""), lab=ix.g==="org"?CLo:CL, groups=[[],[],[],[]];
    for(const sc of st.secs){ if(!sc.ok || !(sc.fav===sc.fav) || sc.nan>0.6) continue; const c=sc.fav>=85?0:sc.fav>=50?1:sc.fav>=20?2:3; groups[c].push(sc); }
    const parts=[];
    groups.forEach((g,c)=>{ if(!g.length) return; const lo=Math.min(...g.map(x=>x.p25)), hi=Math.max(...g.map(x=>x.p75));
      const rng = cvFmtV(lo,ix)===cvFmtV(hi,ix) ? cvFmtV(lo,ix) : `${cvFmtV(lo,ix)} تا ${cvFmtV(hi,ix)}`;
      const secIdx=new Set(g.map(x=>SEC.indexOf(x.nm)));
      const cs = c<=1 ? st.cities.filter(q=>secIdx.has(q.sec) && q.fav>=(c===0?85:50)).sort((a,b)=>b.fav-a.fav).slice(0,3).map(q=>q.nm) : [];
      parts.push(`${lab[c]} در ${cvList(g.map(x=>x.nm))} (${rng}${unit?" "+unit:""})${cs.length?`، از جمله ${cvList(cs)}`:""}`); });
    const nanS=st.secs.filter(x=>x.okSec && x.nan>0.6).map(x=>x.nm);
    if(nanS.length) parts.push(`${ix.bgNull?"بدون مقدار در":"بدون داده در"} ${cvList(nanS)}${ix.bgNull?" (لایهٔ ناپایدار وجود ندارد، پس بازدارندگی هم معنا ندارد)":""}`);
    if(!parts.length) continue;
    let t=`${st.name}: ${parts.join("؛ ")}.`;
    if(ix.g==="sig" && st.peak && st.peak.fav>=20) t+=` هسته‌های محلی تا ${cvFmtV(st.peak.v,ix)}${unit?" "+unit:""} در ${st.peak.sec}${st.peak.near.length?`، حوالی ${cvList(st.peak.near)}`:""} دیده می‌شود که نشانهٔ همرفت فعال در خروجی مدل است.`;
    if(ix.sea && st.seaMed===st.seaMed && st.seaFrac>0.03) t+=` روی پهنه‌های آبی مقدار آن حدود ${cvFmtV(st.seaMed,ix)}${unit?" "+unit:""} است که برای همرفت خشکی معتبر نیست و وزنش در آنجا کاهش یافت.`;
    if(cvWMode()==="man") t+=` (وزن دستی: ${FA(st.weight)})`;
    if(st.n>1) t+=` (میانگین ${FA(st.n)} نقشه${st.hours>1?` در ${FA(st.hours)} ساعت`:""})`;
    paras.push(t);
  }
  // ۳) مقایسه با بارش مدل‌ها
  if(comps.length){
    const b=comps[0], q=x=>FA(Math.round(x*100))+"٪";
    let t=`مقایسه با بارش مدل‌ها (بارش در تحلیل دخالت نداشته است): بارش ${b.model} بیشترین هم‌خوانی را با شرایط شاخص‌ها دارد؛ ${q(b.hit)} از پهنهٔ بارشی آن در نواحی با احتمال همرفت بیش از ۲۰٪ است و ${q(b.cover)} از این نواحی را بارش می‌پوشاند (همبستگی ${FA(b.r.toFixed(2))}).`;
    for(const c of comps.slice(1)) t+=` ${c.model}: ${q(c.hit)} بارش در نواحی مساعد، پوشش ${q(c.cover)}، همبستگی ${FA(c.r.toFixed(2))}${c.hit<0.4?" — بخش بزرگی از بارش این مدل در نواحی نامساعد از نظر شاخص‌هاست":""}.`;
    if(comps.length>1 && comps[0].score-comps[comps.length-1].score<0.05) t+=" اختلاف هم‌خوانی مدل‌ها ناچیز است.";
    paras.push(t);
  } else paras.push("مقایسه با بارش مدل‌ها انجام نشد، چون نقشهٔ بارشی بارگذاری نشده است.");
  return paras;
}
// نمودار خطی مطلوبیت هر شاخص در بخش‌های منطقه (هر خط = یک شاخص)
const CV_SERIES=["#2a78d6","#eb6834","#1baf7a","#eda100","#e87ba4","#008300","#4a3aa7","#e34948"];
function cvChart(idxStats, pSec, SEC, secOK, regionFa){
  const cats=SEC.map((n,k)=>k).filter(k=>secOK[k]); if(cats.length<2 || !idxStats.length) return null;
  const W=1100, Hc=560, sc=2, c=document.createElement("canvas"); c.width=W*sc; c.height=Hc*sc; const x=c.getContext("2d"); x.scale(sc,sc);
  x.fillStyle="#fff"; x.fillRect(0,0,W,Hc);
  const ser=idxStats.map((st,i)=>({name:st.short||st.name, color:CV_SERIES[i%8], dash:i>=8?[7,4]:[], mk:Math.floor(i/8)%3, vals:cats.map(k=>st.secs[k].fav)}));
  const L=70, R=W-30, T=64, B=Hc-150, X=j=>L+(R-L)*(cats.length===1?0.5:j/(cats.length-1)), Y=v=>B-(B-T)*Math.max(0,Math.min(100,v))/100;
  x.direction="rtl"; x.textBaseline="alphabetic";
  x.fillStyle="#1d2433"; x.font=`19px ${FT.titr}`; x.textAlign="right"; x.fillText(`مطلوبیت شاخص‌های همرفت در بخش‌های ${regionFa||"منطقه"}`, R, 32);
  x.fillStyle="#5b6577"; x.font=`13px ${FT.body}`; x.fillText("۰٪ = نامساعد · ۵۰٪ = مساعد · ۱۰۰٪ = ایده‌آل (بر پایهٔ آستانه‌های استاندارد هر شاخص؛ میانگین روی خشکی‌های هر بخش)", R, 52);
  for(const v of [0,25,50,75,100]){ x.strokeStyle=v===50?"#9aa3b2":"#e6e8ec"; x.lineWidth=1; x.setLineDash(v===50?[5,4]:[]); x.beginPath(); x.moveTo(L,Y(v)); x.lineTo(R,Y(v)); x.stroke(); x.setLineDash([]);
    x.fillStyle="#5b6577"; x.font=`12px ${FT.body}`; x.textAlign="right"; x.fillText(FA(v)+"٪", L-8, Y(v)+4); }
  x.fillStyle="#5b6577"; x.font=`12px ${FT.body}`; x.textAlign="left"; x.fillText("آستانهٔ مساعد", L+4, Y(50)-5);
  x.textAlign="center"; x.font=`14px ${FT.body}`; x.fillStyle="#1d2433"; cats.forEach((k,j)=>x.fillText(SEC[k], X(j), B+22));
  const marker=(px,py,mk,col)=>{ x.fillStyle=col; x.strokeStyle="#fff"; x.lineWidth=2; x.beginPath();
    if(mk===0) x.arc(px,py,4.5,0,7); else if(mk===1) x.rect(px-4.5,py-4.5,9,9); else { x.moveTo(px,py-5.5); x.lineTo(px+5.5,py+4.5); x.lineTo(px-5.5,py+4.5); x.closePath(); } x.fill(); x.stroke(); };
  // احتمال ترکیبی: خط مرجع خاکستری
  const pv=cats.map(k=>pSec[k]);
  x.strokeStyle="#6b7280"; x.lineWidth=3; x.setLineDash([2,5]); x.lineCap="round"; x.beginPath(); pv.forEach((v,j)=>{ if(!(v===v)) return; j?x.lineTo(X(j),Y(v)):x.moveTo(X(j),Y(v)); }); x.stroke(); x.setLineDash([]);
  for(const s_ of ser){ x.strokeStyle=s_.color; x.lineWidth=2; x.setLineDash(s_.dash); x.beginPath(); let st=false;
    s_.vals.forEach((v,j)=>{ if(!(v===v)){ st=false; return; } if(!st){ x.moveTo(X(j),Y(v)); st=true; } else x.lineTo(X(j),Y(v)); }); x.stroke(); x.setLineDash([]);
    s_.vals.forEach((v,j)=>{ if(v===v) marker(X(j),Y(v),s_.mk,s_.color); }); }
  // راهنما
  const items=ser.map(s_=>({t:s_.name, col:s_.color, dash:s_.dash, mk:s_.mk})).concat([{t:"احتمال ترکیبی همرفت", col:"#6b7280", dash:[2,5], mk:-1}]);
  x.font=`13px ${FT.body}`; let lx=R, ly=B+52;
  for(const it of items){ const w=x.measureText(it.t).width+46; if(lx-w<L-40){ lx=R; ly+=24; }
    x.strokeStyle=it.col; x.lineWidth=it.mk<0?3:2; x.setLineDash(it.dash); x.beginPath(); x.moveTo(lx-24,ly-4); x.lineTo(lx,ly-4); x.stroke(); x.setLineDash([]); if(it.mk>=0) marker(lx-12,ly-4,it.mk,it.col);
    x.fillStyle="#1d2433"; x.textAlign="right"; x.fillText(it.t, lx-30, ly); lx-=w+12; }
  return c;
}
// کادر نقشه نباید نوار رنگ، تیتر یا حاشیه را در بر بگیرد: بریدن از طرف نوار رنگ و چسباندن به خط قاب
function cvTightFrame(m, T){
  const d=m.data, W=m.w, H=m.h, r=T.bar.rect, hz=T.bar.orient==="h", L=(x,y)=>{ const i=(y*W+x)*4; return 0.299*d[i]+0.587*d[i+1]+0.114*d[i+2]; };
  const ovX = r[0]<T.fx1 && r[2]>T.fx0, ovY = r[1]<T.fy1 && r[3]>T.fy0;
  if(hz && ovX){ const cy=(r[1]+r[3])/2;
    if(cy > (T.fy0+T.fy1)/2 && T.fy1 > r[1]-4) T.fy1 = Math.max(T.fy0+50, r[1]-6);
    else if(cy <= (T.fy0+T.fy1)/2 && T.fy0 < r[3]+4) T.fy0 = Math.min(T.fy1-50, r[3]+6); }
  if(!hz && ovY){ const cx=(r[0]+r[2])/2;
    if(cx > (T.fx0+T.fx1)/2 && T.fx1 > r[0]-4) T.fx1 = Math.max(T.fx0+50, r[0]-6);
    else if(cx <= (T.fx0+T.fx1)/2 && T.fx0 < r[2]+4) T.fx0 = Math.min(T.fx1-50, r[2]+6); }
  // خط قاب: سطر/ستون تیرهٔ سرتاسری نزدیک لبه‌ها (تا ۱۵٪ از هر لبه به داخل)
  const rowDark=y=>{ let c=0; for(let x=T.fx0;x<=T.fx1;x++) if(L(x,y)<90) c++; return c/(T.fx1-T.fx0+1); };
  const colDark=x=>{ let c=0; for(let y=T.fy0;y<=T.fy1;y++) if(L(x,y)<90) c++; return c/(T.fy1-T.fy0+1); };
  const sh=Math.round(0.15*(T.fy1-T.fy0)), sw=Math.round(0.15*(T.fx1-T.fx0));
  for(let y=T.fy1;y>=T.fy1-sh;y--) if(rowDark(y)>0.85){ T.fy1=y-1; break; }
  for(let y=T.fy0;y<=T.fy0+sh;y++) if(rowDark(y)>0.85){ T.fy0=y+1; break; }
  for(let x=T.fx1;x>=T.fx1-sw;x--) if(colDark(x)>0.85){ T.fx1=x-1; break; }
  for(let x=T.fx0;x<=T.fx0+sw;x++) if(colDark(x)>0.85){ T.fx0=x+1; break; }
  return T;
}
function cvProfile(m){
  const T=cvTightFrame(m, detectTemplate([m]));
  const key=`cvc_${T.W}x${T.H}_${T.fx0}_${T.fy0}_${T.fx1}_${T.fy1}_${T.fp.length}_${++cv.seq}`;
  const prof={key, name:"آزاد", custom:true, sigs:null, topStrip:false, useCap:false, keepBorders:true, invalid(){ return this.inv||[]; },
    W:T.W, H:T.H, fx0:T.fx0, fx1:T.fx1, fy0:T.fy0, fy1:T.fy1, bg:T.bg, bgSep:T.bgSep, barStart:T.bgSep?1:0, segCenters:T.segCenters, segs:T.segs, bar:T.bar, inv:T.inv, fp:T.fp, tol:T.tol, T,
    pal:(T.bgSep?[T.bg]:[]).concat(T.colors), edges:null, models:[m], ax:0, bx:1, ay:0, by:1, staticDirty:true};
  if(!T.bgSep){ let bi=0, bd=1e9; T.colors.forEach((c,k)=>{ const dd=cdist(c,T.bg); if(dd<bd){ bd=dd; bi=k; } }); prof.bgIdx=bi; } else prof.bgIdx=0;
  PROFILES[key]=prof;
  return prof;
}
function cvSetEdges(m, txt){
  const prof=m.prof, v=parseEdges(txt), K=prof.T.colors.length;
  const asc=v&&v.every((x,k)=>!k || x>v[k-1]), desc=v&&v.every((x,k)=>!k || x<v[k-1]);
  if(!v || v.length!==K+1 || !(asc||desc)) return `${FA(K+1)} عدد پیوسته صعودی یا نزولی لازم است: مرز هر ${FA(K)} رنگ نوار به ترتیب از اولین رنگ (برای بازهٔ باز: -inf و +)`;
  m.v=v; m.desc=desc; m.edgesTxt=txt; prof.edges = prof.T.bgSep ? [v[0]-1, ...v] : v; prof.staticDirty=true; return "";
}
function cvRemember(m){ store.set("cv.fp."+m.prof.fp, {edges:m.edgesTxt, type:m.type, bgAbove:m.bgAbove, unit:m.unit}); }
// مقدار نمایندهٔ هر کلاس رنگ (وسط بازه؛ بازه‌های باز با گام همسایه)
function cvRep(m){
  if(m.desc){ const r=cvRep({v:m.v.map(x=>-x), bgAbove:!m.bgAbove, prof:m.prof}); return r.map(x=>-x); }
  const v=m.v, K=v.length-1, out=[];
  for(let j=0;j<K;j++){ const lo=v[j], hi=v[j+1];
    if(isFinite(lo)&&isFinite(hi)) out.push((lo+hi)/2);
    else if(isFinite(lo)){ const st=j>0&&isFinite(v[j-1])?lo-v[j-1]:Math.max(1,Math.abs(lo)*0.2); out.push(lo+st/2); }
    else { const st=j+2<=K&&isFinite(v[j+2])?v[j+2]-hi:Math.max(1,Math.abs(hi)*0.2); out.push(hi-st/2); } }
  if(m.prof.T.bgSep){
    const st0=isFinite(v[1])&&isFinite(v[0])?v[1]-v[0]:1, stK=isFinite(v[K])&&isFinite(v[K-1])?v[K]-v[K-1]:1;
    const bgv = m.bgAbove ? (isFinite(v[K]) ? v[K]+stK/2 : out[K-1]+stK) : (isFinite(v[0]) ? v[0]-st0/2 : out[0]-st0);
    return [bgv, ...out];
  }
  return out;
}

// رفع ابهام نوع شاخص از روی واژه‌های دیگر عنوان، تراز و بازهٔ اعداد نوار رنگ
function cvResolveType(m, bt){
  const kb=(bt&&bt.kb)||{}, has=k=>kb[k]>=0.62, lv=m.level||"", fin=(m.v||[]).filter(isFinite), mid=fin.length?fin[Math.floor(fin.length/2)]:NaN;
  const old=m.type;
  if((m.type==="cape"||m.type==="precip"||m.type==="cprec") && bt.w==="Convective" && has("precip")) m.type="cprec";
  if(m.type==="precip" && has("cape") && kb.cape>=0.62 && /convective/i.test(bt.w||"")) m.type="cprec";
  if(m.type==="t500"||m.type==="gph500"){ if(mid===mid) m.type = mid>300 ? "gph500" : "t500"; }
  if(m.type==="jet"){ if(/۱۰ متری/.test(lv)) m.type="gust"; }
  if(m.type==="srh" && /۰ تا ۱/.test(lv)) m.type="srh01";
  if(m.type!==old){ m.bgAbove=!!CV_IDX[m.type].bgAbove; m.typeSrc=(m.typeSrc||"")+" + تراز/نوار"; }
  const U=CV_IDX[m.type].units; if(U && bt && bt.unit && U[bt.unit]) m.unit=bt.unit; else if(U && !U[m.unit]) m.unit=Object.keys(U)[0];
}
const CV_LOCK=mkLock();
function cvAdd(files, role="idx"){ files=[...files]; return CV_LOCK(()=>cvAdd_(files, role)); }
async function cvAdd_(files, role="idx"){
  files=[...files].filter(isImg); if(!files.length) return; const gen=cv.gen||0;
  const prev=P?P.key:null;
  if(!CV_OCR_T) await cvOcrFonts();
  for(const f of files){
    if((cv.gen||0)!==gen) break;
    const m={file:f, name:f.name.replace(/\.[^.]+$/,""), weight:1, unit:"m/s", bgAbove:false, role};
    try{
      cvStatus(`خواندن ${f.name}…`, 0.02); await tick();
      Object.assign(m, await readFile(f));
      m.prof=cvProfile(m); const nj=nwpMeta(m);
      try{ const full=document.createElement("canvas"); full.width=m.w; full.height=m.h; full.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(m.data), m.w, m.h),0,0);
        const sc=Math.min(1, 460/m.w), th=document.createElement("canvas"); th.width=Math.round(m.w*sc); th.height=Math.round(m.h*sc); th.getContext("2d").drawImage(full,0,0,th.width,th.height); m.thumb=th; m.thSc=sc; }catch(e){}
      const learned=learnedFP("cv.fp.", m.prof.fp), gs=guessScale(m.prof.T.colors, m.prof.T);
      const byName=cvGuessType(f.name), byTitle=cvTitleType(m)||{};
      m.type = byName || (gs && !gs.kind && !(byTitle.k && byTitle.s>=0.8) ? "precip" : null) || (byTitle.k) || (learned&&learned.type) || (gs && gs.kind==="rh" ? "rh" : gs && !gs.kind ? "precip" : "custom");
      if(role==="cmp") m.type="precip";
      else if(CV_IDX[m.type].cmp){ m.role="cmp"; m.moved=true; }
      // نام منطقه (پانویس weather.us؛ نقشه‌های WeatherBELL ایران‌اند) و نام مدل
      m.region = (m.w===984&&m.h===808) ? "Iran" : byTitle.region;
      if(!m.region && m.w===760 && m.h===760) m.regionFa = wuSigRegion(m.data);
      m.level = byTitle.level ? CV_LEVELS[byTitle.level] : null;
      m.model = byTitle.model ? CV_MODELS[byTitle.model] : null;
      if(!m.model){ const key=(m.w===760&&m.h===760)?"wu":(m.w===984&&m.h===808)?"wb":null;
        if(key){ await useProfile(key); const nm=recognize(m.data); if(nm) m.model=nm; } }
      if(!m.model){ const g=guessModelName(f.name); if(/^(ECMWF|GFS|ICON|UKMO|GEM|ARPEGE|ACCESS|JMA|NAVGEM|CFS|ERA5|WRF)$/.test(g)) m.model=g; }
      if(nj){ m.type=NWP_CV[nj.p]||(/^(p|s)/.test(nj.p)?"precip":"custom"); m.region=nj.g==="fars"?"Fars":"Iran"; m.regionFa=NWP_REG_FA[nj.g]; m.model=nj.m; }
      m.typeSrc = nj ? "نشانهٔ نقشهٔ MetStat" : byName ? "نام فایل" : byTitle.k ? `عنوان نقشه («${byTitle.w}»)` : (learned&&learned.type) ? "قالب یادگرفته" : "";
      if(byTitle && byTitle.unit && CV_IDX.shear.units[byTitle.unit]) m.unit=byTitle.unit;
      m.bgAbove = learned && learned.bgAbove!==undefined ? learned.bgAbove : !!CV_IDX[m.type].bgAbove;
      if(learned && learned.unit) m.unit=learned.unit;
      let txt = (gs&&gs.kind&&gs.edges) || (learned&&learned.edges) || (gs&&gs.edges) || "", rd=null;
      m.edgeSrc = learned&&learned.edges ? "یادگرفته" : gs ? "مقیاس آشنا" : "";
      if(nj){ txt=nj.e; m.edgeSrc="از نشانهٔ نقشهٔ MetStat"; }
      if(!txt){ try{ rd=cvReadBar(m); }catch(e){ console.warn("cvReadBar",e); } if(rd){ txt=rd.txt; m.edgeSrc = `خوانده از نوار رنگ (${FA(rd.n)} برچسب${rd.interp?`، ${FA(rd.interp)} مرز درون‌یابی`:""}) — بررسی کنید`; } }
      if(txt){ const e=cvSetEdges(m, txt); if(e){ m.note=e; if(rd){ m.v=null; m.edgesTxt=txt; } } } else m.note="اعداد نوار رنگ خوانده نشد؛ دستی وارد کنید (یک بار برای این قالب)";
      try{ const t=readTimes(m); if(t && t.end) m.times=t; }catch(e){}
      if(!byName && role!=="cmp" && !nj) cvResolveType(m, byTitle);
    }catch(e){ console.error(e); m.bad=true; m.note="قالب نقشه تشخیص داده نشد: "+e.message; }
    if((cv.gen||0)!==gen) break;
    cv.maps.push(m);
  }
  // نقشه‌های هم‌اندازه از یک سایت‌اند: بزرگ‌ترین کادر تشخیص‌داده‌شده برای همه به کار می‌رود
  const groups={}; for(const m of cv.maps) if(!m.bad && m.prof) (groups[m.w+"x"+m.h]=groups[m.w+"x"+m.h]||[]).push(m);
  // کادر مشترکِ نقشه‌های هم‌اندازه = میانهٔ کادرها (نه بزرگ‌ترین؛ یک تشخیص اشتباه نباید به همه سرایت کند)
  for(const g of Object.values(groups)){ if(g.length<2) continue; const area=p=>(p.fx1-p.fx0)*(p.fy1-p.fy0), big=g.map(m=>m.prof).reduce((a,b)=>area(b)>area(a)?b:a);
    const med=k=>{ if(g.length===2) return big[k]; const a=g.map(m=>m.prof[k]).sort((x,y)=>x-y); return a[(a.length-1)>>1]; };
    const F={fx0:med("fx0"), fy0:med("fy0"), fx1:med("fx1"), fy1:med("fy1")};
    for(const m of g){ const p=m.prof; if(["fx0","fy0","fx1","fy1"].some(k=>p[k]!==F[k])){ Object.assign(p,F); p.staticDirty=true; } } }
  shareEdges(cv.maps);
  if(prev && PROFILES[prev]) await useProfile(prev); else P=undefined;
  cvDrawList(); cvSchedule(50);
}
function cvDrawList(){
  $("cvList").innerHTML=""; $("cvPList").innerHTML="";
  const firstIdx=cv.maps.findIndex(m=>m.role!=="cmp" && !m.bad);
  cv.maps.forEach((m,idx)=>{
    const box = m.role==="cmp" ? $("cvPList") : $("cvList");
    const row=document.createElement("div"); row.className="cvrow";
    const l1=document.createElement("div"); l1.className="l1";
    const nm=document.createElement("b"); nm.textContent=(idx===firstIdx?"★ ":"")+m.file.name; nm.title=idx===firstIdx?"نقشهٔ مرجع: قالب و کادر خروجی از این نقشه است":m.file.name;
    const sel=document.createElement("select"); sel.setAttribute("aria-label","نوع شاخص");
    sel.innerHTML=Object.entries(CV_IDX).filter(([k,v])=>!v.cmp && !v.haz).map(([k,v])=>`<option value="${k}">${v.n}</option>`).join(""); sel.value=m.type||"custom"; sel.disabled=!!m.bad;
    sel.onchange=()=>{ m.type=sel.value; m.bgAbove=!!CV_IDX[m.type].bgAbove; if(m.v) cvRemember(m); cvDrawList(); cvThrPanel(); cvSchedule(100); };
    let first=sel;
    if(m.role==="cmp"){ first=document.createElement("input"); first.className="wt"; first.style.width="96px"; first.value=m.model||""; first.placeholder="نام مدل"; first.setAttribute("aria-label","نام مدل");
      first.onchange=()=>{ m.model=first.value.trim()||null; cvDrawInputs(); cvSchedule(100); }; }
    const wt=document.createElement("input"); wt.className="wt"; wt.type="number"; wt.min="0"; wt.step="0.5"; wt.value=m.weight; wt.title="وزن نسبی این شاخص"; wt.setAttribute("aria-label","وزن");
    wt.onchange=()=>{ m.weight=Math.max(0,parseFloat(wt.value)||0); cvSchedule(100); };
    const del=document.createElement("button"); del.className="del"; del.type="button"; del.textContent="×"; del.setAttribute("aria-label","حذف "+m.file.name);
    del.onclick=()=>{ cv.maps.splice(idx,1); cvDrawList(); cvThrPanel(); cvSchedule(50); };
    l1.append(nm, first, del);
    const l2=document.createElement("div"); l2.className="l2";
    if(!m.bad){
      const ed=document.createElement("input"); ed.className="ed"; ed.value=m.edgesTxt||""; ed.placeholder=`${FA(m.prof.T.colors.length+1)} عدد: حد پایین هر رنگ و حد بالای آخرین`;
      ed.title="اعداد نوار رنگ این نقشه، به ترتیب از اولین رنگ"; if(!m.v) ed.style.borderColor="var(--warn)";
      ed.onchange=()=>{ const e=cvSetEdges(m, ed.value); m.note=e; if(!e){ cvRemember(m); try{ const n=cvLearnBar(m, ed.value); if(n&&n.length) m.edgeSrc=`دستی (شکل ${FA(n.length)} رقم برای خواندن خودکار بعدی یاد گرفته شد)`; else m.edgeSrc="دستی"; }catch(err){ console.warn(err); } shareEdges(cv.maps); } cvDrawList(); cvSchedule(50); };
      l2.append(ed);
      if(m.prof.T.bgSep){ const bg=document.createElement("select"); bg.innerHTML=`<option value="0">زمینهٔ بی‌رنگ: کمتر از کمترین عدد</option><option value="1">زمینهٔ بی‌رنگ: بیشتر از بیشترین عدد</option>`; bg.value=m.bgAbove?"1":"0";
        bg.onchange=()=>{ m.bgAbove=bg.value==="1"; if(m.v) cvRemember(m); cvSchedule(50); }; l2.append(bg); }
      if(CV_IDX[m.type].units){ const un=document.createElement("select"); un.innerHTML=Object.keys(CV_IDX[m.type].units).map(u=>`<option>${u}</option>`).join(""); un.value=m.unit; un.onchange=()=>{ m.unit=un.value; if(m.v) cvRemember(m); cvSchedule(50); }; l2.append(un); }
    }
    const sm=document.createElement("small"); sm.textContent=(m.note||(m.v?`${FA(m.w)}×${FA(m.h)} · ${FA(m.prof.T.colors.length)} رنگ · واحد ${CV_IDX[m.type].units?m.unit:CV_IDX[m.type].u||"—"}`:""))+(m.moved?" · نقشهٔ بارش است؛ به فهرست مقایسه منتقل شد":"")+(m.role==="cmp"&&m.model?` · مدل ${m.model}`:"")+(m.typeSrc&&!m.bad&&m.role!=="cmp"?` · نوع از ${m.typeSrc}`:(!m.bad&&!m.bad&&m.type==="custom"?" · نوع شاخص شناخته نشد؛ از فهرست انتخاب کنید":"")); if(m.bad||!m.v) sm.className="bad";
    row.append(l1, l2, sm); box.append(row);
  });
  $("cvEmpty").hidden = cv.maps.length>0;
  $("cvPDrop").classList.toggle("need", cv.maps.some(m=>m.role!=="cmp") && !cv.maps.some(m=>m.role==="cmp"));
  cvWeightsPanel(); cvDrawInputs();
}
// وزن دستی شاخص‌ها؛ پیش‌فرض همه برابر (۱)
function cvWeightsPanel(){
  const box=$("cvW"); if(!box) return; const types=[...new Set(cv.maps.filter(m=>m.role!=="cmp" && !m.bad).map(m=>m.type))];
  const mode=cvWMode(), warm=cvWarmNow();
  box.innerHTML=`<label>روش وزن‌دهی<select id="cvWMode"><option value="sci">علمی-فصلی (خودکار)</option><option value="man">دستی (نظر کاربر)</option><option value="eq">برابر</option></select></label>
    <p class="hint" style="margin:2px 0 6px">${mode==="sci"?`وزن‌ها بر اساس مهارت شاخص‌ها در ${warm?"فصل گرم":"فصل سرد"} (مطالعات اعتبارسنجی شاخص‌های ناپایداری) تنظیم شده‌اند؛ برای تغییر، «دستی» را انتخاب کنید.`:mode==="man"?"وزن هر شاخص را جابه‌جا کنید؛ عدد کم‌رنگ، وزن علمی همان شاخص است.":"همهٔ شاخص‌ها وزن برابر دارند."}</p>`;
  box.querySelector("#cvWMode").value=mode;
  box.querySelector("#cvWMode").onchange=e=>{ store.set("cv.wmode", e.target.value); cvWeightsPanel(); cvSchedule(100); };
  if(!types.length){ box.insertAdjacentHTML("beforeend",`<p class="hint" style="margin:0">با افزودن نقشهٔ شاخص‌ها، وزن هر کدام اینجا تنظیم می‌شود.</p>`); return; }
  for(const t of types){ const row=document.createElement("div"); row.className="cvwrow";
    const w=cvIdxW(t, warm), sci=cvSciW(t, warm), lb=document.createElement("span"); lb.textContent=CV_IDX[t].n.replace(/\s*\(.*\)/,""); lb.title=CV_GROUP[CV_IDX[t].g];
    const rg=document.createElement("input"); rg.type="range"; rg.min="0"; rg.max="3"; rg.step="0.1"; rg.value=w; rg.disabled=mode!=="man"; rg.setAttribute("aria-label","وزن "+lb.textContent);
    const nb=document.createElement("input"); nb.type="number"; nb.min="0"; nb.max="10"; nb.step="0.1"; nb.value=w; nb.disabled=mode!=="man"; nb.setAttribute("aria-label","وزن عددی "+lb.textContent);
    const sc=document.createElement("small"); sc.className="sci"; sc.textContent=`علمی ${FA(sci)}`;
    const set=v=>{ const o=store.get("cv.wman",{}); o[t]=Math.max(0,parseFloat(v)||0); store.set("cv.wman",o); rg.value=Math.min(3,o[t]); nb.value=o[t]; cvSchedule(250); };
    rg.oninput=()=>set(rg.value); nb.onchange=()=>set(nb.value);
    row.append(lb, rg, nb, sc); box.append(row); }
}
// پیش‌نمایش هر نقشهٔ ورودی: کادر نقشه (آبی)، نوار رنگ (نارنجی)، رنگ‌های خوانده‌شده و وضعیت
function cvDrawInputs(){
  const box=$("cvInputs"); box.innerHTML=""; $("cvInBox").hidden=!cv.maps.length; $("cvInCount").textContent=cv.maps.length?`(${FA(cv.maps.length)})`:"";
  const needs=cv.maps.some(m=>m.bad||!m.v); if(needs || !cv.res) $("cvInBox").open=true; else if(!$("cvInBox").dataset.user) $("cvInBox").open=false;
  cv.maps.forEach((m,idx)=>{
    const fg=document.createElement("figure"), c=document.createElement("canvas"), cap=document.createElement("figcaption");
    if(m.thumb){ c.width=m.thumb.width; c.height=m.thumb.height; const x=c.getContext("2d"); x.drawImage(m.thumb,0,0);
      if(m.prof){ const sc=m.thSc, p=m.prof; x.lineWidth=2; x.strokeStyle="#1f6fe5"; x.strokeRect(p.fx0*sc, p.fy0*sc, (p.fx1-p.fx0)*sc, (p.fy1-p.fy0)*sc);
        const r=p.bar&&p.bar.rect; if(r){ x.strokeStyle="#ff8c14"; x.lineWidth=2.5; x.strokeRect(r[0]*sc-2, r[1]*sc-2, (r[2]-r[0])*sc+4, (r[3]-r[1])*sc+4); } } }
    else { c.width=230; c.height=150; }
    fg.append(c);
    if(!m.bad && m.prof){ const ch=document.createElement("div"); ch.className="chips"; const cols=m.prof.T.colors;
      cols.forEach((col,k)=>{ const sp=document.createElement("span"); sp.style.background=`rgb(${col})`; sp.textContent = m.v ? (isFinite(m.v[k])?fmtN(m.v[k]):(m.v[k]<0?"−∞":"+")) : FA(k+1); sp.title=m.v?`${m.v[k]} تا ${m.v[k+1]}`:`رنگ ${k+1}`; ch.append(sp); });
      fg.append(ch); }
    const st = m.bad ? `<span class="bad">⚠ ${m.note||"قالب نقشه تشخیص داده نشد"}</span>`
      : !m.v ? `<span class="bad">⚠ ${FA(m.prof.T.colors.length)} رنگ در نوار پیدا شد؛ ${FA(m.prof.T.colors.length+1)} عدد نوار رنگ را در فهرست کناری وارد کنید (حد پایین هر رنگ و در آخر حد بالا)</span>`
      : `<span class="ok">✓ ${CV_IDX[m.type].n}${m.typeSrc?" (از "+m.typeSrc+")":""}</span>${m.edgeSrc?`<br><small>اعداد نوار: ${m.edgeSrc}</small>`:""}`;
    cap.innerHTML=`<b></b>${m.role==="cmp"?`<span class="tagc">مقایسه${m.model?" · "+m.model:""}</span> `:""}${st}`; cap.querySelector("b").textContent=m.file.name;
    fg.append(cap); if(m.bad||!m.v) fg.className="need";
    fg.onclick=()=>{ const row=$("cvList").children[idx], ed=row&&row.querySelector("input.ed"); if(ed){ ed.scrollIntoView({block:"center",behavior:"smooth"}); ed.focus(); } };
    box.append(fg);
  });
}
const fmtN=v=>{ const a=Math.abs(v); return FA(a>=100||Number.isInteger(v)?Math.round(v):+v.toFixed(a<1?2:1)); };
function cvRefTable(){
  const box=$("cvRef"); if(!box || box.dataset.done) return; box.dataset.done=1;
  box.innerHTML=`<table class="cvref"><thead><tr><th>شاخص</th><th>گروه</th><th>بی‌اثر ← مساعد ← ایده‌آل</th><th>تفسیر استاندارد</th></tr></thead><tbody>`+
    Object.entries(CV_IDX).filter(([k,ix])=>k!=="custom" && !ix.haz).map(([k,ix])=>`<tr><td>${ix.n}${ix.u&&!ix.rel?` <small>(${ix.u})</small>`:""}${ix.sea?" 🌊":""}</td><td>${CV_GROUP[ix.g]}</td><td>${ix.occ?ix.occ.map(v=>"\u2068"+FA(v)+(ix.rel?"٪":"")+"\u2069").join(" ← "):"— (فقط اثر بر شدت)"}</td><td>${ix.ref||""}</td></tr>`).join("")+
    `</tbody></table><p class="hint" style="margin:6px 0 0">🌊 = روی دریا (مثل خلیج فارس) معتبر نیست؛ وزن این شاخص‌ها روی آب کم می‌شود. منابع: SPC/NWS، Gálvez & Davison (WPC)، George (1960)، Miller (1972).</p>`;
}
function cvThrPanel(){ cvRefTable();
  const box=$("cvThr"), T=cvThr(), types=[...new Set(cv.maps.filter(m=>!m.bad).map(m=>m.type))];
  if(!types.length){ box.innerHTML=`<p class="hint" style="margin:0">با افزودن نقشه‌ها، آستانه‌های همان شاخص‌ها اینجا می‌آید.</p>`; return; }
  const inp=(k,part,i,v)=>`<input type="number" step="any" data-k="${k}" data-p="${part}" data-i="${i}" value="${v??""}" ${v===null||v===undefined?"disabled":""}>`;
  box.innerHTML=`<div class="cvthr"><b>شاخص</b><b>بی‌اثر ۰٪</b><b>مساعد ۵۰٪</b><b>ایده‌آل ۱۰۰٪</b><b>شدت ضعیف</b><b>شدت شدید</b>`+
    types.map(k=>{ const t=T[k], ix=CV_IDX[k], o=t.occ&&t.occ.length===3?t.occ:(t.occ?[t.occ[0],(t.occ[0]+t.occ[1])/2,t.occ[1]]:null);
      return `<span title="${ix.ref||""}">${ix.n}${ix.rel?" (٪ مقیاس)":ix.u?" ("+ix.u+")":""}${ix.sea?" 🌊":""}</span>${inp(k,"occ",0,o&&o[0])}${inp(k,"occ",1,o&&o[1])}${inp(k,"occ",2,o&&o[2])}${inp(k,"sev",0,t.sev&&t.sev[0])}${inp(k,"sev",1,t.sev&&t.sev[1])}`; }).join("")+`</div>`;
  box.querySelectorAll("input").forEach(el=>el.onchange=()=>{ const o=store.get("cv.thr2",{}), k=el.dataset.k, p=el.dataset.p, cur=cvThr()[k][p].slice(); cur[+el.dataset.i]=parseFloat(el.value); o[k]=o[k]||{}; if(p==="occ" && cur.length===2) cur.splice(1,0,(cur[0]+cur[1])/2); o[k][p]=cur; store.set("cv.thr2",o); cvSchedule(100); });
}
function cvSchedule(delay=400){ clearTimeout(cv.timer); cv.timer=setTimeout(()=>CV_LOCK(cvRun), delay); }
// رقومی‌سازی یک نقشه روی کادر خودش
// درون‌یابی وزن‌دار با عکس فاصله (IDW) برای پیکسل‌های نامعتبر (مرز، نوشته، برچسب): w = 1/d^p
function cvIDW(vals, ok, W, H, p, R=12){
  const pw=new Float32Array(2*R*R+1); for(let d2=1;d2<pw.length;d2++) pw[d2]=Math.pow(d2,-p/2);
  const fill=[];
  for(let i=0;i<W*H;i++){ if(ok[i]) continue; const x=i%W, y=(i/W)|0; let sw=0, sv=0, n=0;
    for(let r=1;r<=R && n<12;r++) for(let dy=-r;dy<=r;dy++){ const yy=y+dy; if(yy<0||yy>=H) continue; const st=(dy===-r||dy===r)?1:2*r;
      for(let dx=-r;dx<=r;dx+=st){ const xx=x+dx; if(xx<0||xx>=W) continue; const j=yy*W+xx; if(!ok[j]) continue; const w=pw[dx*dx+dy*dy]; sw+=w; sv+=w*vals[j]; n++; } }
    if(n) fill.push(i, sv/sw); }
  for(let k=0;k<fill.length;k+=2){ vals[fill[k]]=fill[k+1]; ok[fill[k]]=1; }
}
async function cvDigitize(m){
  await useProfile(m.prof.key);
  if(m.prof.staticDirty){ computeStatic(m.prof.models); m.prof.staticDirty=false; }
  const rects=P.invalid(m.data), cls=classify(m.data, Infinity, rects), rep=cvRep(m), vals=new Float32Array(N), ok=new Uint8Array(N);
  // سفیدِ خالص (زمینهٔ برچسب شهرها و نوشته‌ها) اگر در پالت نیست، داده نیست؛ از اطراف پر می‌شود
  if(!P.pal.some(c=>c[0]>=246&&c[1]>=246&&c[2]>=246)){ const d=m.data;
    for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x, q=((y+P.fy0)*P.W+x+P.fx0)*4; if(d[q]>=249&&d[q+1]>=249&&d[q+2]>=249) cls[i]=-1; } }
  let nv=0; for(let i=0;i<N;i++) if(cls[i]>=0 && rep[cls[i]]===rep[cls[i]]){ vals[i]=rep[cls[i]]; ok[i]=1; nv++; }
  cvIDW(vals, ok, FW, FH, Math.max(0.5, parseFloat($("cvIdwP").value)||2));
  inpaint(vals, ok);
  const sc = CV_IDX[m.type].units ? (CV_IDX[m.type].units[m.unit]||1) : 1;
  if(sc!==1) for(let i=0;i<N;i++) vals[i]*=sc;
  if(CV_IDX[m.type].abs) for(let i=0;i<N;i++) vals[i]=Math.abs(vals[i]);
  if(CV_IDX[m.type].nn) for(let i=0;i<N;i++) if(vals[i]<0) vals[i]=0;
  // زمینهٔ بی‌رنگ CIN = جایی که لایهٔ ناپایدار وجود ندارد → مقدار تعریف‌نشده، نه «بدون بازدارندگی»
  if(CV_IDX[m.type].bgNull){ const d=m.data;
    for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const i=y*FW+x, q=((y+P.fy0)*P.W+x+P.fx0)*4; if((P.bgSep && cls[i]===0) || (d[q]>=244&&d[q+1]>=244&&d[q+2]>=244)) vals[i]=NaN; } }
  const raw = (CV_IDX[m.type].anom || CV_IDX[m.type].rel) ? vals.slice() : null;
  if(CV_IDX[m.type].anom){ const a=[]; for(let i=0;i<N;i+=7) if(vals[i]===vals[i]) a.push(vals[i]); a.sort((x,y)=>x-y);
    if(a.length>10) for(let i=0;i<N;i++){ const v=vals[i]; if(!(v===v)) continue; let lo=0, hi=a.length; while(lo<hi){ const md=(lo+hi)>>1; if(a[md]<v) lo=md+1; else hi=md; } vals[i]=100*lo/a.length; } }
  if(CV_IDX[m.type].rel){ const fin=m.v.filter(isFinite), lo=Math.min(...fin), hi=Math.max(...fin), d=(hi-lo)||1; for(let i=0;i<N;i++) vals[i]=100*(vals[i]-lo)/d; }
  return {vals, raw, cls, FW, FH, fx0:P.fx0, fy0:P.fy0, validFrac:nv/N};
}
// زمین‌مرجع معلوم برای قالب‌های ثابت (اندازهٔ تصویر + نام منطقه)
const CV_GEO_KNOWN={"760x760:Iran":null, "760x760:Fars":[-4393.74,89.99,3352.58,-103.44], "984x808:Iran":null};
async function cvGeo(m){
  if(m.geoDone) return m.geo;
  { const zn=(m.region&&CV_REGIONS[m.region])||m.regionFa; if(m.w===760&&m.h===760&&zn&&WU_ZOOM_GEO[zn]&&zn!=="ایران"){ m.geo=WU_ZOOM_GEO[zn].slice(); m.geoDone=true; return m.geo; } }
  if(!CV_GEO_KNOWN["760x760:Iran"]){ CV_GEO_KNOWN["760x760:Iran"]=WU_GEO; CV_GEO_KNOWN["984x808:Iran"]=[PROFILES.wb.ax,PROFILES.wb.bx,PROFILES.wb.ay,PROFILES.wb.by]; }
  const gk=m.w+"x"+m.h+":"+(m.region||"");
  // قالب‌های ثابت (weather.us و WeatherBELL برش ایران): زمین‌مرجع معلوم است؛ جست‌وجوی مکان لازم نیست
  if(gk==="760x760:Iran" || gk==="984x808:Iran"){ m.geo=CV_GEO_KNOWN[gk].slice(); m.geoDone=true; return m.geo; }
  // نقشهٔ هم‌اندازه و هم‌منطقه با همان کادر که مکانش پیدا شده: همان زمین‌مرجع
  if(m.region){ const pool=[...(cv.maps||[]), ...(wn.maps||[])], o=pool.find(q=>q!==m && q.geoDone && q.geo && q.w===m.w && q.h===m.h && q.region===m.region && q.prof && m.prof && q.prof.fx0===m.prof.fx0 && q.prof.fy0===m.prof.fy0 && q.prof.fx1===m.prof.fx1 && q.prof.fy1===m.prof.fy1);
    if(o){ m.geo=o.geo.slice(); m.geoSrc="قالب هم‌منطقه"; m.geoDone=true; return m.geo; } }
  const tpl = (m.w===984&&m.h===808) ? [PROFILES.wb.ax,PROFILES.wb.bx,PROFILES.wb.ay,PROFILES.wb.by] : (m.w===760&&m.h===760) ? WU_GEO : null;
  try{ const r=await grLocate({maps:[m], prof:m.prof, tplGeo:tpl, W:m.w, H:m.h, hint:null}, m.prof.pal, []); m.geo=r.ok?r.g:null; }catch(e){ console.error(e); m.geo=null; }
  if(m.region){
    if(m.geo) store.set("cvgeo."+gk, m.geo);
    else { const o=cv.maps.find(q=>q!==m && q.geoDone && q.geo && q.w===m.w && q.h===m.h && q.region===m.region);
      m.geo = (o&&o.geo) || store.get("cvgeo."+gk, null) || CV_GEO_KNOWN[gk] || null; if(m.geo) m.geoSrc="قالب هم‌منطقه"; } }
  m.geoDone=true; return m.geo;
}
// هم‌ترازی یک نقشهٔ رقومی‌شده با کادر نقشهٔ مرجع: هم‌قالب → جابه‌جایی پیکسلی؛ قالب دیگر → مختصات جغرافیایی + درون‌یابی دوخطی
async function cvAlign(m, D, ref, rp){
  const RW=rp.fx1-rp.fx0+1, RH=rp.fy1-rp.fy0+1, out=new Float32Array(RW*RH).fill(NaN);
  let same = m.w===ref.w && m.h===ref.h && Math.abs(m.prof.fx0-rp.fx0)<=3 && Math.abs(m.prof.fy0-rp.fy0)<=3 && Math.abs(m.prof.fx1-rp.fx1)<=3 && Math.abs(m.prof.fy1-rp.fy1)<=3;
  // قالب یکسان ولی محدودهٔ جغرافیایی متفاوت (مثلاً ایران و زوم فارس از یک سایت): با مختصات هم‌تراز شود
  if(same && m!==ref && m.region && ref.region && m.region!==ref.region) same=false;
  const zk=q=>q.region||q.regionFa||null;
  if(same && m!==ref && !(zk(m) && zk(m)===zk(ref))){ const ga=await cvGeo(ref), gb=await cvGeo(m);
    if(ga && gb){ const lon=(rp.fx0-ga[0])/ga[1], lat=(rp.fy0-ga[2])/ga[3], lon2=(rp.fx1-ga[0])/ga[1], lat2=(rp.fy1-ga[2])/ga[3];
      const d=Math.max(Math.abs(gb[0]+gb[1]*lon-rp.fx0), Math.abs(gb[2]+gb[3]*lat-rp.fy0), Math.abs(gb[0]+gb[1]*lon2-rp.fx1), Math.abs(gb[2]+gb[3]*lat2-rp.fy1));
      if(d>6) same=false; } }
  if(same){ for(let y=0;y<RH;y++){ const yy=y+rp.fy0-D.fy0; if(yy<0||yy>=D.FH) continue; for(let x=0;x<RW;x++){ const xx=x+rp.fx0-D.fx0; if(xx<0||xx>=D.FW) continue; out[y*RW+x]=D.vals[yy*D.FW+xx]; } } return {out, same:true}; }
  const g0=await cvGeo(ref), g1=await cvGeo(m); if(!g0||!g1) return null;
  const smp=(fx,fy)=>{ const x0=Math.floor(fx), y0=Math.floor(fy), tx=fx-x0, ty=fy-y0; let sv=0, sw=0;
    for(let k=0;k<4;k++){ const dx=k&1, dy=k>>1, w=(dx?tx:1-tx)*(dy?ty:1-ty), xx=x0+dx, yy=y0+dy; if(w<=0||xx<0||yy<0||xx>=D.FW||yy>=D.FH) continue; const v=D.vals[yy*D.FW+xx]; if(v===v){ sv+=v*w; sw+=w; } }
    return sw>0 ? sv/sw : NaN; };
  for(let y=0;y<RH;y++){ const lat=(y+rp.fy0-g0[2])/g0[3], fy=g1[2]+g1[3]*lat-D.fy0;
    for(let x=0;x<RW;x++){ const lon=(x+rp.fx0-g0[0])/g0[1]; out[y*RW+x]=smp(g1[0]+g1[1]*lon-D.fx0, fy); } }
  return {out, same:false};
}

