/* ===== آمار بازدید (فقط روی هاست واقعی؛ نیازمند فایل stats.php کنار index.html) =====
   بدون کوکی و بدون ذخیرهٔ IP؛ رویدادها: بازدید صفحه، ساخت نقشه، ذخیره/دانلود با قالب، مدت نشست. صفحهٔ آمار فقط با رمز (بررسی در سرور). */
const MS_STATS=(()=>{
  const on=/^https?:/.test(location.protocol), url="stats.php", sid=Math.random().toString(36).slice(2,12), t0=Date.now(), Q=[];
  const tz=(()=>{ try{ return Intl.DateTimeFormat().resolvedOptions().timeZone||""; }catch(e){ return ""; } })(), lang=(navigator.language||"").slice(0,8), mob=/Mobi|Android|iPhone/i.test(navigator.userAgent);
  let timer=null;
  const flush=(beacon)=>{ if(!on||!Q.length) return; const body=JSON.stringify({a:"log", ev:Q.splice(0,50)});
    try{ if(beacon && navigator.sendBeacon){ navigator.sendBeacon(url, new Blob([body],{type:"application/json"})); return; } fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body,keepalive:true}).catch(()=>{}); }catch(e){} };
  const log=(k,o={})=>{ if(!on) return; Q.push({k, s:sid, tz, l:lang, m:mob?1:0, ...o}); clearTimeout(timer); timer=setTimeout(()=>flush(false), 1500); };
  const page=()=>{ try{ const m=store.get("mode",""); return (typeof ROUTES!=="undefined" && ROUTES[m]) || m || "home"; }catch(e){ return "home"; } };
  let lastP=null; const view=()=>{ const p=$("landing")&&!$("landing").hidden ? "home" : page(); if(p!==lastP){ lastP=p; log("view",{p}); } };
  addEventListener("hashchange", ()=>setTimeout(view,50)); addEventListener("popstate", ()=>setTimeout(view,50));
  document.addEventListener("click", ()=>setTimeout(view,300), true);
  addEventListener("pagehide", ()=>{ log("end",{d:Math.round((Date.now()-t0)/1000)}); flush(true); });
  // دانلودها (هر لینک دانلود، حتی آن‌هایی که بیرون از صفحه ساخته و کلیک می‌شوند)
  const oc=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){ try{ if(this.hasAttribute("download")){ const n=this.getAttribute("download")||""; log("dl",{p:page(), f:(n.split(".").pop()||"").toLowerCase().slice(0,8)}); } }catch(e){} return oc.apply(this,arguments); };
  // نقشه‌های ساخته‌شده
  const wrapRun=(name, cnt)=>{ const f=window[name]; if(typeof f!=="function"||f.__st) return; const w=async function(...a){ const r=await f.apply(this,a); try{ const n=cnt(); if(n>0) log("map",{p:page(), n}); }catch(e){} return r; }; w.__st=1; w.__g=f.__g; window[name]=w; };
  addEventListener("load", ()=>setTimeout(()=>{ view();
    wrapRun("run", ()=>state.models.some(m=>m.ok)?(state.order.length||1):0); wrapRun("dsRunAll", ()=>ds.maps.length); wrapRun("cvRun", ()=>1); wrapRun("ltRun", ()=>1); if(typeof wnRun==="function") wrapRun("wnRun", ()=>1); }, 50));
  return {log, flush, on};
})();
// ===== صفحهٔ آمار (فقط با رمز) =====
function msStatsOpen(){
  const d=vDialog("statsDlg","statsdlg"); const en=LANG==="en"; d.dir=en?"ltr":"rtl";
  d.querySelector("h3").textContent=en?"Site statistics":"آمار سایت"; const b=d.querySelector(".vdb"), f=d.querySelector(".vdf"); b.replaceChildren(); f.replaceChildren();
  if(!MS_STATS.on){ const p=document.createElement("p"); p.textContent=en?"Statistics work only on the hosted site (with stats.php next to index.html).":"آمار فقط روی سایت اصلی (با فایل stats.php کنار index.html) کار می‌کند."; b.append(p); d.showModal(); return; }
  const inp=document.createElement("input"); inp.type="password"; inp.placeholder=en?"Password":"رمز"; inp.autocomplete="off"; inp.style.cssText="width:100%;max-width:280px;margin:8px 0";
  const go=document.createElement("button"); go.type="button"; go.className="btn main"; go.textContent=en?"Show":"نمایش";
  const msg=document.createElement("p"); msg.className="hint";
  go.onclick=async()=>{ go.disabled=true; msg.textContent="…";
    try{ const r=await fetch("stats.php?a=sum",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({a:"sum",pw:inp.value})}); const j=await r.json();
      if(!j.ok){ msg.textContent=en?"Wrong password":"رمز نادرست است"; go.disabled=false; return; } inp.value=""; msStatsRender(b, j.r); f.replaceChildren(); }
    catch(e){ msg.textContent=(en?"Not available: ":"در دسترس نیست: ")+e.message; go.disabled=false; } };
  inp.onkeydown=e=>{ if(e.key==="Enter") go.click(); };
  b.append(inp, msg); f.append(go); d.showModal(); inp.focus();
}
function msStatsRender(b, R){
  const en=LANG==="en", T=(a,c)=>en?c:a; b.replaceChildren();
  const days=Object.entries(R.days), sum=(a,k)=>a.reduce((s,[,o])=>s+(o[k]||0),0);
  const card=(t,v)=>`<div class="stk"><b>${v}</b><span>${t}</span></div>`;
  const avg = R.sessions ? Math.round(R.dur/R.sessions) : 0;
  const top=document.createElement("div"); top.className="stks";
  top.innerHTML=card(T("بازدید (کل)","Page views"),FA(sum(days,"v")))+card(T("بازدیدکنندهٔ روزانه (جمع)","Daily visitors (sum)"),FA(sum(days,"u")))+card(T("نقشهٔ ساخته‌شده","Maps produced"),FA(R.maps))+card(T("ذخیره/دانلود","Saves/downloads"),FA(R.dls))+card(T("میانگین مدت نشست","Avg. session"),FA(`${Math.floor(avg/60)}:${String(avg%60).padStart(2,"0")}`))+card(T("سهم موبایل","Mobile share"),FA(Math.round(100*R.mobile/Math.max(1,sum(days,"v"))))+"٪");
  b.append(top);
  const bars=(title, labels, vals, color)=>{ const h=document.createElement("h4"); h.textContent=title; b.append(h); const c=document.createElement("canvas"); const W=Math.max(320,Math.min(860, labels.length*26+60)), H=180; c.width=W*2; c.height=H*2; c.style.width="100%"; c.style.maxWidth=W+"px";
    const x=c.getContext("2d"); x.scale(2,2); const mx=Math.max(1,...vals), bw=(W-50)/Math.max(1,labels.length); x.font="10px sans-serif"; x.fillStyle="#666";
    vals.forEach((v,i)=>{ const hh=(H-40)*v/mx; x.fillStyle=color; x.fillRect(40+i*bw+2, H-24-hh, Math.max(2,bw-4), hh); x.fillStyle="#444"; if(labels.length<=31 || i%Math.ceil(labels.length/31)===0){ x.save(); x.translate(40+i*bw+bw/2, H-12); x.textAlign="center"; x.fillText(String(labels[i]),0,0); x.restore(); } if(v && bw>18){ x.textAlign="center"; x.fillText(String(v), 40+i*bw+bw/2, H-28-hh); } });
    x.strokeStyle="#bbb"; x.beginPath(); x.moveTo(38,H-24); x.lineTo(W-6,H-24); x.stroke(); b.append(c); };
  const last=n=>days.slice(-n);
  const d30=last(30); bars(T("بازدید روزانه (۳۰ روز اخیر)","Daily page views (last 30 days)"), d30.map(([k])=>k.slice(5)), d30.map(([,o])=>o.v), "#2563eb");
  const agg=(fmt)=>{ const m=new Map(); for(const [k,o] of days){ const key=fmt(k); m.set(key,(m.get(key)||0)+o.v); } return [...m.entries()]; };
  const wk=agg(k=>{ const d=new Date(k+"T00:00:00Z"), y=d.getUTCFullYear(), s=new Date(Date.UTC(y,0,1)), w=Math.ceil(((d-s)/864e5+s.getUTCDay()+1)/7); return `${y}-W${w}`; }).slice(-16);
  bars(T("بازدید هفتگی","Weekly page views"), wk.map(e=>e[0].slice(5)), wk.map(e=>e[1]), "#0e9f6e");
  const mo=agg(k=>k.slice(0,7)).slice(-12); bars(T("بازدید ماهانه","Monthly page views"), mo.map(e=>e[0]), mo.map(e=>e[1]), "#d97706");
  const yr=agg(k=>k.slice(0,4)); bars(T("بازدید سالانه","Yearly page views"), yr.map(e=>e[0]), yr.map(e=>e[1]), "#7c3aed");
  bars(T("ساعت بازدید (وقت ایران)","Visit hour (Iran time)"), R.hours.map((_,h)=>h), R.hours, "#0891b2");
  const topN=(o,n=12)=>Object.entries(o).sort((a,c)=>c[1]-a[1]).slice(0,n);
  const pg=topN(R.pages); bars(T("صفحه‌ها","Pages"), pg.map(e=>e[0]), pg.map(e=>e[1]), "#2563eb");
  const fm=topN(R.formats); if(fm.length) bars(T("قالب فایل‌های ذخیره‌شده","Saved file formats"), fm.map(e=>e[0]), fm.map(e=>e[1]), "#db2777");
  const geo=topN(Object.keys(R.country).length?R.country:R.tz); if(geo.length) bars(Object.keys(R.country).length?T("کشور بازدیدکنندگان","Visitor countries"):T("منطقهٔ زمانی بازدیدکنندگان (جغرافیا)","Visitor time zones (geography)"), geo.map(e=>e[0].replace(/^.*\//,"")), geo.map(e=>e[1]), "#65a30d");
}
(function(){ // دکمهٔ کوچک آمار در گوشهٔ پایین صفحهٔ اول
  const add=()=>{ const land=$("landing"); if(!land || $("statsBtn")) return; const btn=document.createElement("button"); btn.id="statsBtn"; btn.type="button"; btn.title="آمار سایت"; btn.setAttribute("aria-label","آمار سایت"); btn.textContent="📊"; btn.onclick=msStatsOpen; land.append(btn); };
  if(document.readyState!=="loading") add(); else addEventListener("DOMContentLoaded", add);
})();
