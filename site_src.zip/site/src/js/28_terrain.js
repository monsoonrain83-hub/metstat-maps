/* ===== لایه‌های زمین ایران (از شیپ‌فایل‌های کاربر: خاک و شکل زمین، حساسیت به فرسایش) =====
   شبکهٔ ۰٫۰۲۵ درجه (≈۲٫۵ کیلومتر)، ۴۴ تا ۶۳٫۵ شرقی و ۲۵ تا ۴۰ شمالی.
   بایت ۱: شکل زمین (۴ بیت: ۱ دشت/کف دره/چاله/پلایا/شوره‌زار/تالاب، ۲ فلات، ۳ دامنه/مخروط‌افکنهٔ کم‌شیب، ۴ تپه، ۵ کوه با شیب متوسط، ۶ کوه پرشیب/سنگلاخ، ۷ بدلند/گنبد نمکی/کلوت، ۸ تپهٔ ماسه‌ای/ماسهٔ ساحلی، ۹ دره، ۱۰ آب)
          + بافت خاک سطحی (۲ بیت: ۱ درشت، ۲ متوسط، ۳ ریز) + شوری (۱ بیت)
   بایت ۲: ردهٔ حساسیت به فرسایش (I تا X → ۱ تا ۱۰) */
{{BLOB:terrain}}
const TERRAIN_META={x0:44, y1:40, dx:0.025, nx:780, ny:600};
let _terrain=null;
async function terrainLoad(){
  if(_terrain) return _terrain;
  const raw=await dsInflate(b64u8(TERRAIN_B64)), n=TERRAIN_META.nx*TERRAIN_META.ny;
  _terrain={lf:raw.subarray(0,n), ero:raw.subarray(n,2*n)}; return _terrain;
}
function terrainAt(T, lat, lon){
  const M=TERRAIN_META, j=Math.floor((lon-M.x0)/M.dx), i=Math.floor((M.y1-lat)/M.dx);
  if(i<0||j<0||i>=M.ny||j>=M.nx) return null; const k=i*M.nx+j, b=T.lf[k];
  if(!b && !T.ero[k]) return null;
  return {lf:b&15, tx:(b>>4)&3, sal:(b>>6)&1, ero:T.ero[k]};
}
