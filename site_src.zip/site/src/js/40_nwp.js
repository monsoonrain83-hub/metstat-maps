/* ===== نقشه‌های مدل MetStat (nwp_maps.py؛ داده‌های باز مدل‌ها) =====
   هر نقشه در دو ردیف پایین تصویر یک «نشانهٔ ماشینی» دارد (پارامتر، مدل، اجرا، زمان معتبر، منطقه، اعداد نوار رنگ).
   هندسه همان weather.us است (۷۶۰×۷۶۰، کادر ۲…۷۵۷ × ۲…۶۱۴، نوار رنگ روی ردیف ۶۸۰)، پس زمین‌مرجع، مرزها و
   همهٔ ابزارهای صفحه‌های تحلیل بدون OCR و بدون حدس روی آن کار می‌کند. */
const NWP_GEO={iran:[-1506.432,35.07327,1611.463,-40.47955], fars:[-4387.15,89.808,3366.55,-103.991]};
const NWP_REG_FA={iran:"ایران", fars:"فارس"};
const NWP_VAR={t2m:"temp", tmax:"tmax", tmin:"tmin", tanom:"tanom", tsoil:"tsoil", rh:"rh", sfc:"rh", z850:"rh", z700:"rh", z500:"rh", gust:"gust", w500:"wind", w300:"wind", cape:"cape"};
const NWP_CV={cape:"cape", li:"li", ki:"ki", gdi:"gdi", si:"soar", refl:"refl", cin:"cin", pw:"pwat"};
const _nwpCache=new WeakMap();
function nwpMetaD(d, W, H){
  if(!d || !W || !H) return null;
  if(_nwpCache.has(d)) return _nwpCache.get(d);
  let out=null;
  try{
    const nib=k=>{ const y=H-2+Math.floor(k/W), x=k%W, i=(y*W+x)*4, r=d[i]; return (d[i+1]===0x3C && d[i+2]===(r^0xA5) && (r&15)===8) ? (r>>4) : -1; };
    const at=k=>{ const a=nib(2*k), b=nib(2*k+1); return (a<0||b<0) ? -1 : (a<<4)|b; };
    if(at(0)===77 && at(1)===83 && at(2)===50){
      const n=(at(3)<<8)|at(4); if(n>0 && 2*(n+5)<=2*W){ let s=""; for(let k=0;k<n;k++){ const b=at(5+k); if(b<0){ s=null; break; } s+=String.fromCharCode(b); }
        if(s){ const j=JSON.parse(s); if(j && j.p && j.e) out=j; } }
    }
  }catch(e){ out=null; }
  _nwpCache.set(d,out); return out;
}
function nwpMeta(m){ return m && m.data ? nwpMetaD(m.data, m.w, m.h) : null; }
const nwpDate=s=>new Date(Date.UTC(+s.slice(0,4),+s.slice(4,6)-1,+s.slice(6,8),+s.slice(8,10)));
function nwpTimes(j){
  const end=nwpDate(j.t), h=+j.h||0, start=new Date(+end-h*36e5);
  return {src:"nwp", offset:210, init:nwpDate(j.r), start:h?start:end, end, valid:end, single:true, conf:true, minSim:1, nwp:true};
}
function nwpGeoWESN(reg){ const g=NWP_GEO[reg]||NWP_GEO.iran, [ax,bx,ay,by]=g; return [(2-ax)/bx, (757-ax)/bx, (614-ay)/by, (2-ay)/by]; }
// قالب کامل برای حالت «آزاد»: کادر، رنگ‌ها و اعداد نوار رنگ از خود نشانه (بدون حدس)
function nwpTemplate(models){
  const m=models[0], j=nwpMeta(m); if(!j || m.w!==760 || m.h!==760) return null;
  const d=m.data, W=760, y=680, segs=[]; let s=3, prev=null;
  for(let x=3;x<=758;x++){ const i=(y*W+Math.min(x,757))*4, c=[d[i],d[i+1],d[i+2]];
    if(x===758 || (prev && (c[0]!==prev[0]||c[1]!==prev[1]||c[2]!==prev[2]))){ segs.push({a:s,b:x-1,c:prev}); s=x; } prev=c; }
  const colors=segs.map(q=>q.c), pr=/^pr_/.test(j.s);
  const bg = pr ? colors[0] : [255,255,255], bgSep=!pr;
  const fp=`nwp:${j.s}:${colors.length}`;
  return {W:760,H:760, tol:2, exactShare:1, fx0:2, fx1:757, fy0:2, fy1:614, bg, bgSep, bgIdx:bgSep?0:0, colors, segs, segCenters:segs.map(q=>[Math.round((q.a+q.b)/2),y]),
    bar:{orient:"h", c0:671, c1:689, rect:[3,671,758,690]}, inv:[[0,615,760,760]], fp, nwp:j};
}
function nwpEdgesFor(T){ const j=T&&T.nwp; if(!j) return null; return /^pr_/.test(j.s) ? j.e : j.e; }
function nwpNote(j){ return `نقشهٔ مدل MetStat شناسایی شد: ${j.m} — ${j.p} — اجرای ${j.r.slice(8,10)}Z (${NWP_REG_FA[j.g]||j.g}); اعداد نوار رنگ و زمین‌مرجع از خود نقشه خوانده شد`; }
