/* ---------- زمان نقشه‌ها: کمترین شروع و بیشترین پایان ---------- */
state.timeManual = false;
const tzSuffix = off => off===0 ? " UTC" : (off===210 ? (LANG==="en"?" Iran time":" به وقت ایران") : ` (UTC${off>0?"+":"-"}${String(Math.floor(Math.abs(off)/60)).padStart(2,"0")}:${String(Math.abs(off)%60).padStart(2,"0")})`);
function persianDT(dUTC, off){ const x=new Date(+dUTC + off*6e4); return faDate(x.toISOString().slice(0,16), true); }
function aggregateTimes(){
  const ok=state.models.filter(m=>m.ok), ts=ok.filter(m=>m.times).map(m=>m.times);
  if(!ts.length) return null;
  const start=new Date(Math.min(...ts.map(x=>+x.start))), end=new Date(Math.max(...ts.map(x=>+x.end)));
  const inits=[...new Set(ts.filter(x=>x.init).map(x=>+x.init))].sort((a,b)=>a-b).map(v=>new Date(v));
  return {start, end, inits, offset:ts[0].offset, src:ts[0].src, conf:ts.every(x=>x.conf), n:ts.length, nAll:ok.length, ts};
}
const toLocalInput = (d, off=210) => new Date(+d + off*6e4).toISOString().slice(0,16);
function updateTimeUI(){
  const A = aggregateTimes(), box=$("timeAuto");
  box.hidden = !A; $("timeAutoBtn").hidden = !(A && state.timeManual);
  if(!A){ return; }
  if(state.models.filter(m=>m.ok).every(m=>m.times&&m.times.nwp)) box.dataset.asked="1";   // زمان نقشه‌های MetStat از نشانهٔ خود نقشه است؛ پرسش لازم نیست
  // برش متن تاریخ از نقشهٔ کمترین شروع و نقشهٔ بیشترین پایان
  const ok=state.models.filter(m=>m.ok && m.times && m.times.crop);
  const mA=ok.reduce((p,q)=>(!p||q.times.start<p.times.start)?q:p,null), mB=ok.reduce((p,q)=>(!p||q.times.end>p.times.end)?q:p,null);
  const parts=[mA, mB!==mA ? mB : null].filter(Boolean), cv=$("timeCrop");
  if(parts.length){
    const sc=2, W=Math.max(...parts.map(m=>m.times.crop[2]-m.times.crop[0])), Hs=parts.map(m=>m.times.crop[3]-m.times.crop[1]);
    cv.width=W*sc; cv.height=Hs.reduce((a,b)=>a+b+2,0)*sc; const c=cv.getContext("2d"); c.fillStyle="#fff"; c.fillRect(0,0,cv.width,cv.height); c.imageSmoothingEnabled=false;
    let y=0; for(const m of parts){ const [x0,y0,x1,y1]=m.times.crop, tmp=document.createElement("canvas"); tmp.width=m.w; tmp.height=m.h;
      tmp.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(m.data), m.w, m.h),0,0);
      c.drawImage(tmp, x0,y0,x1-x0,y1-y0, 0,y*sc,(x1-x0)*sc,(y1-y0)*sc); y+=y1-y0+2; }
    cv.hidden=false;
  } else cv.hidden=true;
  const mode=$("tzMode").value, off = mode==="src" ? A.offset : (mode==="ir" ? 210 : 0), suf=tzSuffix(off);
  const many = A.ts.some(x=>+x.start!==+A.start || +x.end!==+A.end);
  let msg = (A.conf ? "✓ " : "⚠ ") + `از روی ${FA(A.n)} نقشه خوانده شد: از ${persianDT(A.start,off)}${suf} تا ${persianDT(A.end,off)}${suf}`;
  if(many) msg += " (کمترین شروع و بیشترین پایانِ نقشه‌ها)";
  if(A.n < A.nAll) msg += ` · زمان ${FA(A.nAll-A.n)} نقشه خوانده نشد`;
  if(!A.conf) msg += " · چند رقم با اطمینان کامل خوانده نشد؛ با متن تصویر بالا مقایسه کنید و اگر درست است «درست است» را بزنید (برنامه یاد می‌گیرد).";
  if(A.src==="name") msg = "ⓘ زمان از نام فایل‌ها برداشته شد: " + `از ${persianDT(A.start,off)}${suf} تا ${persianDT(A.end,off)}${suf}`;
  if(state.timeManual) msg = "زمان دستی به کار می‌رود. " + msg;
  $("timeMsg").textContent = msg; $("timeMsg").style.color = A.conf ? "var(--ok)" : "var(--warn)";
  $("timeOk").hidden = A.conf || A.src==="name";
  // برای مرجع، فیلدهای دستی هم پر می‌شوند (وقت ایران)
  if(!state.timeManual){ $("t0").value=toLocalInput(A.start); $("t1").value=toLocalInput(A.end);
    if(A.inits[0]){ $("initD").value=A.inits[0].toISOString().slice(0,10); $("initH").value=String(A.inits[0].getUTCHours()).padStart(2,"0"); } }
}
$("timeOk").onclick=()=>{ learnTimes(); state.models.forEach(m=>{ if(m.times) m.times.conf=true; }); updateTimeUI(); schedule(); };
$("timeEditBtn").onclick=()=>{ state.timeManual=true; $("timeManual").open=true; updateTimeUI(); schedule(); };
$("timeAutoBtn").onclick=()=>{ state.timeManual=false; updateTimeUI(); schedule(); };
["t0","t1","initD","initH"].forEach(id=>$(id).addEventListener("change", ()=>{ if(aggregateTimes()){ state.timeManual=true; updateTimeUI(); } }));
$("tzMode").addEventListener("change", ()=>{ store.set("tzMode",$("tzMode").value); updateTimeUI(); schedule(); });
$("tzMode").value = store.get("tzMode","src");

/* ---------- متغیر: بارش، دما، باد، … ---------- */
(function initVarUI(){
  const sel=$("varSel");
  sel.replaceChildren(...Object.entries(VARS).map(([k,v])=>{ const o=document.createElement("option"); o.value=k; o.textContent = k==="custom" ? "سفارشی…" : `${v.n} (${v.u})`; return o; }));
  sel.value = store.get("varSel","precip"); varThr(sel.value);
  $("thr").addEventListener("input", ()=>store.set("thr."+sel.value, $("thr").value));
  $("varName").value=store.get("varName",""); $("varUnit").value=store.get("varUnit","");
  const changed=()=>{ varThr(sel.value); $("varCustom").hidden = sel.value!=="custom"; $("gOffRow").hidden = VARS[sel.value].frost!=="air"; store.set("varSel", sel.value); store.set("varName",$("varName").value); store.set("varUnit",$("varUnit").value);
    state.models.forEach(m=>{ m.mm=null; m.hit={}; }); if(P && P.edges){ useProfile(P.key).then(()=>schedule()); } updateTimeUI(); };
  sel.onchange=()=>{ $("varNote").textContent=""; changed(); };
  $("varName").addEventListener("change", changed); $("varUnit").addEventListener("change", changed);
  $("varCustom").hidden = sel.value!=="custom";
})();
function detectVariable(){
  const sel=$("varSel");
  if(P && !P.custom){
    // قالب‌های ثابت فقط بارش‌اند؛ ولی بارش برف (معادل آب) از عنوان نقشه تشخیص داده می‌شود
    let k="precip"; const m0=state.models.find(m=>m.ok), nj=nwpMeta(m0);
    if(nj) k = /^s/.test(nj.p) ? "snowp" : "precip"; else
    if(P.key==="wb" && P.variant==="snow") k="snow"; else
    try{ if(m0 && (/snow|برف/i.test(m0.file.name) || wuSnowTitle(m0))) k="snowp";
      else if(m0 && (CV_OCR_T || ["OcrPop","OcrDj","OcrLib"].every(f=>document.fonts.check("700 36px "+f)))){ const br = P.key==="wu" ? [3,672,757,690] : [P.barX0||39, (P.barY||785)-9, P.barX1||698, (P.barY||785)+9];
        const r=cvTitleType({...m0, prof:{fx0:P.fx0, fy0:P.fy0, fx1:P.fx1, fy1:P.fy1, bar:{orient:"h", rect:br}}}); if(r && r.vb && r.vb.snow>=0.64) k="snowp"; } }catch(e){}
    if(sel.value!==k){ sel.value=k; varThr(k); state.models.forEach(m=>{ m.mm=null; m.hit={}; }); store.set("varSel",k); }
    sel.disabled=true; $("varCustom").hidden=true; $("gOffRow").hidden=true;
    const h24=P.key==="wu" && (P.variant==="h24"||P.variant==="h1");
    const hh=P.hours?FA(P.hours):null;
    $("varNote").textContent = k==="snow" ? "تشخیص خودکار: بارش برف تجمعی (سانتی‌متر، نسبت ۱۰ به ۱؛ نوار رنگ برف WeatherBELL)" : hh ? (k==="snowp" ? `تشخیص خودکار: بارش برف ${hh} ساعته (معادل آب، میلی‌متر)` : `تشخیص خودکار: بارش ${hh} ساعته (از عنوان نقشهٔ weather.us)`) : (k==="snowp" ? (h24?"تشخیص خودکار: بارش برف ۲۴ ساعته (معادل آب، میلی‌متر)":"تشخیص خودکار: بارش برف تجمعی کل (معادل آب، میلی‌متر)") : P.key==="wu" ? (h24?"تشخیص خودکار: بارش ۲۴ ساعته (نوار رنگ ۲۴ ساعتهٔ weather.us)":"تشخیص خودکار: بارش تجمعی کل (نوار رنگ بارش کل weather.us)") : `تشخیص خودکار: بارش تجمعی (قالب ${P.name})`); return; }
  if(!P || !P.custom){ sel.value="precip"; sel.disabled=true; $("varCustom").hidden=true;
    $("varNote").textContent = P ? `قالب ${P.name} فقط نقشهٔ بارش تجمعی را می‌شناسد؛ برای دما یا نقشه‌های دیگر از حالت «آزاد» استفاده کنید.` : ""; return; }
  sel.disabled=false;
  { const nj=P.T&&P.T.nwp; if(nj){ const k=NWP_VAR[nj.p];
      if(k && VARS[k]){ if(sel.value!==k){ sel.value=k; sel.onchange(); } }
      else { sel.value="custom"; $("varName").value=nj.n||nj.p; $("varUnit").value=nj.u||""; sel.onchange(); }
      $("varNote").textContent=`تشخیص خودکار از نشانهٔ نقشهٔ MetStat (${nj.n||nj.p})`; return; } }
  if(P.T && P.T.tt){ const k=ttVar(P.T); if(k){ if(sel.value!==k){ sel.value=k; sel.onchange(); } $("varNote").textContent="تشخیص خودکار: ناهنجاری بارش (نوار رنگ سبز/قهوه‌ای tropicaltidbits)"; return; } }
  const names=state.models.filter(m=>m.ok).map(m=>m.file.name).join(" ");
  for(const [k,v] of Object.entries(VARS)){ if(v.re && v.re.test(names)){ if(sel.value!==k){ sel.value=k; sel.onchange(); } $("varNote").textContent="تشخیص خودکار از نام فایل"; return; } }
  { const g=P.T && guessScale(P.T.colors, P.T); if(g && g.fuzzy && g.kind && VARS[g.kind]){ if(sel.value!==g.kind){ sel.value=g.kind; sel.onchange(); } $("varNote").textContent="تشخیص خودکار: "+g.name; return; }
    if(g && g.fuzzy && !g.kind){ if(sel.value!=="precip"){ sel.value="precip"; sel.onchange(); } $("varNote").textContent="تشخیص خودکار: "+g.name; return; } }
  if(P.T && guessScale(P.T.colors) && !guessScale(P.T.colors).kind){ if(sel.value!=="precip"){ sel.value="precip"; sel.onchange(); } $("varNote").textContent="تشخیص خودکار: نوار رنگ همان مقیاس بارش است"; return; }
  // عنوان نقشه (OCR) + بازهٔ اعداد نوار رنگ
  try{ const m0=state.models.find(m=>m.ok); if(m0 && P.T && (CV_OCR_T || ["OcrPop","OcrDj","OcrLib"].every(f=>document.fonts.check("700 36px "+f)))){
      const r=cvTitleType({...m0, prof:{fx0:P.T.fx0, fy0:P.T.fy0, fx1:P.T.fx1, fy1:P.T.fy1, bar:P.T.bar}}), vb=(r&&r.vb)||{}, ok=k=>vb[k]>=0.62;
      const hb=(r&&r.hb)||{}, kb=(r&&r.kb)||{};
      let k=null; if(hb.anom>=0.64) k="tanom"; else if(kb.td2m>=0.66) k="td"; else if(hb.soil>=0.7 && !(r&&r.level==="2m") && (ok("temp")||wuTempEdges(P.T))) k="tsoil";
      else if(ok("temp")) k = ok("tmax") ? "tmax" : ok("tmin") ? "tmin" : "temp"; else if(ok("gust")) k="gust"; else for(const c of ["wind","rh","mslp","cloud","snow","cape","precip"]) if(ok(c)){ k=c; break; }
      if(!k && r && r.k==="td2m") k="td";
      if(!k && r && r.k==="t500" && !(r.level && /500/.test(r.level))) k = (hb.soil>=0.7 && r.level!=="2m") ? "tsoil" : "temp";
      if(!k && r && r.k && VARS[r.k]) k=r.k;
      if(!k && r && r.k && CV_IDX[r.k] && !CV_IDX[r.k].cmp){ sel.value="custom"; $("varName").value=CV_IDX[r.k].n.replace(/\s*\(.*\)/,""); $("varUnit").value=(CV_IDX[r.k].units?(r.unit||Object.keys(CV_IDX[r.k].units)[0]):CV_IDX[r.k].u)||""; sel.onchange();
        $("varNote").textContent=`تشخیص خودکار از عنوان نقشه («${r.w}»)${state.fromTpl?` — نقشهٔ ${state.fromTpl}`:""}`; return; }
      if(!k){ const e=parseEdges($("tplEdges").value)||[], fin=e.filter(isFinite); if(fin.length>2){ const lo=Math.min(...fin), hi=Math.max(...fin); if(hi>=900 && lo>=850 && hi<=1100) k="mslp"; else if(lo<0 && hi<=60) k="temp"; } if(!k && wuTempEdges(P.T)) k="temp"; }
      if(k){ if(sel.value!==k){ sel.value=k; sel.onchange(); } $("varNote").textContent=`تشخیص خودکار از عنوان نقشه${r&&r.w?` («${r.w}»)`:""}${state.fromTpl?` — نقشهٔ ${state.fromTpl}`:""}`; return; } } }catch(e){ console.warn(e); }
  $("varNote").textContent="متغیر از روی نقشه معلوم نشد؛ اگر بارش نیست از فهرست انتخاب کنید.";
}

/* ---------- تشخیص خودکار منطقه ---------- */
const REGIONS = ["ایران","فارس","شرق فارس","شمال فارس","شمال‌غرب فارس","جنوب‌غرب فارس","جنوب‌شرق فارس","خوزستان","هرمزگان","تهران","گیلان","آذربایجان‌ها و اردبیل","خاورمیانه","غرب آسیا","خلیج فارس","ترکیه","عراق","افغانستان","پاکستان","آسیای مرکزی","قفقاز","اروپا","آسیا","جهان"];
const REGION_WORDS = [
  [/(^|[^a-z])fars([^a-z]|$)|فارس(?!\s*خلیج)/i,"فارس"], [/khuzestan|خوزستان/i,"خوزستان"], [/hormozgan|هرمزگان/i,"هرمزگان"], [/gilan|guilan|گیلان/i,"گیلان"], [/tehran|تهران/i,"تهران"],
  [/iran|ایران|persia/i,"ایران"], [/middle[-_ ]?east|mideast|خاورمیانه/i,"خاورمیانه"], [/west[-_ ]?asia|غرب[ _-]?آسیا/i,"غرب آسیا"],
  [/persian[-_ ]?gulf|arabian[-_ ]?gulf|خلیج/i,"خلیج فارس"], [/turkey|t[uü]rkiye|ترکیه/i,"ترکیه"], [/iraq|عراق/i,"عراق"],
  [/afghan|افغانستان/i,"افغانستان"], [/pakistan|پاکستان/i,"پاکستان"], [/central[-_ ]?asia|آسیای[ _-]?مرکزی/i,"آسیای مرکزی"],
  [/caucas|قفقاز/i,"قفقاز"], [/europe|اروپا/i,"اروپا"], [/world|global|جهان/i,"جهان"], [/asia|آسیا/i,"آسیا"]];
const REGION_SIG_WU = {"ایران": "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101111000111000111100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101100000000100110010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101000000000100100010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101000000111100100010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101000001000100100010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101000001000100100010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001101000001111100100010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"};
const WU_REG = {y0:722, y1:740, x0:12, x1:252};
function wuRegionSig(d){ let s=""; for(let y=WU_REG.y0;y<WU_REG.y1;y++) for(let x=WU_REG.x0;x<WU_REG.x1;x++){ const i=(y*760+x)*4; s += (0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])<128 ? "1":"0"; } return s; }
const hamming=(a,b)=>{ let n=0; for(let i=0;i<a.length;i++) if(a[i]!==b[i]) n++; return n; };
// امضای درشتِ مرزهای ثابت (حالت آزاد): هر خانهٔ ۴۸×۳۶ که خط دارد = ۱
function staticRegionSig(){
  if(!P.baseMask) return null; const gx=48, gy=36, b=new Uint8Array(gx*gy);
  for(let y=0;y<FH;y++) for(let x=0;x<FW;x++) if(P.baseMask[y*FW+x]===1) b[Math.floor(y*gy/FH)*gx+Math.floor(x*gx/FW)]=1;
  return Array.from(b).join("");
}
let regionSrc = null;      // {kind:"wu"|"cu", sig, fp}
function setRegion(name, note){
  const sel=$("regionSel");
  if(REGIONS.includes(name)){ sel.value=name; $("region").hidden=true; }
  else { sel.value="__custom"; $("region").hidden=false; }
  $("region").value=name; $("regionNote").textContent = note||""; store.set("region", name);
  if(typeof wuzSync==="function") try{ wuzSync(); }catch(e){}
}
function detectRegion(stage){
  const ms = state.models.filter(m=>m.ok); if(!ms.length || !P) return;
  const byName = ()=>{ for(const m of ms) for(const [re,name] of REGION_WORDS) if(re.test(m.file.name)) return name; return null; };
  if(P.key==="wb"){ regionSrc=null; setRegion("ایران", "تشخیص خودکار: قالب WeatherBELL فقط برای ایران است"); return; }
  if(P.key==="wu"){
    const sig = wuRegionSig(ms[0].data), learned = store.get("regionSigs.wu", []);
    const cands = Object.entries(REGION_SIG_WU).map(([r,s])=>({r,s})).concat(learned.map(o=>({r:o.region,s:o.sig})));
    let best=null, bd=1e9; for(const c of cands){ const d=hamming(sig,c.s); if(d<bd){ bd=d; best=c.r; } }
    regionSrc={kind:"wu", sig};
    if(best && bd < sig.length*0.012) return setRegion(best, "تشخیص خودکار از نام منطقه در پایین نقشه");
    const oz=wuZoomOCR(ms[0]); if(oz) return setRegion(oz, "تشخیص خودکار از نام زوم در پایین نقشهٔ weather.us");
    const nm=byName(); if(nm) return setRegion(nm, "تشخیص خودکار از نام فایل");
    return setRegion($("region").value, "این منطقه هنوز شناخته نشده؛ از فهرست انتخاب کنید تا برای دفعه‌های بعد یاد گرفته شود");
  }
  if(P.custom){
    if(P.T && P.T.tt && P.T.tt.me){ regionSrc=null; return setRegion("خاورمیانه", "تشخیص خودکار: زوم خاورمیانهٔ tropicaltidbits"); }
    if(ms[0].w===760 && ms[0].h===760){ const oz=wuZoomOCR(ms[0]) || wuSigRegion(ms[0].data); if(oz && REGIONS.includes(oz)){ regionSrc={kind:"wu", sig:wuRegionSig(ms[0].data)}; return setRegion(oz, "تشخیص خودکار از پانویس نقشهٔ weather.us"); } }
    const nm=byName(); if(nm){ regionSrc=null; return setRegion(nm, "تشخیص خودکار از نام فایل"); }
    if(stage!=="static") return;
    const sig = staticRegionSig(); if(!sig) return;
    regionSrc={kind:"cu", sig, fp:P.fp};
    const learned = store.get("regionSigs.cu", []); let best=null, bd=1e9;
    for(const o of learned){ if(o.sig.length!==sig.length) continue; const d=hamming(sig,o.sig); if(d<bd){ bd=d; best=o.region; } }
    if(best && bd < sig.length*0.08) return setRegion(best, "تشخیص خودکار از شکل مرزهای نقشه (یادگرفته‌شده)");
    return setRegion($("region").value, "منطقه از روی نقشه شناخته نشد؛ از فهرست انتخاب کنید تا یاد گرفته شود");
  }
}

// نام زوم weather.us از پانویس پایین‌چپ (همان OCR بخش همرفت)
function wuZoomOCR(m){
  try{ if(!CV_OCR_T && !["OcrPop","OcrDj","OcrLib"].every(f=>document.fonts.check("700 36px "+f))) return null;
    const fake={...m, prof:{fx0:2, fy0:2, fx1:757, fy1:614, bar:{orient:"h", rect:[3,672,757,690]}}};
    const r=cvTitleType(fake); const fa=r && r.region && CV_REGIONS[r.region]; return fa && REGIONS.includes(fa) ? fa : null; }catch(e){ return null; }
}

// امضای پانویس weather.us (نام منطقه/مختصات) در برابر نمونه‌های یادگرفته
function wuSigRegion(d){ try{ const sig=wuRegionSig(d), learned=store.get("regionSigs.wu", []);
  const cands=Object.entries(REGION_SIG_WU).map(([r,s_])=>({r,s:s_})).concat(learned.map(o=>({r:o.region,s:o.sig}))); let best=null, bd=1e9;
  for(const c of cands){ if(c.s.length!==sig.length) continue; const dd=hamming(sig,c.s); if(dd<bd){ bd=dd; best=c.r; } }
  return best && bd < sig.length*0.012 ? best : null; }catch(e){ return null; } }
function wuLearnSig(d, name){ if(!d || !name) return; const sig=wuRegionSig(d); const list=store.get("regionSigs.wu", []).filter(o=>hamming(o.sig,sig)>sig.length*0.012); list.push({sig, region:name}); store.set("regionSigs.wu", list.slice(-40)); }
function learnRegion(name){
  if(!regionSrc || !name) return;
  const key = regionSrc.kind==="wu" ? "regionSigs.wu" : "regionSigs.cu";
  const list = store.get(key, []).filter(o=> hamming(o.sig, regionSrc.sig) > regionSrc.sig.length*0.012);
  list.push({sig:regionSrc.sig, region:name}); store.set(key, list.slice(-30));
  $("regionNote").textContent = "یاد گرفته شد: نقشه‌های این منطقه از این به بعد خودکار شناخته می‌شوند";
}
(function initRegionUI(){
  const sel=$("regionSel");
  sel.replaceChildren(...REGIONS.map(r=>{ const o=document.createElement("option"); o.value=r; o.textContent=r; return o; }));
  const c=document.createElement("option"); c.value="__custom"; c.textContent="سفارشی…"; sel.append(c);
  const saved=store.get("region","ایران"); setRegion(saved, "");
  sel.onchange=()=>{ if(sel.value==="__custom"){ $("region").hidden=false; $("region").focus(); return; }
    $("region").hidden=true; $("region").value=sel.value; store.set("region", sel.value); learnRegion(sel.value); try{ wuzSync(); }catch(e){} schedule(); };
  $("region").addEventListener("change", ()=>{ learnRegion($("region").value.trim()); });
})();

