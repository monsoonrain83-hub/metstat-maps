/* =====================================================================
   اطلس اقلیمی ایستگاهی: پایگاه دادهٔ یکپارچهٔ ماهانهٔ ایستگاه‌ها (از اکسل‌های کاربر، کنترل کیفیت‌شده)
   نمودار ماهانه و سالانه، چند ایستگاه هم‌زمان، شاخص‌های اقلیمی و همبستگی با تأخیر، نقشهٔ درون‌یابی
   (IDW، کریجینگ معمولی، اسپلاین صفحهٔ نازک؛ با و بدون ارتفاع) و پهنه‌بندی همبستگی و روند.
   دادهٔ خام هیچ‌جا به‌صورت عددی قابل دانلود نیست؛ فقط تصویر نمودار و نقشه.
   ===================================================================== */
{{BLOB:clim_db}}
const CA={db:null, sel:new Set(), busy:false, last:null};
const CA_T=(fa,en)=>LANG==="en"?en:fa;
const CA_P={
  prcp:{fa:"بارش",en:"Precipitation",u:"میلی‌متر",ue:"mm",agg:"sum",elev:true,kind:"p"},
  rd:{fa:"روزهای بارانی (≥۱ میلی‌متر)",en:"Rain days (≥1 mm)",u:"روز",ue:"days",agg:"sum",elev:true,kind:"p"},
  pmax:{fa:"بیشینهٔ بارش ۲۴ ساعته",en:"Max 24‑h precipitation",u:"میلی‌متر",ue:"mm",agg:"max",elev:true,kind:"p"},
  tmean:{fa:"دمای میانگین",en:"Mean temperature",u:"°C",ue:"°C",agg:"mean",elev:true,kind:"t"},
  tmax:{fa:"میانگین دمای بیشینه",en:"Mean maximum temperature",u:"°C",ue:"°C",agg:"mean",elev:true,kind:"t"},
  tmin:{fa:"میانگین دمای کمینه",en:"Mean minimum temperature",u:"°C",ue:"°C",agg:"mean",elev:true,kind:"t"},
  txx:{fa:"بیشینهٔ مطلق دما",en:"Absolute maximum temperature",u:"°C",ue:"°C",agg:"max",elev:true,kind:"t"},
  tnn:{fa:"کمینهٔ مطلق دما",en:"Absolute minimum temperature",u:"°C",ue:"°C",agg:"min",elev:true,kind:"t"},
  fd:{fa:"روزهای یخبندان (کمینه ≤ ۰)",en:"Frost days (Tmin ≤ 0)",u:"روز",ue:"days",agg:"sum",elev:true,kind:"c"},
  hd:{fa:"روزهای داغ (بیشینه ≥ ۴۰)",en:"Hot days (Tmax ≥ 40)",u:"روز",ue:"days",agg:"sum",elev:true,kind:"h"},
  rh:{fa:"رطوبت نسبی",en:"Relative humidity",u:"٪",ue:"%",agg:"mean",elev:false,kind:"r"},
  sun:{fa:"ساعات آفتابی",en:"Sunshine hours",u:"ساعت",ue:"h",agg:"sum",elev:false,kind:"s"},
  evap:{fa:"تبخیر",en:"Evaporation",u:"میلی‌متر",ue:"mm",agg:"sum",elev:true,kind:"e"},
  snd:{fa:"روزهای برف یا برف‌وباران",en:"Snow/sleet days",u:"روز",ue:"days",agg:"sum",elev:true,kind:"c"},
  dust:{fa:"روزهای گردوخاک",en:"Dust days",u:"روز",ue:"days",agg:"sum",elev:false,kind:"h"},
  tsd:{fa:"روزهای توفان تندری",en:"Thunderstorm days",u:"روز",ue:"days",agg:"sum",elev:false,kind:"p"}
};
const CA_MN=["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
const CA_MNE=["Farvardin","Ordibehesht","Khordad","Tir","Mordad","Shahrivar","Mehr","Aban","Azar","Dey","Bahman","Esfand"];
const CA_PER=[["year","سال شمسی (فروردین تا اسفند)","Solar Hijri year (Farvardin–Esfand)"],["wy","سال آبی (مهر تا شهریور)","Water year (Mehr–Shahrivar)"],
  ["s1","بهار","Spring"],["s2","تابستان","Summer"],["s3","پاییز","Autumn"],["s4","زمستان","Winter"],["s5","فصل بارش (مهر تا اردیبهشت)","Wet season (Mehr–Ordibehesht)"],
  ...CA_MN.map((m,i)=>["m"+(i+1),m,CA_MNE[i]])];
// ماه‌های هر دوره (۱ تا ۱۲، شمسی) و اینکه سال برچسب از کدام سال است (سال آبی: سال مهر)
function caPerMonths(per){ if(per==="year") return [1,2,3,4,5,6,7,8,9,10,11,12]; if(per==="wy") return [7,8,9,10,11,12,13,14,15,16,17,18];
  if(per==="s1") return [1,2,3]; if(per==="s2") return [4,5,6]; if(per==="s3") return [7,8,9]; if(per==="s4") return [10,11,12]; if(per==="s5") return [7,8,9,10,11,12,13,14];
  if(per[0]==="c"){ const [a,b]=per.slice(1).split("_").map(Number), out=[]; let m=a; for(let k=0;k<12;k++){ out.push(m); if(((m-1)%12)+1===b) break; m++; } return out; }   // بازهٔ دلخواه (عبور از اسفند به سال بعد)
  return [+per.slice(1)]; }
const caPerName=per=>{ if(per && per[0]==="c"){ const [a,b]=per.slice(1).split("_").map(Number), MN=LANG==="en"?CA_MNE:CA_MN; return a===b ? MN[a-1] : CA_T(`${MN[a-1]} تا ${MN[b-1]}`,`${MN[a-1]}–${MN[b-1]}`); }
  const r=CA_PER.find(x=>x[0]===per); return r? CA_T(r[1],r[2]) : per; };
// مقدار دوره در هر سال برای یک ایستگاه؛ برای بارش سال آبی، سال‌هایی که فقط جمع سالانه در منبع دارند هم افزوده می‌شوند
// میانگین بلندمدت منتشرشده (نرمال) برای ایستگاه‌هایی که سری ماهانه ندارند؛ فقط برای نقشهٔ مقدار سالانه
function caNmGet(s,p){ const n=s.nm||{}, g=(a,b)=>n[a]&&n[a][b]!=null?n[a][b]:null;
  switch(p){ case "prcp":return g("prcp","mean"); case "rd":return g("prcp","rd"); case "pmax":return g("prcp","pmax");
    case "tmean":return g("tmean","mean"); case "tmax":return g("tmax","mean"); case "tmin":return g("tmin","mean");
    case "txx":return g("tmax","abs"); case "tnn":return g("tmin","abs"); case "rh":return g("rh","mean");
    case "sun":return g("sun","mean"); case "evap":return g("evap","mean"); case "fd":return g("fd","mean"); } return null; }
function caAggSt(st, p, per, agg){ const a=caSeries(st,p); const m=a?caAgg(a,per,agg):new Map();
  if(p==="prcp" && per==="wy" && st.a && st.a.prcp) for(const [y,v] of Object.entries(st.a.prcp)) if(!m.has(+y)) m.set(+y, v);
  if(p==="prcp" && per==="wy" && st.ov && st.ov.prcp) for(const [y,v] of Object.entries(st.ov.prcp)) m.set(+y, v);
  return m; }
async function caLoad(){
  if(CA.db) return CA.db;
  const u=b64u8(CLIM_PACK); let q=0x9E3779B9>>>0;
  for(let i=0;i<u.length;i++){ q=(q^(q<<13))>>>0; q=(q^(q>>>17))>>>0; q=(q^(q<<5))>>>0; u[i]^=q&255; }
  const all=await dsInflate(u), ml=new DataView(all.buffer, all.byteOffset, 4).getUint32(0,true);
  CLIM_META=JSON.parse(new TextDecoder().decode(all.subarray(4,4+ml)));
  const raw=all.slice(4+ml), I16=new Int16Array(raw.buffer, raw.byteOffset, raw.byteLength>>1);
  const M=CLIM_META; let n=0; for(const s of M.st) for(const e of Object.values(s.d)) n=Math.max(n,e[1]+e[2]);
  CA.db={I16, M, NM:n+12};
  // شاخص‌ها: ماهانهٔ میلادی → ماه شمسی (میانگین وزنی روزهای مشترک؛ شاخص‌ها کندتغییرند)
  CA.idx={}; const g0=M.idx.g0;
  for(const [k,arr] of Object.entries(M.idx.v)){ const out=new Float32Array(CA.db.NM).fill(NaN);
    for(let t=0;t<CA.db.NM;t++){ const jy=M.jy0+Math.floor(t/12), jm=t%12+1; const [gy,gm,gd]=j2gArr(jy,jm,1); const dn=jm<=6?31:jm<=11?30:29;
      // ماه شمسی از روز gd ماه gm میلادی شروع می‌شود: دو ماه میلادی با وزن روزها
      const gi=(gy-g0[0])*12+(gm-g0[1]); if(gi<0||gi+1>=arr.length) continue; const a=arr[gi], b=arr[gi+1];
      const dimG=new Date(Date.UTC(gy,gm,0)).getUTCDate(), w1=Math.max(0,Math.min(dn, dimG-gd+1)), w2=dn-w1;
      if(a==null && b==null) continue; out[t] = a==null ? b : b==null ? a : (a*w1+b*w2)/dn; }
    CA.idx[k]=out; }
  return CA.db;
}
function j2gArr(jy,jm,jd){ return caD2G(caJ2D(jy,jm,jd)); }
// تبدیل تاریخ (الگوریتم jalaali)
function caJalCal(jy){ const B=[-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178]; let gy=jy+621, leapJ=-14, jp=B[0], jump=0;
  for(let i=1;i<B.length;i++){ const jm=B[i]; jump=jm-jp; if(jy<jm) break; leapJ+=Math.floor(jump/33)*8+Math.floor((jump%33)/4); jp=jm; }
  let n=jy-jp; leapJ+=Math.floor(n/33)*8+Math.floor(((n%33)+3)/4); if(jump%33===4 && jump-n===4) leapJ++;
  const leapG=Math.floor(gy/4)-Math.floor((Math.floor(gy/100)+1)*3/4)-150; return {gy, march:20+leapJ-leapG}; }
function caG2D(gy,gm,gd){ let d=Math.floor((gy+Math.trunc((gm-8)/6)+100100)*1461/4)+Math.floor((153*((gm+9)%12)+2)/5)+gd-34840408; return d-Math.floor(Math.floor((gy+100100+Math.trunc((gm-8)/6))/100)*3/4)+752; }
function caD2G(jdn){ let j=4*jdn+139361631; j=j+Math.floor(Math.floor((4*jdn+183187720)/146097)*3/4)*4-3908; const i=Math.floor((j%1461)/4)*5+308;
  const gd=Math.floor((i%153)/5)+1, gm=(Math.floor(i/153)%12)+1, gy=Math.floor(j/1461)-100100+Math.trunc((8-gm)/6); return [gy,gm,gd]; }
function caJ2D(jy,jm,jd){ const r=caJalCal(jy); return caG2D(r.gy,3,r.march)+(jm-1)*31-Math.floor(jm/7)*(jm-7)+jd-1; }
// سری ماهانهٔ یک ایستگاه (کل محور زمان)
function caSeries(st,p){ const e=st.d[p]; if(!e) return null; const {I16,NM}=CA.db, sc=CLIM_META.scale[p], out=new Float32Array(NM).fill(NaN);
  for(let k=0;k<e[2];k++){ const v=I16[e[0]+k]; if(v!==-32768) out[e[1]+k]=v/sc; } return out; }
// مقدار یک دوره در هر سال: {year: value} (فقط اگر همهٔ ماه‌های دوره داده دارند)
function caAgg(series, per, agg){ const jy0=CLIM_META.jy0, ms=caPerMonths(per), out=new Map();
  const y0=jy0, y1=jy0+Math.floor(series.length/12)-1;
  for(let y=y0;y<=y1;y++){ let s=0, n=0, mx=-Infinity, mn=Infinity, ok=true;
    for(const m of ms){ const t=(y-jy0)*12+(m-1); const v=t<series.length?series[t]:NaN; if(!(v===v)){ ok=false; break; } s+=v; n++; if(v>mx) mx=v; if(v<mn) mn=v; }
    if(!ok||!n) continue; out.set(y, agg==="sum"?s:agg==="max"?mx:agg==="min"?mn:s/n); }
  return out; }
function caIdxAgg(name, per, lag){ const a=CA.idx[name]; if(!a) return new Map(); const ms=caPerMonths(per), jy0=CLIM_META.jy0, out=new Map();
  for(let y=jy0;y<jy0+Math.floor(a.length/12);y++){ let s=0,n=0,ok=true; for(const m of ms){ const t=(y-jy0)*12+(m-1)-lag; const v=t>=0&&t<a.length?a[t]:NaN; if(!(v===v)){ ok=false; break; } s+=v; n++; }
    if(ok&&n) out.set(y, s/n); } return out; }
// ---------- آمار ----------
function caPearson(x,y){ const n=x.length; if(n<4) return {r:NaN,p:NaN,n}; let mx=0,my=0; for(let i=0;i<n;i++){ mx+=x[i]; my+=y[i]; } mx/=n; my/=n;
  let sxy=0,sxx=0,syy=0; for(let i=0;i<n;i++){ const a=x[i]-mx,b=y[i]-my; sxy+=a*b; sxx+=a*a; syy+=b*b; } const r=sxy/Math.sqrt(sxx*syy||1);
  const t=r*Math.sqrt((n-2)/Math.max(1e-12,1-r*r)); return {r, p:caTp(Math.abs(t),n-2), n, b:sxy/(sxx||1), a:my-sxy/(sxx||1)*mx}; }
function caTp(t,df){ // p دوطرفه از توزیع t (تابع بتای ناقص)
  const x=df/(df+t*t); return caIncBeta(x, df/2, 0.5); }
function caIncBeta(x,a,b){ if(x<=0) return 0; if(x>=1) return 1; const lb=caLgamma(a+b)-caLgamma(a)-caLgamma(b), front=Math.exp(Math.log(x)*a+Math.log(1-x)*b+lb);
  if(x<(a+1)/(a+b+2)) return front*caCf(x,a,b)/a; return 1-front*caCf(1-x,b,a)/b; }
function caCf(x,a,b){ let f=1,c=1,d=0; for(let i=0;i<=200;i++){ const m=Math.floor(i/2); let num = i===0?1: i%2===0 ? m*(b-m)*x/((a+2*m-1)*(a+2*m)) : -(a+m)*(a+b+m)*x/((a+2*m)*(a+2*m+1));
    d=1+num*d; if(Math.abs(d)<1e-30) d=1e-30; d=1/d; c=1+num/c; if(Math.abs(c)<1e-30) c=1e-30; const cd=c*d; f*=cd; if(Math.abs(1-cd)<1e-8) break; } return f-1; }
function caLgamma(z){ const g=[76.18009172947146,-86.50532032941677,24.01409824083091,-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5]; let x=z, y=z, t=x+5.5; t-=(x+0.5)*Math.log(t); let s=1.000000000190015; for(const c of g) s+=c/++y; return -t+Math.log(2.5066282746310005*s/x); }
// روند: شیب سن و آزمون من–کندال
function caTrend(xs,ys){ const n=xs.length; if(n<8) return null; const sl=[]; let S=0;
  for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){ sl.push((ys[j]-ys[i])/(xs[j]-xs[i])); S+=Math.sign(ys[j]-ys[i]); }
  sl.sort((a,b)=>a-b); const slope=sl[sl.length>>1], v=n*(n-1)*(2*n+5)/18, z=S>0?(S-1)/Math.sqrt(v):S<0?(S+1)/Math.sqrt(v):0;
  const p=2*(1-caNcdf(Math.abs(z))), med=[...ys].sort((a,b)=>a-b)[n>>1], mx=[...xs].sort((a,b)=>a-b)[n>>1];
  return {slope, z, p, b:med-slope*mx}; }
function caNcdf(z){ const t=1/(1+0.2316419*z), d=0.3989423*Math.exp(-z*z/2); const p=d*t*(0.3193815+t*(-0.3565638+t*(1.781478+t*(-1.821256+t*1.330274)))); return 1-p; }
function caStats(v){ const a=v.filter(x=>x===x).sort((p,q)=>p-q), n=a.length; if(!n) return null; const m=a.reduce((s,x)=>s+x,0)/n;
  const sd=Math.sqrt(a.reduce((s,x)=>s+(x-m)*(x-m),0)/Math.max(1,n-1)); return {n, mean:m, sd, cv:m?sd/Math.abs(m)*100:NaN, min:a[0], max:a[n-1], med:a[n>>1]}; }
const caF=(v,d=1)=>!(v===v)||v==null ? "—" : FA((Math.round(v*10**d)/10**d).toFixed(d).replace(/\.0+$/,""));
const CA_IDXFA={"nino 1":"نینو ۱+۲","nino 3":"نینو ۳","NINO 3/4":"نینو ۳٫۴","Nino 4":"نینو ۴","MEI v2":"شاخص چندمتغیرهٔ انسو (MEI)","DMI":"دوقطبی اقیانوس هند (DMI)","QBO30":"نوسان شبه‌دوسالانه، ۳۰ هکتوپاسکال (QBO30)","QBO50":"نوسان شبه‌دوسالانه، ۵۰ هکتوپاسکال (QBO50)","AMO":"نوسان چنددهه‌ای اطلس (AMO)","PNA":"الگوی اقیانوس آرام–آمریکای شمالی (PNA)","EAWR":"الگوی شرق اطلس–غرب روسیه (EAWR)","AO":"نوسان شمالگان (AO)","NAO":"نوسان اطلس شمالی (NAO)","PDO":"نوسان دهه‌ای اقیانوس آرام (PDO)","ONI":"شاخص نینوی اقیانوسی (ONI)","SOI":"شاخص نوسان جنوبی (SOI)","BEST":"شاخص ترکیبی انسو (BEST)","TNA":"اطلس شمالی حاره‌ای (TNA)","AAO":"نوسان جنوبگان (AAO)","EPO":"نوسان شرق اقیانوس آرام (EPO)","SCAND":"الگوی اسکاندیناوی (SCAND)","GBI":"شاخص بندال گرینلند (GBI)","WP":"الگوی غرب اقیانوس آرام (WP)","ep/np":"الگوی شرق/شمال اقیانوس آرام (EP/NP)","EA":"الگوی شرق اطلس (EA)","POL":"الگوی قطبی–اوراسیا (POL)","PT":"الگوی حاره‌ای–نیمکرهٔ شمالی (PT)"};
const caIdxName=k=>LANG==="en"?k:(CA_IDXFA[k]||k);
const caStName=s=>LANG==="en" ? (s.en||s.fa) : (s.fa||s.en).replace(/\(IRIMO\)/g,"(سازمان هواشناسی)");
// ---------- نمودارها (بوم، ظاهر سه‌بعدی ملایم) ----------
const CA_COL=["#2563eb","#e11d48","#059669","#d97706","#7c3aed","#0891b2","#be185d","#65a30d","#ea580c","#4f46e5","#0f766e","#b91c1c"];
function caShade(hex,f){ const c=(hex[0]==="#"?hexRGB(hex):(hex.match(/\d+/g)||[0,0,0]).slice(0,3).map(Number)).map(v=>Math.max(0,Math.min(255,Math.round(f>0? v+(255-v)*f : v*(1+f))))); return `rgb(${c})`; }
function caCanvas(W,H,sc=2){ const c=document.createElement("canvas"); c.width=W*sc; c.height=H*sc; const x=c.getContext("2d"); x.scale(sc,sc); c.__W=W; c.__H=H; return [c,x]; }
function caFrame(x,W,H,title,sub){
  const g=x.createLinearGradient(0,0,0,H); g.addColorStop(0,"#f8fafc"); g.addColorStop(1,"#eef2f7"); x.fillStyle=g; x.fillRect(0,0,W,H);
  const en=LANG==="en", al=en?"left":"right", X=en?24:W-24, dir=en?"ltr":"rtl";
  txt(x,title,X,34,`bold 19px ${FT.body}`,{align:al,color:"#0f172a",dir,maxW:W-60});
  if(sub) txt(x,sub,X,58,`13px ${FT.body}`,{align:al,color:"#475569",dir,maxW:W-60});
}
function caAxes(x, L, T, R, B, xmin, xmax, ymin, ymax, opt={}){
  // سایهٔ صفحهٔ نمودار
  x.save(); x.shadowColor="rgba(15,23,42,.12)"; x.shadowBlur=14; x.shadowOffsetY=4; x.fillStyle="#fff"; x.fillRect(L,T,R-L,B-T); x.restore();
  const ny=6, step=caNice((ymax-ymin)/ny), y0=Math.floor(ymin/step)*step, y1=Math.ceil(ymax/step)*step;
  const Y=v=>B-(v-y0)/(y1-y0||1)*(B-T);
  x.strokeStyle="#e2e8f0"; x.lineWidth=1; x.font=`12px ${FT.body}`;
  for(let v=y0; v<=y1+step*1e-6; v+=step){ const yy=Y(v); x.beginPath(); x.moveTo(L,yy); x.lineTo(R,yy); x.stroke(); txt(x,caF(v,step<1?(step<0.1?2:1):0),L-6,yy+4,`12px ${FT.body}`,{align:"right",color:"#64748b",dir:"ltr"}); }
  if(opt.zero && y0<0 && y1>0){ x.strokeStyle="#94a3b8"; x.lineWidth=1.3; x.beginPath(); x.moveTo(L,Y(0)); x.lineTo(R,Y(0)); x.stroke(); }
  x.strokeStyle="#cbd5e1"; x.lineWidth=1; x.strokeRect(L,T,R-L,B-T);
  if(opt.ylab){ x.save(); x.translate(opt.ylx!=null?opt.ylx:16,(T+B)/2); x.rotate(-Math.PI/2); txt(x,opt.ylab,0,0,`12px ${FT.body}`,{align:"center",color:"#475569",dir:LANG==="en"?"ltr":"rtl"}); x.restore(); }
  return {Y, y0, y1};
}
function caNice(v){ const e=Math.pow(10,Math.floor(Math.log10(Math.max(1e-9,v)))), f=v/e; return (f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10)*e; }
function caBar3D(x, cx, w, yTop, yBase, col){
  const d=Math.min(8, w*0.35), top=Math.min(yTop,yBase), h=Math.abs(yBase-yTop);
  const g=x.createLinearGradient(cx-w/2,0,cx+w/2,0); g.addColorStop(0,caShade(col,0.25)); g.addColorStop(0.55,col); g.addColorStop(1,caShade(col,-0.18));
  x.fillStyle=g; x.fillRect(cx-w/2, top, w, h);
  x.fillStyle=caShade(col,-0.35); x.beginPath(); x.moveTo(cx+w/2,top); x.lineTo(cx+w/2+d,top-d*0.6); x.lineTo(cx+w/2+d,top+h-d*0.6); x.lineTo(cx+w/2,top+h); x.closePath(); x.fill();
  x.fillStyle=caShade(col,0.45); x.beginPath(); x.moveTo(cx-w/2,top); x.lineTo(cx-w/2+d,top-d*0.6); x.lineTo(cx+w/2+d,top-d*0.6); x.lineTo(cx+w/2,top); x.closePath(); x.fill();
}
function caLegend(x, items, X, Y, W){ const en=LANG==="en"; x.font=`12.5px ${FT.body}`; let cx=en?X:X+W, cy=Y;
  for(const it of items){ const w=x.measureText(it.t).width+30; if(en? cx+w>X+W : cx-w<X){ cx=en?X:X+W; cy+=20; }
    const bx=en?cx:cx-14; x.fillStyle=it.c; x.fillRect(bx,cy-10,12,12); txt(x,it.t,en?cx+18:cx-18,cy,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#1e293b",dir:en?"ltr":"rtl"}); cx+= en? w : -w; } }
function caBrand(x,W,H){ const S={brand:$("brand")?$("brand").value.trim():"", handle:$("handle")?$("handle").value.trim():"", logoImg:state.logoImg}; try{ drawBrand(x,S,LANG==="en"?W-200:18,H-46,180,40,{side:true,align:LANG==="en"?"right":"left",fs:12}); }catch(e){} }
// ۱) نمودار ماهانه (میانگین دوره برای هر ماه؛ چند ایستگاه = ستون‌های گروهی)
function caChartMonthly(sts, p, y0, y1){
  const P=CA_P[p], W=980, H=560, [c,x]=caCanvas(W,H), L=70, R=W-30, T=96, B=H-110;
  const ser=sts.map(s=>{ const a=caSeries(s,p); const m=new Array(12).fill(0).map((_,k)=>{ const v=[]; for(let y=y0;y<=y1;y++){ const t=(y-CLIM_META.jy0)*12+k; const q=a&&t>=0&&t<a.length?a[t]:NaN; if(q===q) v.push(q); } return v.length>=Math.max(3,(y1-y0+1)*0.5)?v.reduce((s,q)=>s+q,0)/v.length:NaN; }); return {s, m}; });
  const vals=ser.flatMap(o=>o.m).filter(v=>v===v); if(!vals.length) return null;
  caFrame(x,W,H, CA_T(`میانگین ماهانهٔ ${P.fa}`,`Monthly mean ${P.en}`)+(sts.length===1?" — "+caStName(sts[0]):""), CA_T(`دورهٔ ${FA(y0)} تا ${FA(y1)} (سال شمسی) · ${P.u}`,`${y0}–${y1} (Solar Hijri) · ${P.ue}`));
  const mn=Math.min(0,...vals), mx=Math.max(...vals); const A=caAxes(x,L,T,R,B,0,12,mn,mx+(mx-mn)*0.08,{zero:true,ylab:CA_T(P.u,P.ue)});
  const gw=(R-L)/12, k=ser.length, bw=Math.min(34, gw*0.7/k);
  const en=LANG==="en", MN=en?CA_MNE:CA_MN;
  for(let m=0;m<12;m++){ const cxm=L+gw*(en?m+0.5:11-m+0.5); txt(x,MN[m],cxm,B+18,`12px ${FT.body}`,{align:"center",color:"#334155",dir:en?"ltr":"rtl"});
    ser.forEach((o,i)=>{ const v=o.m[m]; if(!(v===v)) return; const cx_=cxm+(i-(k-1)/2)*bw*1.15; caBar3D(x,cx_,bw,A.Y(v),A.Y(Math.max(A.y0,0)),CA_COL[i%CA_COL.length]);
       }); }
  if(k>1) caLegend(x, ser.map((o,i)=>({t:caStName(o.s), c:CA_COL[i%CA_COL.length]})), 40, B+46, W-80);
  else { /* مقدار عددی (جمع سالانه) نمایش داده نمی‌شود */ }
  c.__rep={type:"monthly", p, y0, y1, ser:ser.map(o=>({name:caStName(o.s), m:o.m, lat:o.s.lat}))};
  caBrand(x,W,H); return c;
}
// ۲) نمودار سالانه (سری زمانی + روند سن + میانگین متحرک)
function caChartAnnual(sts, p, per, y0, y1){
  const P=CA_P[p], W=980, H=560, [c,x]=caCanvas(W,H), L=70, R=W-30, T=96, B=H-118;
  const ser=sts.map(s=>{ const m=caAggSt(s,p,per,P.agg); const ys=[...m.keys()].filter(y=>y>=y0&&y<=y1).sort((a,b)=>a-b); return {s, ys, vs:ys.map(y=>m.get(y))}; }).filter(o=>o.ys.length);
  if(!ser.length) return null;
  const all=ser.flatMap(o=>o.vs), mn=Math.min(...all), mx=Math.max(...all), yA=Math.min(...ser.map(o=>o.ys[0])), yB=Math.max(...ser.map(o=>o.ys[o.ys.length-1]));
  caFrame(x,W,H, CA_T(`سری زمانی ${P.fa} — ${caPerName(per)}`,`${P.en} time series — ${caPerName(per)}`)+(sts.length===1?" — "+caStName(sts[0]):""), CA_T(`${FA(yA)} تا ${FA(yB)} · ${P.u} · خط‌چین: روند (شیب سن)`,`${yA}–${yB} · ${P.ue} · dashed: trend (Sen's slope)`));
  const pad=(mx-mn)*0.1||1, A=caAxes(x,L,T,R,B,yA,yB,Math.min(mn-pad, P.agg==="sum"&&mn>=0?0:mn-pad),mx+pad,{zero:true,ylab:CA_T(P.u,P.ue)});
  const en=LANG==="en", X=y=>en? L+(y-yA+0.5)/(yB-yA+1)*(R-L) : R-(y-yA+0.5)/(yB-yA+1)*(R-L);
  const step=Math.max(1,Math.ceil((yB-yA+1)/14)); for(let y=yA;y<=yB;y+=step) txt(x,FA(y),X(y),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"});
  const info=[];
  ser.forEach((o,i)=>{ const col=CA_COL[i%CA_COL.length];
    if(ser.length===1){ const bw=Math.max(3,(R-L)/(yB-yA+1)*0.62), st=caStats(o.vs);
      o.ys.forEach((y,k)=>{ const v=o.vs[k], c2= st && v>=st.mean ? col : caShade(col,0.4); caBar3D(x,X(y),bw,A.Y(v),A.Y(Math.max(A.y0,Math.min(0,A.y1)) ),c2); });
      if(st){ x.setLineDash([2,4]); x.strokeStyle="#0f172a"; x.lineWidth=1; x.beginPath(); x.moveTo(L,A.Y(st.mean)); x.lineTo(R,A.Y(st.mean)); x.stroke(); x.setLineDash([]); } }
    else { x.strokeStyle=col; x.lineWidth=2.2; x.shadowColor=caShade(col,0.3); x.shadowBlur=6; x.beginPath(); let pen=false, py=null;
      o.ys.forEach((y,k)=>{ const X_=X(y), Y_=A.Y(o.vs[k]); if(pen && py!==null && y-py===1) x.lineTo(X_,Y_); else x.moveTo(X_,Y_); pen=true; py=y; }); x.stroke(); x.shadowBlur=0;
      o.ys.forEach((y,k)=>{ x.fillStyle="#fff"; x.beginPath(); x.arc(X(y),A.Y(o.vs[k]),2.6,0,7); x.fill(); x.strokeStyle=col; x.lineWidth=1.4; x.stroke(); }); }
    const tr=caTrend(o.ys,o.vs);
    if(tr){ x.setLineDash([7,5]); x.strokeStyle=ser.length===1?"#dc2626":col; x.lineWidth=1.8; x.beginPath(); x.moveTo(X(o.ys[0]),A.Y(tr.b+tr.slope*o.ys[0])); x.lineTo(X(o.ys[o.ys.length-1]),A.Y(tr.b+tr.slope*o.ys[o.ys.length-1])); x.stroke(); x.setLineDash([]);
      info.push({s:o.s, tr, st:caStats(o.vs)}); }
  });
  if(ser.length>1) caLegend(x, ser.map((o,i)=>({t:caStName(o.s), c:CA_COL[i%CA_COL.length]})), 40, B+44, W-80);
  else if(info[0]){ const q=info[0]; txt(x, CA_T(`روند ${q.tr.slope<0?"کاهشی":"افزایشی"} (${q.tr.p<0.05?"معنی‌دار، p<0٫05":"غیرمعنی‌دار"})`,
      `Trend: ${q.tr.slope<0?"downward":"upward"} (${q.tr.p<0.05?"significant, p<0.05":"not significant"})`), en?40:W-40, B+46, `13px ${FT.body}`, {align:en?"left":"right", color:"#0f172a", dir:en?"ltr":"rtl", maxW:W-80}); }
  c.__rep={type:"annual", p, per, ser:ser.map(o=>({name:caStName(o.s), ys:o.ys, vs:o.vs}))};
  caBrand(x,W,H); c.__info=info; return c;
}
// ۳) سری زمانی شاخص با تحلیل
function caChartIndex(name, per, y0, y1){
  const m=caIdxAgg(name, per, 0), ys=[...m.keys()].filter(y=>y>=y0&&y<=y1).sort((a,b)=>a-b); if(ys.length<3) return null;
  const vs=ys.map(y=>m.get(y)), st=caStats(vs), tr=caTrend(ys,vs);
  const W=980, H=560, [c,x]=caCanvas(W,H), L=70, R=W-30, T=96, B=H-128, en=LANG==="en";
  caFrame(x,W,H, CA_T(`شاخص ${caIdxName(name)} — ${caPerName(per)}`,`${name} index — ${caPerName(per)}`), CA_T(`${FA(ys[0])} تا ${FA(ys[ys.length-1])} (سال شمسی؛ میانگین وزنی ماه‌های میلادی هم‌پوشان)`,`${ys[0]}–${ys[ys.length-1]} (Solar Hijri; day‑weighted Gregorian months)`));
  const mn=Math.min(...vs), mx=Math.max(...vs), pad=(mx-mn)*0.1||1, A=caAxes(x,L,T,R,B,0,1,mn-pad,mx+pad,{zero:true});
  const X=y=>en? L+(y-ys[0]+0.5)/(ys[ys.length-1]-ys[0]+1)*(R-L) : R-(y-ys[0]+0.5)/(ys[ys.length-1]-ys[0]+1)*(R-L), bw=Math.max(2,(R-L)/(ys.length+1)*0.7);
  const base=A.Y(Math.max(A.y0,Math.min(0,A.y1)));
  ys.forEach((y,k)=>{ const v=vs[k], hi=v>=st.mean+st.sd, lo=v<=st.mean-st.sd; caBar3D(x,X(y),bw,A.Y(v),base, v>=0?(hi?"#b91c1c":"#f87171"):(lo?"#1d4ed8":"#60a5fa")); });
  const step=Math.max(1,Math.ceil(ys.length/14)); for(let i=0;i<ys.length;i+=step) txt(x,FA(ys[i]),X(ys[i]),B+18,`11.5px ${FT.body}`,{align:"center",color:"#334155",dir:"ltr"});
  if(tr){ x.setLineDash([7,5]); x.strokeStyle="#0f172a"; x.lineWidth=1.6; x.beginPath(); x.moveTo(X(ys[0]),A.Y(tr.b+tr.slope*ys[0])); x.lineTo(X(ys[ys.length-1]),A.Y(tr.b+tr.slope*ys[ys.length-1])); x.stroke(); x.setLineDash([]); }
  const hiY=ys.filter((y,k)=>vs[k]>=st.mean+st.sd), loY=ys.filter((y,k)=>vs[k]<=st.mean-st.sd);
  const l1=CA_T(`روند ${tr?((tr.slope<0?"کاهشی":"افزایشی")+(tr.p<0.05?" (معنی‌دار)":" (غیرمعنی‌دار)")):"نامشخص"}`,
    `Trend: ${tr?((tr.slope<0?"downward":"upward")+(tr.p<0.05?" (significant)":" (not significant)")):"n/a"}`);
  const l2=CA_T(`فاز قوی مثبت (≥ میانگین + ۱ انحراف معیار): ${hiY.slice(-12).map(FA).join("، ")||"—"}`,`Strong positive (≥ mean + 1 SD): ${hiY.slice(-12).join(", ")||"—"}`);
  const l3=CA_T(`فاز قوی منفی (≤ میانگین − ۱ انحراف معیار): ${loY.slice(-12).map(FA).join("، ")||"—"}`,`Strong negative (≤ mean − 1 SD): ${loY.slice(-12).join(", ")||"—"}`);
  [l1,l2,l3].forEach((s,i)=>txt(x,s,en?40:W-40,B+44+i*19,`12.5px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl",maxW:W-80}));
  c.__rep={type:"index", name, per, ys, vs};
  caBrand(x,W,H); return c;
}
// ۴) همبستگی پارامتر با شاخص: پراکنش + خط رگرسیون، و نمودار همبستگی با تأخیر ۰ تا ۱۲ ماه
function caCorrData(st, p, per, idx, lag, y0, y1){ if(!st.d[p]) return null; const pm=caAggSt(st,p,per,CA_P[p].agg), im=caIdxAgg(idx,per,lag), xs=[], ys=[], yr=[];
  for(const [y,v] of pm){ if(y<y0||y>y1) continue; const q=im.get(y); if(q===undefined) continue; xs.push(q); ys.push(v); yr.push(y); } return {xs,ys,yr,...caPearson(xs,ys)}; }
function caChartCorr(sts, p, per, idx, lag, y0, y1){
  const P=CA_P[p], W=980, H=600, [c,x]=caCanvas(W,H), en=LANG==="en";
  const one=sts.length===1;
  caFrame(x,W,H, CA_T(`همبستگی ${P.fa} با شاخص ${caIdxName(idx)} — ${caPerName(per)}`,`Correlation of ${P.en} with ${idx} — ${caPerName(per)}`)+(one?" — "+caStName(sts[0]):""),
    CA_T(`تأخیر شاخص: ${FA(lag)} ماه · ${FA(y0)} تا ${FA(y1)} · ضریب پیرسون و آزمون t دوطرفه`,`Index lag: ${lag} months · ${y0}–${y1} · Pearson r, two‑sided t‑test`));
  // راست: پراکنش (اولین ایستگاه)، چپ: همبستگی با تأخیر برای همهٔ ایستگاه‌ها
  const d=caCorrData(sts[0],p,per,idx,lag,y0,y1);
  const sx0=en?60:520, sx1=en?470:930, T=96, B=H-120;
  if(d && d.xs.length>=4){ const mnx=Math.min(...d.xs), mxx=Math.max(...d.xs), mny=Math.min(...d.ys), mxy=Math.max(...d.ys), px=(mxx-mnx)*0.08||1, py=(mxy-mny)*0.1||1;
    const A=caAxes(x,sx0,T,sx1,B,0,1,mny-py,mxy+py,{ylab:CA_T(P.u,P.ue),ylx:sx0-44}); const X=v=>sx0+(v-(mnx-px))/((mxx+px)-(mnx-px))*(sx1-sx0);
    for(let i=0;i<=4;i++){ const v=mnx-px+i*((mxx+px)-(mnx-px))/4; txt(x,caF(v,2),X(v),B+16,`11px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"}); }
    txt(x,CA_T(`شاخص ${caIdxName(idx)}`,`${idx} index`),(sx0+sx1)/2,B+34,`12px ${FT.body}`,{align:"center",color:"#475569",dir:en?"ltr":"rtl"});
    x.strokeStyle="#dc2626"; x.lineWidth=2; x.beginPath(); x.moveTo(X(mnx-px),A.Y(d.a+d.b*(mnx-px))); x.lineTo(X(mxx+px),A.Y(d.a+d.b*(mxx+px))); x.stroke();
    d.xs.forEach((v,i)=>{ const g=x.createRadialGradient(X(v)-1.5,A.Y(d.ys[i])-1.5,0.5,X(v),A.Y(d.ys[i]),5); g.addColorStop(0,"#93c5fd"); g.addColorStop(1,"#1d4ed8"); x.fillStyle=g; x.beginPath(); x.arc(X(v),A.Y(d.ys[i]),4.6,0,7); x.fill(); });
    txt(x,CA_T(`r = ${caF(d.r,2)} · p = ${caF(d.p,3)} · n = ${FA(d.n)} سال`,`r = ${caF(d.r,2)} · p = ${caF(d.p,3)} · n = ${d.n} years`),(sx0+sx1)/2,T-10,`bold 13px ${FT.body}`,{align:"center",color:d.p<0.05?"#b91c1c":"#334155",dir:en?"ltr":"rtl"}); }
  // همبستگی با تأخیر
  const lx0=en?530:60, lx1=en?930:470, lags=[...Array(13).keys()];
  const R=sts.slice(0,8).map(s=>lags.map(l=>{ const q=caCorrData(s,p,per,idx,l,y0,y1); return q&&q.n>=8?q:null; }));
  const A2=caAxes(x,lx0,T,lx1,B,0,12,-1,1,{zero:true,ylab:CA_T("ضریب همبستگی r","correlation r"),ylx:lx0-44}); const n0=R[0]&&R[0].find(q=>q)?R[0].find(q=>q).n:12, rc=n0>3? caRcrit(n0):0.5;
  x.setLineDash([4,4]); x.strokeStyle="#f59e0b"; x.lineWidth=1.2; for(const s of [rc,-rc]){ x.beginPath(); x.moveTo(lx0,A2.Y(s)); x.lineTo(lx1,A2.Y(s)); x.stroke(); } x.setLineDash([]);
  const LX=l=>en? lx0+(l+0.5)/13*(lx1-lx0) : lx1-(l+0.5)/13*(lx1-lx0), bw=(lx1-lx0)/13*0.7/Math.max(1,R.length);
  R.forEach((row,i)=>row.forEach((q,l)=>{ if(!q) return; const cx_=LX(l)+(i-(R.length-1)/2)*bw*1.1; caBar3D(x,cx_,bw,A2.Y(q.r),A2.Y(0), q.p<0.05?CA_COL[i%CA_COL.length]:caShade(CA_COL[i%CA_COL.length],0.55)); }));
  lags.forEach(l=>txt(x,FA(l),LX(l),B+16,`11px ${FT.body}`,{align:"center",color:"#64748b",dir:"ltr"}));
  txt(x,CA_T("تأخیر شاخص (ماه) — خط‌چین نارنجی: آستانهٔ معنی‌داری ۵٪","Index lag (months) — orange dashed: 5% significance"),(lx0+lx1)/2,B+34,`12px ${FT.body}`,{align:"center",color:"#475569",dir:en?"ltr":"rtl"});
  if(R.length>1) caLegend(x, sts.slice(0,8).map((s,i)=>({t:caStName(s), c:CA_COL[i%CA_COL.length]})), 40, B+62, W-80);
  // بهترین تأخیر
  let bestL=null;
  if(R[0]){ let b=null; R[0].forEach((q,l)=>{ if(q && (!b||Math.abs(q.r)>Math.abs(b.q.r))) b={q,l}; }); if(b) bestL={l:b.l, r:b.q.r};
    if(b) txt(x,CA_T(`بیشترین همبستگی در تأخیر ${FA(b.l)} ماه: r = ${caF(b.q.r,2)} (${b.q.p<0.05?"معنی‌دار":"غیرمعنی‌دار"})`,`Strongest at lag ${b.l} months: r = ${caF(b.q.r,2)} (${b.q.p<0.05?"significant":"not significant"})`),en?40:W-40,H-56,`bold 13px ${FT.body}`,{align:en?"left":"right",color:"#0f172a",dir:en?"ltr":"rtl"}); }
  c.__rep={type:"corr", p, per, idx, lag, d, name:caStName(sts[0]), best:bestL};
  caBrand(x,W,H); return c;
}
function caRcrit(n){ const df=n-2; let lo=0, hi=1; for(let k=0;k<40;k++){ const r=(lo+hi)/2, t=r*Math.sqrt(df/(1-r*r)); if(caTp(t,df)>0.05) lo=r; else hi=r; } return hi; }
// ---------- درون‌یابی ----------
function caKm(a,b){ const la=(a.lat+b.lat)/2*Math.PI/180; return Math.hypot((a.lat-b.lat)*111.2,(a.lon-b.lon)*111.2*Math.cos(la)); }
function caSolve(A,b){ // حذف گاوسی با محورگیری؛ A: آرایهٔ سطرها (کپی می‌شود)
  const n=b.length, M=A.map((r,i)=>[...r,b[i]]);
  for(let i=0;i<n;i++){ let p=i; for(let k=i+1;k<n;k++) if(Math.abs(M[k][i])>Math.abs(M[p][i])) p=k; [M[i],M[p]]=[M[p],M[i]]; const d=M[i][i]||1e-12;
    for(let k=i+1;k<n;k++){ const f=M[k][i]/d; if(!f) continue; for(let j=i;j<=n;j++) M[k][j]-=f*M[i][j]; } }
  const x=new Array(n).fill(0); for(let i=n-1;i>=0;i--){ let s=M[i][n]; for(let j=i+1;j<n;j++) s-=M[i][j]*x[j]; x[i]=s/(M[i][i]||1e-12); } return x; }
function caInv(A){ const n=A.length, M=A.map((r,i)=>{ const e=new Array(n).fill(0); e[i]=1; return [...r,...e]; });
  for(let i=0;i<n;i++){ let p=i; for(let k=i+1;k<n;k++) if(Math.abs(M[k][i])>Math.abs(M[p][i])) p=k; [M[i],M[p]]=[M[p],M[i]]; const d=M[i][i]||1e-12; for(let j=0;j<2*n;j++) M[i][j]/=d;
    for(let k=0;k<n;k++){ if(k===i) continue; const f=M[k][i]; if(!f) continue; for(let j=0;j<2*n;j++) M[k][j]-=f*M[i][j]; } }
  return M.map(r=>r.slice(n)); }
// واریوگرام نمایی برازش‌شده (اثر قطعه‌ای، آستانه، دامنه) به واریوگرام تجربی
function caVariogram(pts){ const n=pts.length, pairs=[]; let dmax=0;
  for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){ const d=caKm(pts[i],pts[j]); pairs.push([d,0.5*(pts[i].v-pts[j].v)**2]); if(d>dmax) dmax=d; }
  const nb=12, h=dmax/2/nb, bins=Array.from({length:nb},()=>[0,0,0]); for(const [d,g] of pairs){ const k=Math.floor(d/h); if(k<nb){ bins[k][0]+=d; bins[k][1]+=g; bins[k][2]++; } }
  const E=bins.filter(b=>b[2]>=3).map(b=>[b[0]/b[2],b[1]/b[2],b[2]]); const varz=caStats(pts.map(p=>p.v)).sd**2||1;
  let best=null; for(const nf of [0,0.05,0.1,0.2,0.35]) for(const sf of [0.6,0.8,1,1.2,1.5]) for(const rf of [0.05,0.1,0.15,0.2,0.3,0.45,0.6]){ const c0=nf*varz, c=sf*varz, a=rf*dmax;
    let s=0; for(const [d,g,w] of E){ const m=c0+c*(1-Math.exp(-3*d/a)); s+=w*(g-m)**2/(m*m+1e-9); } if(!best||s<best.s) best={s,c0,c,a}; }
  return best; }
function caBuild(pts, method){ // برمی‌گرداند {f(lat,lon), loo:[...]}
  const n=pts.length;
  if(method==="idw"){ const pw=2; const f=(la,lo)=>{ let s=0,w=0; for(const p of pts){ const d=caKm(p,{lat:la,lon:lo}); if(d<0.5) return p.v; const q=1/d**pw; s+=q*p.v; w+=q; } return s/w; };
    const loo=pts.map((p,i)=>{ let s=0,w=0; pts.forEach((q,j)=>{ if(i===j) return; const d=caKm(p,q)||0.5, ww=1/d**pw; s+=ww*q.v; w+=ww; }); return s/w-p.v; }); return {f, loo}; }
  // کریجینگ معمولی (فرم دوگانه) یا اسپلاین صفحهٔ نازک
  let K, phi;
  if(method==="ok"){ const vg=caVariogram(pts); const C=d=>(vg.c0+vg.c)-(d<1e-6?0:vg.c0+vg.c*(1-Math.exp(-3*d/vg.a))); phi=C; }
  else { const sc=100; phi=d=>{ const r=d/sc; return r<1e-9?0:r*r*Math.log(r); }; }
  const m= method==="ok" ? 1 : 3, N=n+m; K=Array.from({length:N},()=>new Array(N).fill(0));
  for(let i=0;i<n;i++){ for(let j=0;j<n;j++) K[i][j]=phi(caKm(pts[i],pts[j])); if(method==="tps") K[i][i]+=1e-3*(caStats(pts.map(p=>p.v)).sd||1);
    K[i][n]=1; K[n][i]=1; if(m===3){ K[i][n+1]=pts[i].lon; K[i][n+2]=pts[i].lat; K[n+1][i]=pts[i].lon; K[n+2][i]=pts[i].lat; } }
  const rhs=[...pts.map(p=>p.v),...new Array(m).fill(0)], Ki=caInv(K), w=Ki.map(r=>r.reduce((s,a,j)=>s+a*rhs[j],0));
  const f=(la,lo)=>{ let s=w[n]+(m===3?w[n+1]*lo+w[n+2]*la:0); const q={lat:la,lon:lo}; for(let i=0;i<n;i++) s+=w[i]*phi(caKm(pts[i],q)); return s; };
  const loo=pts.map((p,i)=>-w[i]/(Ki[i][i]||1e-12));   // خطای حذف‌یک‌نقطه (Rippa 1999)
  return {f, loo};
}
// رگرسیون ارتفاع (و عرض و طول جغرافیایی) برای حذف روند پیش از درون‌یابی
function caElevTrend(pts){ const X=pts.map(p=>[1,p.elev,p.lat,p.lon]), A=[0,1,2,3].map(i=>[0,1,2,3].map(j=>X.reduce((s,r)=>s+r[i]*r[j],0))), b=[0,1,2,3].map(i=>X.reduce((s,r,k)=>s+r[i]*pts[k].v,0));
  for(let i=0;i<4;i++) A[i][i]+=1e-6; const c=caSolve(A,b); let ss=0, st=0; const m=pts.reduce((s,p)=>s+p.v,0)/pts.length;
  pts.forEach(p=>{ const e=p.v-(c[0]+c[1]*p.elev+c[2]*p.lat+c[3]*p.lon); ss+=e*e; st+=(p.v-m)**2; }); return {c, r2:1-ss/(st||1)}; }
const caRMSE=a=>Math.sqrt(a.reduce((s,e)=>s+e*e,0)/Math.max(1,a.length));
async function caInterp(pts, method, useElev){
  let tr=null; let P=pts;
  if(useElev){ tr=caElevTrend(pts); P=pts.map(p=>({...p, v:p.v-(tr.c[0]+tr.c[1]*p.elev+tr.c[2]*p.lat+tr.c[3]*p.lon)})); }
  const ms= method==="auto" ? ["idw","ok","tps"] : [method], res={};
  for(const m of ms){ try{ res[m]=caBuild(P,m); res[m].rmse=caRMSE(res[m].loo); }catch(e){ console.warn(m,e); } }
  const best=Object.entries(res).filter(([k,r])=>isFinite(r.rmse)).sort((a,b)=>a[1].rmse-b[1].rmse)[0];
  return {tr, best:best[0], f:best[1].f, rmse:best[1].rmse, all:Object.fromEntries(Object.entries(res).map(([k,r])=>[k,r.rmse]))};
}
// ---------- رنگ‌ها و رده‌ها (گسسته) ----------
const CA_PALS={
  p:["#f7fbff","#deebf7","#c6dbef","#9ecae1","#6baed6","#4292c6","#2171b5","#08519c","#08306b","#3f007d","#54278f","#756bb1"],
  t:["#313695","#4575b4","#74add1","#abd9e9","#e0f3f8","#ffffbf","#fee090","#fdae61","#f46d43","#d73027","#a50026","#67001f"],
  c:["#ffffff","#e0f3f8","#c6dbef","#9ecae1","#6baed6","#4292c6","#2171b5","#08519c","#6a51a3","#54278f","#3f007d","#2d004b"],
  h:["#ffffcc","#ffeda0","#fed976","#feb24c","#fd8d3c","#fc4e2a","#e31a1c","#bd0026","#800026","#4d0018","#2d000e","#1a0008"],
  r:["#8c510a","#bf812d","#dfc27d","#f6e8c3","#f5f5f5","#c7eae5","#80cdc1","#35978f","#01665e","#003c30","#00281f","#001a14"],
  s:["#fff7bc","#fee391","#fec44f","#fe9929","#ec7014","#cc4c02","#993404","#662506","#4a1a04","#331203","#1f0b02","#120601"],
  e:["#ffffe5","#fff7bc","#fee391","#fec44f","#fe9929","#ec7014","#cc4c02","#993404","#662506","#4a1a04","#331203","#1f0b02"],
  div:["#053061","#2166ac","#4393c3","#92c5de","#d1e5f0","#f7f7f7","#fddbc7","#f4a582","#d6604d","#b2182b","#67001f"],
  pdiv:["#543005","#8c510a","#bf812d","#dfc27d","#f6e8c3","#f5f5f5","#c7eae5","#80cdc1","#35978f","#01665e","#003c30"]
};
function caBreaks(vals, kind){
  if(kind==="corr") return [-1,-0.7,-0.5,-0.3,-0.2,-0.1,0.1,0.2,0.3,0.5,0.7,1];
  const a=vals.filter(v=>v===v).sort((p,q)=>p-q); if(!a.length) return [0,1];
  let lo=a[Math.floor(a.length*0.01)], hi=a[Math.floor(a.length*0.99)];
  if(kind==="div"){ const m=Math.max(Math.abs(lo),Math.abs(hi))||1, st=caNice(m/5), b=[]; for(let k=-5;k<=5;k++) b.push(+(k*st).toFixed(6)); return b; }
  if(hi-lo<1e-9) hi=lo+1; const st=caNice((hi-lo)/10); const b0=Math.floor(lo/st)*st, out=[]; for(let v=b0; v<=hi+st*0.5; v+=st) out.push(+v.toFixed(6)); return out; }
function caClassOf(v,br){ if(!(v===v)) return -1; let k=0; while(k<br.length-1 && v>=br[k+1]) k++; return Math.min(k, br.length-2); }
// ---------- نقشه ----------
// پوشش داده: سهم مساحت ایرانِ داخل کادر که در فاصلهٔ ۱۰۰ کیلومتری دست‌کم یک ایستگاه دارای داده است
function caCoverage(pts){
  const la0=Math.min(...pts.map(p=>p.lat))-0.45, la1=Math.max(...pts.map(p=>p.lat))+0.45, lo0=Math.min(...pts.map(p=>p.lon))-0.45, lo1=Math.max(...pts.map(p=>p.lon))+0.45;
  const iran=((window.CQC_LAYERS||{}).iran||[])[0], polys=iran?iran.g:[]; if(!polys.length) return 1;
  const inPoly=(lo,la)=>{ for(const poly of polys){ const ring=poly[0]; let c_=false; for(let i=0,j=ring.length-1;i<ring.length;j=i++){ const [xi,yi]=ring[i],[xj,yj]=ring[j]; if(((yi>la)!==(yj>la)) && lo<(xj-xi)*(la-yi)/(yj-yi)+xi) c_=!c_; } if(c_) return true; } return false; };
  let n=0, ok=0; const st=0.15;
  for(let la=la0+st/2; la<la1; la+=st) for(let lo=lo0+st/2; lo<lo1; lo+=st){ if(!inPoly(lo,la)) continue; n++; const cl=Math.cos(la*Math.PI/180);
    for(const p of pts){ if(Math.hypot((p.lat-la)*111,(p.lon-lo)*111*cl)<=100){ ok++; break; } } }
  return n? ok/n : 1;
}
// ---------- رنگ‌بندی نقشه‌های اطلس ----------
// wmp: نوار بارش weathermodels (رنگ‌های خود سایت؛ برای مقادیر بزرگ مرزها با ضریب ۲/۴/۵/۱۰ بزرگ می‌شوند)
// wmt: نوار دمای ۲ متری weathermodels (رده‌های ۱ درجه)
// panom: ناهنجاری/شاخص بارش (نوار ناهنجاری بارش CFS/NMME از tropicaltidbits)   tanom: ناهنجاری دما و همبستگی (نوار ناهنجاری دمای weather.us)
const caHex=c=>"#"+c.map(v=>Math.max(0,Math.min(255,v|0)).toString(16).padStart(2,"0")).join("");
function caQuant(vals,p){ const a=vals.filter(v=>v===v).sort((x,y)=>x-y); return a.length? a[Math.min(a.length-1,Math.max(0,Math.floor((a.length-1)*p)))] : NaN; }
function caSubset(E, C, lo, hi, minN){ // E: مرزها (len n)، C: رنگ هر رده (len n) — رده i = [E[i],E[i+1])
  let a=0; while(a<E.length-1 && E[a+1]<=lo) a++;
  let b=a; while(b<E.length-1 && E[b+1]<=hi) b++;
  while(b-a+1<minN){ if(a>0) a--; if(b-a+1<minN && b<E.length-1) b++; if(a===0 && b===E.length-1) break; }
  const br=E.slice(a,b+1); br.push(b+1<E.length? E[b+1] : E[b]+(E[b]-E[b-1]||1));
  return {breaks:br, colors:C.slice(a,b+1)};
}
function caDiverge(br, pal, center, cl, cr){
  const n=br.length-1, mids=[]; for(let i=0;i<n;i++) mids.push([br[i],br[i+1]]);
  const neg=mids.filter(([a,b])=>b<=center).length, pos=mids.filter(([a,b])=>a>=center).length; let rn=0;
  return mids.map(([a,b],i)=>{
    if(b<=center){ const r=neg-i; return pal[Math.max(0,(cl-1)-Math.round((r-1)*(cl-1)/Math.max(1,neg-1)))]; }
    if(a>=center){ rn++; return pal[Math.min(pal.length-1,(cr+1)+Math.round((rn-1)*(pal.length-1-(cr+1))/Math.max(1,pos-1)))]; }
    return pal[cl]; });
}
function caSchemeOf(o, vals){
  const sc=o.scheme; if(!sc) return null;
  const lo=caQuant(vals,0.003), hi=caQuant(vals,0.997);
  if(sc==="wmp" && typeof WMC_PRECIP_LAB!=="undefined"){
    let k=1; for(const f of [1,2,5,10,20]){ k=f; if(hi<=500*f) break; }
    const E=[0,...WMC_PRECIP_LAB].map(v=>v*k), C=["#ffffff",...WMC_PRECIP_PAL.map(caHex)];
    const r=caSubset(E,C,Math.max(0,lo),hi,7); r.factor=k; r.fmt=v=>caF(v,v<10&&v%1?1:0); return r; }
  if(sc==="wmt" && typeof WMC_T2M_PAL!=="undefined"){
    const C=WMC_T2M_PAL.map(caHex), E=[-99,...C.slice(1).map((_,k)=>-51+k)];
    const r=caSubset(E,C,lo,hi,8); r.breaks[0]=Math.max(r.breaks[0],-60); r.step=Math.max(1,Math.ceil((r.breaks.length-1)/22)); r.fmt=v=>caF(v,0); return r; }
  if(sc==="panom"||sc==="tanom"){
    const pal=sc==="panom" ? (MT_PALS.tt_cfsm||CA_PALS.pdiv) : (MT_PALS.wu_tanom?MT_PALS.wu_tanom.slice(2,17):CA_PALS.div);
    const cl=sc==="panom"?17:(MT_PALS.wu_tanom?8:5), cr=sc==="panom"?18:(MT_PALS.wu_tanom?8:5), center=o.center!=null?o.center:0;
    const br=o.breaks || caBreaks(vals, o.kind==="corr"?"corr":"div");
    return {breaks:br, colors:caDiverge(br,pal,center,cl,cr)}; }
  return null;
}
// ---------- نقشه ----------
function caLL2(polys, lo0, la1, sx, sy){ return polys.map(poly=>poly.map(ring=>ring.map(([lo,la])=>[(lo-lo0)*sx,(la1-la)*sy]))); }
async function caMap(o){
  // o: {pts:[{lat,lon,elev,v,sig,name,uv}], title, sub, unit, kind, scheme, center, breaks, method, useElev, clampMin, note, warn}
  const pts=o.pts.filter(p=>p.lat!=null && p.v===p.v); if(pts.length<3) throw new Error(CA_T("دست‌کم ۳ ایستگاه با مقدار لازم است","At least 3 stations with values are needed"));
  const LY=window.CQC_LAYERS||{}, iranP=(LY.iran||[])[0], polys=iranP?iranP.g:[], OST=LY.ostan||[], en=LANG==="en";
  const inRing=(lo,la,ring)=>{ let c_=false; for(let i=0,j=ring.length-1;i<ring.length;j=i++){ const [xi,yi]=ring[i],[xj,yj]=ring[j]; if(((yi>la)!==(yj>la)) && lo<(xj-xi)*(la-yi)/(yj-yi)+xi) c_=!c_; } return c_; };
  const inPolys=(lo,la,g)=>g.some(poly=>inRing(lo,la,poly[0]));
  // کادر: فیت مرز ایران؛ اگر ایستگاه‌ها فقط در چند استان باشند، فیت همان استان‌ها
  const bb=g=>{ let a=1e9,b=-1e9,c=1e9,d=-1e9; for(const poly of g) for(const [lo,la] of poly[0]){ a=Math.min(a,lo); b=Math.max(b,lo); c=Math.min(c,la); d=Math.max(d,la); } return [a,b,c,d]; };
  let [lo0,lo1,la0,la1]=polys.length? bb(polys) : [44,63.4,25,39.8];
  const used=new Set(); for(const p of pts){ const k=OST.findIndex(f=>inPolys(p.lon,p.lat,f.g)); if(k>=0) used.add(k); }
  if(used.size && used.size<8){ const B=[...used].map(k=>bb(OST[k].g)); lo0=Math.min(...B.map(b=>b[0])); lo1=Math.max(...B.map(b=>b[1])); la0=Math.min(...B.map(b=>b[2])); la1=Math.max(...B.map(b=>b[3])); }
  let maskG=polys; if(used.size && used.size<8) maskG=[...used].flatMap(k=>OST[k].g);
  const mg=Math.max(0.18,(la1-la0)*0.025); lo0-=mg; lo1+=mg; la0-=mg; la1+=mg;
  const cosm=Math.cos((la0+la1)/2*Math.PI/180), ar=(lo1-lo0)*cosm/(la1-la0);
  const W=1500, PADX=36, HEAD=112; let MW=W-2*PADX, MHh=Math.round(MW/ar); if(MHh>1250){ MHh=1250; MW=Math.round(MHh*ar); }
  const FOOT=176+(o.warn?24:0)+(o.note?20:0), H=HEAD+MHh+FOOT, [c,x]=caCanvas(W,H,2), mx0=Math.round((W-MW)/2), my0=HEAD;
  const X=lo=>mx0+(lo-lo0)/(lo1-lo0)*MW, Y=la=>my0+(la1-la)/(la1-la0)*MHh, pxPerDeg=MW/(lo1-lo0);
  x.fillStyle="#fff"; x.fillRect(0,0,W,H);
  const I=await caInterp(pts, o.method||"auto", !!o.useElev);
  let dem=null; if(o.useElev){ try{ dem=await dsBuiltinDEM(); }catch(e){} }
  const demAt=(la,lo)=>{ if(!dem) return 0; const j=Math.round((lo-dem.x0)/dem.dx), i=Math.round((dem.y0-la)/dem.dy); if(i<0||j<0||i>=dem.ny||j>=dem.nx) return 0; const v=dem.data[i*dem.nx+j]; return v===v?v:0; };
  // ماسک ایران روی شبکه با رسم چندضلعی (سریع)
  // تفکیک پهنه‌بندی: پیش‌فرض حدود ۱ کیلومتر (بسیار بالا)؛ از منوی «تفکیک پهنه‌بندی» قابل تعیین
  const kmPx=(lo1-lo0)*111.32*cosm/MW, resKm=o.resKm||(+($("caRes")&&$("caRes").value)||1);
  const gs=Math.max(0.5, Math.min(12, resKm/kmPx)), GW=Math.ceil(MW/gs)+1, GH=Math.ceil(MHh/gs)+1, F=new Float32Array(GW*GH).fill(NaN);
  // فاصله تا نزدیک‌ترین ایستگاه روی شبکهٔ درشت (برای مرز ۳۰۰ کیلومتری کافی است)
  const DG=Math.max(1,Math.round(8/gs)), DW=Math.ceil(GW/DG)+1, DH=Math.ceil(GH/DG)+1, DM=new Float32Array(DW*DH);
  for(let j=0;j<DH;j++) for(let i=0;i<DW;i++){ const la=la1-(j*DG)*(la1-la0)/(GH-1), lo=lo0+(i*DG)*(lo1-lo0)/(GW-1); let dm=1e9; for(const p of pts){ const d=Math.hypot((p.lat-la)*111,(p.lon-lo)*111*cosm); if(d<dm) dm=d; } DM[j*DW+i]=dm; }
  const mk=document.createElement("canvas"); mk.width=GW; mk.height=GH; const mx=mk.getContext("2d"); mx.fillStyle="#000";
  const sx=(GW-1)/(lo1-lo0), sy=(GH-1)/(la1-la0);
  if(maskG.length){ mx.beginPath(); for(const poly of caLL2(maskG,lo0,la1,sx,sy)) for(const ring of poly){ ring.forEach(([a,b],i)=>i?mx.lineTo(a,b):mx.moveTo(a,b)); mx.closePath(); } mx.fill("evenodd"); } else mx.fillRect(0,0,GW,GH);
  const M=mx.getImageData(0,0,GW,GH).data;
  const pv=pts.map(p=>p.v), pMn=Math.min(...pv), pMx=Math.max(...pv), pR=pMx-pMn, vMin= pMn>=0 ? pMn*0.75 : pMn-0.05*pR, vMax=pMx+0.1*pR;
  // میدان درون‌یابی (هموار) روی شبکهٔ ~۳ کیلومتری حساب و دوخطی ریز می‌شود؛ جزئیات ریز از روند ارتفاع (DEM) با تفکیک کامل می‌آید
  const CF=Math.max(1,Math.round((3/kmPx)/gs)), CW=Math.ceil((GW-1)/CF)+2, CH=Math.ceil((GH-1)/CF)+2, RC=new Float32Array(CW*CH).fill(NaN);
  let tick=performance.now();
  for(let cy=0;cy<CH;cy++){ const gy=Math.min(cy*CF,GH-1+CF), la=la1-gy/sy;
    for(let cx=0;cx<CW;cx++){ const gx=cx*CF, dm=DM[Math.min(DH-1,Math.round(Math.min(gy,GH-1)/DG))*DW+Math.min(DW-1,Math.round(Math.min(gx,GW-1)/DG))]; if(dm>340) continue; RC[cy*CW+cx]=I.f(la,lo0+gx/sx); }
    if(performance.now()-tick>100){ caStatus(CA_T(`درون‌یابی… ${FA(Math.round(cy/CH*60))}٪`,`Interpolating… ${Math.round(cy/CH*60)}%`),0.6+0.2*cy/CH); await new Promise(r=>setTimeout(r,0)); tick=performance.now(); } }
  const fAt=(gx,gy)=>{ const fx=gx/CF, fy=gy/CF, x0=Math.floor(fx), y0=Math.floor(fy), tx=fx-x0, ty=fy-y0, i=y0*CW+x0;
    const a=RC[i], b=RC[i+1], c_=RC[i+CW], d=RC[i+CW+1];
    if(a===a&&b===b&&c_===c_&&d===d) return (a*(1-tx)+b*tx)*(1-ty)+(c_*(1-tx)+d*tx)*ty;
    let s_=0,w_=0; for(const [v_,w0] of [[a,(1-tx)*(1-ty)],[b,tx*(1-ty)],[c_,(1-tx)*ty],[d,tx*ty]]) if(v_===v_){ s_+=v_*w0; w_+=w0; } return w_?s_/w_:NaN; };
  for(let gy=0;gy<GH;gy++){ const la=la1-gy/sy;
    for(let gx=0;gx<GW;gx++){ if(M[(gy*GW+gx)*4+3]<128) continue; const lo=lo0+gx/sx;
      const dmin=DM[Math.round(gy/DG)*DW+Math.round(gx/DG)];
      if(dmin>300) continue;
      let v=CF>1?fAt(gx,gy):I.f(la,lo); if(!(v===v)) v=I.f(la,lo); if(I.tr){ const e=demAt(la,lo); v+=I.tr.c[0]+I.tr.c[1]*e+I.tr.c[2]*la+I.tr.c[3]*lo; }
      // برون‌یابی محدود: مقدار پهنه از دامنهٔ مشاهده‌شدهٔ ایستگاه‌ها بیش از ۱۵٪ فراتر نمی‌رود (جلوگیری از فرورفتگی/قلهٔ ساختگی)
      v=Math.max(vMin,Math.min(vMax,v));
      if(o.kind==="corr") v=Math.max(-1,Math.min(1,v)); if(o.clampMin!=null) v=Math.max(o.clampMin,v);
      F[gy*GW+gx]=v; }
    if(performance.now()-tick>100){ caStatus(CA_T(`ترسیم پهنه… ${FA(60+Math.round(gy/GH*40))}٪`,`Rendering… ${60+Math.round(gy/GH*40)}%`),0.8+0.15*gy/GH); await new Promise(r=>setTimeout(r,0)); tick=performance.now(); } }
  const vals=[...F].filter(v=>v===v);
  const SC=caSchemeOf(o, vals.length?vals:pts.map(p=>p.v));
  let br, pal;
  if(SC){ br=SC.breaks; pal=SC.colors.map(hexRGB); }
  else { br=o.breaks||caBreaks(vals.length?vals:pts.map(p=>p.v), o.kind==="corr"?"corr":(o.kind==="div"||o.kind==="pdiv")?"div":"seq");
    const pal0=CA_PALS[o.kind==="corr"?"div":o.kind]||CA_PALS.p, nc0=br.length-1; pal=Array.from({length:nc0},(_,k)=>pal0[Math.round(k*(pal0.length-1)/Math.max(1,nc0-1))]).map(hexRGB); }
  const nc=br.length-1;
  // رسم پیکسلی با رده‌های گسسته (بدون رنگ واسطه)
  const S2=2, PW=MW*S2|0, PH=MHh*S2|0, img=new ImageData(PW,PH), cnt=new Array(nc).fill(0); let tot=0;
  for(let py=0;py<PH;py++){ const fy=py/S2/gs, y0=Math.min(GH-1,Math.floor(fy)), y1=Math.min(GH-1,y0+1), ty=fy-y0;
    for(let px=0;px<PW;px++){ const fx=px/S2/gs, x0=Math.min(GW-1,Math.floor(fx)), x1=Math.min(GW-1,x0+1), tx=fx-x0;
      const a=F[y0*GW+x0], b=F[y0*GW+x1], c_=F[y1*GW+x0], d=F[y1*GW+x1]; let v;
      if(a===a&&b===b&&c_===c_&&d===d) v=(a*(1-tx)+b*tx)*(1-ty)+(c_*(1-tx)+d*tx)*ty; else v=F[(ty<0.5?y0:y1)*GW+(tx<0.5?x0:x1)];
      const k=caClassOf(v,br), q=(py*PW+px)*4; if(k<0){ img.data[q+3]=0; continue; } const col=pal[k]; img.data[q]=col[0]; img.data[q+1]=col[1]; img.data[q+2]=col[2]; img.data[q+3]=255; if(((px|py)&3)===0){ cnt[k]++; tot++; } } }
  const off=document.createElement("canvas"); off.width=PW; off.height=PH; off.getContext("2d").putImageData(img,0,0);
  // زمینه: خشکی بیرون ایران خاکستری روشن، دریا آبی
  x.fillStyle="#efefec"; x.fillRect(mx0,my0,MW,MHh);
  x.save(); x.beginPath(); x.rect(mx0,my0,MW,MHh); x.clip();
  const path=(g,fill,stroke,lw)=>{ for(const poly of g){ x.beginPath(); for(const ring of poly){ ring.forEach(([lo,la],i)=>i?x.lineTo(X(lo),Y(la)):x.moveTo(X(lo),Y(la))); x.closePath(); } if(fill){ x.fillStyle=fill; x.fill("evenodd"); } if(stroke){ x.strokeStyle=stroke; x.lineWidth=lw; x.stroke(); } } };
  for(const f of LY.sea||[]) path(f.g,"#d4e4f4",null,0);
  if(polys.length) path(polys,"#fafafa",null,0);
  x.imageSmoothingEnabled=false; x.drawImage(off,mx0,my0,MW,MHh); x.imageSmoothingEnabled=true;
  for(const f of OST) path(f.g,null,"rgba(30,41,59,.55)",0.7);
  for(const f of LY.sea||[]) path(f.g,null,"#6b8fb8",0.8);
  if(polys.length) path(polys,null,"#111827",1.5);
  if(typeof seatsOn==="function" && seatsOn()) seatsDraw(x,(la,lo)=>[X(lo),Y(la)],null,pxPerDeg);
  // ایستگاه‌ها (نقطه‌های کوچک) و برچسب مقدار بدون هم‌پوشانی
  const occ=[]; const hit=(r)=>occ.some(q=>r[0]<q[2]&&r[2]>q[0]&&r[1]<q[3]&&r[3]>q[1]);
  for(const p of pts){ const px=X(p.lon), py=Y(p.lat); occ.push([px-3,py-3,px+3,py+3]); x.beginPath(); x.arc(px,py,p.sig!==undefined?2.6:2.1,0,7); x.fillStyle=p.sig?"#000":"#fff"; x.fill(); x.lineWidth=1; x.strokeStyle="#000"; x.stroke(); }
  /* برچسب مقدار ایستگاه‌ها روی نقشه نمایش داده نمی‌شود */
  // نام دریاها
  const SEAS=[[37.95,51.15,"دریای کاسپین","Caspian Sea"],[27.15,51.25,"خلیج فارس","Persian Gulf"],[25.05,58.35,"دریای عمان","Gulf of Oman"]];
  for(const [la,lo,fa,e] of SEAS){ if(la<la0+0.15||la>la1-0.15||lo<lo0+0.6||lo>lo1-0.6) continue; const s_=en?e:fa, fs=Math.max(11,Math.min(17,pxPerDeg*0.2));
    x.font=`600 ${fs}px ${FT.body}`; const w=x.measureText(s_).width; occ.push([X(lo)-w/2,Y(la)-fs,X(lo)+w/2,Y(la)+4]);
    txtHalo(x, s_, X(lo), Y(la), `600 ${fs}px ${FT.body}`, {color:"#1f4e8c", halo:2.5, dir:en?"ltr":"rtl", align:"center"}); }
  // نام استان‌ها در فضای خالی، اندازه به نسبت فضا
  const step=7;
  for(const f of OST){ const nm=en?(f.p.en||f.p.name):f.p.name; if(!nm) continue;
    const rings=f.g.map(pl=>pl[0].map(([lo,la])=>[X(lo),Y(la)])), big=rings.reduce((a,r)=>r.length>a.length?r:a,rings[0]);
    let bx0=1e9,bx1=-1e9,by0=1e9,by1=-1e9; for(const [a,b] of big){ bx0=Math.min(bx0,a); bx1=Math.max(bx1,a); by0=Math.min(by0,b); by1=Math.max(by1,b); }
    let best=null;
    for(let yy=by0+step/2; yy<by1; yy+=step) for(let xx=bx0+step/2; xx<bx1; xx+=step){
      if(xx<mx0+10||xx>mx0+MW-10||yy<my0+10||yy>my0+MHh-10) continue;
      let ins=false; for(let i=0,j=big.length-1;i<big.length;j=i++){ const [xi,yi]=big[i],[xj,yj]=big[j]; if(((yi>yy)!==(yj>yy)) && xx<(xj-xi)*(yy-yi)/(yj-yi)+xi) ins=!ins; } if(!ins) continue;
      let de=1e9; for(let i=0,j=big.length-1;i<big.length;j=i++){ const [ax,ay]=big[j],[bx,by]=big[i], dx=bx-ax, dy=by-ay, L2=dx*dx+dy*dy||1, t=Math.max(0,Math.min(1,((xx-ax)*dx+(yy-ay)*dy)/L2)), d=Math.hypot(xx-ax-t*dx, yy-ay-t*dy); if(d<de) de=d; }
      let dO=1e9; for(const q of occ){ const ddx=Math.max(q[0]-xx,0,xx-q[2]), ddy=Math.max(q[1]-yy,0,yy-q[3]); const d=Math.hypot(ddx,ddy); if(d<dO) dO=d; }
      const sc_=Math.min(de, dO*1.6);
      if(!best||sc_>best.s) best={x:xx,y:yy,s:sc_,de}; }
    if(!best) continue;
    let fs=Math.max(0,Math.min(16, best.de*0.42)); x.font=`600 ${fs}px ${FT.body}`; let w=x.measureText(nm).width;
    while(fs>=8 && w>best.s*2.1){ fs-=0.5; x.font=`600 ${fs}px ${FT.body}`; w=x.measureText(nm).width; }
    if(fs<8) continue;
    const r=[best.x-w/2,best.y-fs*0.75,best.x+w/2,best.y+fs*0.35]; if(hit(r)) continue; occ.push(r);
    txtHalo(x, nm, best.x, best.y+fs*0.3, `600 ${fs}px ${FT.body}`, {color:"#3f4a5a", halo:2.2, dir:en?"ltr":"rtl", align:"center"}); }
  x.restore();
  x.strokeStyle="#111827"; x.lineWidth=1.2; x.strokeRect(mx0-0.5,my0-0.5,MW+1,MHh+1);
  // شبکهٔ طول و عرض (بیرون کادر)
  const gst=caNice((lo1-lo0)/7);
  for(let lo=Math.ceil(lo0/gst)*gst; lo<=lo1; lo+=gst){ x.strokeStyle="#111827"; x.lineWidth=1; x.beginPath(); x.moveTo(X(lo),my0+MHh); x.lineTo(X(lo),my0+MHh+5); x.stroke(); txt(x,FA(+lo.toFixed(1))+"°E",X(lo),my0+MHh+17,`11px ${FT.body}`,{align:"center",color:"#475569",dir:"ltr"}); }
  for(let la=Math.ceil(la0/gst)*gst; la<=la1; la+=gst){ x.beginPath(); x.moveTo(mx0-5,Y(la)); x.lineTo(mx0,Y(la)); x.stroke(); txt(x,FA(+la.toFixed(1))+"°N",mx0-7,Y(la)+4,`11px ${FT.body}`,{align:"right",color:"#475569",dir:"ltr"}); }
  // سربرگ به سبک weather.us
  const al=en?"left":"right", TX=en?mx0:mx0+MW, dir=en?"ltr":"rtl";
  x.fillStyle="#0b2545"; x.fillRect(0,0,W,6);
  txt(x,o.title,TX,46,`bold 25px ${FT.body}`,{align:al,color:"#0b1f3a",dir,maxW:MW-240});
  if(o.sub) txt(x,o.sub,TX,76,`15px ${FT.body}`,{align:al,color:"#334155",dir,maxW:MW-240});
  txt(x,CA_T("اطلس اقلیمی ایستگاه‌ها · MetStat","Station Climate Atlas · MetStat"),TX,99,`12px ${FT.body}`,{align:al,color:"#64748b",dir,maxW:MW-240});
  try{ const S={brand:$("brand")?$("brand").value.trim():"", handle:$("handle")?$("handle").value.trim():"", logoImg:state.logoImg}; drawBrand(x,S,en?mx0+MW-200:mx0,24,200,62,{side:true,align:en?"right":"left",fs:13}); }catch(e){}
  // نوار رنگ افقی
  const LYb=my0+MHh+40, LW=Math.min(MW,Math.max(420,nc*34)), LX0=mx0+(MW-LW)/2, cw=LW/nc, dirLeg=1;
  for(let k=0;k<nc;k++){ const cc=pal[en?k:k]; x.fillStyle=`rgb(${cc})`; x.fillRect(LX0+k*cw,LYb,cw,20); }
  x.strokeStyle="#1f2937"; x.lineWidth=0.8; x.strokeRect(LX0,LYb,LW,20); for(let k=1;k<nc;k++){ x.beginPath(); x.moveTo(LX0+k*cw,LYb); x.lineTo(LX0+k*cw,LYb+20); x.strokeStyle="rgba(31,41,55,.45)"; x.stroke(); }
  const lstep=SC&&SC.step?SC.step:Math.max(1,Math.ceil((nc+1)/24)), fmt=SC&&SC.fmt?SC.fmt:(v=>caF(v,Math.abs(v)<1&&v!==0?2:Math.abs(v)<10?1:0));
  for(let k=0;k<=nc;k+=1){ if(k%lstep && k!==nc) continue; const v=br[k]; if(!isFinite(v)||(k===0&&v<=-99)) continue; x.strokeStyle="#1f2937"; x.beginPath(); x.moveTo(LX0+k*cw,LYb+20); x.lineTo(LX0+k*cw,LYb+25); x.stroke(); txt(x,fmt(v),LX0+k*cw,LYb+37,`11.5px ${FT.body}`,{align:"center",color:"#0f172a",dir:"ltr"}); }
  if(o.unit) txt(x,o.unit+(SC&&SC.factor>1?CA_T(` — نوار رنگ بارش weathermodels (مرزها × ${FA(SC.factor)})`,` — weathermodels precipitation colours (bounds × ${SC.factor})`):SC&&SC.factor===1?CA_T(" — نوار رنگ بارش weathermodels"," — weathermodels precipitation colours"):o.scheme==="wmt"?CA_T(" — نوار رنگ دمای weathermodels"," — weathermodels temperature colours"):""),LX0+LW/2,LYb+58,`bold 13px ${FT.body}`,{align:"center",color:"#1f2937",dir,maxW:MW});
  // پانویس
  const MN={idw:CA_T("وزن‌دهی عکس فاصله (IDW)","Inverse distance weighting (IDW)"),ok:CA_T("کریجینگ معمولی (واریوگرام نمایی)","Ordinary kriging (exponential variogram)"),tps:CA_T("اسپلاین صفحهٔ نازک","Thin‑plate spline")};
  const cvTxt=Object.entries(I.all).map(([k,v])=>`${k.toUpperCase()} ${caF(v,2)}`).join(" · ");
  x.fillStyle="#e2e8f0"; x.fillRect(mx0,LYb+72,MW,1);
  const foot=CA_T(`روش پهنه‌بندی: ${MN[I.best]}${I.tr?" با روند ارتفاع":""} · ${FA(pts.length)} ایستگاه · اعتبارسنجی حذف‌یک‌نقطه انجام شده است`,`Interpolation: ${MN[I.best]}${I.tr?" with elevation trend":""} · ${pts.length} stations · leave‑one‑out cross‑validated`);
  txt(x,foot,TX,LYb+92,`12px ${FT.body}`,{align:al,color:"#334155",dir,maxW:MW});
  txt(x,CA_T("منبع داده: آمار ایستگاه‌های هواشناسی، کنترل کیفیت و پردازش MetStat · نقطهٔ سیاه: معنی‌دار · wtafkik.ir","Data: meteorological station records, quality-controlled and processed by MetStat · black dot: significant · wtafkik.ir"),TX,LYb+112,`11.5px ${FT.body}`,{align:al,color:"#64748b",dir,maxW:MW});
  let fy=LYb+132; if(o.note){ txt(x,o.note,TX,fy,`11.5px ${FT.body}`,{align:al,color:"#64748b",dir,maxW:MW}); fy+=20; }
  if(o.warn) txt(x,o.warn,TX,fy,`bold 12.5px ${FT.body}`,{align:al,color:"#b91c1c",dir,maxW:MW});
  c.__frac=cnt.map(k=>tot?k/tot:0); c.__interp=I; c.__br=br;
  c.__geo={mx0,my0,MW,MHh,lo0,lo1,la0,la1,sc:2,resKm:gs*kmPx}; c.__lab=pts.map(p=>({lat:p.lat,lon:p.lon,name:p.name,val:""}));
  return c;
}
// ---------- رابط کاربری ----------
function caStatus(t,f){ const s=$("caStatus"); s.hidden=!t; $("caStText").textContent=t||""; if(f!=null) $("caStBar").style.width=(f*100)+"%"; }
function caBuildUI(){
  const A=$("caAside"); if(A.dataset.ok) return; A.dataset.ok=1;
  const ost=[...new Set(CLIM_META.st.map(s=>s.ostan).filter(Boolean))].sort((a,b)=>a.localeCompare(b,"fa"));
  const og=(lab,arr)=>`<optgroup label="${lab}">${arr.map(([v,f,e])=>`<option value="${v}">${CA_T(f,e)}</option>`).join("")}</optgroup>`;
  const per=og(CA_T("سالانه","Annual"),CA_PER.slice(0,2))+og(CA_T("فصل‌ها","Seasons"),CA_PER.slice(2,7))+og(CA_T("ماه‌ها (تک‌ماه)","Single months"),CA_PER.slice(7))+`<optgroup label="${CA_T("بازهٔ دلخواه","Custom range")}"><option value="custom">${CA_T("از ماه … تا ماه … (انتخاب در پایین)","From month … to month … (choose below)")}</option></optgroup>`;
  const mo=(CA_MN.map((m,i)=>`<option value="${i+1}">${CA_T(m,CA_MNE[i])}</option>`)).join("");
  const idx=Object.keys(CLIM_META.idx.v).map(k=>`<option value="${k}">${caIdxName(k)}</option>`).join("");
  const yr=[...new Set(CLIM_META.st.flatMap(s=>[s.y0,s.y1]))]; const yMin=Math.max(1330,Math.min(...yr)), yMax=Math.max(...yr);
  A.innerHTML=`
  <section class="panel"><h2>${CA_T("ایستگاه‌ها","Stations")}</h2>
    <div class="row2"><label>${CA_T("استان","Province")}<select id="caOst"><option value="">${CA_T("همهٔ استان‌ها","All provinces")}</option>${ost.map(o=>`<option>${o}</option>`).join("")}</select></label>
    <label>${CA_T("نوع","Type")}<select id="caType"><option value="">${CA_T("همه","All")}</option><option value="synoptic">${CA_T("سینوپتیک","Synoptic")}</option><option value="raingauge">${CA_T("باران‌سنجی","Rain gauge")}</option><option value="climatology">${CA_T("اقلیم‌شناسی","Climatological")}</option><option value="aws">${CA_T("خودکار","AWS")}</option></select></label></div>
    <label>${CA_T("جست‌وجوی نام","Search name")}<input id="caQ" placeholder="${CA_T("مثلاً شیراز","e.g. Shiraz")}"></label>
    <div class="caList" id="caList"></div>
    <div class="row2"><button class="btn sm" type="button" id="caAll">${CA_T("انتخاب همهٔ فهرست","Select all listed")}</button><button class="btn sm" type="button" id="caNone">${CA_T("پاک کردن انتخاب","Clear selection")}</button></div>
    <p class="hint" id="caSelInfo"></p></section>
  <section class="panel"><h2>${CA_T("پارامتر و دوره","Parameter and period")}</h2>
    <label>${CA_T("پارامتر","Parameter")}<select id="caPar"></select></label>
    <label><b>${CA_T("ماه / فصل / دوره (برای همهٔ نمودارها و نقشه‌ها)","Month / season / period (for all charts and maps)")}</b><select id="caPer">${per}</select></label>
    <div class="row2" id="caCustRow" hidden><label>${CA_T("از ماه","From month")}<select id="caCm0">${mo}</select></label><label>${CA_T("تا ماه","To month")}<select id="caCm1">${mo}</select></label></div>
    <p class="hint">${CA_T("مثلاً «دی» برای تحلیل ماه دی در همهٔ سال‌ها، یا بازهٔ «آذر تا بهمن». بازه‌ای که از اسفند می‌گذرد به سال بعد ادامه می‌یابد و با سال ماه شروع نام‌گذاری می‌شود.","E.g. “Dey” for that month in every year, or a custom “Azar–Bahman” range. A range crossing Esfand continues into the next year and is labelled by its starting year.")}</p>
    <div class="row2"><label>${CA_T("از سال","From year")}<input type="number" id="caY0" value="${Math.max(yMin,1361)}" min="${yMin}" max="${yMax}"></label><label>${CA_T("تا سال","To year")}<input type="number" id="caY1" value="${yMax}" min="${yMin}" max="${yMax}"></label></div>
    <div class="row2"><button class="btn main" type="button" id="caBtnM">${CA_T("نمودار ماهانه","Monthly chart")}</button><button class="btn main" type="button" id="caBtnA">${CA_T("نمودار سالانه","Annual chart")}</button></div></section>
  <section class="panel"><h2>${CA_T("شاخص‌های اقلیمی","Climate indices")}</h2>
    <label>${CA_T("شاخص","Index")}<select id="caIdx">${idx}</select></label>
    <label>${CA_T("تأخیر شاخص نسبت به پارامتر (ماه)","Index lead/lag (months)")}<input type="number" id="caLag" value="0" min="0" max="12"></label>
    <div class="row2"><button class="btn main" type="button" id="caBtnI">${CA_T("سری زمانی شاخص","Index time series")}</button><button class="btn main" type="button" id="caBtnC">${CA_T("نمودار همبستگی","Correlation chart")}</button></div></section>
  <section class="panel" id="caMapPanel"><h2>${CA_T("نقشه و پهنه‌بندی","Map and zoning")}</h2>
    <p class="hint" id="caMapHint"></p>
    <label>${CA_T("نوع نقشه","Map type")}<select id="caMapType"><option value="val">${CA_T("میانگین پارامتر در دوره","Period mean of the parameter")}</option><option value="corr">${CA_T("پهنه‌بندی همبستگی با شاخص","Correlation with the index")}</option><option value="trend">${CA_T("روند (شیب سن در دهه)","Trend (Sen's slope per decade)")}</option><option value="anom">${CA_T("ناهنجاری یک سال نسبت به میانگین دوره","Anomaly of one year vs period mean")}</option></select></label>
    <label id="caAnYRow" hidden>${CA_T("سال ناهنجاری","Anomaly year")}<input type="number" id="caAnY" value="${yMax-1}"></label>
    <label>${CA_T("روش درون‌یابی","Interpolation")}<select id="caMeth"><option value="auto">${CA_T("بهترین روش (اعتبارسنجی حذف‌یک‌نقطه)","Best method (leave‑one‑out cross‑validation)")}</option><option value="ok">${CA_T("کریجینگ معمولی","Ordinary kriging")}</option><option value="tps">${CA_T("اسپلاین صفحهٔ نازک","Thin‑plate spline")}</option><option value="idw">${CA_T("وزن‌دهی عکس فاصله (IDW)","IDW")}</option></select></label>
    <label>${CA_T("تفکیک پهنه‌بندی","Grid resolution")}<select id="caRes"><option value="1">${CA_T("بسیار بالا — حدود ۱ کیلومتر (پیش‌فرض)","Very high — ~1 km (default)")}</option><option value="0.6">${CA_T("بیشینه — حدود ۰٫۶ کیلومتر (کندتر)","Maximum — ~0.6 km (slower)")}</option><option value="2">${CA_T("بالا — ۲ کیلومتر","High — 2 km")}</option><option value="5">${CA_T("متوسط — ۵ کیلومتر","Medium — 5 km")}</option><option value="10">${CA_T("سریع — ۱۰ کیلومتر","Fast — 10 km")}</option></select></label>
    <label class="chk" id="caElevRow"><input type="checkbox" id="caElev" checked> ${CA_T("دخالت ارتفاع (رگرسیون با DEM و درون‌یابی باقیمانده‌ها)","Use elevation (regression on DEM + residual interpolation)")}</label>
    <label class="chk"><input type="checkbox" id="caSeats"> ${CA_T("نقاط مراکز شهرستان‌ها روی نقشه","County-seat points on the map")}</label>
    <label class="chk"><input type="checkbox" id="caForce"> ${CA_T("ترسیم حتی اگر پوشش داده کمتر از ۵۰٪ باشد (با هشدار روی نقشه)","Draw even if data coverage is below 50% (with a warning on the map)")}</label>
    <button class="btn main" type="button" id="caBtnMap">${CA_T("ترسیم نقشه","Draw map")}</button></section>`;
  const fillList=()=>{ const o=$("caOst").value, ty=$("caType").value, q=$("caQ").value.trim(), qn=q.replace(/ي/g,"ی").replace(/ك/g,"ک").toLowerCase();
    const L=CLIM_META.st.filter(s=>(!o||s.ostan===o)&&(!ty||s.type===ty)&&(!q||(s.fa+" "+s.en).replace(/ي/g,"ی").replace(/ك/g,"ک").toLowerCase().includes(qn)));
    $("caList").replaceChildren(...L.slice(0,400).map(s=>{ const l=document.createElement("label"); l.className="chk"; const c=document.createElement("input"); c.type="checkbox"; c.checked=CA.sel.has(s.id); c.onchange=()=>{ c.checked?CA.sel.add(s.id):CA.sel.delete(s.id); caSync(); };
      l.append(c, document.createTextNode(` ${caStName(s)} `)); const sm=document.createElement("small"); sm.textContent=`${s.ostan||""} · ${s.y0?FA(s.y0)+"–"+FA(s.y1):CA_T("میانگین بلندمدت","long-term mean")}${s.type==="raingauge"?CA_T(" · باران‌سنجی"," · rain gauge"):s.type==="aws"?CA_T(" · خودکار"," · AWS"):s.type==="climatology"?CA_T(" · اقلیم‌شناسی"," · climatological"):""}${s.org&&s.org!=="سازمان هواشناسی"?" · "+(LANG==="en"?({"وزارت نیرو":"Ministry of Energy","جهاد کشاورزی":"Agriculture Jihad","پایگاه هوایی امیدیه":"Omidiyeh air base","ایستگاه خودکار (AWS)":"AWS"}[s.org]||s.org):s.org):""}`; l.append(sm);
      if(s.vs==="unverified"){ const w=document.createElement("small"); w.className="caUv"; w.textContent=CA_T(" ⚠ مختصات تأییدنشده"," ⚠ unverified coordinates"); w.title=CA_T("مختصات/ارتفاع این ایستگاه با فرادادهٔ رسمی سازمان هواشناسی تأیید نشده است ("+(s.lsrc||"")+")","Coordinates/elevation not confirmed against official IRIMO metadata"); l.append(w); }
      return l; }));
    CA.listed=L; };
  for(const id of ["caOst","caType"]) $(id).onchange=fillList; $("caQ").oninput=()=>{ clearTimeout(CA.qt); CA.qt=setTimeout(fillList,150); };
  $("caAll").onclick=()=>{ (CA.listed||[]).forEach(s=>CA.sel.add(s.id)); fillList(); caSync(); };
  $("caNone").onclick=()=>{ CA.sel.clear(); fillList(); caSync(); };
  $("caMapType").onchange=()=>{ $("caAnYRow").hidden=$("caMapType").value!=="anom"; caSync(); };
  $("caPar").onchange=caSync;
  $("caSeats").checked=store.get("seats.on",false); $("caSeats").onchange=()=>store.set("seats.on",$("caSeats").checked);
  $("caPer").onchange=()=>{ $("caCustRow").hidden=$("caPer").value!=="custom"; };
  $("caCm0").value="9"; $("caCm1").value="11";
  $("caBtnM").onclick=()=>caDo("m"); $("caBtnA").onclick=()=>caDo("a"); $("caBtnI").onclick=()=>caDo("i"); $("caBtnC").onclick=()=>caDo("c"); $("caBtnMap").onclick=()=>caDo("map");
  fillList(); caSync();
}
function caSelected(){ return CLIM_META.st.filter(s=>CA.sel.has(s.id)); }
function caPerSel(){ const v=$("caPer").value; if(v!=="custom") return v; const a=+$("caCm0").value, b=+$("caCm1").value; return `c${a}_${b}`; }
function caSync(){
  const sts=caSelected(), par=$("caPar"), cur=par.value;
  const ps=Object.keys(CA_P).filter(p=>sts.length? sts.some(s=>s.d[p]) : true);
  par.replaceChildren(...ps.map(p=>{ const o=document.createElement("option"); o.value=p; o.textContent=CA_T(CA_P[p].fa,CA_P[p].en)+(sts.length?` (${FA(sts.filter(s=>s.d[p]).length)})`:""); return o; }));
  if(ps.includes(cur)) par.value=cur;
  $("caSelInfo").textContent = sts.length ? CA_T(`${FA(sts.length)} ایستگاه انتخاب شده`,`${sts.length} stations selected`) : CA_T("یک یا چند ایستگاه انتخاب کنید","Select one or more stations");
  const withLoc=sts.filter(s=>s.lat!=null && s.d[par.value]).length, ok=withLoc>=10;
  ["caMapType","caMeth","caElev","caBtnMap","caAnY"].forEach(id=>$(id).disabled=!ok);
  $("caMapHint").textContent= ok ? CA_T(`${FA(withLoc)} ایستگاه با مختصات برای «${CA_P[par.value].fa}»`,`${withLoc} stations with coordinates for ${CA_P[par.value].en}`) : CA_T("برای نقشه دست‌کم ۱۰ ایستگاه (با مختصات و دادهٔ این پارامتر) انتخاب کنید.","Select at least 10 stations (with coordinates and data for this parameter) to enable the map.");
  const p=par.value, mt=$("caMapType").value, elevOk=CA_P[p] && CA_P[p].elev && (mt==="val"||mt==="rl"||mt==="q");
  $("caElevRow").hidden=!elevOk;
}
function caCard(title, cv, note){
  const card=document.createElement("article"); card.className="card wide"; const h=document.createElement("header"); h.innerHTML=`<h3></h3>`; h.querySelector("h3").textContent=title;
  const img=new Image(); img.src=cv.toDataURL("image/png"); img.style.width="100%"; img.alt=title;
  const zt=cv.__geo?CA_T("بزرگ‌نمایی نقشه (نام و مقدار ایستگاه‌ها در بزرگ‌نمایی نوشته می‌شود)","Zoom map (station names and values appear when zoomed)"):CA_T("بزرگ‌نمایی","Zoom");
  img.style.cursor="zoom-in"; img.title=zt; img.onclick=()=>caZoom(img, cv, title);
  const wrap=document.createElement("div"); wrap.className="caImgWrap"; wrap.append(img);
  const zb=document.createElement("button"); zb.type="button"; zb.className="caZoomBtn"; zb.title=zt; zb.setAttribute("aria-label",zt); zb.innerHTML='<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.5 15.5 21 21M10.5 7.5v6M7.5 10.5h6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>'; zb.onclick=()=>caZoom(img, cv, title); wrap.append(zb);
  const dl=document.createElement("div"); dl.className="dl"; const b=document.createElement("button"); b.type="button"; b.className="btn"; b.textContent=CA_T("دانلود PNG","Download PNG");
  b.onclick=()=>cv.toBlob(bl=>{ const u=URL.createObjectURL(bl), a=document.createElement("a"); a.href=u; a.download="metstat_"+title.replace(/[^\w؀-ۿ]+/g,"_").slice(0,60)+".png"; a.click(); setTimeout(()=>URL.revokeObjectURL(u),4000); },"image/png");
  const zb2=document.createElement("button"); zb2.type="button"; zb2.className="btn"; zb2.textContent="🔍 "+CA_T("بزرگ‌نمایی","Zoom"); zb2.onclick=()=>caZoom(img, cv, title);
  dl.append(b, zb2);
  if(cv.__rep && typeof caReportSrc==="function"){ const rb=document.createElement("button"); rb.type="button"; rb.className="btn main"; rb.textContent=CA_T("تولید گزارش و تحلیل","Generate report & analysis");
    rb.onclick=()=>{ try{ vReportShow(caReportSrc(cv.__rep, title, img)); }catch(e){ console.error(e); caStatus("⚠ "+e.message,0); } }; dl.append(rb); }
  card.append(h,wrap); if(note){ const p=document.createElement("p"); p.className="hint"; p.textContent=note; card.append(p); } card.append(dl);
  $("caCards").prepend(card); $("caEmpty").hidden=true;
  if(window.matchMedia && matchMedia("(max-width:980px)").matches) setTimeout(()=>card.scrollIntoView({behavior:"smooth",block:"start"}),60);
  return card;
}
async function caDo(kind){
  if(kind==="map" && typeof CAX_MT!=="undefined" && CAX_MT.has($("caMapType").value)) return caxMapDo();
  if(CA.busy) return; CA.busy=true;
  try{ await caLoad(); await document.fonts.ready;
    const sts=caSelected(), p=$("caPar").value, per=caPerSel(), y0=+$("caY0").value, y1=+$("caY1").value, idx=$("caIdx").value, lag=Math.max(0,Math.min(12,+$("caLag").value||0));
    if(kind!=="i" && !sts.length) throw new Error(CA_T("دست‌کم یک ایستگاه انتخاب کنید","Select at least one station"));
    caStatus(CA_T("در حال محاسبه…","Computing…"),0.3); await new Promise(r=>setTimeout(r,20));
    if(kind==="m"){ const cv=caChartMonthly(sts.slice(0,12),p,y0,y1); if(!cv) throw new Error(CA_T("دادهٔ کافی در این دوره نیست","Not enough data in this period")); caCard(CA_T("نمودار ماهانه","Monthly chart")+" — "+CA_T(CA_P[p].fa,CA_P[p].en), cv, sts.length>12?CA_T("فقط ۱۲ ایستگاه اول نمایش داده شد.","Only the first 12 stations are shown."):""); }
    else if(kind==="a"){ const cv=caChartAnnual(sts.slice(0,12),p,per,y0,y1); if(!cv) throw new Error(CA_T("دادهٔ کافی در این دوره نیست","Not enough data in this period")); caCard(CA_T("نمودار سالانه","Annual chart")+" — "+CA_T(CA_P[p].fa,CA_P[p].en), cv); }
    else if(kind==="i"){ const cv=caChartIndex(idx,per,y0,y1); if(!cv) throw new Error(CA_T("دادهٔ شاخص در این دوره نیست","No index data in this period")); caCard(CA_T("سری زمانی شاخص ","Index time series ")+idx, cv); }
    else if(kind==="c"){ const cv=caChartCorr(sts.slice(0,8),p,per,idx,lag,y0,y1); caCard(CA_T("همبستگی با ","Correlation with ")+idx, cv); }
    else if(kind==="map"){ const mt=$("caMapType").value, P=CA_P[p], pts=[];
      for(const s of sts){ if(s.lat==null) continue; const nmv=(mt==="val"&&(per==="wy"||per==="year")&&s.nm)?caNmGet(s,p):null; if(!s.d[p] && nmv==null) continue; const m=s.d[p]?caAggSt(s,p,per,P.agg):new Map(), ys=[...m.keys()].filter(y=>y>=y0&&y<=y1);
        if(mt==="val"){ if(ys.length<Math.max(5,(y1-y0+1)*0.4)){ if(nmv!=null) pts.push({lat:s.lat,lon:s.lon,elev:s.elev||0,v:nmv,name:caStName(s),uv:s.vs==="unverified"}); continue; } const v=ys.reduce((q,y)=>q+m.get(y),0)/ys.length; pts.push({lat:s.lat,lon:s.lon,elev:s.elev||0,v,name:caStName(s),uv:s.vs==="unverified"}); }
        else if(mt==="anom"){ const ay=+$("caAnY").value; if(!m.has(ay) || ys.length<10) continue; const mean=ys.reduce((q,y)=>q+m.get(y),0)/ys.length; const v= (P.kind==="p"||p==="evap") ? (mean>0?(m.get(ay)-mean)/mean*100:NaN) : m.get(ay)-mean; if(v===v) pts.push({lat:s.lat,lon:s.lon,elev:s.elev||0,v,name:caStName(s),uv:s.vs==="unverified"}); }
        else if(mt==="trend"){ const xs=ys.sort((a,b)=>a-b); if(xs.length<12) continue; const tr=caTrend(xs,xs.map(y=>m.get(y))); if(tr) pts.push({lat:s.lat,lon:s.lon,elev:s.elev||0,v:tr.slope*10,sig:tr.p<0.05,name:caStName(s),uv:s.vs==="unverified"}); }
        else if(mt==="corr"){ const d=caCorrData(s,p,per,idx,lag,y0,y1); if(d && d.n>=12 && d.r===d.r) pts.push({lat:s.lat,lon:s.lon,elev:0,v:d.r,sig:d.p<0.05,name:caStName(s),uv:s.vs==="unverified"}); } }
      if(pts.length<5) throw new Error(CA_T(`فقط ${FA(pts.length)} ایستگاه دادهٔ کافی دارد؛ دوره را بزرگ‌تر یا ایستگاه‌های بیشتری انتخاب کنید.`,`Only ${pts.length} stations have enough data; widen the period or add stations.`));
      const useElev=!$("caElevRow").hidden && $("caElev").checked && mt==="val" && P.elev && pts.length>=8;
      const kind_= mt==="corr" ? "corr" : mt==="trend"||mt==="anom" ? (P.kind==="p"?"pdiv":"div") : P.kind;
      const unit= mt==="corr" ? CA_T("ضریب همبستگی پیرسون (نقطهٔ سیاه: معنی‌دار در سطح ۵٪)","Pearson r (black dot: significant at 5%)") : mt==="trend" ? CA_T(`${P.u} در دهه (نقطه‌ها: ایستگاه‌ها)`,`${P.ue} per decade`) : mt==="anom" ? ((P.kind==="p"||p==="evap")?CA_T("درصد اختلاف از میانگین","% departure from mean"):CA_T(`اختلاف از میانگین (${P.u})`,`Departure from mean (${P.ue})`)) : CA_T(P.u,P.ue);
      const ttl= mt==="corr" ? CA_T(`پهنه‌بندی همبستگی ${P.fa} با ${caIdxName(idx)} — ${caPerName(per)}`,`Correlation of ${P.en} with ${idx} — ${caPerName(per)}`)
        : mt==="trend" ? CA_T(`روند ${P.fa} — ${caPerName(per)}`,`${P.en} trend — ${caPerName(per)}`)
        : mt==="anom" ? CA_T(`ناهنجاری ${P.fa} سال ${FA(+$("caAnY").value)} — ${caPerName(per)}`,`${P.en} anomaly ${$("caAnY").value} — ${caPerName(per)}`)
        : CA_T(`میانگین ${P.fa} — ${caPerName(per)}`,`Mean ${P.en} — ${caPerName(per)}`);
      const sub=CA_T(`دورهٔ ${FA(y0)} تا ${FA(y1)}${mt==="corr"?` · تأخیر ${FA(lag)} ماه`:""}`,`${y0}–${y1}${mt==="corr"?` · lag ${lag} months`:""}`);
      const cov=caCoverage(pts); let warn=null;
      if(cov<0.5){
        const msg=CA_T(`پوشش داده ناکافی: فقط ${FA(Math.round(cov*100))}٪ از مساحت ایرانِ داخل کادر در شعاع ۱۰۰ کیلومتری ایستگاهی با دادهٔ کافی است.`,`Insufficient data coverage: only ${Math.round(cov*100)}% of Iran's area inside the frame lies within 100 km of a station with enough data.`);
        if(!$("caForce").checked) throw new Error(msg+CA_T(" نقشه ترسیم نشد؛ دوره، پارامتر یا ایستگاه‌ها را تغییر دهید (یا گزینهٔ «ترسیم حتی اگر…» را بزنید)."," The map was not drawn; change the period, parameter or stations (or tick “Draw even if…”)."));
        warn="⚠ "+CA_T(`این نقشه مشکل دارد: ${msg.replace("پوشش داده ناکافی: ","")} مقادیر دور از ایستگاه‌ها قابل اعتماد نیستند.`,`This map is unreliable: ${msg.replace("Insufficient data coverage: ","")} Values far from stations should not be trusted.`);
      }
      caStatus(CA_T("درون‌یابی و ترسیم نقشه…","Interpolating and drawing the map…"),0.6); await new Promise(r=>setTimeout(r,20));
      const isPc=P.kind==="p"||p==="evap", mmP=(p==="prcp"||p==="pmax");
      const scheme= mt==="corr" ? "tanom" : mt==="val" ? (mmP?"wmp":P.kind==="t"?"wmt":null) : (P.kind==="t"?"tanom":isPc?"panom":"tanom");
      const brA=(mt==="anom"&&isPc)?[-100,-80,-60,-40,-20,-10,10,20,40,60,80,100,150,200,300]:null;
      const cv=await caMap({pts, title:ttl, sub, unit, kind:kind_, scheme, center:0, breaks:brA||undefined, warn, method:$("caMeth").value, useElev, clampMin:(mt==="val"&&P.agg!=="mean"&&P.kind!=="t")?0:null,
        note:CA_T("خانه‌های دورتر از ۳۰۰ کیلومتر از نزدیک‌ترین ایستگاه و بیرون از ایران رنگ نمی‌گیرند.","Cells farther than 300 km from the nearest station, and outside Iran, are left blank.")});
      const isPm=P.kind==="p"||p==="evap";
      cv.__rep={kind:"map", mt, p, per, y0, y1, ay:+$("caAnY").value, lag, idx, pts, cov, interp:cv.__interp, frac:cv.__frac, br:cv.__br,
        unitShort: mt==="corr" ? "" : mt==="anom" ? (isPm?CA_T("٪","%"):" "+CA_T(P.u,P.ue)) : mt==="trend" ? " "+CA_T(P.u+" در دهه",P.ue+"/decade") : " "+CA_T(P.u,P.ue)};
      caCard(ttl, cv); }
    caStatus("",1);
  }catch(e){ console.error(e); caStatus("⚠ "+e.message,0); }
  CA.busy=false;
}
function caAsideToggle(force){
  const A=$("caAside"), b=$("caAsideTgl"); if(!A||!b) return; const c= force!==undefined ? force : !A.classList.contains("collapsed");
  A.classList.toggle("collapsed",c); const en=typeof LANG!=="undefined"&&LANG==="en";
  b.textContent = c ? (en?"▾ Show settings menus":"▾ نمایش منوهای تنظیمات") : (en?"▴ Hide settings menus":"▴ بستن منوهای تنظیمات");
}
document.addEventListener("click",e=>{ if(e.target && e.target.id==="caAsideTgl") caAsideToggle(); });
async function openCA(){
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp"]) if($(id)) $(id).hidden=true; $("caApp").hidden=false; store.set("mode","ca"); window.scrollTo(0,0);
  caStatus(CA_T("بارگذاری پایگاه داده…","Loading database…"),0.2); await caLoad(); caStatus("",1); caBuildUI();
}

// ---------- بزرگ‌نمایی نقشه: با زوم، نام و مقدار ایستگاه‌ها هر جا جا باشد نوشته می‌شود ----------
function caZoom(img, cv, title){
  const d=vDialog("caZoomDlg","zoomdlg"), en=LANG==="en"; d.dir=en?"ltr":"rtl"; d.querySelector("h3").textContent=title;
  const b=d.querySelector(".vdb"); b.replaceChildren(); const f=d.querySelector(".vdf"); f.replaceChildren();
  const box=document.createElement("div"); box.className="czBox"; const c=document.createElement("canvas"); box.append(c); b.append(box);
  const tools=document.createElement("div"); tools.className="czTools";
  const mk=(t,fn,ti)=>{ const x=document.createElement("button"); x.type="button"; x.className="btn sm"; x.textContent=t; x.title=ti||""; x.onclick=fn; tools.append(x); return x; };
  const lbChk=document.createElement("label"); lbChk.className="chk"; lbChk.innerHTML=`<input type="checkbox" checked> ${CA_T("نام ایستگاه‌ها","Station names")}`; tools.append(lbChk);
  f.append(tools); d.showModal();
  const G=cv.__geo, L=cv.__lab||[], IW=img.naturalWidth, IH=img.naturalHeight, x=c.getContext("2d");
  let W=0,H=0,dpr=Math.min(2,window.devicePixelRatio||1), s=1, fit=1, tx=0, ty=0;
  const size=()=>{ const r=box.getBoundingClientRect(); W=r.width; H=r.height; c.width=W*dpr; c.height=H*dpr; c.style.width=W+"px"; c.style.height=H+"px"; };
  const reset=()=>{ size(); fit=Math.min(W/IW,H/IH); s=fit; tx=(W-IW*s)/2; ty=(H-IH*s)/2; draw(); };
  const clampV=()=>{ const mw=IW*s, mh=IH*s; tx=mw<W?(W-mw)/2:Math.min(0,Math.max(W-mw,tx)); ty=mh<H?(H-mh)/2:Math.min(0,Math.max(H-mh,ty)); };
  function draw(){ clampV(); x.setTransform(dpr,0,0,dpr,0,0); x.fillStyle="#fff"; x.fillRect(0,0,W,H); x.imageSmoothingEnabled=s<1; x.drawImage(img,tx,ty,IW*s,IH*s);
    if(!lbChk.querySelector("input").checked || s<fit*1.6 || !G) return;
    // موقعیت ایستگاه‌ها روی صفحه
    const k=G.sc, occ=[], fs=12; x.font=`600 ${fs}px ${FT.body}`;
    const pos=L.map(p=>({p, X:tx+(G.mx0+(p.lon-G.lo0)/(G.lo1-G.lo0)*G.MW)*k*s, Y:ty+(G.my0+(G.la1-p.lat)/(G.la1-G.la0)*G.MHh)*k*s})).filter(q=>q.X>-50&&q.X<W+50&&q.Y>-20&&q.Y<H+20);
    for(const q of pos) occ.push([q.X-3,q.Y-3,q.X+3,q.Y+3]);
    const hit=r=>occ.some(o=>r[0]<o[2]&&r[2]>o[0]&&r[1]<o[3]&&r[3]>o[1]);
    for(const q of pos){ const t=`${q.p.name}`, w=x.measureText(t).width;
      const cands=[[q.X+5,q.Y-4,"left"],[q.X-5,q.Y-4,"right"],[q.X+5,q.Y+13,"left"],[q.X-5,q.Y+13,"right"]];
      for(const [ax,ay,al] of cands){ const r=al==="left"?[ax,ay-fs+2,ax+w,ay+3]:[ax-w,ay-fs+2,ax,ay+3]; if(r[0]<2||r[2]>W-2||r[1]<2||r[3]>H-2||hit(r)) continue;
        occ.push(r); txtHalo(x,t,ax,ay,`600 ${fs}px ${FT.body}`,{align:al,color:"#0f172a",halo:3,dir:en?"ltr":"rtl"}); break; } } }
  const zoomAt=(f_,cx,cy)=>{ const ns=Math.max(fit,Math.min(fit*14,s*f_)); tx=cx-(cx-tx)*ns/s; ty=cy-(cy-ty)*ns/s; s=ns; draw(); };
  mk("+",()=>zoomAt(1.5,W/2,H/2),CA_T("بزرگ‌نمایی","Zoom in")); mk("−",()=>zoomAt(1/1.5,W/2,H/2),CA_T("کوچک‌نمایی","Zoom out")); mk(CA_T("کل نقشه","Fit"),reset);
  lbChk.querySelector("input").onchange=draw;
  c.addEventListener("wheel",e=>{ e.preventDefault(); const r=c.getBoundingClientRect(); zoomAt(e.deltaY<0?1.2:1/1.2,e.clientX-r.left,e.clientY-r.top); },{passive:false});
  const ptr=new Map(); let pd=0;
  c.addEventListener("pointerdown",e=>{ c.setPointerCapture(e.pointerId); ptr.set(e.pointerId,[e.clientX,e.clientY]); });
  c.addEventListener("pointermove",e=>{ if(!ptr.has(e.pointerId)) return; const old=ptr.get(e.pointerId); ptr.set(e.pointerId,[e.clientX,e.clientY]);
    if(ptr.size===1){ tx+=e.clientX-old[0]; ty+=e.clientY-old[1]; draw(); }
    else if(ptr.size===2){ const [a,b2]=[...ptr.values()], dd=Math.hypot(a[0]-b2[0],a[1]-b2[1]), r=c.getBoundingClientRect(); if(pd) zoomAt(dd/pd,(a[0]+b2[0])/2-r.left,(a[1]+b2[1])/2-r.top); pd=dd; } });
  const up=e=>{ ptr.delete(e.pointerId); if(ptr.size<2) pd=0; }; c.addEventListener("pointerup",up); c.addEventListener("pointercancel",up);
  c.addEventListener("dblclick",e=>{ const r=c.getBoundingClientRect(); zoomAt(2,e.clientX-r.left,e.clientY-r.top); });
  requestAnimationFrame(reset); const ro=new ResizeObserver(()=>{ const ow=W; size(); if(ow) draw(); }); ro.observe(box); d.addEventListener("close",()=>ro.disconnect(),{once:true});
}
