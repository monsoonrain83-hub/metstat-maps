/* ---------- ابزار عددی ---------- */
function dsGauss1(src, W, H, s, horiz, out){
  const r=Math.max(1,Math.ceil(3*s)), k=new Float64Array(2*r+1); let ks=0;
  for(let q=-r;q<=r;q++){ k[q+r]=Math.exp(-q*q/(2*s*s)); ks+=k[q+r]; } for(let q=0;q<k.length;q++) k[q]/=ks;
  if(horiz){ for(let y=0;y<H;y++){ const o=y*W; for(let x=0;x<W;x++){ let a=0; for(let q=-r;q<=r;q++){ let xx=x+q; xx=xx<0?0:xx>=W?W-1:xx; a+=k[q+r]*src[o+xx]; } out[o+x]=a; } } }
  else { for(let y=0;y<H;y++) for(let x=0;x<W;x++){ let a=0; for(let q=-r;q<=r;q++){ let yy=y+q; yy=yy<0?0:yy>=H?H-1:yy; a+=k[q+r]*src[yy*W+x]; } out[y*W+x]=a; } }
}
function dsGauss(a, W, H, sy, sx){
  const t=new Float64Array(W*H), o=new Float64Array(W*H);
  if(sx>0.05) dsGauss1(a,W,H,sx,true,t); else t.set(a);
  if(sy>0.05) dsGauss1(t,W,H,sy,false,o); else o.set(t);
  return o;
}
// هموارسازی گوسی با نادیده‌گرفتن پیکسل‌های بی‌داده (normalized convolution)
function dsMGauss(a, valid, W, H, sy, sx, wgt){
  const v=new Float64Array(W*H), w=new Float64Array(W*H);
  for(let i=0;i<W*H;i++) if(valid[i] && a[i]===a[i]){ const q=wgt?wgt[i]:1; v[i]=a[i]*q; w[i]=q; }
  const s=dsGauss(v,W,H,sy,sx), nn=dsGauss(w,W,H,sy,sx), out=new Float64Array(W*H);
  for(let i=0;i<W*H;i++) out[i] = nn[i]>1e-3*(wgt?1e-3:1) ? s[i]/nn[i] : NaN;
  return out;
}
function dsMaxFilter(a, W, H, ry, rx){
  const t=new Float64Array(W*H), o=new Float64Array(W*H);
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){ let m=-Infinity; for(let q=Math.max(0,x-rx);q<=Math.min(W-1,x+rx);q++){ const v=a[y*W+q]; if(v>m) m=v; } t[y*W+x]=m; }
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){ let m=-Infinity; for(let q=Math.max(0,y-ry);q<=Math.min(H-1,y+ry);q++){ const v=t[q*W+x]; if(v>m) m=v; } o[y*W+x]=m; }
  return o;
}
function dsGrad(z, W, H, dxk, dyk){
  const gx=new Float64Array(W*H), gy=new Float64Array(W*H), ok=i=>z[i]===z[i];
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){ const i=y*W+x; if(!ok(i)){ gx[i]=gy[i]=NaN; continue; }
    const xl=x>0&&ok(i-1)?x-1:x, xr=x<W-1&&ok(i+1)?x+1:x; gx[i]= xr>xl ? (z[y*W+xr]-z[y*W+xl])/((xr-xl)*dxk) : 0;
    const yu=y>0&&ok(i-W)?y-1:y, yd=y<H-1&&ok(i+W)?y+1:y; gy[i]= yd>yu ? -(z[yd*W+x]-z[yu*W+x])/((yd-yu)*dyk) : 0; }
  return [gx,gy];
}
function dsDistKm(valid, W, H, dxk, dyk){
  const d=new Float64Array(W*H), dd=Math.hypot(dxk,dyk);
  for(let i=0;i<W*H;i++) d[i]=valid[i]?1e9:0;
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){ const i=y*W+x; if(!d[i]) continue; let v=d[i];
    if(x>0) v=Math.min(v,d[i-1]+dxk); if(y>0){ v=Math.min(v,d[i-W]+dyk); if(x>0) v=Math.min(v,d[i-W-1]+dd); if(x<W-1) v=Math.min(v,d[i-W+1]+dd); } d[i]=v; }
  for(let y=H-1;y>=0;y--) for(let x=W-1;x>=0;x--){ const i=y*W+x; if(!d[i]) continue; let v=d[i];
    if(x<W-1) v=Math.min(v,d[i+1]+dxk); if(y<H-1){ v=Math.min(v,d[i+W]+dyk); if(x<W-1) v=Math.min(v,d[i+W+1]+dd); if(x>0) v=Math.min(v,d[i+W-1]+dd); } d[i]=v; }
  return d;
}
function dsPct(arr, p){ const a=Float64Array.from(arr).sort(); if(!a.length) return NaN; const k=(a.length-1)*p/100, i=Math.floor(k); return i+1<a.length ? a[i]+(a[i+1]-a[i])*(k-i) : a[i]; }
// معکوس ماتریس متقارن مثبت معین (چولسکی)
function dsSpdInv(A, p){
  const L=new Float64Array(p*p);
  for(let i=0;i<p;i++) for(let j=0;j<=i;j++){ let s=A[i*p+j]; for(let k=0;k<j;k++) s-=L[i*p+k]*L[j*p+k];
    if(i===j){ if(!(s>0)) return null; L[i*p+i]=Math.sqrt(s); } else L[i*p+j]=s/L[j*p+j]; }
  const Li=new Float64Array(p*p);
  for(let i=0;i<p;i++){ Li[i*p+i]=1/L[i*p+i]; for(let j=0;j<i;j++){ let s=0; for(let k=j;k<i;k++) s-=L[i*p+k]*Li[k*p+j]; Li[i*p+j]=s/L[i*p+i]; } }
  const R=new Float64Array(p*p);
  for(let i=0;i<p;i++) for(let j=0;j<=i;j++){ let s=0; for(let k=i;k<p;k++) s+=Li[k*p+i]*Li[k*p+j]; R[i*p+j]=R[j*p+i]=s; }
  return R;
}
// پایهٔ B-اسپلاین مکعبی یکنواخت روی [lo, hi] با nseg قطعه (nseg+3 تابع)
function dsBrow(x, lo, hi, nseg, out, off){
  const h=(hi-lo)/nseg; let t=(Math.min(Math.max(x,lo),hi-1e-9*(hi-lo))-lo)/h, k=Math.floor(t); if(k>=nseg) k=nseg-1; if(k<0) k=0; const u=t-k;
  for(let q=0;q<nseg+3;q++) out[off+q]=0;
  out[off+k]=(1-u)**3/6; out[off+k+1]=(3*u**3-6*u**2+4)/6; out[off+k+2]=(-3*u**3+3*u**2+3*u+1)/6; out[off+k+3]=u**3/6;
}
function dsPen(nb){ const P=new Float64Array(nb*nb); for(let r=0;r<nb-2;r++){ const d=[1,-2,1]; for(let a=0;a<3;a++) for(let b=0;b<3;b++) P[(r+a)*nb+r+b]+=d[a]*d[b]; } return P; }
function dsCross(X, n, p, y){
  const XtX=new Float64Array(p*p), Xty=new Float64Array(p); let yty=0;
  for(let r=0;r<n;r++){ const o=r*p, yr=y[r]; yty+=yr*yr;
    for(let i=0;i<p;i++){ const xi=X[o+i]; if(!xi) continue; Xty[i]+=xi*yr; for(let j=i;j<p;j++) XtX[i*p+j]+=xi*X[o+j]; } }
  for(let i=0;i<p;i++) for(let j=0;j<i;j++) XtX[i*p+j]=XtX[j*p+i];
  return {XtX, Xty, yty};
}
// حل کمترین مربعات جریمه‌دار: min |y-Xb|² + (b-b0)'S(b-b0)
function dsSolve(C, S, p, b0){
  const A=new Float64Array(p*p); let tr=0;
  for(let i=0;i<p*p;i++) A[i]=C.XtX[i]+S[i];
  for(let i=0;i<p;i++) tr+=A[i*p+i]; for(let i=0;i<p;i++) A[i*p+i]+=1e-9*tr/p;
  const Ai=dsSpdInv(A,p); if(!Ai) return null;
  const rhs=Float64Array.from(C.Xty); if(b0) for(let i=0;i<p;i++){ let s=0; for(let j=0;j<p;j++) s+=S[i*p+j]*b0[j]; rhs[i]+=s; }
  const b=new Float64Array(p); for(let i=0;i<p;i++){ let s=0; for(let j=0;j<p;j++) s+=Ai[i*p+j]*rhs[j]; b[i]=s; }
  let edf=0; for(let i=0;i<p;i++) for(let j=0;j<p;j++) edf+=Ai[i*p+j]*C.XtX[j*p+i];
  let bXy=0, bXXb=0; for(let i=0;i<p;i++){ bXy+=b[i]*C.Xty[i]; let s=0; for(let j=0;j<p;j++) s+=C.XtX[i*p+j]*b[j]; bXXb+=b[i]*s; }
  return {b, Ai, edf, rss:Math.max(C.yty-2*bXy+bXXb, 1e-12)};
}

/* ---------- مدل GAM ---------- */
// log(P+1) = b0 + s(Z_model) + s(lon,lat) + γx·∂Z/∂x + γy·∂Z/∂y
function dsFitGAM(D, cfg){
  const n=D.y.length, nseg=cfg.knots, nb=nseg+3, nxy=6, nbx=nxy+3, nbt=nbx*nbx, useE=cfg.expo;
  const zlo=dsPct(D.z,0.5), zhi=Math.max(dsPct(D.z,99.5), zlo+1);
  const mnA=a=>a.reduce((x,y)=>x<y?x:y), mxA=a=>a.reduce((x,y)=>x>y?x:y), lo0=mnA(D.lon), lo1=mxA(D.lon)+1e-6, la0=mnA(D.lat), la1=mxA(D.lat)+1e-6;
  const iZ=1, iT=1+nb, iE=iT+nbt, p=iE+(useE?2:0), X=new Float64Array(n*p);
  const bz=new Float64Array(nb), bx=new Float64Array(nbx), by=new Float64Array(nbx);
  const esd=[1,1];
  if(useE){ for(const [k,a] of [[0,D.gx],[1,D.gy]]){ let m=0; for(const v of a) m+=v; m/=n; let s=0; for(const v of a) s+=(v-m)**2; esd[k]=Math.sqrt(s/n)+1e-9; } }
  for(let r=0;r<n;r++){ const o=r*p; X[o]=1;
    dsBrow(D.z[r], zlo, zhi, nseg, bz, 0); for(let q=0;q<nb;q++) X[o+iZ+q]=bz[q];
    dsBrow(D.lon[r], lo0, lo1, nxy, bx, 0); dsBrow(D.lat[r], la0, la1, nxy, by, 0);
    for(let a=0;a<nbx;a++){ if(!bx[a]) continue; for(let b=0;b<nbx;b++) X[o+iT+a*nbx+b]=bx[a]*by[b]; }
    if(useE){ X[o+iE]=D.gx[r]/esd[0]; X[o+iE+1]=D.gy[r]/esd[1]; } }
  const zc=new Float64Array(nb);
  for(let c=1;c<p;c++){ let m=0; for(let r=0;r<n;r++) m+=X[r*p+c]; m/=n; for(let r=0;r<n;r++) X[r*p+c]-=m; if(c>=iZ && c<iZ+nb) zc[c-iZ]=m; }
  const C=dsCross(X,n,p,D.y), Pz=dsPen(nb), Px=dsPen(nbx);
  const Pt=new Float64Array(nbt*nbt);
  for(let a=0;a<nbx;a++) for(let b=0;b<nbx;b++) for(let c=0;c<nbx;c++) for(let d=0;d<nbx;d++){
    let v=0; if(b===d) v+=Px[a*nbx+c]; if(a===c) v+=Px[b*nbx+d]; if(v) Pt[(a*nbx+b)*nbt+c*nbx+d]=v; }
  const grid=[0.01,0.1,1,10,100,1000]; let best=null;
  for(const lz of grid) for(const lt of grid){
    const S=new Float64Array(p*p);
    for(let i=0;i<nb;i++) for(let j=0;j<nb;j++) S[(iZ+i)*p+iZ+j]=lz*Pz[i*nb+j];
    for(let i=0;i<nbt;i++) for(let j=0;j<nbt;j++){ const v=Pt[i*nbt+j]; if(v) S[(iT+i)*p+iT+j]=lt*v; }
    const R=dsSolve(C,S,p); if(!R) continue;
    const gcv=n*R.rss/Math.max(n-R.edf,1)**2;
    if(!best || gcv<best.gcv) best={gcv, lz, lt, R};
  }
  if(!best) throw new Error("برازش GAM ناموفق بود");
  const {R}=best, s2=R.rss/Math.max(n-R.edf,1);
  let ym=0; for(const v of D.y) ym+=v; ym/=n; let tss=0; for(const v of D.y) tss+=(v-ym)**2;
  const fitted=new Float64Array(n); for(let r=0;r<n;r++){ let s=0; for(let c=0;c<p;c++) s+=X[r*p+c]*R.b[c]; fitted[r]=s; }
  const cov=new Float64Array(p*p); for(let i=0;i<p*p;i++) cov[i]=R.Ai[i]*s2;
  return {kind:"global", zlo, zhi, nseg, nb, zc, b:R.b, cov, p, iZ, iE:useE?iE:-1, esd, lz:best.lz, lt:best.lt, edf:R.edf, r2:1-R.rss/(tss||1), n, fitted};
}
function dsFitLocal(G, D, idx, cfg){
  const n=idx.length, nb=G.nb, useE=G.iE>=0, iZ=3, iE=iZ+nb, p=iE+(useE?2:0), X=new Float64Array(n*p), y=new Float64Array(n), bz=new Float64Array(nb);
  let ml=0, mt=0; for(const r of idx){ ml+=D.lon[r]; mt+=D.lat[r]; } ml/=n; mt/=n;
  let e0=0, e1=0; if(useE){ for(const r of idx){ e0+=D.gx[r]/G.esd[0]; e1+=D.gy[r]/G.esd[1]; } e0/=n; e1/=n; }
  idx.forEach((r,k)=>{ const o=k*p; X[o]=1; X[o+1]=D.lon[r]-ml; X[o+2]=D.lat[r]-mt;
    dsBrow(D.z[r], G.zlo, G.zhi, G.nseg, bz, 0); for(let q=0;q<nb;q++) X[o+iZ+q]=bz[q]-G.zc[q];
    if(useE){ X[o+iE]=D.gx[r]/G.esd[0]-e0; X[o+iE+1]=D.gy[r]/G.esd[1]-e1; } y[k]=D.y[r]; });
  const C=dsCross(X,n,p,y); let dg=0; for(let q=0;q<nb;q++) dg+=C.XtX[(iZ+q)*p+iZ+q]; const kap=cfg.shrink*dg/nb;
  const S=new Float64Array(p*p), b0=new Float64Array(p), Pz=dsPen(nb);
  for(let i=0;i<nb;i++){ for(let j=0;j<nb;j++) S[(iZ+i)*p+iZ+j]=G.lz*Pz[i*nb+j]; S[(iZ+i)*p+iZ+i]+=kap; b0[iZ+i]=G.b[G.iZ+i]; }
  if(useE) for(let q=0;q<2;q++){ S[(iE+q)*p+iE+q]=kap; b0[iE+q]=G.b[G.iE+q]; }
  const R=dsSolve(C,S,p,b0); if(!R) return null;
  const s2=R.rss/Math.max(n-R.edf,1), cov=new Float64Array(p*p); for(let i=0;i<p*p;i++) cov[i]=R.Ai[i]*s2;
  return {kind:"local", zlo:G.zlo, zhi:G.zhi, nseg:G.nseg, nb, zc:G.zc, b:R.b, cov, p, iZ, iE:useE?iE:-1, esd:G.esd, n};
}
function dsH(M, z, withSE){
  const bz=new Float64Array(M.nb); dsBrow(z, M.zlo, M.zhi, M.nseg, bz, 0); for(let q=0;q<M.nb;q++) bz[q]-=M.zc[q];
  let h=0; for(let q=0;q<M.nb;q++) h+=bz[q]*M.b[M.iZ+q];
  if(!withSE) return h;
  let v=0; for(let a=0;a<M.nb;a++) for(let c=0;c<M.nb;c++) v+=bz[a]*M.cov[(M.iZ+a)*M.p+M.iZ+c]*bz[c];
  return [h, Math.sqrt(Math.max(v,0))];
}
const dsGamma = M => M.iE<0 ? [0,0] : [M.b[M.iE]/M.esd[0], M.b[M.iE+1]/M.esd[1]];
function dsDescribe(M, zs, sig){
  const z5=dsPct(zs,5), z95=dsPct(zs,95), K=200, zz=[], h=[], se=[];
  for(let k=0;k<K;k++){ const z=z5+(z95-z5)*k/(K-1); const [a,b]=dsH(M,z,true); zz.push(z); h.push(a); se.push(b); }
  const hmax=Math.max(...h), hmin=Math.min(...h), rng=hmax-hmin, noise=se.reduce((a,b)=>a+b,0)/K;
  const o={z5, z95, rng, noise, factor:Math.exp(rng), zmax:null, zmin:null, sig:false, type:"تقریباً مستقل از ارتفاع", key:"flat"};
  if(rng < Math.max(sig*noise, 0.05)) return o;
  o.sig=true; const im=h.indexOf(hmax), il=h.indexOf(hmin), tol=Math.max(sig*noise,0.03);
  const intMax = im>0.05*K && im<0.95*K && hmax-h[0]>tol && hmax-h[K-1]>tol;
  const intMin = il>0.05*K && il<0.95*K && h[0]-hmin>tol && h[K-1]-hmin>tol;
  if(intMax){ o.type="تک‌قله‌ای (افزایش تا یک ارتفاع، سپس کاهش)"; o.key="peak"; o.zmax=zz[im]; }
  else if(intMin){ o.type="U شکل (کمینه در ارتفاع‌های میانی)"; o.key="u"; o.zmin=zz[il]; }
  else if(h[K-1]>h[0]){ o.type="افزایشی با ارتفاع"; o.key="up"; o.zmax=zz[im]; }
  else { o.type="کاهشی با ارتفاع"; o.key="down"; o.zmax=zz[im]; }
  return o;
}
function dsLUT(M, zero){ const K=600, h=new Float64Array(K); if(!zero) for(let k=0;k<K;k++) h[k]=dsH(M, M.zlo+(M.zhi-M.zlo)*k/(K-1)); return {lo:M.zlo, hi:M.zhi, h}; }
function dsInterp(L, z){ if(!(z===z)) return 0; let t=(z-L.lo)/(L.hi-L.lo)*(L.h.length-1); if(t<=0) return L.h[0]; const K=L.h.length-1; if(t>=K) return L.h[K]; const i=Math.floor(t), f=t-i; return L.h[i]*(1-f)+L.h[i+1]*f; }

