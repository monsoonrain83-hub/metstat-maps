/* ===== صفحهٔ «تحلیل نقشه‌های آنلاین» =====
   نقشه‌های مدل را اسکریپت سمت هاست (online/mx_fetch.php با Cron) دو بار در روز از meteologix.com (= weather.us) می‌گیرد
   و در online/data می‌گذارد؛ این صفحه فهرست (manifest.json) را می‌خواند و نقشه‌های انتخابی را مستقیم به صفحه‌های
   تحلیل موجود (weather.us، همرفت، هشدار) می‌دهد. ماهواره و رعدوبرق زنده از online/live.php (بدون ذخیره روی هاست). */
const ON={man:null, base:"online/", live:{frames:[], idx:0, timer:null, img:[], info:null}};
const ON_MODEL_FILE={euro:"ECMWF", standard:"GFS", german:"ICON", can:"GEM", aus:"ACCESS", ecmwf:"ECMWF", gfs:"GFS", icon:"ICON", ukmo:"UKMO", gem:"GEM", arpege:"ARPEGE", access:"ACCESS"};
const ON_LIVE_REG=[["iran","ایران","ایران"],["fars","فارس","فارس"],["hormozgan","هرمزگان","هرمزگان"],["gilan","گیلان","گیلان"],["east-azarbaijan","آذربایجان شرقی","آذربایجان‌ها و اردبیل"],["khuzestan","خوزستان","خوزستان"],["tehran","تهران","تهران"]];
const ON_OPS=[
  {id:"show", fa:"نمایش و تغییر ظاهر نقشه‌ها (هر پارامتر)", kind:"show"},
  {id:"p24ens", fa:"بارش ۲۴ ساعته: میانگین، بیشینه، کمینه و احتمال بارش (آستانه‌های مختلف) از چند مدل", kind:"models", p:"p24"},
  {id:"paccens", fa:"بارش تجمعی: میانگین، بیشینه، کمینه و احتمال بارش از چند مدل", kind:"models", p:"pacc"},
  {id:"p1ens", fa:"بارش ۱ ساعته: میانگین، بیشینه، کمینه و احتمال از چند مدل", kind:"models", p:"p1"},
  {id:"p3ens", fa:"بارش ۳ ساعته: میانگین، بیشینه، کمینه و احتمال از چند مدل", kind:"models", p:"p3"},
  {id:"p6ens", fa:"بارش ۶ ساعته: میانگین، بیشینه، کمینه و احتمال از چند مدل", kind:"models", p:"p6"},
  {id:"p48ens", fa:"بارش ۴۸ ساعته: میانگین، بیشینه، کمینه و احتمال از چند مدل", kind:"models", p:"p48"},
  {id:"p120ens", fa:"بارش ۱۲۰ ساعته: میانگین، بیشینه، کمینه و احتمال از چند مدل", kind:"models", p:"p120"},
  {id:"p24sum", fa:"تجمع بارش: جمع بارش ۲۴ ساعتهٔ چند روز", kind:"days", p:"p24"},
  {id:"p24diff", fa:"تفریق بارش: اختلاف دو مدل یا دو روز", kind:"pair", p:"p24"},
  {id:"t2m", fa:"دمای ۲ متری: میانگین، بیشینه، کمینه و توافق مدل‌ها", kind:"models", p:"t2m"},
  {id:"snow", fa:"برف ۲۴ ساعته: مقایسه و میانگین مدل‌ها", kind:"models", p:"snow24"},
  {id:"snowacc", fa:"برف تجمعی: مقایسه و میانگین مدل‌ها", kind:"models", p:"snowacc"},
  {id:"tmax", fa:"دمای بیشینه: میانگین و توافق مدل‌ها", kind:"models", p:"tmax"},
  {id:"tmin", fa:"دمای کمینه: میانگین و توافق مدل‌ها", kind:"models", p:"tmin"},
  {id:"conv", fa:"پتانسیل همرفت (احتمال وقوع و شدت توفان تندری)", kind:"conv", ps:["cape","li","ki","gdi","si","cin","pw","refl"], min:2},
  {id:"warn", fa:"نقشهٔ هشدارهای جوی (رنگی)", kind:"warn", ps:["p24","gust","cape","snow24","t2m","refl"], min:1}
];
const onPar=id=>(ON.man&&ON.man.params||[]).find(p=>p.id===id)||{id,fa:id,unit:""};
const onModelFa=m=>(ON.man&&ON.man.models&&ON.man.models[m]&&ON.man.models[m].fa)||m;
const onFmtValid=v=>{ const d=new Date(Date.UTC(+v.slice(0,4),+v.slice(4,6)-1,+v.slice(6,8),+v.slice(8,10))); return `${persianDT(d,0)} UTC (${persianDT(d,210).split(" ").pop()} به وقت ایران)`; };
const onFmtRun=r=>r?`${faDate(`${r.slice(0,4)}-${r.slice(4,6)}-${r.slice(6,8)}`)} — اجرای ${r.slice(8,10)}Z`:"—";
function onItems(f){ const reg=$("onReg")?$("onReg").value:"iran"; return (ON.man?ON.man.items:[]).filter(i=>i.r===reg && (!f || f(i))); }
function onStatus(t,f){ const s=$("onStatus"); s.hidden=!t; $("onStText").textContent=t||""; if(f!=null) $("onStBar").style.width=(f*100)+"%"; }

async function onLoadManifest(){
  if(!/^https?:/.test(location.protocol)){ ON.man=null; return "این صفحه فقط روی هاست (wtafkik.ir) کار می‌کند؛ نقشه‌ها را برنامهٔ nwp_maps.py (GitHub Actions) می‌سازد و روی هاست می‌گذارد."; }
  try{ const r=await fetch(ON.base+"data/manifest.json?"+Date.now(),{cache:"no-store"}); if(!r.ok) throw new Error(r.status); ON.man=await r.json(); try{ onPruneOld(); nvFixMonths(); }catch(_){ } }
  catch(e){ ON.man=null; return "فهرست نقشه‌ها (online/data/manifest.json) پیدا نشد؛ برنامهٔ ساخت نقشه‌ها (GitHub Actions) هنوز اجرا نشده است (راهنمای نصب را ببینید)."; }
  if(ON.man.status==="waiting") return `نقشه‌های اجرای قبلی حذف شده‌اند؛ دریافت اجرای ${onFmtRun(ON.man.next)} به‌زودی شروع می‌شود.`;
  return "";
}
function onBuildUI(msg){
  const a=$("onAside"), M=ON.man;
  const regs=M&&M.regions?Object.entries(M.regions).filter(([k])=>k!=="me"):[["iran",{fa:"ایران"}]];
  a.innerHTML=nvAsideHTML()+`
  <section class="card"><details id="onAnalysis"><summary><h3 style="display:inline">تحلیل چندمدلی و ابزارهای نقشه</h3></summary>
    <label>منطقهٔ نقشه‌های تحلیلی <select id="onReg">${regs.map(([k,v])=>`<option value="${k}">${v.fa}</option>`).join("")}</select></label>
    <label>عملیات <select id="onOp"></select></label>
    <div id="onOpBox"></div>
    <button class="btn main" type="button" id="onRun">اجرا و ارسال به صفحهٔ تحلیل</button>
    <p class="hint">میانگین، بیشینه، کمینه، احتمال، جمع و تفریق نقشه‌ها: نقشه‌های انتخاب‌شده مستقیم به صفحهٔ تحلیل می‌روند و همهٔ گزینه‌های آن صفحه (مرزبندی، نوار رنگ، خروجی، گزارش متنی، راهنما و…) در دسترس است.</p></details></section>`
  +nvCompHTML()+nvIdxHTML()+`
  <section class="card"><h3>ماهواره و رعدوبرق زنده</h3>
    <label>تصویر <select id="onLvType"><option value="sat">ماهوارهٔ Meteosat — باند مرئی HD (هر ۱۵ دقیقه)</option><option value="lt">رعدوبرق (هر ۵ دقیقه)</option></select></label>
    <label>منطقه <select id="onLvReg">${ON_LIVE_REG.map(([k,f])=>`<option value="${k}">${f}</option>`).join("")}</select></label>
    <label>تعداد فریم <input type="number" id="onLvN" min="1" max="24" value="8"></label>
    <label class="chk"><input type="checkbox" id="onLvBrd" checked> مرزبندی MetStat</label>
    <button class="btn main" type="button" id="onLvGo">دریافت جدیدترین تصاویر</button>
    <p class="hint">تصاویر روی هاست ذخیره نمی‌شوند؛ هر بار از منبع گرفته می‌شوند. ماهواره هر ۱۵ و رعدوبرق هر ۵ دقیقه به‌روز می‌شود.</p></section>`;
  if(M && M.regions){ const r=store.get("on.reg",""); if(M.regions[r]&&r!=="me") $("onReg").value=r; }
  $("onReg").onchange=()=>{ store.set("on.reg",$("onReg").value); onFillOps(); };
  $("onReload").onclick=async()=>{ const m=await onLoadManifest(); onBuildUI(m); };
  $("onOp").onchange=()=>{ store.set("on.op",$("onOp").value); onOpBox(); };
  $("onRun").onclick=()=>onRunOp().catch(e=>{ console.error(e); onStatus("⚠ "+e.message,0); });
  $("onLvGo").onclick=()=>onLiveFetch().catch(e=>{ console.error(e); onStatus("⚠ "+e.message,0); });
  $("onLvBrd").onchange=()=>onLiveDraw();
  onFillOps();
  const has=!!(M&&M.items&&M.items.length);
  $("onEmpty").hidden=has; if(msg) $("onEmpty").querySelector("div").textContent=msg;
  const vw=$("onViewer"); if(vw){ vw.hidden=!has; vw.innerHTML=has?nvViewerHTML():""; if(has){ nvInit(); ncInit(); } }
  niInit();
}
// فقط عملیاتی که پارامترهایش در این اجرا/منطقه موجود است
function onOpAvailable(op){
  const it=onItems(); if(!it.length) return false;
  const has=p=>it.some(i=>i.p===p), models=p=>new Set(it.filter(i=>i.p===p).map(i=>i.m));
  if(op.kind==="show") return true;
  if(op.kind==="models") return models(op.p).size>=1;
  if(op.kind==="days") return it.filter(i=>i.p===op.p).length>=2;
  if(op.kind==="pair") return it.filter(i=>i.p===op.p).length>=2;
  return op.ps.filter(has).length>=op.min;
}
function onFillOps(){
  const s=$("onOp"), ops=ON_OPS.filter(onOpAvailable);
  s.innerHTML=ops.map(o=>`<option value="${o.id}">${o.fa}</option>`).join("") || `<option value="">— نقشه‌ای در دسترس نیست —</option>`;
  const w=store.get("on.op",""); if(ops.some(o=>o.id===w)) s.value=w;
  onOpBox();
}
const onSel=(id,opts,lab)=>`<label>${lab} <select id="${id}">${opts.map(([v,t])=>`<option value="${v}">${t}</option>`).join("")}</select></label>`;
const onChecks=(id,opts,lab,all=true)=>`<div class="onChk"><b>${lab}</b><div id="${id}">${opts.map(([v,t])=>`<label class="chk"><input type="checkbox" value="${v}" ${all?"checked":""}> ${t}</label>`).join("")}</div></div>`;
const onChecked=id=>[...document.querySelectorAll(`#${id} input:checked`)].map(i=>i.value);
const uniq=a=>[...new Set(a)];
function onOpBox(){
  const op=ON_OPS.find(o=>o.id===$("onOp").value), box=$("onOpBox"); if(!op){ box.innerHTML=""; return; }
  const it=onItems();
  if(op.kind==="show"){
    const ms=uniq(it.map(i=>i.m));
    box.innerHTML=onSel("onM",ms.map(m=>[m,onModelFa(m)]),"مدل")+`<label>پارامتر <select id="onP"></select></label><div id="onTimes"></div>`;
    const fillP=()=>{ const ps=uniq(it.filter(i=>i.m===$("onM").value).map(i=>i.p)); $("onP").innerHTML=ps.map(p=>`<option value="${p}">${onPar(p).fa}</option>`).join(""); fillT(); };
    const fillT=()=>{ const vs=it.filter(i=>i.m===$("onM").value&&i.p===$("onP").value).map(i=>i.v).sort();
      $("onTimes").innerHTML=onChecks("onT",vs.map(v=>[v,onFmtValid(v)]),"زمان معتبر پیش‌بینی",false); const f=document.querySelector("#onT input"); if(f) f.checked=true; };
    $("onM").onchange=fillP; $("onP").onchange=fillT; fillP(); return;
  }
  if(op.kind==="models"){
    const vs=uniq(it.filter(i=>i.p===op.p).map(i=>i.v)).sort();
    box.innerHTML=onSel("onV",vs.map(v=>[v,onFmtValid(v)]),"زمان معتبر")+`<div id="onMs"></div><label>آستانهٔ احتمال/توافق <input id="onThr" type="text" placeholder="مثلاً ۱، ۵، ۱۰" value=""></label>`;
    const fill=()=>{ const ms=uniq(it.filter(i=>i.p===op.p&&i.v===$("onV").value).map(i=>i.m)); $("onMs").innerHTML=onChecks("onMsC",ms.map(m=>[m,onModelFa(m)]),"مدل‌ها"); };
    $("onV").onchange=fill; fill(); return;
  }
  if(op.kind==="days"){
    const ms=uniq(it.filter(i=>i.p===op.p).map(i=>i.m));
    box.innerHTML=onSel("onM",ms.map(m=>[m,onModelFa(m)]),"مدل")+`<div id="onDs"></div>`;
    const fill=()=>{ const vs=it.filter(i=>i.p===op.p&&i.m===$("onM").value).map(i=>i.v).sort(); $("onDs").innerHTML=onChecks("onDsC",vs.map(v=>[v,onFmtValid(v)]),"روزها (پایان هر ۲۴ ساعت)"); };
    $("onM").onchange=fill; fill(); return;
  }
  if(op.kind==="pair"){
    const all=it.filter(i=>i.p===op.p).sort((a,b)=>a.v.localeCompare(b.v)||a.m.localeCompare(b.m)), o=all.map(i=>[i.f,`${onModelFa(i.m)} — ${onFmtValid(i.v)}`]);
    box.innerHTML=onSel("onA",o,"نقشهٔ الف")+onSel("onB",o,"منهای نقشهٔ ب"); if(o[1]) $("onB").value=o[1][0]; return;
  }
  // همرفت و هشدار: یک مدل و یک زمان؛ همهٔ پارامترهای لازمِ موجود
  const ms=uniq(it.filter(i=>op.ps.includes(i.p)).map(i=>i.m));
  box.innerHTML=onSel("onM",ms.map(m=>[m,onModelFa(m)]),"مدل")+`<label>زمان معتبر <select id="onV"></select></label><div id="onPs" class="hint"></div>`;
  const fillV=()=>{ const vs=uniq(it.filter(i=>i.m===$("onM").value&&op.ps.includes(i.p)&&!/^(p24|pacc|snow24|snowacc)$/.test(i.p)).map(i=>i.v)).sort();
    $("onV").innerHTML=vs.map(v=>`<option value="${v}">${onFmtValid(v)}</option>`).join(""); fillP(); };
  const fillP=()=>{ const fs=onPickSet(op,$("onM").value,$("onV").value); $("onPs").textContent="پارامترهای موجود: "+(fs.map(i=>onPar(i.p).fa).join("، ")||"—"); };
  $("onM").onchange=fillV; $("onV").onchange=fillP; fillV();
}
// برای همرفت/هشدار: پارامترهای لحظه‌ای همان زمان + انباشت ۲۴ ساعته‌ای که این زمان را دربرمی‌گیرد
function onPickSet(op,m,v){
  const it=onItems(i=>i.m===m && op.ps.includes(i.p)), out=[];
  for(const p of op.ps){ const c=it.filter(i=>i.p===p); if(!c.length) continue;
    let x=c.find(i=>i.v===v);
    if(!x && /^(p24|snow24)$/.test(p)) x=c.filter(i=>i.v>=v).sort((a,b)=>a.v.localeCompare(b.v))[0];
    if(x) out.push(x); }
  return out;
}
async function onFiles(items){
  const out=[]; let k=0;
  for(const i of items){ onStatus(`دریافت نقشه از هاست (${FA(++k)} از ${FA(items.length)})…`, k/items.length*0.5);
    const r=await fetch(ON.base+i.f); if(!r.ok) throw new Error("نقشه روی هاست پیدا نشد: "+i.f);
    const b=await r.blob(); out.push(new File([b],`${ON_MODEL_FILE[i.m]||i.m}_${i.p}_${i.v}.png`,{type:"image/png"})); }
  return out;
}
async function onRunOp(){
  const op=ON_OPS.find(o=>o.id===$("onOp").value); if(!op) return;
  const it=onItems(); let items=[];
  if(op.kind==="show"){ const t=onChecked("onT"); items=it.filter(i=>i.m===$("onM").value&&i.p===$("onP").value&&t.includes(i.v)); }
  else if(op.kind==="models"){ const ms=onChecked("onMsC"); items=it.filter(i=>i.p===op.p&&i.v===$("onV").value&&ms.includes(i.m)); }
  else if(op.kind==="days"){ const ds=onChecked("onDsC"); items=it.filter(i=>i.p===op.p&&i.m===$("onM").value&&ds.includes(i.v)); }
  else if(op.kind==="pair"){ items=[$("onA").value,$("onB").value].map(f=>it.find(i=>i.f===f)).filter(Boolean); if(items[0]===items[1]) throw new Error("دو نقشهٔ متفاوت انتخاب کنید"); }
  else items=onPickSet(op,$("onM").value,$("onV").value);
  if(!items.length) throw new Error("نقشه‌ای انتخاب نشده است");
  if(op.kind==="conv" && items.length<2) throw new Error("برای پتانسیل همرفت دست‌کم دو شاخص ناپایداری لازم است");
  const files=await onFiles(items);
  onStatus("ارسال به صفحهٔ تحلیل…",0.6);
  if(op.kind==="conv"){ openCV(); try{ CLEAR.cv(); }catch(e){} await cvAdd(files); try{ cvThrPanel(); }catch(e){} return; }
  if(op.kind==="warn"){ openWN(); try{ CLEAR.wn(); }catch(e){} await wnAdd(files); return; }
  // صفحهٔ weather.us: میانگین، بیشینه، کمینه، توافق و احتمال؛ ابزار نقشه: جمع و تفریق
  await switchMode("wu"); try{ CLEAR.main(); }catch(e){}
  if(op.kind==="models" && $("onThr") && $("onThr").value.trim()){ $("thr").value=$("onThr").value.trim(); $("thr").dispatchEvent(new Event("input")); $("thr").dispatchEvent(new Event("change")); }
  $("mtSum").checked = op.kind==="days"; $("mtSum").dispatchEvent(new Event("change"));
  await addFiles(files);
  if(op.kind==="pair"){ await new Promise(r=>setTimeout(r,300)); const A=$("mtDiffA"), B=$("mtDiffB");
    if([...A.options].some(o=>o.value==="#0")){ A.value="#0"; B.value="#1"; A.dispatchEvent(new Event("change")); B.dispatchEvent(new Event("change")); } }
}

/* ---------- ماهواره و رعدوبرق زنده ---------- */
async function onLiveFetch(){
  const type=$("onLvType").value, reg=$("onLvReg").value, n=Math.max(1,Math.min(24,+$("onLvN").value||8));
  if(!/^https?:/.test(location.protocol)) throw new Error("تصاویر زنده فقط روی هاست (با live.php) کار می‌کند");
  onStatus("دریافت فهرست جدیدترین تصاویر…",0.05);
  const r=await fetch(`${ON.base}live.php?a=frames&type=${type}&region=${encodeURIComponent(reg)}&n=${n}`,{cache:"no-store"}); const J=await r.json();
  if(!r.ok || J.error) throw new Error(J.error||("HTTP "+r.status));
  const L=ON.live; L.info=J; L.type=type; L.reg=reg; L.img=[]; L.frames=[];
  let k=0;
  for(const f of J.frames){ onStatus(`دریافت تصویر ${FA(++k)} از ${FA(J.frames.length)}…`, k/J.frames.length);
    const im=new Image(); im.src=ON.base+f.url; const ok=await im.decode().then(()=>true).catch(()=>false);
    if(ok) L.frames.push({t:f.t, im}); }
  if(!L.frames.length) throw new Error("هیچ تصویری دریافت نشد (منبع در دسترس نیست یا هنوز تصویر جدید منتشر نشده)");
  L.idx=L.frames.length-1; onLiveCard(); onLiveDraw(); onStatus("",1);
}
function onLiveCompose(fr, scale=1){
  const L=ON.live, J=L.info, W=760, H=760, c=document.createElement("canvas"); c.width=W*scale; c.height=H*scale; const x=c.getContext("2d"); x.scale(scale,scale);
  x.fillStyle="#fff"; x.fillRect(0,0,W,H);
  const zoom=(ON_LIVE_REG.find(r=>r[0]===L.reg)||[])[2], P0=PROFILES.wu, fx=P0.fx0, fy=P0.fy0, fw=P0.fx1-P0.fx0, fh=P0.fy1-P0.fy0;
  if(J.raw){ x.imageSmoothingEnabled=true; x.drawImage(fr.im, fx, fy, fw, fh);
    if($("onLvBrd").checked && WU_ZOOM_IMG[zoom] && WU_ZOOM_IMG[zoom].complete) x.drawImage(WU_ZOOM_IMG[zoom],0,0,W,H); }
  else { // تصویر کامل منبع (مرزهای خودش را دارد)
    const s=Math.min(W/fr.im.naturalWidth, (fy+fh)/fr.im.naturalHeight); x.drawImage(fr.im, (W-fr.im.naturalWidth*s)/2, 0, fr.im.naturalWidth*s, fr.im.naturalHeight*s); }
  x.strokeStyle="#000"; x.lineWidth=1.5; x.strokeRect(fx,fy,fw,fh);
  const d=new Date(fr.t), regFa=(ON_LIVE_REG.find(r=>r[0]===L.reg)||[,""])[1];
  const ttl=L.type==="sat"?`تصویر ماهواره‌ای Meteosat (باند مرئی HD) — ${regFa}`:`رعدوبرق — ${regFa}`;
  txt(x, ttl, W-14, fy+fh+32, `20px ${FT.titr}`, {maxW:W-260});
  txt(x, `${persianDT(d,210)} به وقت ایران (${persianDT(d,0).split(" ").pop()} UTC)`, W-14, fy+fh+60, `15px ${FT.body}`, {color:"#222"});
  txt(x, L.type==="sat"?"منبع تصویر: EUMETSAT / Meteologix":"منبع داده: Meteologix (شبکهٔ آشکارسازی رعدوبرق)", W-14, fy+fh+84, `12px ${FT.body}`, {color:"#555"});
  try{ drawBrand(x,{brand:$("brand")?$("brand").value.trim():"",handle:$("handle")?$("handle").value.trim():"",logoImg:state.logoImg},14,fy+fh+22,200,56,{side:true,align:"left"}); }catch(e){}
  c.__lt=true; return c;
}
function onLiveCard(){
  const host=$("onLive"); host.hidden=false;
  host.innerHTML=`<article class="card wide" id="onLvCard"><header><h3>${ON.live.type==="sat"?"ماهواره (زنده)":"رعدوبرق (زنده)"}</h3><div class="sub" id="onLvSub"></div></header>
   <div class="onLvBar"><button class="btn sm" id="onLvPrev">◀</button><button class="btn sm" id="onLvPlay">▶ پخش</button><button class="btn sm" id="onLvNext">▶</button>
   <input type="range" id="onLvSl" min="0" max="${ON.live.frames.length-1}" value="${ON.live.idx}"><button class="btn sm" id="onLvRef">↻ تازه‌سازی</button></div>
   <img id="onLvImg" alt="" style="width:100%;height:auto;display:block">
   <div class="onLvBar"><button class="btn sm" id="onLvPng">دانلود PNG</button><span>GIF متحرک:</span>${[240,320,480,760].map(w=>`<button class="btn sm" data-gw="${w}">${FA(w)}</button>`).join("")}<button class="btn sm" id="onLvRep">گزارش متنی</button></div></article>`;
  const L=ON.live, go=k=>{ L.idx=(k+L.frames.length)%L.frames.length; $("onLvSl").value=L.idx; onLiveDraw(); };
  $("onLvPrev").onclick=()=>go(L.idx-1); $("onLvNext").onclick=()=>go(L.idx+1); $("onLvSl").oninput=e=>go(+e.target.value);
  $("onLvPlay").onclick=()=>{ if(L.timer){ clearInterval(L.timer); L.timer=null; $("onLvPlay").textContent="▶ پخش"; } else { L.timer=setInterval(()=>go(L.idx+1),600); $("onLvPlay").textContent="⏸ توقف"; } };
  $("onLvRef").onclick=()=>onLiveFetch().catch(e=>onStatus("⚠ "+e.message,0));
  $("onLvPng").onclick=()=>{ const c=onLiveCompose(L.frames[L.idx],2); c.toBlob(b=>onSave(b,`metstat_${L.type}_${L.reg}_${L.frames[L.idx].t.replace(/\D/g,"").slice(0,12)}.png`)); };
  document.querySelectorAll("#onLvCard [data-gw]").forEach(b=>b.onclick=async()=>{ const w=+b.dataset.gw; onStatus("ساخت GIF…",0.3); await tick();
    const fr=[], de=[]; for(let k=0;k<L.frames.length;k++){ const c=onLiveCompose(L.frames[k]); let s=c; if(w<760){ s=document.createElement("canvas"); s.width=w; s.height=Math.round(760*w/760); const sx=s.getContext("2d"); sx.imageSmoothingQuality="high"; sx.drawImage(c,0,0,s.width,s.height); }
      fr.push(s.getContext("2d").getImageData(0,0,s.width,s.height).data); de.push(k===L.frames.length-1?150:60); await tick(); }
    const g=gifEncode(fr, w, Math.round(760*w/760), de); onSave(g,`metstat_${L.type}_${L.reg}_${w}.gif`); onStatus("",1); });
  $("onLvRep").onclick=()=>{ const f=L.frames, a=new Date(f[0].t), b=new Date(f[f.length-1].t), regFa=(ON_LIVE_REG.find(r=>r[0]===L.reg)||[,""])[1];
    const t=`${L.type==="sat"?"تصویر ماهواره‌ای Meteosat، باند مرئی HD":"نقشهٔ رعدوبرق"} — ${regFa}\nبازهٔ تصاویر: از ${persianDT(a,210)} تا ${persianDT(b,210)} به وقت ایران (${FA(f.length)} فریم، هر ${FA(L.info.step)} دقیقه)\nمنبع: Meteologix${L.type==="sat"?" / EUMETSAT":""} — تهیه‌شده در MetStat (wtafkik.ir)`;
    try{ navigator.clipboard.writeText(t); }catch(e){} alert(t); };
}
function onLiveDraw(){
  const L=ON.live; if(!L.frames.length || !$("onLvImg")) return;
  const fr=L.frames[L.idx], c=onLiveCompose(fr); $("onLvImg").src=c.toDataURL("image/png");
  $("onLvSub").textContent=`فریم ${FA(L.idx+1)} از ${FA(L.frames.length)} · ${persianDT(new Date(fr.t),210)} به وقت ایران${L.info.raw?"":" · مرزهای منبع (لایهٔ خام در دسترس نبود)"}`;
}
function onSave(blob,name){ const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=name; document.body.append(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); },2000); }

async function openON(){
  for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp"]) if($(id)) $(id).hidden=true;
  $("onApp").hidden=false; $("srcName").textContent="تحلیل نقشه‌های آنلاین"; $("srcBtn").hidden=false; store.set("mode","on"); window.scrollTo(0,0);
  onStatus("خواندن فهرست نقشه‌های روی هاست…",0.2); const msg=await onLoadManifest(); onStatus("",1); onBuildUI(msg);
}
// هر صفحهٔ دیگری که باز شود، این صفحه پنهان می‌شود
for(const fn of ["switchMode","showLanding","openCQC","openDS","openCV","openLT","openWN","openCA"]){
  const f=window[fn]; if(typeof f!=="function") continue;
  window[fn]=function(...a){ if($("onApp")&&!$("onApp").hidden){ try{ nvLeave(); }catch(e){} } if($("onApp")) $("onApp").hidden=true; return f.apply(this,a); };
}

/* مدل‌هایی که آخرین اجرایشان بیش از ۹۰ روز پیش بوده از فهرست حذف می‌شوند (با اجرای تازه خودکار برمی‌گردند) */
const ON_MAXAGE=90*864e5;
function onPruneOld(){ const M=ON.man&&ON.man.models; if(!M) return; const now=Date.now(), gone=[];
  for(const [k,o] of Object.entries(M)){ const r=String(o.run||""); if(r.length<8) continue;
    const t=Date.UTC(+r.slice(0,4),+r.slice(4,6)-1,+r.slice(6,8),+(r.slice(8,10)||0)); if(isFinite(t)&&now-t>ON_MAXAGE){ gone.push(k); delete M[k]; } }
  if(gone.length&&ON.man.items) ON.man.items=ON.man.items.filter(i=>!gone.includes(i.m)); ON.man.hidden=gone; }
/* بررسی پس‌زمینهٔ نسخهٔ تازه: هر ۵ دقیقه و هنگام برگشت به تب؛ اگر مدل/اجرای جدیدی آمد منوها خودکار به‌روز می‌شوند */
const onSig=()=>ON.man?JSON.stringify([Object.entries(ON.man.models||{}).map(([k,o])=>[k,o.run,o.status,o.done]),(ON.man.items||[]).length]):"";
let onRefBusy=false;
async function onAutoRefresh(){ if(onRefBusy||document.hidden||!ON.man) return; onRefBusy=true; const old=ON.man, before=onSig();
  try{ const msg=await onLoadManifest(); if(!ON.man){ ON.man=old; return; } if(onSig()===before) return;
    if(!$("nvStage")) onBuildUI(msg); else nvRefreshMenus(); }
  catch(e){ ON.man=old; } finally{ onRefBusy=false; } }
setInterval(onAutoRefresh,300000); document.addEventListener("visibilitychange",()=>{ if(!document.hidden) onAutoRefresh(); });
