/* =====================================================================
   همرفت: احتمال وقوع و شدت بالقوه از روی نقشه‌های شاخص‌های همرفتی
   هر نقشه رقومی می‌شود (قالب و نوار رنگ خودکار)، روی کادر نقشهٔ اول قرار می‌گیرد،
   با تابع عضویت «بی‌اثر ← کاملاً مساعد» به مطلوبیت ۰ تا ۱ تبدیل و به روش مؤلفه‌ای ترکیب می‌شود.
   ===================================================================== */
// آستانه‌های استاندارد هر شاخص: occ = [بی‌اثر (۰٪)، مساعد (۵۰٪)، ایده‌آل (۱۰۰٪)] — برای شاخص‌های نزولی (LI و CIN) اعداد کاهشی‌اند
// sev = [شدت ضعیف، شدت شدید] ؛ sea:true یعنی روی دریا قابل اعتماد نیست و وزنش آنجا کم می‌شود ؛ rel:true یعنی آستانه بر حسب درصدِ مقیاس نوار رنگ همان نقشه
const CV_IDX = {
  cape:  {n:"CAPE (انرژی پتانسیل همرفتی)", u:"J/kg", g:"inst",  occ:[100,800,1500],  sev:[1000,3000], sea:true, re:/cape|کیپ|انرژی\s*پتانسیل/i,
          ref:"< ۳۰۰ ضعیف · ۳۰۰–۱۰۰۰ ناپایداری کم تا متوسط · ۱۰۰۰–۲۵۰۰ متوسط · > ۲۵۰۰ قوی (روی خشکی؛ روی دریا معتبر نیست)"},
  cin:   {n:"CIN (بازدارندگی همرفتی)",     u:"J/kg", g:"trig",  occ:[200,75,25],     sev:null,  abs:true, sea:true, bgAbove:true, bgNull:true, re:/(^|[^a-z])cin([^a-z]|$)|inhibition|بازدارندگی/i,
          ref:"۰–۲۵ بدون مانع (ایده‌آل) · ۲۵–۷۵ مانع ضعیف · ۷۵–۲۰۰ مانع متوسط، صعود قوی لازم · > ۲۰۰ لایهٔ وارونگی قوی (روی دریا معتبر نیست)"},
  ltg:   {n:"چگالی رعدوبرق (مدل)",        u:"flash/km²/day", nn:true, g:"sig", occ:[0.01,0.2,1], sev:[1,5], re:/lightn|flash|رعدوبرق|رعد\s*و\s*برق/i,
          ref:"< ۰٫۰۱ بدون رعدوبرق · ۰٫۰۱–۰٫۲ منفرد · ۰٫۲–۱ پراکنده تا فعال · > ۱ شدید · > ۵ بسیار شدید (رعدوبرقِ شبیه‌سازی‌شده در مدل)"},
  refl:  {n:"بازتاب پایهٔ رادار (مدل)",    u:"dBZ",  nn:true, g:"sig",   occ:[10,25,40],      sev:[40,55],   re:/reflect|dbz|بازتاب/i,
          ref:"< ۱۰ بدون پژواک · ۱۰–۲۵ بارش سبک · ۲۵–۴۰ بارش متوسط تا رگباری · > ۴۰ هستهٔ همرفتی فعال · > ۵۰ تگرگ و توفان شدید محتمل"},
  tsc:   {n:"Thunderstorm composite",      u:"",     g:"inst",  occ:[10,40,75],      sev:[50,90], rel:true, sea:true, re:/thunderstorm[-_ ]?comp|tstm[-_ ]?comp|composite/i,
          ref:"مقیاس اختصاصی سایت؛ آستانه‌ها بر حسب درصدِ نوار رنگ همان نقشه: > ۴۰٪ مساعد · > ۷۵٪ خیلی مساعد (روی دریا معتبر نیست)"},
  li:    {n:"شاخص بالابری LI",             u:"°C",   g:"inst",  occ:[2,-1,-4],       sev:[-3,-8],   bgAbove:true, re:/(^|[^a-z])s?b?li([^a-z]|$)|lifted|بالابری/i,
          ref:"> ۲ پایدار · ۰ تا ۲ ناپایداری ضعیف · ۰ تا ۴- ناپایدار · < ۴- ناپایداری قوی · < ۸- بسیار شدید (برای LI سطحی و LI ۸۵۰ هکتوپاسکال؛ واحد K و °C در اختلاف دما یکی است)"},
  si:    {n:"شاخص شوالتر",                 u:"°C",   g:"inst",  occ:[3,0,-3],        sev:[-2,-6],   bgAbove:true, re:/showalter|(^|[^a-z])ssi([^a-z]|$)|شوالتر/i,
          ref:"> ۳ پایدار · ۱ تا ۳ رگبار محتمل · ۰ تا ۳- توفان تندری محتمل · < ۳- توفان شدید · < ۶- بسیار شدید"},
  ki:    {n:"شاخص K",                      u:"°C",   g:"inst",  occ:[20,28,35],      sev:[30,40],   re:/k[-_ ]?index|(^|[^a-z])ki([^a-z]|$)|شاخص\s*k/i,
          ref:"< ۲۰ بدون همرفت · ۲۰–۲۵ پراکنده و کم · ۲۶–۳۰ پراکنده · ۳۱–۳۵ گسترده · > ۳۵ خیلی مساعد (فراگیر)"},
  tt:    {n:"Total Totals",                u:"°C",   g:"inst",  occ:[44,48,52],      sev:[50,58],   re:/total[-_ ]?totals|(^|[^a-z])tt([^a-z]|$)/i,
          ref:"< ۴۴ نامساعد · ۴۴–۵۰ توفان تندری محتمل · ۵۰–۵۵ توفان شدید منفرد · > ۵۵ توفان شدید پراکنده"},
  gdi:   {n:"شاخص گالوز-دیویسون GDI",      u:"",     g:"inst",  occ:[5,25,45],       sev:[35,55],   re:/gdi|galvez|davison|گالوز/i,
          ref:"< ۵ فرونشینی، بدون همرفت · ۵–۱۵ همرفت کم‌عمق · ۱۵–۲۵ رعدوبرق منفرد · ۲۵–۳۵ رعدوبرق پراکنده · ۳۵–۴۵ پراکنده تا گسترده · > ۴۵ خیلی محتمل، بارش سنگین"},
  soar:  {n:"Soaring Index",               u:"",     g:"inst",  occ:[0,5,10],        sev:[8,15],    re:/soaring|سورینگ/i,
          ref:"< ۰ نامساعد · ۰–۵ ضعیف · ۵–۱۰ مساعد · > ۱۰ عالی"},
  boyden:{n:"شاخص بویدن",                  u:"",     g:"inst",  occ:[92,94,97],      sev:[95,100],  re:/boyden|بویدن/i,
          ref:"< ۹۴ رعدوبرق بعید · ≥ ۹۴ رعدوبرق محتمل · ≥ ۹۷ خیلی مساعد"},
  dci:   {n:"شاخص همرفت عمیق DCI",         u:"",     g:"inst",  occ:[15,25,32],      sev:[28,38],   re:/(^|[^a-z])dci([^a-z]|$)|deep[-_ ]?convect/i,
          ref:"< ۱۵ نامساعد · ۱۵–۲۵ همرفت ممکن · ۲۵–۳۰ مساعد · > ۳۰ خیلی مساعد"},
  lapse: {n:"آهنگ کاهش دما ۷۰۰ تا ۵۰۰",    u:"°C/km",g:"inst",  occ:[5.5,6.5,7.5],   sev:[7,8.5],   re:/lapse|آهنگ\s*کاهش|لپس/i,
          ref:"< ۵٫۵ پایدار · ۶–۷ ناپایداری مشروط · > ۷ تند (مساعد) · > ۸٫۵ نزدیک بی‌دررو خشک"},
  sweat: {n:"SWEAT",                       u:"",     g:"inst",  occ:[150,250,300],   sev:[300,450], re:/sweat/i,
          ref:"< ۱۵۰ ضعیف · ۱۵۰–۲۵۰ رعدوبرق خفیف · ۲۵۰–۳۰۰ رعدوبرق · ۳۰۰–۴۰۰ توفان شدید ممکن · > ۴۰۰ توفان شدید/تندباد"},
  shear: {n:"چینش لایهٔ عمیق ۰ تا ۶ کیلومتر (DLS)",      u:"m/s",  nn:true, g:"org",   occ:null,            sev:[10,25],   re:/shear|(^|[^a-z])dls([^a-z]|$)|bulk|چینش|برش\s*باد/i, units:{"m/s":1, "kt":0.5144, "km/h":0.2778},
          ref:"< ۱۰ m/s (۲۰ kt) سلول منفرد کوتاه‌عمر · ۱۰–۲۰ m/s چندسلولی سازمان‌یافته · > ۲۰ m/s (۴۰ kt) ابرسلول — اثرش بر شدت است نه وقوع"},
  srh:   {n:"SRH لایهٔ ۰ تا ۳ کیلومتر",      u:"m²/s²",nn:true, g:"org",   occ:null,            sev:[100,300], re:/(^|[^a-z])srh([^a-z]|$)|helicity|هلیسیتی/i,
          ref:"< ۱۰۰ ضعیف · ۱۰۰–۲۵۰ چرخش ممکن · > ۳۰۰ ابرسلول چرخان قوی — اثرش بر شدت است"},
  pwat:  {n:"آب قابل بارش",                u:"mm",   nn:true, g:"moist", occ:[10,18,30],      sev:null,      re:/pwat|precipitable|(^|[^a-z])pw([^a-z]|$)|آب\s*قابل\s*بارش/i,
          ref:"< ۱۰ خشک · ۱۵–۲۰ خوب · ۲۰–۳۰ خیلی خوب · > ۳۰ خیلی مناسب (هرچه بیشتر، بهتر)"},
  rh:    {n:"رطوبت نسبی ۷۰۰ هکتوپاسکال",     u:"%",    g:"moist", occ:[40,60,80],      sev:null,      re:/(^|[^a-z])rh([^a-z]|$)|humid|رطوبت/i,
          ref:"< ۴۰٪ خشک · ۶۰٪ مساعد · > ۸۰٪ خیلی مساعد"},
  td2m:  {n:"نقطهٔ شبنم ۲ متری",            u:"°C",   g:"moist", occ:[0,8,16],        sev:null,      re:/dew[-_ ]?point|(^|[^a-z])td2?m?([^a-z]|$)|نقطه\s*شبنم/i,
          ref:"< ۰ هوای خشک · ۸–۱۲ رطوبت سطحی مناسب · > ۱۶ خیلی مساعد (در فصل سرد مقادیر کمتر هم کافی است)"},
  cprec: {n:"بارش همرفتی (مدل)",           u:"mm",   nn:true, g:"sig", occ:[0.1,1,5],        sev:[5,20],    re:/conv[-_ ]?prec|convective[-_ ]?precip|بارش\s*همرفتی/i,
          ref:"> ۰٫۱ همرفت در مدل · > ۱ مساعد · > ۵ همرفت فعال · > ۲۰ رگبار شدید"},
  t500:  {n:"دمای ۵۰۰ هکتوپاسکال",          u:"°C",   g:"inst",  occ:[-8,-14,-20],     sev:[-16,-24], re:/t500|temp[a-z]*[-_ ]?500|500[-_ ]?(hpa|mb|mbar)?[-_ ]?temp|دمای\s*۵۰۰/i,
          ref:"> ۸- گرم (پایدارکننده) · ۱۴- تا ۲۰- هوای سرد بالایی، مساعد · < ۲۰- ناوهٔ سرد قوی، خیلی مساعد (تگرگ محتمل)"},
  gph500:{n:"ارتفاع ژئوپتانسیل ۵۰۰ هکتوپاسکال", u:"",  g:"inst",  occ:[70,40,15],      sev:[30,10],   anom:true, re:/geopot|gph|z500|ژئوپتانسیل/i,
          ref:"نسبت به خود نقشه: ناحیهٔ ناوه (ارتفاع کمتر از اطراف) مساعد، پشته نامساعد — آستانه‌ها بر حسب صدک ارتفاع در همان نقشه"},
  srh01: {n:"SRH لایهٔ ۰ تا ۱ کیلومتر",      u:"m²/s²",nn:true, g:"org",   occ:null,            sev:[50,150],  re:/srh[-_ ]?0?[-_ ]?1|0[-_]1[-_ ]?km[-_ ]?srh/i,
          ref:"< ۵۰ ضعیف · ۱۰۰–۱۵۰ چرخش سطح پایین · > ۱۵۰ گردباد محتمل (همراه با ابرسلول) — اثرش بر شدت است"},
  jet:   {n:"باد ۲۵۰/۳۰۰ هکتوپاسکال (رودباد)", u:"m/s", nn:true, g:"org",  occ:null,            sev:[25,50],   units:{"m/s":1, "kt":0.5144, "km/h":0.2778}, re:/jet|(250|300)[-_ ]?(hpa|mb|mbar)?[-_ ]?wind|wind[-_ ]?(250|300)|رودباد/i,
          ref:"< ۲۵ m/s ضعیف · ۲۵–۴۰ m/s رودباد، واگرایی بالایی و سازمان‌یافتگی · > ۵۰ m/s رودباد قوی — اثرش بر شدت و سازمان‌یافتگی است"},
  fzl:   {n:"ارتفاع تراز صفر درجه",        u:"m",    nn:true, g:"org",   occ:null,            sev:[4500,3000], re:/freez|zero[-_ ]?deg|0°?c[-_ ]?(level|height)|fzl|تراز\s*صفر/i,
          ref:"> ۴۵۰۰ m تگرگ معمولاً پیش از رسیدن ذوب می‌شود · ۳۰۰۰–۴۰۰۰ m تگرگ محتمل · < ۳۰۰۰ m تگرگ به زمین می‌رسد — فقط بر شدت (تگرگ) اثر دارد"},
  gust:  {n:"تندباد (Gusts)",              u:"km/h", nn:true, g:"sig",   occ:[40,60,80],      sev:[60,100],  units:{"km/h":1, "kt":1.852, "m/s":3.6}, re:/gust|تندباد/i,
          ref:"< ۴۰ km/h عادی · ۶۰ km/h تندباد همرفتی محتمل · > ۸۰ km/h تندباد شدید (فروریزش توفان) · > ۱۰۰ km/h خسارت‌زا"},
  scp:   {n:"شاخص ابرسلول SCP",            u:"",     nn:true, g:"org",   occ:null,            sev:[1,4],     re:/(^|[^a-z])scp([^a-z]|$)|supercell/i,
          ref:"< ۱ ابرسلول بعید · ۱–۴ ابرسلول ممکن · > ۴ ابرسلول محتمل — اثرش بر شدت است"},
  stp:   {n:"شاخص گردباد STP",             u:"",     nn:true, g:"org",   occ:null,            sev:[0.5,2],   re:/(^|[^a-z])stp([^a-z]|$)|tornado/i,
          ref:"< ۰٫۵ گردباد بعید · ۰٫۵–۱ ممکن · > ۱ محتمل · > ۲ گردباد قوی ممکن — اثرش بر شدت است"},
  precip:{n:"بارش مدل (فقط برای مقایسه)",   u:"mm",   g:"cmp", cmp:true, occ:[0.2,2,5],       sev:[5,30],    re:/precip(?!itable)|rain|apcp|(^|[^a-z])tp([^a-z]|$)|بارش(?!\s*قابل)|باران/i,
          ref:"در تحلیل همرفت دخالت داده نمی‌شود؛ فقط برای مقایسهٔ مدل‌ها با شرایط شاخص‌ها"},
  custom:{n:"شاخص دیگر (سفارشی)",          u:"",     g:"inst",  occ:[10,50,90],      sev:[50,90],   rel:true, re:null,
          ref:"آستانه‌ها بر حسب درصدِ نوار رنگ همان نقشه"}
};
const CV_PROV={"تهران":"تهران","مشهد":"خراسان رضوی","اصفهان":"اصفهان","شیراز":"فارس","تبریز":"آذربایجان شرقی","کرج":"البرز","اهواز":"خوزستان","قم":"قم","کرمانشاه":"کرمانشاه","ارومیه":"آذربایجان غربی","رشت":"گیلان","زاهدان":"سیستان و بلوچستان","کرمان":"کرمان","همدان":"همدان","یزد":"یزد","اردبیل":"اردبیل","بندرعباس":"هرمزگان","اراک":"استان مرکزی","زنجان":"زنجان","سنندج":"کردستان","قزوین":"قزوین","خرم‌آباد":"لرستان","گرگان":"گلستان","ساری":"مازندران","بجنورد":"خراسان شمالی","بوشهر":"بوشهر","بیرجند":"خراسان جنوبی","ایلام":"ایلام","شهرکرد":"چهارمحال و بختیاری","سمنان":"سمنان","یاسوج":"کهگیلویه و بویراحمد"};
// نام منطقه از روی گسترهٔ جغرافیایی کادر نقشه
function cvRegionFromGeo(rp){
  if(!rp.geo) return "";
  const lon0=(rp.fx0-rp.ax)/rp.bx, lon1=(rp.fx1-rp.ax)/rp.bx, lat0=(rp.fy1-rp.ay)/rp.by, lat1=(rp.fy0-rp.ay)/rp.by;
  const span=Math.abs(lon1-lon0), clo=(lon0+lon1)/2, cla=(lat0+lat1)/2;
  if(span>=30) return "خاورمیانه";
  if(span>=11) return (cla>24&&cla<40&&clo>44&&clo<64) ? "ایران" : "منطقه";
  let best=null, bd=1e9; for(const [nm,la,lo] of CV_CITIES){ if(!CV_PROV[nm]) continue; const d=Math.hypot(la-cla,(lo-clo)*Math.cos(cla*Math.PI/180)); if(d<bd){ bd=d; best=nm; } }
  return best && bd<3 ? CV_PROV[best] : "";
}
const CV_CITIES=[["تهران",35.69,51.39],["مشهد",36.30,59.60],["اصفهان",32.65,51.67],["شیراز",29.59,52.58],["تبریز",38.08,46.29],["کرج",35.83,50.99],["اهواز",31.32,48.67],["قم",34.64,50.88],["کرمانشاه",34.31,47.07],["ارومیه",37.55,45.07],["رشت",37.28,49.58],["زاهدان",29.50,60.86],["کرمان",30.28,57.08],["همدان",34.80,48.51],["یزد",31.90,54.37],["اردبیل",38.25,48.29],["بندرعباس",27.18,56.27],["اراک",34.09,49.69],["زنجان",36.67,48.48],["سنندج",35.31,47.00],["قزوین",36.27,50.00],["خرم‌آباد",33.49,48.36],["گرگان",36.84,54.44],["ساری",36.56,53.06],["بجنورد",37.47,57.33],["بوشهر",28.97,50.84],["بیرجند",32.87,59.22],["ایلام",33.64,46.42],["شهرکرد",32.33,50.86],["سمنان",35.57,53.40],["یاسوج",30.67,51.59],["استهبان",29.13,54.04],["لار",27.68,54.34],["جهرم",28.50,53.56],["فسا",28.94,53.65],["داراب",28.75,54.55],["کازرون",29.62,51.65],["آباده",31.16,52.65],["چابهار",25.29,60.64],["دزفول",32.38,48.40],["سبزوار",36.21,57.68],["بغداد",33.31,44.37],["بصره",30.51,47.81],["کویت",29.38,47.99],["ریاض",24.71,46.68],["دوحه",25.29,51.53],["دبی",25.20,55.27],["مسقط",23.59,58.41],["باکو",40.41,49.87],["عشق‌آباد",37.96,58.33],["هرات",34.35,62.20],["کابل",34.53,69.17],["کراچی",24.86,67.01],["اربیل",36.19,44.01],["ایروان",40.18,44.51],["آنکارا",39.93,32.86],["دمشق",33.51,36.29],["منامه",26.23,50.59],["ارزوئیه",28.46,56.36],["بافت",29.23,56.60],["سیرجان",29.45,55.68],["جیرفت",28.68,57.74],["بم",29.11,58.36],["رفسنجان",30.41,55.99],["حاجی‌آباد",28.31,55.90],["نی‌ریز",29.20,54.33],["فیروزآباد",28.84,52.57],["مرودشت",29.87,52.80],["بهبهان",30.60,50.24],["گچساران",30.36,50.80],["کنگان",27.83,52.06],["مینودشت",37.23,55.37],["خوی",38.55,44.95],["مراغه",37.39,46.24],["زابل",31.03,61.50],["ایرانشهر",27.20,60.68],["میناب",27.15,57.08],["قشم",26.95,56.27],["کاشان",33.98,51.44],["نائین",32.86,53.09],["طبس",33.60,56.92],["شاهرود",36.42,54.98],["تربت حیدریه",35.27,59.22],["بروجرد",33.90,48.75],["ملایر",34.30,48.82],["سقز",36.25,46.27],["مهاباد",36.76,45.72],["آمل",36.47,52.35],["لاهیجان",37.21,50.00],["آستارا",38.43,48.87]];
const CV_GROUP = {inst:"ناپایداری", moist:"رطوبت", trig:"عامل صعود", sig:"نشانهٔ همرفت در خروجی مدل", org:"سازمان‌یافتگی", cmp:"مقایسه (بدون دخالت)"};
const INT_SCHEME = {colors:["#9be29b","#ffd23f","#ff7f11","#c4128c"], edges:[10,30,50,70],
  cls:v=>{ if(!(v>=10)) return -1; if(v<30) return 0; if(v<50) return 1; if(v<70) return 2; return 3; },
  labs:["بدون همرفت","ضعیف","متوسط","شدید","بسیار شدید"], title:"شدت بالقوه",
  maxTxt:v=>`بیشترین شدت: ${["بدون همرفت","ضعیف","متوسط","شدید","بسیار شدید"][INT_SCHEME.cls(v)+1]}`};
const cv = { maps:[], busy:false, pending:false, timer:null, cards:null, res:null, seq:0 };
const cvThr = () => { const o=store.get("cv.thr2",{}), r={}; for(const [k,v] of Object.entries(CV_IDX)) r[k]={occ:(o[k]&&o[k].occ)||v.occ, sev:(o[k]&&o[k].sev)||v.sev}; return r; };
function cvStatus(t, frac){ $("cvStatus").hidden=false; $("cvStText").textContent=t; if(frac!==undefined) $("cvStBar").style.width=(frac*100)+"%"; }
function cvGuessType(name){ for(const [k,v] of Object.entries(CV_IDX)) if(v.re && v.re.test(name)) return k; return null; }
// ---- خواندن نام شاخص از عنوان روی خود نقشه (بدون اینترنت؛ تطبیق شکل واژه با واژه‌های کلیدی) ----
const CV_WORDS = {
  cape:["CAPE","MUCAPE","SBCAPE","MLCAPE","(CAPE)","CAPE,","Convective"],
  cin:["CIN","(CIN)","Inhibition","MLCIN","SBCIN","MUCIN"],
  li:["Lifted","(LI)","LI"],
  si:["Showalter"],
  ki:["K-Index","K-index","(KI)","KIndex","K-Index:"],
  tt:["Totals","Total-Totals","TT-Index"],
  lapse:["Lapse"],
  sweat:["SWEAT"],
  shear:["Shear","Bulk","DLS","Deep-layer"],
  pwat:["Precipitable","PWAT"],
  rh:["Humidity","(RH)"],
  precip:["Precipitation","Precip","Rainfall","Rain"],
  gdi:["GDI","(GDI)","Galvez","Davison","Galvez-Davison"], soar:["Soaring"], tsc:["Thunderstorm","Thunderstorms","composite"],
  boyden:["Boyden"], dci:["DCI","(DCI)"], srh:["Helicity","SRH","(SRH)"],
  td2m:["Dewpoint","Dew","Taupunkt"], t500:["Temperature","Temp."], gph500:["Geopotential","Geopot.","Geopot"], jet:["Jetstream","Jet","Wind","Winds"],
  fzl:["Freezing","Zero-degree","0°C-level","Freezing-level"], gust:["Gusts","Gust","gusts"], scp:["SCP","(SCP)","Supercell"], stp:["STP","(STP)","Tornado"],
  refl:["reflectivity","Reflectivity","(dBZ)","dBZ","Radar"], ltg:["Lightning","Lightn.","Lightn","(Flashes/km²/day)","Flashes"],
  u_kt:["(kt)","(kn)","knots","(kts)"], "u_m/s":["(m/s)","m/s","(ms-1)"], "u_km/h":["(km/h)","km/h"]
};
const CV_REGIONS={Iran:"ایران",Fars:"فارس",Gilan:"گیلان",Guilan:"گیلان",Mazandaran:"مازندران",Golestan:"گلستان",Tehran:"تهران",Isfahan:"اصفهان",Esfahan:"اصفهان",Khuzestan:"خوزستان",Kerman:"کرمان",Hormozgan:"هرمزگان",Bushehr:"بوشهر",Sistan:"سیستان و بلوچستان",Baluchestan:"سیستان و بلوچستان",Khorasan:"خراسان",Kurdistan:"کردستان",Kordestan:"کردستان",Kermanshah:"کرمانشاه",Lorestan:"لرستان",Ilam:"ایلام",Hamadan:"همدان",Markazi:"استان مرکزی",Qom:"قم",Qazvin:"قزوین",Zanjan:"زنجان",Ardabil:"آذربایجان‌ها و اردبیل",Azerbaijan:"آذربایجان‌ها و اردبیل","East Azerbaijan":"آذربایجان‌ها و اردبیل","West Azerbaijan":"آذربایجان‌ها و اردبیل",FarsE:"شرق فارس",FarsN:"شمال فارس",FarsNW:"شمال‌غرب فارس",FarsSW:"جنوب‌غرب فارس",FarsSE:"جنوب‌شرق فارس",Semnan:"سمنان",Yazd:"یزد",Chaharmahal:"چهارمحال و بختیاری",Kohgiluyeh:"کهگیلویه و بویراحمد",Alborz:"البرز",Middle:"خاورمیانه",Iraq:"عراق",Turkey:"ترکیه",Afghanistan:"افغانستان",Pakistan:"پاکستان",Caucasus:"قفقاز",Arabia:"شبه‌جزیرهٔ عربستان"};
const CV_MODELS={ECMWF:"ECMWF",IFS:"ECMWF",GFS:"GFS",ICON:"ICON",GEM:"GEM",UKMO:"UKMO",ARPEGE:"ARPEGE",ACCESS:"ACCESS",NAVGEM:"NAVGEM",CMA:"CMA",JMA:"JMA",WRF:"WRF",AROME:"AROME",HRRR:"HRRR",NAM:"NAM"};
const CV_LEVELS={"0-1km":"۰ تا ۱ کیلومتر","0-3km":"۰ تا ۳ کیلومتر","0-6km":"۰ تا ۶ کیلومتر","250mbar":"۲۵۰ هکتوپاسکال","300mbar":"۳۰۰ هکتوپاسکال","250hPa":"۲۵۰ هکتوپاسکال","300hPa":"۳۰۰ هکتوپاسکال","500hPa":"۵۰۰ هکتوپاسکال","10m":"۱۰ متری","2m":"۲ متری","850mbar":"۸۵۰ هکتوپاسکال","850hPa":"۸۵۰ هکتوپاسکال","700mbar":"۷۰۰ هکتوپاسکال","500mbar":"۵۰۰ هکتوپاسکال","(surface)":"سطحی","surface":"سطحی","unstable":"ناپایدارترین لایه","mixed":"لایهٔ آمیخته","Mixed-Layer":"لایهٔ آمیخته"};
for(const k in CV_LEVELS) CV_WORDS["lv_"+k]=[k];
for(const k in CV_REGIONS) if(!/^Fars[A-Z]/.test(k)) CV_WORDS["rg_"+k]=[k];
// زوم‌های بدون نام weather.us: پانویس مختصات مرکز نقشه را دارد (مثلاً 53.7E, 29.0N)
const WU_COORD_ZOOMS=[["53.7E","29.0N","FarsE"],["54.4E","27.9N","FarsSE"],["52.9E","27.9N","FarsSW"],["51.6E","30.0N","FarsNW"],["52.6E","31.1N","FarsN"]];

for(const k in CV_MODELS) CV_WORDS["md_"+k]=[k];
// واژه‌های عنوان برای پارامتر نقشه در حالت‌های اصلی
const VAR_WORDS={temp:["Temperature","Temp.","temperature"], tmax:["Maximum","Max.","maximum"], tmin:["Minimum","Min.","minimum"], wind:["Wind","Windspeed","Wind-speed","wind"], gust:["Gusts","Gust","gusts"],
  rh:["Humidity","humidity"], mslp:["Pressure","MSLP","pressure"], cloud:["Cloud","Clouds","Cloudiness","cloud"], snow:["Snow","Snowfall","Snowdepth","snow","(Snow)"], precip:["Precipitation","Rain","precipitation"], cape:["CAPE"]};
for(const k in VAR_WORDS) CV_WORDS["v_"+k]=VAR_WORDS[k];
// واژه‌های عنوان پدیده‌های خطرناک (حالت هشدار)
const HZ_WORDS={anom:["Anomaly","anomaly","Anomalie"], uv:["UV","UV-Index","UV-index","(UV)"], flood:["Flood","flood","Flooding","Flash-flood"], hail:["Hail","hail","Hailstones"], wave:["Wave","Waves","wave","Significant"], dust:["Dust","dust","Sand"], vis:["Visibility","visibility","Fog"], rate:["rate","Rate","intensity","Intensity","(mm/h)","mm/h"], prob:["Probability","probability","chance"], soil:["Soil","soil","SOIL","5cm","(5cm)","0-10cm","0-7cm"]};
for(const k in HZ_WORDS) CV_WORDS["h_"+k]=HZ_WORDS[k];
const CV_OCR_GH=18, CV_OCR_CW=12, CV_OCR_CH=6; var CV_OCR_CUT=0.4;   // بردار درشت برای پیش‌غربال سریع واژه‌ها
let CV_OCR_T=null;
function cvOcrVec(dark, W, x0, y0, w, h, gw, gh=CV_OCR_GH){
  const v=new Float32Array(gw*gh); let s=0;
  for(let gy=0;gy<gh;gy++){ const ya=y0+Math.floor(gy*h/gh), yb=Math.max(ya+1, y0+Math.floor((gy+1)*h/gh));
    for(let gx=0;gx<gw;gx++){ const xa=x0+Math.floor(gx*w/gw), xb=Math.max(xa+1, x0+Math.floor((gx+1)*w/gw)); let a=0, n=0;
      for(let y=ya;y<yb;y++) for(let x=xa;x<xb;x++){ a+=dark[y*W+x]; n++; }
      v[gy*gw+gx]=a/n; s+=a/n; } }
  const mu=s/v.length; let q=0; for(let i=0;i<v.length;i++){ v[i]-=mu; q+=v[i]*v[i]; } q=Math.sqrt(q)||1; for(let i=0;i<v.length;i++) v[i]/=q;
  return v;
}
async function cvOcrFonts(){ try{ await Promise.all(["400","500","700"].flatMap(w=>["OcrPop","OcrDj","OcrLib"].map(f=>document.fonts.load(`${w} 36px ${f}`, "CAPE")))); }catch(e){} }
let CV_FAMS=null;
function cvOcrFams(){
  if(CV_FAMS) return CV_FAMS;
  const x=document.createElement("canvas").getContext("2d"), cand=["Arial","Helvetica","Verdana","Tahoma","Segoe UI","Roboto","Trebuchet MS","Open Sans"], probe="CAPE Precipitable wQ 0123456789", fams=["OcrPop","OcrDj","OcrLib"];
  x.font="48px monospace"; const mono=x.measureText(probe).width;
  for(const f of cand){ x.font=`48px "${f}", monospace`; if(Math.abs(x.measureText(probe).width-mono)>1) fams.push(`"${f}"`); }
  return CV_FAMS=fams;
}
function* cvOcrGen(){
  let tt=performance.now();
  const c=document.createElement("canvas"), x=c.getContext("2d",{willReadFrequently:true});
  // فقط قلم‌هایی که واقعاً نصب‌اند (بقیه همان قلم پیش‌فرض را تکرار می‌کنند)
  const fams=cvOcrFams();
  const vars=w=>{ const s=new Set([w]); if(/[a-z]/.test(w)){ s.add(w.toUpperCase()); s.add(w.toLowerCase()); s.add(w[0].toUpperCase()+w.slice(1).toLowerCase()); } return [...s]; };
  const out=[], seen=new Set();
  for(const [k,ws] of Object.entries(CV_WORDS)) for(const w0 of ws) for(const w of vars(w0)) for(const f of fams) for(const wt of (f==="OcrPop"?["400","500","700"]:["400","700"])) for(const ls of [0,2.5,5]){
    const setF=()=>{ x.font=`${wt} 36px ${f}`; if("letterSpacing" in x) x.letterSpacing=ls+"px"; else if(ls) return false; return true; };
    if(performance.now()-tt>25){ yield; tt=performance.now(); }
    if(!setF()) continue; const tw=Math.ceil(x.measureText(w).width+ls*w.length)+16; c.width=tw; c.height=60;
    x.fillStyle="#fff"; x.fillRect(0,0,tw,60); x.fillStyle="#000"; setF(); x.textBaseline="alphabetic"; x.fillText(w,8,44);
    const d=x.getImageData(0,0,tw,60).data, dark=new Float32Array(tw*60); let X0=tw, X1=-1, Y0=60, Y1=-1;
    for(let i=0;i<tw*60;i++){ const L=0.299*d[i*4]+0.587*d[i*4+1]+0.114*d[i*4+2], v=(255-L)/255; dark[i]=v; if(v>0.3){ const xx=i%tw, yy=(i/tw)|0; if(xx<X0)X0=xx; if(xx>X1)X1=xx; if(yy<Y0)Y0=yy; if(yy>Y1)Y1=yy; } }
    if(X1<0) continue;
    const ww=X1-X0+1, hh=Y1-Y0+1, a=ww/hh, gw=Math.max(3, Math.min(160, Math.round(CV_OCR_GH*a)));
    const v=cvOcrVec(dark, tw, X0, Y0, ww, hh, gw), sig=w+"|"+gw+"|"+v[0].toFixed(3)+v[v.length>>1].toFixed(3);
    if(seen.has(sig)) continue; seen.add(sig);
    out.push({k, w, a, gw, v, c:cvOcrVec(dark, tw, X0, Y0, ww, hh, CV_OCR_CW, CV_OCR_CH), short: w.replace(/[^A-Za-z]/g,"").length<=3});
  }
  for(const t of out){ const m=/^(u|rg|md|lv|re|rn|v|h)_(.*)$/.exec(t.k); t.pre=m?m[1]:""; t.kk=m?m[2]:t.k; }
  out.sort((p,q)=>p.a-q.a);   // مرتب بر پایهٔ نسبت ابعاد برای جست‌وجوی دودویی
  CV_OCR_T=out; cvOcrCacheSave(out);
}

// قالب‌های OCR یک‌بار ساخته می‌شوند (حدود چند ثانیه)؛ نسخهٔ ساخته‌شده در IndexedDB مرورگر می‌ماند تا دفعهٔ بعد فوری باشد.
// ساخت پس‌زمینه‌ای در برش‌های ۲۵ میلی‌ثانیه‌ای انجام می‌شود تا صفحه هنگ نکند؛ اگر کاربر زودتر نقشه بدهد، همان مولد تا آخر اجرا می‌شود.
let CV_OCR_GEN=null;
function cvOcrTemplates(){
  if(CV_OCR_T) return CV_OCR_T;
  if(!CV_OCR_GEN) CV_OCR_GEN=cvOcrGen();
  while(!CV_OCR_T){ const r=CV_OCR_GEN.next(); if(r.done && !CV_OCR_T) throw new Error("ساخت قالب OCR ناقص ماند"); }
  return CV_OCR_T;
}
function cvOcrCacheKey(){ let h=0; const s=JSON.stringify(CV_WORDS)+"|"+cvOcrFams().join(",")+"|"+CV_OCR_GH+"|"+CV_OCR_CW+"x"+CV_OCR_CH; for(let i=0;i<s.length;i++) h=(Math.imul(h,31)+s.charCodeAt(i))|0; return "ocrT.v1."+h; }
function cvIDB(){ return new Promise((res,rej)=>{ try{ const r=indexedDB.open("metstat-cache",1); r.onupgradeneeded=()=>r.result.createObjectStore("kv"); r.onsuccess=()=>res(r.result); r.onerror=()=>rej(r.error); }catch(e){ rej(e); } }); }
async function cvOcrCacheLoad(){ try{ const db=await cvIDB(), key=cvOcrCacheKey(); const v=await new Promise((res,rej)=>{ const q=db.transaction("kv").objectStore("kv").get(key); q.onsuccess=()=>res(q.result); q.onerror=()=>rej(q.error); });
  if(v && Array.isArray(v) && v.length>50 && !CV_OCR_T) CV_OCR_T=v; db.close(); }catch(e){} }
function cvOcrCacheSave(out){ (async()=>{ try{ const db=await cvIDB(); const tx=db.transaction("kv","readwrite"); tx.objectStore("kv").put(out, cvOcrCacheKey()); tx.oncomplete=()=>db.close(); }catch(e){} })(); }
async function cvOcrPrewarm(){
  try{ await cvOcrFonts(); await cvOcrCacheLoad(); if(CV_OCR_T) return;
    if(!CV_OCR_GEN) CV_OCR_GEN=cvOcrGen();
    while(!CV_OCR_T){ const r=CV_OCR_GEN.next(); if(r.done) break; await new Promise(r=>setTimeout(r,0)); } }catch(e){}
}

// واژه‌های متنی تصویر: مؤلفه‌های همبند تیره روی زمینهٔ روشن (و برعکس)، گروه‌بندی در سطر و واژه
function cvOcrWords(m, skip){
  const W=m.w, H=m.h, d=m.data, N=W*H, L=new Float32Array(N);
  for(let i=0;i<N;i++) L[i]=0.299*d[i*4]+0.587*d[i*4+1]+0.114*d[i*4+2];
  // میانگین محلی برای جدا کردن نوشته از سطوح رنگی بزرگ
  const r=12, I=new Float64Array((W+1)*(H+1));
  for(let y=0;y<H;y++){ let s=0; for(let x=0;x<W;x++){ s+=L[y*W+x]; I[(y+1)*(W+1)+x+1]=I[y*(W+1)+x+1]+s; } }
  const mean=(x,y)=>{ const xa=Math.max(0,x-r), xb=Math.min(W,x+r+1), ya=Math.max(0,y-r), yb=Math.min(H,y+r+1); return (I[yb*(W+1)+xb]-I[ya*(W+1)+xb]-I[yb*(W+1)+xa]+I[ya*(W+1)+xa])/((xb-xa)*(yb-ya)); };
  const words=[];
  for(const pol of [0,1]){
    const fg=new Uint8Array(N), dark=new Float32Array(N);
    for(let y=0;y<H;y++) for(let x=0;x<W;x++){ const i=y*W+x; if(skip(x,y)) continue; const l=L[i], mu=mean(x,y);
      if(pol===0){ if(l<130 && mu>105 && mu-l>40) fg[i]=1; dark[i]=(255-l)/255; }
      else { if(l>180 && mu<150 && l-mu>40) fg[i]=1; dark[i]=l/255; } }
    // مؤلفه‌های همبند
    const lab=new Int32Array(N).fill(-1), comps=[], st=[];
    for(let i0=0;i0<N;i0++){ if(!fg[i0]||lab[i0]>=0) continue;
      let x0=W,x1=-1,y0=H,y1=-1,n=0; st.push(i0); lab[i0]=comps.length;
      while(st.length){ const i=st.pop(), x=i%W, y=(i/W)|0; n++; if(x<x0)x0=x; if(x>x1)x1=x; if(y<y0)y0=y; if(y>y1)y1=y;
        for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ const xx=x+dx, yy=y+dy; if(xx<0||yy<0||xx>=W||yy>=H) continue; const j=yy*W+xx; if(fg[j]&&lab[j]<0){ lab[j]=comps.length; st.push(j); } } }
      comps.push({x0,x1,y0,y1,n, h:y1-y0+1, w:x1-x0+1}); }
    const cs=comps.filter(c=>c.h>=2 && c.h<=90 && c.w<=8*Math.max(c.h,6) && c.n>=2 && !(c.h>8 && c.w>c.h*6));
    // سطرها: هم‌پوشانی عمودی با ارتفاع حروف اصلی
    const big=cs.filter(c=>c.h>=7).sort((a,b)=>a.x0-b.x0), lines=[];
    for(const c of big){ let best=null;
      for(const ln of lines){ const ov=Math.min(ln.y1,c.y1)-Math.max(ln.y0,c.y0); if(ov>0.5*Math.min(c.h,ln.y1-ln.y0+1) && c.x0-ln.x1 < 2.5*ln.hmax && c.h<2.2*ln.hmax && ln.hmax<2.2*c.h){ best=ln; break; } }
      if(best){ best.cs.push(c); best.x1=Math.max(best.x1,c.x1); best.y0=Math.min(best.y0,c.y0); best.y1=Math.max(best.y1,c.y1); best.hmax=Math.max(best.hmax,c.h); }
      else lines.push({cs:[c], x0:c.x0, x1:c.x1, y0:c.y0, y1:c.y1, hmax:c.h}); }
    for(const ln of lines){
      // نقطه و ویرگول و نقطهٔ i
      for(const c of cs) if(c.h<7 && c.y0>=ln.y0-ln.hmax*0.5 && c.y1<=ln.y1+ln.hmax*0.5 && c.x0>=ln.x0-ln.hmax && c.x1<=ln.x1+ln.hmax && !ln.cs.includes(c)) ln.cs.push(c);
      ln.cs.sort((a,b)=>a.x0-b.x0);
      const gapT=Math.max(2, 0.3*ln.hmax); let cur=null;
      const flush=()=>{ if(!cur) return; const cc=cur.cs;
        // ویرگول و نقطهٔ انتهای واژه حذف شود
        while(cc.length>1){ const c=cc[cc.length-1]; if(c.h<0.6*ln.hmax && c.w<0.45*ln.hmax && c.y0>ln.y0+0.45*ln.hmax) cc.pop(); else break; }
        const wd={x0:1e9,x1:-1,y0:1e9,y1:-1,n:cc.length,dark,W}; for(const c of cc){ wd.x0=Math.min(wd.x0,c.x0); wd.x1=Math.max(wd.x1,c.x1); wd.y0=Math.min(wd.y0,c.y0); wd.y1=Math.max(wd.y1,c.y1); }
        lw.push(wd); cur=null; };
      const lw=[];
      for(const c of ln.cs){
        if(cur && c.x0-cur.x1 <= gapT){ cur.x1=Math.max(cur.x1,c.x1); cur.cs.push(c); }
        else { flush(); cur={x1:c.x1, cs:[c]}; } }
      flush();
      // قلم‌های با فاصلهٔ حروف زیاد: ترکیب ۲ و ۳ تکهٔ پشت‌سرهم هم نامزد واژه‌اند
      for(let a=0;a<lw.length;a++){ words.push(lw[a]); let m={...lw[a]};
        for(let b=a+1;b<Math.min(lw.length,a+3);b++){ if(lw[b].x0-lw[b-1].x1 > 0.9*ln.hmax) break;
          m={...m, x1:lw[b].x1, y0:Math.min(m.y0,lw[b].y0), y1:Math.max(m.y1,lw[b].y1), n:m.n+lw[b].n, merged:true}; words.push(m); } }
    }
  }
  return words.filter(w=>{ const h=w.y1-w.y0+1, ww=w.x1-w.x0+1; return h>=7 && h<=110 && ww>=h*0.6; });
}
// بهترین شاخص از روی عنوان؛ ابتدا بیرون کادر نقشه، اگر چیزی نبود کل تصویر

// خواندن مختصات پانویس weather.us (مثلاً «53.7E, 29.0N») با خوانشگر ارقام نوار رنگ
function wuFooterCoords(m){
  try{
    const W=m.w, H=m.h, d=m.data, br=m.prof&&m.prof.bar&&m.prof.bar.rect; const y0=Math.min(H-30, (br?br[3]:H-90)+28), x0=6, x1=Math.min(W, 380), RW=x1-x0, RH=H-y0;
    const dark=new Float32Array(RW*RH), fg=new Uint8Array(RW*RH);
    for(let y=0;y<RH;y++) for(let x=0;x<RW;x++){ const i=((y+y0)*W+x+x0)*4, L=0.299*d[i]+0.587*d[i+1]+0.114*d[i+2], v=Math.max(0,(235-L)/235); dark[y*RW+x]=v; if(v>0.35) fg[y*RW+x]=1; }
    const lab=new Int32Array(RW*RH).fill(-1), comps=[], st=[];
    for(let i0=0;i0<RW*RH;i0++){ if(!fg[i0]||lab[i0]>=0) continue; let a=RW,b=-1,c=RH,e=-1; st.push(i0); lab[i0]=comps.length;
      while(st.length){ const i=st.pop(), x=i%RW, y=(i/RW)|0; if(x<a)a=x; if(x>b)b=x; if(y<c)c=y; if(y>e)e=y;
        for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){ const xx=x+dx, yy=y+dy; if(xx<0||yy<0||xx>=RW||yy>=RH) continue; const j=yy*RW+xx; if(fg[j]&&lab[j]<0){ lab[j]=comps.length; st.push(j); } } }
      comps.push({x0:a,x1:b,y0:c,y1:e,w:b-a+1,h:e-c+1}); }
    const big=comps.filter(c=>c.h>=6&&c.h<=20); if(big.length<3) return null;
    const lines=[]; for(const c of big.sort((a,b)=>a.y0-b.y0)){ const ln=lines.find(l=>Math.min(l.y1,c.y1)-Math.max(l.y0,c.y0)>0.4*Math.min(c.h,l.y1-l.y0+1)); if(ln){ ln.cs.push(c); ln.y0=Math.min(ln.y0,c.y0); ln.y1=Math.max(ln.y1,c.y1); } else lines.push({cs:[c],y0:c.y0,y1:c.y1}); }
    for(const ln of lines.slice(0,2)){
      const Hd=Math.max(...ln.cs.map(c=>c.h)), cs=comps.filter(c=>c.y0>=ln.y0-2&&c.y1<=ln.y1+3).sort((a,b)=>a.x0-b.x0); let str="", prev=null;
      for(const c of cs){ if(prev && c.x0-prev.x1>0.45*Hd) str+=" ";
        if(c.h>=0.6*Hd){ const g=cvSplitDigits(dark,RW,c,ln.y0,ln.y1,Hd); str+=g.s; } else if(c.h<=0.35*Hd && c.y1>=ln.y1-0.25*Hd) str+="."; else str+="~";
        prev=c; }
      const nums=[...str.matchAll(/(\d{2})\.(\d)/g)].map(q=>+(q[1]+"."+q[2]));
      if(nums.length>=2){ for(const [e,n,key] of WU_COORD_ZOOMS){ if(Math.abs(nums[0]-parseFloat(e))<=0.15 && Math.abs(nums[1]-parseFloat(n))<=0.15) return key; } }
    }
  }catch(e){ console.warn("wuFooterCoords", e); }
  return null;
}
const CV_WCACHE=new Map();
// امتیاز یک واژه در برابر الگوها (با پیش‌غربال بردار درشت)
function cvOcrScore(T, w, ww, hh, fk){
  const a=ww/hh, cache={}, wc=cvOcrVec(w.dark, w.W, w.x0, w.y0, ww, hh, CV_OCR_CW, CV_OCR_CH), NC=wc.length, kb={}, vb={}, hb={}, ev=[]; let top=null;
  const aLo=a*Math.exp(-0.25), aHi=a*Math.exp(0.25); let i0=0, i1=T.length; while(i0<i1){ const md=(i0+i1)>>1; if(T[md].a<aLo) i0=md+1; else i1=md; }
  const fine=t=>{ const v=cache[t.gw]||(cache[t.gw]=cvOcrVec(w.dark, w.W, w.x0, w.y0, ww, hh, t.gw)); let s=0; for(let i=0;i<v.length;i++) s+=v[i]*t.v[i]; return s; };
  for(let ti=i0; ti<T.length && T[ti].a<=aHi; ti++){ const t=T[ti], pre=t.pre, k=t.kk;
    let cs=0; for(let q=0;q<NC;q++) cs+=wc[q]*t.c[q];
    if(cs<CV_OCR_CUT){ if(!pre){ if(!(kb[k]>=cs)) kb[k]=cs; } else if(pre==="v"){ if(!(vb[k]>=cs)) vb[k]=cs; } else if(pre==="h"){ if(!(hb[k]>=cs)) hb[k]=cs; } continue; }
    if(pre==="h"){ const s0=fine(t); if(!(hb[k]>=s0)) hb[k]=s0; continue; }
    if(pre==="v"){ const s0=fine(t); if(!(vb[k]>=s0)) vb[k]=s0; continue; }
    if((pre==="rg"||pre==="re"||pre==="rn") && fk) continue;
    let s=fine(t);
    if(t.short && !pre) s-=0.12;   // واژه‌های کوتاه سخت‌گیرانه‌تر
    if(w.merged) s-=0.02;
    if(pre) ev.push([pre,k,s,t.w]);
    else { if(!(kb[k]>=s)) kb[k]=s; if(!top||s>top.s) top={k, s, w:t.w}; } }
  return {kb, vb, hb, top, cat:ev};
}
function cvTitleType(m){
  try{
    const T=cvOcrTemplates(), p=m.prof, br=p&&p.bar&&p.bar.rect;
    const inBar=(x,y)=>br && x>=br[0]-2 && x<br[2]+2 && y>=br[1]-2 && y<br[3]+2;
    const inFrame=(x,y)=>p && x>=p.fx0 && x<p.fx1 && y>=p.fy0 && y<p.fy1;
    const footY = (br && p && p.bar.orient==="h" && br[1]>p.fy1) ? br[3] : -1;   // پانویس زیر نوار رنگ (نام منطقه و مدل)
    const pass=skip=>{
      const cat={}, kb={}, vb={}, hb={}; let top=null;
      for(const w of cvOcrWords(m, skip)){
        const ww=w.x1-w.x0+1, hh=w.y1-w.y0+1, fk=(footY>=0 && w.y0<footY)?1:0;
        // حافظهٔ واژه‌ها: واژه‌های تکراری (پانویس، نام مدل، نام سایت) در نقشه‌های پشت سر هم دوباره سنجیده نمی‌شوند
        let h=2166136261; for(let y=w.y0;y<=w.y1;y++){ const o=y*w.W; for(let x=w.x0;x<=w.x1;x++) h=Math.imul(h ^ ((w.dark[o+x]*12)|0), 16777619); }
        const key=ww+"x"+hh+"|"+(w.merged?1:0)+fk+"|"+(h>>>0);
        let ev=CV_WCACHE.get(key);
        if(!ev){ ev=cvOcrScore(T, w, ww, hh, fk); if(CV_WCACHE.size>30000) CV_WCACHE.clear(); CV_WCACHE.set(key, ev); }
        for(const k in ev.kb) if(!(kb[k]>=ev.kb[k])) kb[k]=ev.kb[k];
        for(const k in ev.vb) if(!(vb[k]>=ev.vb[k])) vb[k]=ev.vb[k];
        for(const k in ev.hb) if(!(hb[k]>=ev.hb[k])) hb[k]=ev.hb[k];
        if(ev.top && (!top || ev.top.s>top.s)) top=ev.top;
        for(const [pre,k,s,tw] of ev.cat){ const c=cat[pre]||(cat[pre]={k:null,s:-1,s2:-1});
          if(s>c.s){ if(c.k!==k) c.s2=Math.max(c.s2,c.s); c.k=k; c.s=s; c.w=tw; } else if(k!==c.k && s>c.s2) c.s2=s; }
      }
      const r = top && top.s>=0.66 ? top : {k:null, s:0}; r.kb=kb; r.vb=vb; r.hb=hb;
      r.unit = cat.u && cat.u.s>=0.7 ? cat.u.k : null;
      const okc=c=>c && (c.s>=0.72 || (c.s>=0.5 && c.s-c.s2>=0.1));   // قلم ریز پیکسلی: برندهٔ واضح هم پذیرفته می‌شود
      r.region = okc(cat.rg) ? cat.rg.k : null;

      r.model = okc(cat.md) ? cat.md.k : null;
      r.level = cat.lv && cat.lv.s>=0.62 ? cat.lv.k : null;
      return r;
    };
    const r1=pass((x,y)=>inBar(x,y)||inFrame(x,y));
    if(!r1.region || r1.region==='Iran'){ const fz=wuFooterCoords(m); if(fz) r1.region=fz; }
    if(!r1.k){ const r2=pass(inBar); if(r2.k){ r1.k=r2.k; r1.s=r2.s; r1.w=r2.w; r1.kb=r2.kb; } for(const k in r2.vb) if(!(r1.vb[k]>=r2.vb[k])) r1.vb[k]=r2.vb[k]; for(const k in r2.hb) if(!(r1.hb[k]>=r2.hb[k])) r1.hb[k]=r2.hb[k]; }
    return r1;
  }catch(e){ console.warn("cvTitleType", e); return null; }
}
function cvRamp(v, r){ if(!r || !(v===v)) return NaN;
  if(r.length===3){ const [a,b,c]=r; if(a===c) return v>=c?1:0; const t1=(v-a)/(b-a), t2=(v-b)/(c-b);
    if((b-a)*(v-b) <= 0) return Math.max(0,Math.min(0.5, 0.5*t1)); return Math.max(0.5,Math.min(1, 0.5+0.5*t2)); }
  const [lo,hi]=r; if(lo===hi) return v>=hi?1:0; const t=(v-lo)/(hi-lo); return t<0?0:t>1?1:t; }

