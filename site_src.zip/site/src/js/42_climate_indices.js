/* ===================== صفحهٔ «شاخص‌های اقلیمی (آنلاین)» =====================
   دادهٔ نمودارها: online/data/idx/index.json + <id>[_<model>]_<period>.png (ساختهٔ indices.py).
   فیلدهای اختیاری هر شاخص در index.json: val (آخرین مقدار)، prev (مقدار ماه قبل)، since (آغاز فاز فعلی)، fc (پیش‌بینی: [{l,v}])،
   models ([{id,fa}]). اگر نباشند، جدول/تحلیل فقط با آنچه هست کار می‌کند. هیچ سری عددی منتشر نمی‌شود. */
const CI={idx:null, id:"", m:"", per:"", sel:store.get("ci.sel",null), busy:false};
const CI_INFO=[ // [regex, عنوان فارسی, فاز مثبت, فاز منفی, آستانه‌ها, توضیح علمی, مرجع]
 [/oni/i,"شاخص اقیانوسی نینو (ONI)","گرم (ال‌نینو)","سرد (لانینا)",[.5,1,1.5],"میانگین سه‌ماههٔ بی‌هنجاری دمای سطح دریا در ناحیهٔ نینو ۳٫۴ (۵°شمالی تا ۵°جنوبی، ۱۲۰ تا ۱۷۰ درجهٔ غربی). مقادیر ≥ ۰٫۵ به‌مدت ۵ فصل پیاپی ال‌نینو و ≤ ‎−۰٫۵ لانینا است.","NOAA CPC — Cold & Warm Episodes by Season"],
 [/nino|niño|enso/i,"انسو — دمای سطح دریای نینو ۳٫۴ (ENSO)","گرم (ال‌نینو)","سرد (لانینا)",[.5,1,1.5],"بی‌هنجاری دمای سطح دریا در ناحیهٔ نینو ۳٫۴ اقیانوس آرام استوایی؛ مهم‌ترین عامل تغییرپذیری بین‌سالانهٔ اقلیم جهان و بارش ایران.","NOAA PSL / CPC; Trenberth (1997), BAMS"],
 [/mei/i,"شاخص چندمتغیرهٔ انسو (MEI.v2)","گرم (ال‌نینو)","سرد (لانینا)",[.5,1,1.5],"ترکیب استانداردشدهٔ فشار تراز دریا، مؤلفه‌های باد سطحی، دمای سطح دریا، دمای هوا و پوشش ابر در اقیانوس آرام استوایی.","NOAA PSL — MEI.v2; Zhang et al. (2019)"],
 [/soi/i,"شاخص نوسان جنوبی (SOI)","لانینا‌گونه","ال‌نینو‌گونه",[.5,1,1.5],"اختلاف فشار استانداردشدهٔ تاهیتی و داروین؛ مقدار منفی پایدار با ال‌نینو و مقدار مثبت با لانینا هم‌راه است.","Australian BoM; NOAA CPC"],
 [/pdo/i,"نوسان دهه‌ای اقیانوس آرام (PDO)","گرم (مثبت)","سرد (منفی)",[.5,1,1.5],"مؤلفهٔ اصلی بی‌هنجاری دمای سطح دریا در اقیانوس آرام شمالی (بالاتر از ۲۰° شمالی)؛ تغییرپذیری با مقیاس دهه‌ای.","Mantua et al. (1997), BAMS; NOAA NCEI"],
 [/nao/i,"نوسان اطلس شمالی (NAO)","مثبت","منفی",[.5,1,1.5],"اختلاف فشار بین پرفشار آزور و کم‌فشار ایسلند؛ فاز منفی با تشدید سامانه‌های بارشی در مدیترانه و غرب آسیا همراه است.","NOAA CPC; Hurrell (1995), Science"],
 [/aao|antarctic/i,"نوسان جنوبگان (AAO)","مثبت","منفی",[.5,1,1.5],"مؤلفهٔ اصلی ارتفاع ژئوپتانسیل ۷۰۰ هکتوپاسکال در جنوب ۲۰° جنوبی؛ فاز مثبت با تقویت و تنگ‌شدن کمربند بادهای غربی دور جنوبگان همراه است و فاز منفی با نفوذ هوای سرد به عرض‌های پایین‌تر.","NOAA CPC; Thompson & Wallace (2000), J. Climate"],
 [/(^|[^a-z])ao([^a-z]|$)|arctic/i,"نوسان قطب شمال (AO)","مثبت","منفی",[.5,1,1.5],"مؤلفهٔ اصلی ارتفاع ژئوپتانسیل ۱۰۰۰ هکتوپاسکال در شمال ۲۰° شمالی؛ فاز منفی با ورود هوای سرد به عرض‌های میانی همراه است.","NOAA CPC; Thompson & Wallace (1998), GRL"],
 [/tna/i,"شاخص اطلس گرمسیری شمالی (TNA)","گرم","سرد",[.3,.6,.9],"بی‌هنجاری دمای سطح دریا در اطلس گرمسیری شمالی (۵٫۵ تا ۲۳٫۵° شمالی، ۱۵ تا ۵۷٫۵° غربی).","NOAA PSL; Enfield et al. (1999)"],
 [/amo/i,"نوسان چنددههٔ اطلس (AMO)","گرم (مثبت)","سرد (منفی)",[.2,.4,.6],"بی‌هنجاری دمای سطح دریا در اطلس شمالی پس از حذف روند؛ چرخهٔ ۶۰ تا ۸۰ ساله.","NOAA PSL; Enfield et al. (2001)"],
 [/dmi|iod/i,"دوقطبی اقیانوس هند (IOD/DMI)","مثبت","منفی",[.4,.8,1.2],"اختلاف بی‌هنجاری دمای سطح دریا بین غرب و شرق اقیانوس هند؛ فاز مثبت با بارش بیشتر شرق آفریقا و اثر بر بارش پاییزی ایران همراه است.","NOAA PSL; Saji et al. (1999), Nature"],
 [/pna/i,"الگوی اقیانوس آرام – آمریکای شمالی (PNA)","مثبت","منفی",[.5,1,1.5],"الگوی بسامد پایین موج‌های راسبی نیم‌کرهٔ شمالی که با ENSO پیوند دارد.","NOAA CPC; Wallace & Gutzler (1981)"],
 [/wpo/i,"نوسان غرب اقیانوس آرام (WPO)","مثبت","منفی",[.5,1,1.5],"دوقطبی فشار بین شمال شرق آسیا و غرب اقیانوس آرام شمالی.","NOAA CPC"],
 [/eawr|ea.?wr/i,"الگوی شرق اطلس – غرب روسیه (EA/WR)","مثبت","منفی",[.5,1,1.5],"الگوی پیوند از دور اوراسیا که بر دما و بارش اروپای شرقی و غرب آسیا اثر می‌گذارد.","NOAA CPC"],
 [/scand/i,"الگوی اسکاندیناوی (SCAND)","مثبت","منفی",[.5,1,1.5],"الگوی پیوند از دور اوراسیا با مرکز اصلی روی اسکاندیناوی (بلاکینگ).","NOAA CPC"],
 [/qbo/i,"نوسان شبه‌دوسالانه (QBO)","فاز غربی","فاز شرقی",[5,15,25],"چرخش بادهای مداری در پوشن‌سپهر با دورهٔ حدود ۲۸ ماه؛ مقدار بر حسب متر بر ثانیه در ترازهای مختلف.","FU Berlin — QBO data; Baldwin et al. (2001), RG"],
 [/mjo/i,"نوسان مادن–جولین (MJO)","فعال","—",[1,1.5,2],"موج همرفتی شرق‌سو در مناطق گرمسیری با دورهٔ ۳۰ تا ۶۰ روز؛ دامنه و فاز آن بر بارش جنب‌حاره اثر دارد.","BoM; NOAA CPC; Wheeler & Hendon (2004)"]];
const ciMeta=e=>{ const k=(e.id||"")+" "+(e.en||"")+" "+(e.fa||""); const r=CI_INFO.find(x=>x[0].test(k)); return r?{fa:(e.kind==="plume"&&e.fa)?e.fa:r[1],pos:r[2],neg:r[3],th:r[4],desc:r[5],ref:r[6]}:{fa:e.fa||e.en||e.id,pos:"مثبت",neg:"منفی",th:[.5,1,1.5],desc:"",ref:""}; };
const CI_POS=["#fde2e2","#f4a6a6","#d93636"], CI_NEG=["#dbeafe","#8fb8f0","#1f5fbf"];
function ciPhase(e){ const v=+e.val; if(e.val==null||isNaN(v)) return null; const M=ciMeta(e), a=Math.abs(v), [w,m,s]=M.th, lv=a<w?0:a<m?1:a<s?2:3, nm=["خنثی","ضعیف","متوسط","قوی"];
  return {v,lv,txt:lv?`${v>0?M.pos:M.neg} — ${nm[lv]}`:"خنثی", bg:lv?(v>0?CI_POS:CI_NEG)[lv-1]:"#e5e7eb", fg:lv===3?"#fff":"#111"}; }
const ciRank=s=>/(۳|3).{0,3}(ماه|month)|season|فصل/i.test(s)?3:/روز|daily|^d\d*$|day/i.test(s)?0:/هفت|week|^w\d*$/i.test(s)?1:/ماه|month|^m\d*$/i.test(s)?2:5;
const ciFmt=new Intl.DateTimeFormat("fa-IR-u-ca-persian",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit",timeZone:"Asia/Tehran"});
function ciUpd(e){ let s=e.upd&&/[T:]/.test(e.upd)?e.upd:(CI.idx&&CI.idx.updated)||e.upd||""; if(/^\d{4}-\d\d-\d\dT[\d:]+$/.test(s)) s+="Z"; const d=new Date(s); return isNaN(d)?(s||"—"):ciFmt.format(d); }
const ciItems=()=>(CI.idx&&CI.idx.items)||{};
const ciEnt=id=>{ const e=ciItems()[id]; return e?Object.assign({id},e):null; };
const ciUrl=(e,m,p)=>ON.base+`data/idx/${e.id}${m?"_"+m:""}_${p}.png?`+((CI.idx&&CI.idx.updated)||"");
function ciHTML(){ return `<section class="card ciSel"><h3>شاخص‌های اقلیمی (آنلاین)</h3>
  <label>شاخص <select id="ciI"></select></label><label>مدل / منبع <select id="ciM"></select></label><label>دورهٔ نمودار <select id="ciP"></select></label>
  <div class="hint" id="ciMsg">در حال دریافت فهرست شاخص‌ها…</div></section>
 <article class="card ciFig" id="ciFig" hidden><div class="ciHead"><img class="ciLogo" alt="MetStat"><div><div class="ciTtl" id="ciTtl"></div><div class="ciSub" id="ciSub"></div></div></div>
  <div class="ciUpd" id="ciUpd"></div><div class="ciImgW"><img id="ciImg" alt=""></div>
  <div class="ciBtns"><button class="btn sm" type="button" id="ciDl">دانلود PNG</button><button class="btn sm" type="button" id="ciInfo" title="اطلاعات علمی">ℹ i</button></div>
  <div class="ciInfoBox" id="ciInfoBox" hidden></div></article>
 <section class="card" id="ciAnBox" hidden><button class="btn main" type="button" id="ciAn">تحلیل</button><div id="ciAnOut" hidden><pre id="ciAnTxt" class="ciPre"></pre><div class="ciBtns"><button class="btn sm" type="button" id="ciCp">کپی</button><button class="btn sm" type="button" id="ciPdf">PDF</button></div></div></section>
 <section class="card" id="ciTabBox" hidden><h3>جدول ترکیبی شاخص‌ها</h3><div class="ciTW"><table class="ciTab" id="ciTab"></table></div>
  <div class="hint">با تیک هر ردیف، شاخص در جدول می‌آید یا برداشته می‌شود. رنگ: قرمز = فاز مثبت (کم‌رنگ ضعیف، متوسط، پررنگ قوی)، آبی = فاز منفی، خاکستری = خنثی. فقط آخرین مقدار هر شاخص نمایش داده می‌شود.</div></section>`; }
async function ciLoad(){ try{ const r=await fetch(ON.base+"data/idx/index.json?"+Date.now(),{cache:"no-store"}); if(!r.ok) throw 0; CI.idx=await r.json(); }catch(e){ CI.idx=null; } }
function ciFill(id,opts,cur){ const s=$(id); s.innerHTML=opts.map(o=>`<option value="${o[0]}">${o[1]}</option>`).join(""); if(opts.some(o=>o[0]===cur)) s.value=cur; return s.value; }
function ciBuild(){ const it=ciItems(), ids=Object.keys(it), msg=$("ciMsg");
  if(!ids.length){ ["ciI","ciM","ciP"].forEach(i=>ciFill(i,[["","—"]])); msg.textContent="هنوز نمودار شاخصی روی هاست نیست (workflow «metstat-indices» را اجرا کنید)."; $("ciFig").hidden=$("ciAnBox").hidden=$("ciTabBox").hidden=true; return; }
  msg.textContent=""; const groups=[...new Set(ids.map(i=>it[i].grp||""))];
  $("ciI").innerHTML=groups.map(g=>`<optgroup label="${g||"شاخص‌ها"}">`+ids.filter(i=>(it[i].grp||"")===g).map(i=>`<option value="${i}">${ciMeta(ciEnt(i)).fa}</option>`).join("")+`</optgroup>`).join("");
  if(ids.includes(CI.id)) $("ciI").value=CI.id; CI.id=$("ciI").value; ciFillM(); ciTable(); }
function ciFillM(){ const e=ciEnt(CI.id); if(!e) return; const ms=(e.models&&e.models.length)?e.models.map(m=>[m.id,m.fa||m.id]):[["",e.src||"منبع اصلی"]]; CI.m=ciFill("ciM",ms,CI.m);
  const ps=Object.entries(e.per||{}).sort((a,b)=>ciRank(a[0]+" "+a[1])-ciRank(b[0]+" "+b[1])); CI.per=ciFill("ciP",ps,CI.per); ciShow(); }
function ciShow(){ const e=ciEnt(CI.id); if(!e||!CI.per){ $("ciFig").hidden=true; return; } const M=ciMeta(e);
  $("ciFig").hidden=false; $("ciAnBox").hidden=false; $("ciAnOut").hidden=true; $("ciInfoBox").hidden=true; $("ciFig").querySelector(".ciLogo").src=LOGO_SRC;
  $("ciTtl").textContent=M.fa; $("ciSub").textContent=`${$("ciM").selectedOptions[0]?$("ciM").selectedOptions[0].textContent:""} · ${e.per[CI.per]||""}`;
  $("ciUpd").innerHTML=`<span>آخرین به‌روزرسانی</span><b>${ciUpd(e)}</b>${e.last?`<small>آخرین ماه داده: ${e.last}</small>`:""}`;
  const im=$("ciImg"); im.alt=e.en||""; im.src=ciUrl(e,CI.m,CI.per); im.onclick=()=>{ const d=$("zoom"); if(d){ d.querySelector("img").src=im.src; d.showModal(); } };
  $("ciInfoBox").innerHTML=`<p>${M.desc||"توضیحی برای این شاخص ثبت نشده است."}</p>${e.en?`<p><b>نام انگلیسی:</b> ${e.en}</p>`:""}<p><b>منبع داده:</b> ${e.src||"—"}</p>${e.kind==="plume"?`<p><b>روش نمودار:</b> شاخص روزانهٔ نرمال‌شده است. میله‌ها تحلیل روزهای گذشته‌اند؛ بخش بنفش پیش‌بینی گروهی GEFS است (خط پررنگ = میانگین اعضا، نوار پررنگ‌تر = بازهٔ ۱۰ تا ۹۰ درصد اعضا، خطوط نازک = تک‌تک اعضا). هرچه پراکندگی اعضا بیشتر باشد، اطمینان به آن روز کمتر است.</p>${e.note?`<p><b>یادداشت:</b> ${e.note}</p>`:""}`:""}${M.ref?`<p><b>مراجع:</b> ${M.ref}</p>`:""}`; }
function ciTable(){ const it=ciItems(), ids=Object.keys(it); if(!ids.length) return; if(!CI.sel) CI.sel=ids.slice(); $("ciTabBox").hidden=false;
  const hasFc=ids.some(i=>{ const f=it[i].fc; return Array.isArray(f)&&f.length; });
  const rows=ids.map(id=>{ const e=ciEnt(id), M=ciMeta(e), p=ciPhase(e), on=CI.sel.includes(id);
    const lf=Array.isArray(e.fc)&&e.fc.length?e.fc[e.fc.length-1]:null, fp=lf?ciPhase({id:e.id,en:e.en,fa:e.fa,val:lf.v}):null;
    const fcCell=hasFc?`<td${on&&fp?` style="background:${fp.bg};color:${fp.fg}"`:""}>${fp?`${fp.v.toFixed(2)} <small>(${lf.l})</small>`:"—"}</td>`:"";
    return `<tr class="${on?"":"off"}"><td><input type="checkbox" data-id="${id}" ${on?"checked":""}></td><td>${M.fa}</td><td${on&&p?` style="background:${p.bg};color:${p.fg}"`:""}>${p?p.v.toFixed(2):"—"}</td><td${on&&p?` style="background:${p.bg};color:${p.fg}"`:""}>${p?p.txt:"داده‌ای منتشر نشده"}</td><td>${e.since||"—"}</td>${fcCell}</tr>`; }).join("");
  $("ciTab").innerHTML=`<tr><th>نمایش</th><th>شاخص</th><th>مقدار</th><th>فاز</th><th>از</th>${hasFc?"<th>پیش‌بینی</th>":""}</tr>`+rows;
  $("ciTab").querySelectorAll("input[data-id]").forEach(c=>c.onchange=()=>{ CI.sel=[...$("ciTab").querySelectorAll("input[data-id]:checked")].map(x=>x.dataset.id); store.set("ci.sel",CI.sel); ciTable(); }); }
function ciAnalysis(){ const e=ciEnt(CI.id), M=ciMeta(e), p=ciPhase(e), L=[`تحلیل ${M.fa}`,`آخرین به‌روزرسانی: ${ciUpd(e)}`,""];
  if(!p){ L.push("مقدار عددی آخرین ماه برای این شاخص روی هاست منتشر نشده است؛ پس از به‌روزرسانی indices.py تحلیل کامل ساخته می‌شود."); }
  else { L.push(`مقدار فعلی شاخص ${p.v.toFixed(2)} است و در فاز «${p.txt}» قرار دارد.`);
    if(e.since) L.push(`این فاز از ${e.since} ادامه دارد.`);
    if(e.prev!=null&&!isNaN(+e.prev)){ const d=p.v-(+e.prev); L.push(`نسبت به ماه قبل (${(+e.prev).toFixed(2)}) ${Math.abs(d)<.05?"تقریباً بدون تغییر است":d>0?"افزایش یافته است":"کاهش یافته است"}.`); }
    if(Array.isArray(e.fc)&&e.fc.length){ const last=e.fc[e.fc.length-1], q=ciPhase({id:e.id,en:e.en,fa:e.fa,val:last.v}); L.push(`بر پایهٔ پیش‌بینی ${$("ciM").selectedOptions[0]?$("ciM").selectedOptions[0].textContent:"مدل"}، مقدار شاخص تا ${last.l} به ${(+last.v).toFixed(2)} ${q?`(${q.txt})`:""} می‌رسد.`);
      if(last.lo!=null&&last.hi!=null) L.push(`بازهٔ ۱۰ تا ۹۰ درصد اعضا برای ${last.l}: ${(+last.lo).toFixed(2)} تا ${(+last.hi).toFixed(2)}.`);
      if(last.pp!=null&&last.pn!=null) L.push(`احتمال فاز مثبت (بیشتر از +۰٫۵): ${last.pp}٪ · احتمال فاز منفی (کمتر از −۰٫۵): ${last.pn}٪ · احتمال خنثی: ${Math.max(0,100-last.pp-last.pn)}٪.`);
      if(e.fc.length>1) L.push("میانگین اعضا: "+e.fc.map(f=>`${f.l} ${(+f.v).toFixed(2)}`).join("؛ ")+"."); }
    else L.push("پیش‌بینی عددی برای این شاخص در دسترس نیست؛ روند بعدی را با نمودار بالا و مدل‌های پیش‌بینی ببینید."); }
  if(M.desc) L.push("","درباره شاخص: "+M.desc); return L.join("\n"); }
function ciDownload(){ const im=$("ciImg"); if(!im.naturalWidth) return; const e=ciEnt(CI.id), M=ciMeta(e), W=Math.max(900,im.naturalWidth), H=im.naturalHeight*(W/im.naturalWidth), hd=130, c=document.createElement("canvas"); c.width=W; c.height=hd+H+16; const x=c.getContext("2d");
  const lg=new Image(); lg.onload=()=>{ x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height); x.drawImage(lg,W-120,12,100,100*lg.naturalHeight/lg.naturalWidth); x.direction="rtl"; x.textAlign="right"; x.fillStyle="#111"; x.font="bold 34px Vazirmatn,Tahoma"; x.fillText(M.fa,W-140,48); x.font="22px Vazirmatn,Tahoma"; x.fillText(`آخرین به‌روزرسانی: ${ciUpd(e)}`,W-140,90); x.drawImage(im,0,hd,W,H);
    c.toBlob(b=>{ const a=document.createElement("a"); a.href=URL.createObjectURL(b); a.download=`${e.id}_${CI.per}.png`; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),2000); }); }; lg.src=LOGO_SRC; }
function ciBind(){ $("ciI").onchange=()=>{ CI.id=$("ciI").value; ciFillM(); }; $("ciM").onchange=()=>{ CI.m=$("ciM").value; ciShow(); }; $("ciP").onchange=()=>{ CI.per=$("ciP").value; ciShow(); };
  $("ciDl").onclick=ciDownload; $("ciInfo").onclick=()=>{ $("ciInfoBox").hidden=!$("ciInfoBox").hidden; };
  $("ciAn").onclick=()=>{ $("ciAnTxt").textContent=ciAnalysis(); $("ciAnOut").hidden=false; };
  $("ciCp").onclick=async()=>{ try{ await navigator.clipboard.writeText($("ciAnTxt").textContent); $("ciCp").textContent="کپی شد ✓"; setTimeout(()=>$("ciCp").textContent="کپی",1500); }catch(e){ alert("کپی انجام نشد"); } };
  $("ciPdf").onclick=()=>{ const w=window.open("","_blank"); if(!w){ alert("اجازهٔ بازشدن پنجره را بدهید"); return; } w.document.write(`<html dir="rtl" lang="fa"><meta charset="utf-8"><title>تحلیل شاخص</title><body style="font-family:Tahoma,Vazirmatn;line-height:2;padding:24px"><img src="${LOGO_SRC}" style="height:60px"><pre style="white-space:pre-wrap;font-family:inherit;font-size:15px">${$("ciAnTxt").textContent.replace(/</g,"&lt;")}</pre></body></html>`); w.document.close(); setTimeout(()=>w.print(),400); }; }
async function openCI(){ for(const id of ["landing","app","dsApp","cvApp","ltApp","wnApp","cqcApp","caApp","onApp"]) if($(id)) $(id).hidden=true;
  $("ciApp").hidden=false; $("srcName").textContent="شاخص‌های اقلیمی (آنلاین)"; $("srcBtn").hidden=false; store.set("mode","ci"); window.scrollTo(0,0);
  const m=$("ciMain"); if(!m.dataset.ok){ m.innerHTML=ciHTML(); ciBind(); m.dataset.ok=1; } await ciLoad(); ciBuild(); }
setInterval(async()=>{ if($("ciApp").hidden||document.hidden||!CI.idx) return; const u=CI.idx.updated; await ciLoad(); if(CI.idx&&CI.idx.updated!==u){ ciBuild(); } },600000);
for(const fn of ["switchMode","showLanding","openCQC","openDS","openCV","openLT","openWN","openCA","openON"]){ const f=window[fn]; if(typeof f!=="function") continue; window[fn]=function(...a){ if($("ciApp")) $("ciApp").hidden=true; return f.apply(this,a); }; }
