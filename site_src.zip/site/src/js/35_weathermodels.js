/* =====================================================================
   weathermodels.com (نقشه‌های ۱۰۰۰×۷۵۰ ECMWF/GFS/… با نوار رنگ عمودی)
   قالب ثابت: کادر ۶…۹۴۳ × ۴۵…۷۳۰، نوار رنگ x=۹۴۷…۹۶۳؛ بارش ۴۳ خانه (۰٫۵ تا ۵۰۰+ میلی‌متر) و دمای ۲ متری (۵۲− تا ۵۰ درجه، پیوسته)
   زمین‌مرجع (برازش مرز ایران روی خطوط خود نقشه، خطای ~۱ پیکسل): x = −1527.453 + 37.5415·lon ، y = 1793.397 − 43.3825·lat
   ===================================================================== */
{{BLOB:wm_lines}}
const WMC_PRECIP_PAL=[[214, 214, 214], [189, 189, 189], [164, 164, 164], [129, 129, 129], [200, 255, 190], [181, 250, 169], [120, 245, 115], [56, 210, 60], [28, 181, 29], [14, 160, 14], [21, 100, 211], [40, 130, 240], [80, 165, 246], [151, 210, 250], [181, 239, 251], [255, 252, 207], [254, 250, 169], [255, 232, 120], [253, 193, 60], [255, 160, 0], [254, 97, 0], [255, 50, 0], [225, 20, 0], [191, 0, 1], [164, 0, 0], [134, 0, 0], [100, 60, 50], [141, 100, 89], [181, 140, 130], [201, 160, 149], [241, 220, 210], [208, 200, 223], [192, 182, 216], [154, 137, 190], [134, 114, 175], [114, 92, 164], [119, 1, 118], [141, 0, 140], [178, 0, 176], [195, 0, 193], [203, 0, 204], [219, 0, 219], [230, 0, 230]];
const WMC_PRECIP_LAB=[0.5, 1, 1.5, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, 220, 240, 260, 300, 400, 500];
const WMC_T2M_PAL=[[168, 156, 173], [160, 146, 176], [143, 114, 170], [141, 99, 168], [122, 72, 156], [117, 61, 156], [85, 21, 138], [91, 6, 138], [96, 0, 137], [102, 0, 135], [130, 3, 133], [152, 1, 131], [163, 1, 128], [188, 2, 125], [206, 1, 124], [223, 1, 121], [239, 18, 131], [247, 47, 148], [250, 92, 170], [253, 114, 186], [237, 149, 203], [225, 159, 208], [209, 181, 217], [199, 195, 220], [187, 209, 232], [168, 226, 234], [157, 241, 240], [146, 227, 240], [130, 198, 221], [81, 156, 152], [71, 134, 133], [89, 135, 136], [128, 140, 144], [164, 164, 171], [193, 185, 190], [68, 30, 142], [73, 31, 135], [86, 31, 118], [100, 31, 103], [117, 30, 85], [133, 32, 69], [144, 32, 52], [163, 40, 36], [175, 66, 31], [174, 94, 72], [195, 125, 127], [209, 134, 134], [216, 161, 162], [222, 186, 182], [230, 220, 219], [236, 232, 232], [236, 234, 232], [216, 239, 235], [200, 238, 238], [165, 225, 239], [126, 193, 226], [101, 163, 212], [93, 137, 187], [84, 111, 165], [76, 86, 143], [96, 97, 153], [124, 123, 182], [144, 144, 180], [188, 188, 161], [217, 219, 144], [251, 251, 129], [255, 235, 96], [252, 211, 69], [250, 185, 39], [250, 162, 14], [254, 144, 1], [251, 129, 1], [248, 109, 2], [247, 92, 0], [236, 77, 1], [205, 52, 0], [175, 29, 1], [134, 5, 1], [115, 15, 12], [100, 37, 29], [92, 51, 43], [102, 76, 63], [124, 98, 84], [141, 117, 102], [165, 138, 124], [174, 146, 135], [170, 138, 130], [166, 128, 123], [161, 117, 114], [156, 108, 104], [148, 94, 91], [135, 69, 71], [122, 54, 70], [110, 70, 67], [97, 79, 75], [88, 89, 79], [78, 102, 80], [61, 109, 80], [57, 126, 90], [57, 129, 93], [71, 128, 101], [95, 129, 114], [116, 135, 131]];
const WMC_GEO={ax:-1527.453, bx:37.5415, ay:1793.397, by:-43.3825};
let _wmLines=null;
async function wmLinesLoad(){
  if(_wmLines) return _wmLines;
  try{ const n=WM_LINES.W*WM_LINES.H, m=new Uint8Array(n); const raw=await dsInflate(b64u8(WM_LINES.b64));
    for(let i=0;i<n;i++) m[i]=(raw[i>>3]>>(7-(i&7)))&1;
    if(WM_LINES.lakes){ const lk=await dsInflate(b64u8(WM_LINES.lakes)); for(let i=0;i<n;i++) if(!m[i] && ((lk[i>>3]>>(7-(i&7)))&1)) m[i]=2; }   // ۲ = دریاچه: از داده کنار گذاشته می‌شود ولی خط نیست
    _wmLines=m; }catch(e){ console.warn("wm lines",e); _wmLines=new Uint8Array(0); }
  return _wmLines;
}
function wmDetect(m){
  const W=m.w, H=m.h, d=m.data; if(Math.abs(W/H-1000/750)>0.01 || W<700) return null;
  const sx=W/1000, sy=H/750, px=(x,y)=>{ const X=Math.round(x*sx), Y=Math.round(y*sy), R=[],G=[],B=[];
    for(let dy=-2;dy<=2;dy++) for(let dx=-4;dx<=4;dx++){ const i=((Y+dy)*W+X+dx)*4; R.push(d[i]); G.push(d[i+1]); B.push(d[i+2]); }
    const md=a=>a.sort((p,q)=>p-q)[a.length>>1]; return [md(R),md(G),md(B)]; };
  // بارش: ۴۳ خانه، هر خانه ۱۵٫۶۵ پیکسل، از پایین (۷۱۶٫۵) به بالا
  const cand=[];
  { const segs=[]; let s=0; for(let k=0;k<43;k++){ const yb=716.5-15.65*k, yt=yb-15.65, c=px(955,(yb+yt)/2); s+=cdist(c,WMC_PRECIP_PAL[k]);
      segs.push({a:Math.round(yt*sy), b:Math.round(yb*sy)-1, c:WMC_PRECIP_PAL[k], yc:Math.round((yb+yt)/2*sy)}); }
    cand.push({id:"precip", md:s/43, segs, edges:WMC_PRECIP_LAB.join(", ")+", +", kind:undefined, name:"weathermodels — بارش تجمعی (۰٫۵ تا ۵۰۰ میلی‌متر)"}); }
  // دمای ۲ متری: پیوسته؛ هر ۱ درجه یک رده (۶٫۵۶ پیکسل)
  { const segs=[]; let s=0; for(let k=0;k<WMC_T2M_PAL.length;k++){ const v=-52+k, yc=59.5+(50-(v+0.5))*6.5588, c=px(955,yc); s+=cdist(c,WMC_T2M_PAL[k]);
      segs.push({a:Math.round((yc-3.28)*sy), b:Math.round((yc+3.28)*sy)-1, c:WMC_T2M_PAL[k], yc:Math.round(yc*sy)}); }
    const e=WMC_T2M_PAL.map((_,k)=>k===0?"-inf":String(-52+k)); e.push("+");
    cand.push({id:"t2m", md:s/WMC_T2M_PAL.length, segs, edges:e.join(", "), kind:"temp", name:"weathermodels — دمای ۲ متری (°C)"}); }
  const best=cand.sort((a,b)=>a.md-b.md)[0]; if(!best || best.md>(best.id==="t2m"?30:24)) return null;
  const fx0=Math.round(6*sx), fx1=Math.round(943*sx), fy0=Math.round(45*sy), fy1=Math.round(730*sy);
  const lon=x=>(x/sx-WMC_GEO.ax)/WMC_GEO.bx, lat=y=>(y/sy-WMC_GEO.ay)/WMC_GEO.by;
  const geo=[lon(fx0), lon(fx1), lat(fy1), lat(fy0)].map(v=>Math.round(v*1000)/1000);
  const segs=best.segs.map(s=>({a:s.a,b:s.b,c:s.c})), xb=Math.round(955*sx);
  const t2m=best.id==="t2m";
  return {W,H, tol:t2m?40:48, exactShare:0, fx0, fx1, fy0, fy1, bg:t2m?[0,0,0]:[255,255,255], bgSep:!t2m, bgIdx:0, colors:best.segs.map(s=>s.c), segs,
    segCenters:best.segs.map(s=>[xb, s.yc]), bar:{orient:"v", c0:Math.round(949*sx), c1:Math.round(961*sx), rect:[Math.round(947*sx), segs[segs.length-1].a, Math.round(964*sx), segs[0].b+1]},
    inv:[], fp:`wm:${best.id}:${W}x${H}`, wm:{id:best.id, name:best.name, kind:best.kind, edges:best.edges, geo, scale:[sx,sy]}};
}
// خطوط ثابت مرز/ساحل قالب weathermodels (از نمونه‌ها استخراج شده) — پیش از آمار کنار گذاشته می‌شوند
function wmStaticInto(cnt, n){
  if(!(P && P.T && P.T.wm)) return; const M=_wmLines; if(!M||!M.length) return; const [sx,sy]=P.T.wm.scale;
  for(let y=0;y<FH;y++){ const my=Math.round((y+P.fy0)/sy)-WM_LINES.y0; if(my<0||my>=WM_LINES.H) continue;
    for(let x=0;x<FW;x++){ const mx=Math.round((x+P.fx0)/sx)-WM_LINES.x0; if(mx<0||mx>=WM_LINES.W) continue; if(M[my*WM_LINES.W+mx]) cnt[y*FW+x]=Math.max(cnt[y*FW+x],n); } }
}

// اعداد سیاه/سفید چاپ‌شده روی نقشهٔ دمای weathermodels: جعبهٔ دور هر عدد از داده کنار گذاشته می‌شود (هالهٔ خاکستری با رنگ‌های ۴۰+ درجه اشتباه نشود)
function wmTextMask(d, cls){
  if(!(P && P.T && P.T.wm)) return;
  const isT=(r,g,b)=>{ const mx=Math.max(r,g,b), mn=Math.min(r,g,b); return (mx<75 && mx-mn<35) || (mn>=236 && mx-mn<14); };
  const T=new Uint8Array(N); let any=0;
  for(let y=0;y<FH;y++){ const iy=y+P.fy0; for(let x=0;x<FW;x++){ const i=(iy*P.W+x+P.fx0)*4; if(isT(d[i],d[i+1],d[i+2])){ T[y*FW+x]=1; any++; } } }
  if(!any) return;
  if(P.baseMask) for(let i=0;i<N;i++) if(P.baseMask[i]===1) T[i]=0;     // خطوط مرز ثابت جزو عدد نیستند
  const lab=new Int32Array(N).fill(-1), st=[];
  for(let s=0;s<N;s++){ if(!T[s]||lab[s]>=0) continue; let mnx=1e9,mxx=-1,mny=1e9,mxy=-1,cnt=0; lab[s]=1; st.push(s);
    while(st.length){ const q=st.pop(), x=q%FW, y=(q/FW)|0; cnt++; if(x<mnx)mnx=x; if(x>mxx)mxx=x; if(y<mny)mny=y; if(y>mxy)mxy=y;
      for(let dy=-2;dy<=2;dy++){ const yy=y+dy; if(yy<0||yy>=FH) continue; for(let dx=-2;dx<=2;dx++){ const xx=x+dx; if(xx<0||xx>=FW) continue; const j=yy*FW+xx; if(T[j]&&lab[j]<0){ lab[j]=1; st.push(j); } } } }
    const bw=mxx-mnx+1, bh=mxy-mny+1; if(cnt<4 || bw>40 || bh>22) continue;
    for(let y=Math.max(0,mny-2);y<=Math.min(FH-1,mxy+2);y++) for(let x=Math.max(0,mnx-2);x<=Math.min(FW-1,mxx+2);x++) cls[y*FW+x]=-1; }
}
// نام مدل از عنوان نقشه (کادر ثابت بالا-چپ). فعلاً امضای ECMWF؛ امضای مدل‌های دیگر با نام فایل یا نام واردشده توسط کاربر یاد گرفته می‌شود
const WMC_TITLE_SIGS={ECMWF:"000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000011111110000001111100001100000011100110000110000110001111111000000011000000000111100110001110000011100110001110000110001100000000000011000000000110000000001110000111100110001111000100001100000000000011000000001100000000001111000111100110001011001100001100000000000011111100001100000000001011001101100011011011001100001111111000000011000000001100000000001101101101100011011001001100001100000000000011000000001100000000001101111001100011011001101000001100000000000011000000000110000000001100110001100011110001111000001100000000000011000000000111100110001100110001100001110000111000001100000000000011111110000001111100001100000001100001110000111000001100000000000000000000000000000000000000000000000000000000000000000000000"};
function wmTitleBits(m){ if(!m || Math.abs(m.w/m.h-4/3)>0.01) return null; const sx=m.w/1000, sy=m.h/750, d=m.data; let s="";
  for(let y=4;y<20;y++) for(let x=22;x<88;x++){ const X=Math.round(x*sx), Y=Math.round(y*sy), i=(Y*m.w+X)*4; s+=(0.299*d[i]+0.587*d[i+1]+0.114*d[i+2])<140?"1":"0"; } return s; }
function wmModelName(m){
  const b=wmTitleBits(m); if(!b) return null; let best=null, bd=1e9;
  const learned=(typeof store!=="undefined" && store.get("wmsig",{}))||{};
  for(const [k,s] of Object.entries({...WMC_TITLE_SIGS, ...learned})){ if(s.length!==b.length) continue; let dd=0; for(let i=0;i<s.length;i++) if(s[i]!==b[i]) dd++; if(dd<bd){ bd=dd; best=k; } }
  return bd<=60 ? best : null;
}
function wmLearnName(m, name){ try{ const b=wmTitleBits(m); if(!b||!name) return; const L=store.get("wmsig",{}); L[name]=b; store.set("wmsig",L); }catch(e){} }
// نوارهای رنگ weathermodels.com در کتابخانهٔ رنگ نقشه‌های خروجی (بر اساس مقدار؛ بدون رنگ واسطه)
(function(){ try{
  const hx=c=>"#"+c.map(v=>Math.max(0,Math.min(255,v)).toString(16).padStart(2,"0")).join("");
  MT_PALS.wmc_precip=["#ffffff",...WMC_PRECIP_PAL.map(hx)]; MT_PAL_EDGES.wmc_precip=[0,...WMC_PRECIP_LAB];
  MT_PALS.wmc_t2m=WMC_T2M_PAL.map(hx); MT_PAL_EDGES.wmc_t2m=[-99,...WMC_T2M_PAL.slice(1).map((_,k)=>-51+k)];
  const add=(grp,item)=>{ if(MT_PAL_LIB[grp] && !MT_PAL_LIB[grp].some(x=>x[1]===item[1])) MT_PAL_LIB[grp].splice(2,0,item); };
  add("precip",["weathermodels.com (نوار اصلی سایت)","wmc_precip"]); add("snowp",["weathermodels.com (نوار اصلی سایت)","wmc_precip"]);
  for(const g of ["temp","tmax","tmin","td","tsoil"]) add(g,["weathermodels.com دمای ۲ متری","wmc_t2m"]);
}catch(e){ console.warn("wmc palettes",e); } })();
