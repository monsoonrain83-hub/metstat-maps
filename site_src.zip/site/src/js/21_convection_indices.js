// ---- فصل، ساعت و وزن علمی شاخص‌ها ----
// فصل گرم = از ۲۰ فروردین تا ۱۵ آبان؛ در این فصل رشد توده‌های تندری عمدتاً ۱۱ تا ۲۰ به وقت ایران است
function cvLocal(m){ const t=m.times&&m.times.end; if(!t) return null; const d=new Date(+t+210*6e4); return {d, h:d.getUTCHours()+d.getUTCMinutes()/60, key:d.toISOString().slice(0,13)}; }
function cvSeason(d){ const j=g2j(d.getUTCFullYear(), d.getUTCMonth()+1, d.getUTCDate()), jm=j[1], jd=j[2]; return (jm>1||(jm===1&&jd>=20)) && (jm<8||(jm===8&&jd<=15)); }
// وزن علمی: فصل گرم شاخص‌های بستهٔ هوا (LI، شوالتر، K، CAPE، DCI) بیشترین مهارت را دارند؛ فصل سرد CAPE کم‌مهارت است و واداشت همدیدی (ناوهٔ سرد ۵۰۰، رودباد، چینش) مهم‌تر است
const CV_SCI_W={
  warm:{li:1.5, si:1.5, ki:1.3, cape:1.3, dci:1.2, gdi:1.2, tt:1.0, lapse:1.0, boyden:1.0, sweat:0.8, soar:0.8, tsc:1.0, cin:1.0, pwat:1.0, td2m:1.0, rh:0.8,
        refl:1.2, ltg:1.3, cprec:1.2, gust:0.8, t500:0.8, gph500:0.6, shear:0.8, srh:0.6, srh01:0.5, jet:0.6, fzl:0.5, scp:0.6, stp:0.5, custom:1},
  cold:{li:1.2, si:1.3, ki:1.2, cape:0.6, dci:0.9, gdi:0.8, tt:1.3, lapse:1.2, boyden:0.9, sweat:0.8, soar:0.6, tsc:0.8, cin:0.8, pwat:1.0, td2m:0.9, rh:1.1,
        refl:1.2, ltg:1.3, cprec:1.2, gust:0.8, t500:1.4, gph500:1.3, shear:1.2, srh:0.8, srh01:0.6, jet:1.2, fzl:0.6, scp:0.7, stp:0.6, custom:1}};
function cvWMode(){ return store.get("cv.wmode","sci"); }
function cvSciW(type, warm){ const t=CV_SCI_W[warm?"warm":"cold"]; return t[type]!==undefined ? t[type] : 1; }
function cvIdxW(type, warm){ const mode=cvWMode(); if(mode==="eq") return 1; const sci=cvSciW(type, warm); if(mode==="man"){ const o=store.get("cv.wman",{}); return o[type]!==undefined ? o[type] : sci; } return sci; }
function cvWarmNow(){ const ts=cv.maps.map(cvLocal).filter(Boolean); const d = ts.length ? ts[0].d : new Date(Date.now()+210*6e4); return cvSeason(d); }
// ترکیب گروهی شاخص‌ها روی یک زیرمجموعه از نقشه‌ها (یک مدل، یک ساعت یا همه)
function cvCombine(fields, C){
  const {T, method, sig, pmin, sea, seaF} = C;
  const Pf=new Float32Array(N), If=new Float32Array(N), present=new Set(fields.map(f=>CV_IDX[f.m.type].g)), GF={};
  for(const g of present) if(g!=="org") GF[g]=new Float32Array(N).fill(NaN);
  for(let i=0;i<N;i++){
    const G={}, GW={}, GWl={}, DEF={}; let sm=0, sw=0, mn=1, any=false, si=0, swi=0, swil=0, defI=0, so=0, swo=0, st=0, swt=0;
    const onSea = sea && sea[i];
    for(const f of fields){ const t=T[f.m.type], ix=CV_IDX[f.m.type], v=f.vals[i]; let w=f.w; if(!(v===v) || !(w>0)) continue;
      let def=0; if(onSea && ix.sea){ def=w*(1-seaF); w*=seaF; }
      if(t.occ){ const a=cvRamp(v,t.occ); G[ix.g]=(G[ix.g]||0)+w*a; GW[ix.g]=(GW[ix.g]||0)+w; if(!def) GWl[ix.g]=(GWl[ix.g]||0)+w; DEF[ix.g]=(DEF[ix.g]||0)+def; sm+=w*a; sw+=w; if(w>0 && a<mn) mn=a; any=true; }
      if(t.sev){ const b=cvRamp(v,t.sev); if(ix.g==="inst"){ si+=w*b; swi+=w; if(!def) swil+=w; defI+=def; } else if(ix.g==="org"){ so+=w*b; swo+=w; } else { st+=w*b; swt+=w; } } }
    for(const g in DEF){ if(DEF[g]>0 && !(GWl[g]>0)){ G[g]+=0.5*DEF[g]; GW[g]+=DEF[g]; sm+=0.5*DEF[g]; sw+=DEF[g]; } }
    if(defI>0 && !(swil>0)){ si+=0.5*defI; swi+=defI; }
    for(const g in GF) if(GW[g]>0) GF[g][i]=G[g]/GW[g];
    let p=0;
    if(any){
      if(method==="mean") p=sm/sw;
      else if(method==="min") p=mn;
      else { let lg=0, wt=0;
        for(const g in G){ if(g==="inst") continue; const fg=Math.max(0.05, G[g]/GW[g]); lg+=GW[g]*Math.log(fg); wt+=GW[g]; }
        const M = wt ? Math.exp(lg/wt) : 1, Fi = GW.inst ? G.inst/GW.inst : null; p = Fi===null ? M : Fi*M; }
    }
    Pf[i]=p*100;
    const parts=[]; if(swi) parts.push([si/swi,0.55]); if(swo) parts.push([so/swo,0.25]); if(swt) parts.push([st/swt,0.20]);
    let I=0, W_=0; for(const [a,w] of parts){ I+=a*w; W_+=w; } If[i]= W_ ? 100*I/W_ : 0;
  }
  const P2 = sig>0 ? gauss(Pf, sig) : Pf, I2 = sig>0 ? gauss(If, sig) : If;
  for(let i=0;i<N;i++){ let p=P2[i]; if(p>PROB_MAX) p=PROB_MAX; if(p<ZERO_BELOW) p=0; P2[i]=p; I2[i] = p>=pmin ? I2[i] : 0; }
  return {P2, I2, GF};
}
// آیا مقدار کمترِ این شاخص مساعدتر است؟ (LI، شوالتر، CIN، دمای ۵۰۰، ژئوپتانسیل، تراز صفر)
function cvLowerBetter(type){ const ix=CV_IDX[type], r=ix.occ||ix.sev; return !!(r && r[0]>r[r.length-1]); }
async function cvRun(){
  if(cv.busy){ cv.pending=true; return; }
  const maps=cv.maps.filter(m=>!m.bad && m.v && m.role!=="cmp");
  if(!maps.length){ if(cv.maps.length){ const need=cv.maps.filter(m=>!m.bad&&!m.v).length, bad=cv.maps.filter(m=>m.bad).length;
      cvStatus(need ? `⚠ هنوز هیچ نقشه‌ای آمادهٔ ترکیب نیست: برای ${FA(need)} نقشه اعداد نوار رنگ را در فهرست کناری وارد کنید (کادر نارنجی).` : `⚠ قالب ${FA(bad)} نقشه تشخیص داده نشد؛ نقشهٔ کامل (همراه نوار رنگ) بدهید.`, 0);
      $("cvStatus").classList.add("warn"); const f=document.querySelector("#cvInputs figure.need"); if(f) f.scrollIntoView({block:"nearest",behavior:"smooth"}); const ed=document.querySelector("#cvList input.ed"); if(ed && !ed.value) ed.focus(); }
    return; }
  if(!cv.maps.some(m=>m.role==="cmp" && !m.bad && m.v)){
    cvStatus("⚠ برای مقایسه، دست‌کم یک نقشهٔ بارش مدل را در بخش «نقشه‌های بارش مدل‌ها (برای مقایسه)» بارگذاری کنید (الزامی؛ در تحلیل دخالت داده نمی‌شود).", 0);
    $("cvStatus").classList.add("warn"); $("cvPDrop").classList.add("need"); return; }
  $("cvStatus").classList.remove("warn");
  cv.busy=true; $("cvRun").disabled=true; const prev=P?P.key:null; const warns=[];
  { const sk=cv.maps.filter(m=>m.role!=="cmp" && (m.bad||!m.v)), nm=a=>a.slice(0,6).map(m=>"«"+m.file.name+"»").join("، ")+(a.length>6?` و ${FA(a.length-6)} نقشهٔ دیگر`:"");
    const nb=sk.filter(m=>m.bad), ne=sk.filter(m=>!m.bad);
    if(ne.length) warns.push(`${FA(ne.length)} نقشه هنوز اعداد نوار رنگ ندارد و در تحلیل نیامد (${nm(ne)})؛ اعداد را در فهرست کناری وارد کنید.`);
    if(nb.length) warns.push(`قالب ${FA(nb.length)} نقشه تشخیص داده نشد (${nm(nb)}).`); }
  try{
    const ref=maps[0], rp=ref.prof, T=cvThr();
    // ۱) رقومی‌سازی و هم‌ترازکردن با کادر نقشهٔ مرجع
    const fields=[];
    for(let k=0;k<maps.length;k++){ const m=maps[k];
      cvStatus(`رقومی‌سازی ${m.file.name}…`, 0.05+0.5*k/maps.length); await tick();
      const D=await cvDigitize(m);
      if(!(m.w===ref.w && m.h===ref.h)){ cvStatus(`هم‌ترازی ${m.file.name} با نقشهٔ مرجع (یافتن مکان)…`, 0.05+0.5*k/maps.length); await tick(); }
      const al=await cvAlign(m, D, ref, rp);
      if(!al){ warns.push(`«${m.file.name}» قالب دیگری دارد و مکانش پیدا نشد؛ کنار گذاشته شد. نقشه‌های هم‌قالب (یک سایت و یک محدوده) بدهید.`); continue; }
      let raw=null; if(D.raw){ const a2=await cvAlign(m, {...D, vals:D.raw}, ref, rp); raw=a2&&a2.out; }
      fields.push({m, vals:al.out, raw, validFrac:D.validFrac, same:al.same, cls:al.same?D.cls:null, D});
    }
    if(!fields.length) throw new Error("هیچ نقشه‌ای قابل ترکیب نبود");
    await useProfile(rp.key);
    // خطوط ثابت (مرز و ساحل) = پیکسل‌های غیرداده‌ای که در همهٔ نقشه‌های هم‌قالب مشترک‌اند؛ پربندها و نوشته‌های هر نقشه حذف می‌شوند
    { const lumB=f=>{ const b=f.m.prof.bg; return 0.299*b[0]+0.587*b[1]+0.114*b[2]; };
      let same=fields.filter(f=>f.same && f.cls); const light=same.filter(f=>lumB(f)>=110); if(light.length>=2) same=light;
      if(same.length>=2){
        const bgc = rp.pal[rp.bgIdx||0], br=rp.bar&&rp.bar.rect;
        const synth = same.map(f=>{ const dd=new Uint8ClampedArray(ref.data);   // نوار رنگ و حاشیه از نقشهٔ مرجع
          const src=f.m.data, ox=f.D.fx0, oy=f.D.fy0, fw=f.D.FW;
          for(let y=0;y<FH;y++) for(let x=0;x<FW;x++){ const X=x+rp.fx0, Y=y+rp.fy0, sx=X-ox, sy=Y-oy, q=(Y*ref.w+X)*4; if(sx<0||sy<0||sx>=fw||sy>=f.D.FH) continue;
            const c=f.cls[sy*fw+sx]; if(c>=0){ dd[q]=bgc[0]; dd[q+1]=bgc[1]; dd[q+2]=bgc[2]; } else { const k=(Y*f.m.w+X)*4, l=Math.round(Math.min(0.299*src[k]+0.587*src[k+1]+0.114*src[k+2], Math.min(src[k],src[k+1],src[k+2])+40)); dd[q]=l; dd[q+1]=l; dd[q+2]=l; } }
          return {data:dd, w:ref.w, h:ref.h}; });
        computeStatic(synth); rp.staticDirty=true;
        // فقط خطوط تیره (مرز و ساحل) بمانند؛ زمینهٔ سفید برچسب‌ها و هاله‌ها حذف شوند
        if(P.ov && P.ov.bold){ const c=P.ov.bold.getContext("2d"), im=c.getImageData(0,0,P.W,P.H), d=im.data;
          for(let q=0;q<d.length;q+=4) if(d[q+3] && 0.299*d[q]+0.587*d[q+1]+0.114*d[q+2] > 170) d[q+3]=0; c.putImageData(im,0,0); }
      } else if(rp.staticDirty){ computeStatic(rp.models); rp.staticDirty=false; }
    }
    const g0=await cvGeo(ref); if(g0){ rp.geo=true; [rp.ax,rp.bx,rp.ay,rp.by]=g0; } else rp.geo=false;
    if(rp.geo){ P.ov={bold:vectorBorders(rp)}; }
    await useProfile(rp.key);
    cvStatus("ترکیب شاخص‌ها…", 0.65); await tick();
    // ۲) مطلوبیت هر شاخص و ترکیب
    const method=$("cvMethod").value, pmin=parseFloat($("cvPmin").value)||0, sig=Math.max(0,parseFloat($("cvSigma").value)||0);
    if(!fields.some(f=>CV_IDX[f.m.type].g==="inst")) warns.push("هیچ شاخص ناپایداری (CAPE، LI، K، TT و …) وارد نشده؛ احتمال فقط از رطوبت و عامل صعود برآورد شد و قابل اتکا نیست.");
    // ماسک دریا برای CAPE، CIN و Thunderstorm composite
    const seaF=Math.max(0,Math.min(1,(parseFloat($("cvSeaW").value)||0)/100)), hasSea=fields.some(f=>CV_IDX[f.m.type].sea);
    let sea=null, seaFrac=0, outFrac=0;
    if(hasSea){
      if(rp.geo){ sea=new Uint8Array(N); let ns=0, no=0;
        for(let i=0;i<N;i++){ const X=rp.fx0+i%FW, Y=rp.fy0+Math.floor(i/FW), l=landAt((Y-rp.ay)/rp.by, (X-rp.ax)/rp.bx); if(l===0){ sea[i]=1; ns++; } else if(l<0) no++; }
        seaFrac=ns/N; outFrac=no/N;
        if(outFrac>0.3) warns.push("بخشی از نقشه بیرون از محدودهٔ ماسک خشکی/دریا (۱۰ تا ۵۰ شمالی، ۲۵ تا ۸۰ شرقی) است؛ آنجا کاهش وزن روی دریا اعمال نشد.");
      } else warns.push("مکان جغرافیایی نقشهٔ مرجع پیدا نشد؛ کاهش وزن CAPE/CIN/Thunderstorm composite روی دریا اعمال نشد.");
    }
    // وزن هر نقشه = وزن شاخص (علمی-فصلی یا دستی) × ضریب ساعت (فصل گرم: ۱۱ تا ۲۰ به وقت ایران)
    const locs=fields.map(f=>cvLocal(f.m)).filter(Boolean), warm=cvSeason(locs.length?locs[0].d:new Date(Date.now()+210*6e4));
    for(const f of fields){ f.loc=cvLocal(f.m); f.tf = warm && f.loc ? ((f.loc.h>=11 && f.loc.h<20) ? 1 : 0.6) : 1; f.w = cvIdxW(f.m.type, warm)*f.tf; }
    const CTX={T, method, sig, pmin, sea, seaF};
    const ALL=cvCombine(fields, CTX), P2=ALL.P2, I2=ALL.I2, GF=ALL.GF;
    // هر مدل جداگانه
    const mdOf=f=>f.m.model||"مدل نامشخص", models=[...new Set(fields.map(mdOf))];
    const allG=new Set(fields.map(f=>CV_IDX[f.m.type].g).filter(g=>g!=="org"));
    const perModel = models.length>1 ? models.map(md=>{ const fs=fields.filter(f=>mdOf(f)===md); cvStatus(`ترکیب شاخص‌های ${md}…`, 0.7); const g=new Set(fs.map(f=>CV_IDX[f.m.type].g)); return {model:md, n:fs.length, names:[...new Set(fs.map(f=>CV_IDX[f.m.type].n.replace(/\s*\(.*\)/,"")))], missing:[...allG].filter(x=>!g.has(x)), ...cvCombine(fs, CTX)}; }) : [];
    // هر ساعت جداگانه (برای «همرفت در چه ساعتی محتمل‌تر است»)
    const slotKeys=[...new Set(fields.filter(f=>f.loc).map(f=>f.loc.key))].sort(), slots=[];
    if(slotKeys.length>1) for(const k of slotKeys){ const fs=fields.filter(f=>f.loc && f.loc.key===k); if(!fs.some(f=>CV_IDX[f.m.type].g==="inst") || new Set(fs.map(f=>f.m.type)).size<2) continue;
      const R=cvCombine(fs, CTX); let s_=0, n_=0, mx=0, a20=0; for(let i=0;i<N;i+=3){ if(sea&&sea[i]) continue; s_+=R.P2[i]; n_++; if(R.P2[i]>mx) mx=R.P2[i]; if(R.P2[i]>=20) a20++; }
      slots.push({key:k, d:fs[0].loc.d, h:fs[0].loc.h, mean:n_?s_/n_:0, max:mx, a20:n_?a20/n_:0, n:fs.length, names:[...new Set(fs.map(f=>CV_IDX[f.m.type].n.replace(/\s*\(.*\)/,"")))]}); }
    // آمار هر شاخص در همهٔ ساعت‌ها: میانگین و بیشینه (برای شاخص‌های «کمتر بهتر»: کمینه)، برای هر مدل و همهٔ مدل‌ها
    const types=[...new Set(fields.map(f=>f.m.type))], stats=[], typeMean={}, typeExt={};
    // میانگین و مقدار حدی هر پیکسل (حلقهٔ بیرونی روی نقشه‌ها: چند برابر سریع‌تر از حلقهٔ بیرونی روی پیکسل‌ها)
    const agg=(fs, low)=>{ const sum=new Float64Array(N), cnt=new Uint16Array(N), ext=new Float32Array(N).fill(NaN);
      for(const f of fs){ const a=f.raw||f.vals; for(let i=0;i<N;i++){ const v=a[i]; if(v!==v) continue; sum[i]+=v; cnt[i]++; const e=ext[i]; if(e!==e || (low ? v<e : v>e)) ext[i]=v; } }
      const mean=new Float32Array(N); for(let i=0;i<N;i++) mean[i]=cnt[i]?sum[i]/cnt[i]:NaN; return {mean, ext}; };
    for(const t of types){ const fs=fields.filter(f=>f.m.type===t), low=cvLowerBetter(t), mds=[...new Set(fs.map(mdOf))];
      const A=agg(fs, low); const At=(CV_IDX[t].anom||CV_IDX[t].rel) ? agg(fs.map(f=>({...f, raw:null})), low) : A; typeMean[t]=At.mean; typeExt[t]=At.ext;
      stats.push({type:t, model:mds.length===1?mds[0]:"همهٔ مدل‌ها", all:true, n:fs.length, hours:new Set(fs.map(f=>f.loc&&f.loc.key)).size, low, mean:A.mean, ext:A.ext, rep:fs[0].m});
      if(mds.length>1) for(const md of mds){ const g=fs.filter(f=>mdOf(f)===md), B=agg(g, low); stats.push({type:t, model:md, all:false, n:g.length, hours:new Set(g.map(f=>f.loc&&f.loc.key)).size, low, mean:B.mean, ext:B.ext, rep:g[0].m}); } }
    // احتمال تگرگ = احتمال همرفت × مساعدت تگرگ (ناپایداری، چینش باد، تراز صفر درجه، دمای ۵۰۰، آهنگ کاهش دما، بازتاب)
    let HAIL=null, hailInfo=null;
    { const tm=k=>typeMean[k]||null, cl=v=>v<0?0:v>1?1:v;
      const cape=tm("cape"), li=tm("li"), sh=tm("shear"), fz=tm("fzl"), t5=tm("t500"), lr=tm("lapse"), rf=tm("refl"), ki=tm("ki"), tt=tm("tt");
      if(cape||li||rf||ki||tt){ HAIL=new Float32Array(N); const used=new Set();
        // اگر نقشهٔ تراز صفر درجه/دمای ۵۰۰/آهنگ کاهش نیست: برآورد اقلیمی تراز صفر درجه (ماه و عرض جغرافیایی) و فاصلهٔ آن از سطح زمین (DEM)
        // تا تگرگ روی دشت‌های گرم و سواحل و دریای گرم (تراز صفر خیلی بالا) بیش‌برآورد نشود
        let CLIM=null;
        if(!fz && !t5 && !lr && rp.geo){ try{ const dem=await dsBuiltinDEM(); const loc0=locs.length?locs[0].d:new Date(); const mo=(loc0.getUTCMonth?loc0.getUTCMonth():new Date().getUTCMonth());
          const A=[2.4,2.6,3.0,3.4,3.9,4.4,4.8,4.8,4.5,3.9,3.2,2.6][mo]; CLIM=new Float32Array(N);
          for(let i=0;i<N;i++){ const X=rp.fx0+i%FW, Y=rp.fy0+Math.floor(i/FW), la=(Y-rp.ay)/rp.by, lo=(X-rp.ax)/rp.bx; let z=0; const jj=Math.round((lo-dem.x0)/dem.dx), ii=Math.round((dem.y0-la)/dem.dy); if(jj>=0&&ii>=0&&jj<dem.nx&&ii<dem.ny){ const v=dem.data[ii*dem.nx+jj]; if(v===v) z=Math.max(0,v)/1000; }
            const fzl=A-0.08*(la-30), melt=fzl-z; CLIM[i]=cl((3.6-melt)/2.6); } used.add("clim"); }catch(e){ console.warn("hail clim",e); } }
        for(let i=0;i<N;i++){
          const ins=[]; if(cape&&cape[i]===cape[i]){ ins.push(cl((cape[i]-400)/2000)); used.add("cape"); } if(li&&li[i]===li[i]){ ins.push(cl((-1-li[i])/6)); used.add("li"); }
          if(!ins.length){ if(tt&&tt[i]===tt[i]){ ins.push(cl((tt[i]-46)/10)); used.add("tt"); } else if(ki&&ki[i]===ki[i]){ ins.push(cl((ki[i]-24)/14)); used.add("ki"); } }
          const I_=ins.length?Math.max(...ins):0;
          const O_= sh&&sh[i]===sh[i] ? (used.add("shear"), cl((sh[i]-8)/17)) : 0.45;
          const col=[]; if(fz&&fz[i]===fz[i]){ col.push(cl((4300-fz[i])/1500)); used.add("fzl"); } if(t5&&t5[i]===t5[i]){ col.push(cl((-6-t5[i])/12)); used.add("t500"); } if(lr&&lr[i]===lr[i]){ col.push(cl((lr[i]-6)/2)); used.add("lapse"); }
          const C_=col.length?col.reduce((a,b)=>a+b,0)/col.length:(CLIM?CLIM[i]:0.45);
          let H=Math.sqrt(I_)*(0.35+0.65*O_)*(0.35+0.65*C_);
          if(rf&&rf[i]===rf[i]){ H=Math.max(H, cl((rf[i]-45)/15)); used.add("refl"); }
          HAIL[i]=P2[i]*H; }
        if(sig>0){ const g=gauss(HAIL, sig); HAIL=g; }
        if(sea && seaF<1) for(let i=0;i<N;i++) if(sea[i]) HAIL[i]*=Math.max(seaF,0.3);
        let hm=0, a10=0; for(let i=0;i<N;i++){ if(HAIL[i]>hm) hm=HAIL[i]; if(HAIL[i]>=10) a10++; }
        const miss=["shear","fzl","t500","lapse"].filter(k=>!used.has(k)); used.delete("clim");
        hailInfo={max:hm, a10:a10/N, used:[...used], miss, clim:!!CLIM}; }
      else warns.push("برای نقشهٔ احتمال تگرگ دست‌کم یکی از شاخص‌های CAPE، LI، K، Total Totals یا بازتاب رادار لازم است."); }
    // ۴) مقایسه با نقشه‌های بارش مدل‌ها — بدون هیچ دخالتی در احتمال
    const cmpMaps=cv.maps.filter(m=>m.role==="cmp" && !m.bad && m.v), comps=[], NN=N, land=i=>!(sea&&sea[i]);
    for(const m of cmpMaps){ cvStatus(`مقایسه با بارش ${m.model||m.file.name}…`, 0.8); await tick();
      const D=await cvDigitize(m), al=await cvAlign(m, D, ref, rp); await useProfile(rp.key);
      if(!al){ warns.push(`نقشهٔ بارش «${m.file.name}» با نقشهٔ مرجع هم‌تراز نشد و در مقایسه نیامد.`); continue; }
      const pr=al.out; let mx=0; for(let i=0;i<NN;i++) if(pr[i]>mx) mx=pr[i];
      const wetT = mx>=5 ? 1 : 0.2;
      let n=0, sx=0, sy=0, sxx=0, syy=0, sxy=0, wet=0, fav=0, both=0;
      for(let i=0;i<NN;i++){ const v=pr[i]; if(!(v===v) || !land(i)) continue; const a=P2[i], b=Math.log1p(Math.max(0,v)); n++; sx+=a; sy+=b; sxx+=a*a; syy+=b*b; sxy+=a*b;
        const W_=v>=wetT, F_=a>=20; if(W_) wet++; if(F_) fav++; if(W_&&F_) both++; }
      const r = n>10 ? (sxy-sx*sy/n)/Math.sqrt(Math.max(1e-9,(sxx-sx*sx/n)*(syy-sy*sy/n))) : 0, hit=wet?both/wet:0, cover=fav?both/fav:0;
      comps.push({model:(m.model||m.file.name.replace(/\.[^.]+$/,""))+(m.region&&ref.region&&m.region!==ref.region?` (${CV_REGIONS[m.region]||m.region})`:""), r, hit, cover, wetFrac:n?wet/n:0, wetT, mx, score:0.5*Math.max(0,r)+0.25*hit+0.25*cover, pr}); }
    comps.sort((a,b)=>b.score-a.score);
    if(!cmpMaps.length) warns.push("نقشهٔ بارش هیچ مدلی برای مقایسه بارگذاری نشده است؛ آن را در بخش «نقشه‌های بارش مدل‌ها» اضافه کنید.");
    // ۵) آمار شاخص‌ها در ۹ بخش منطقه
    const SEC=["شمال‌غرب","شمال","شمال‌شرق","غرب","مرکز","شرق","جنوب‌غرب","جنوب","جنوب‌شرق"];
    const secOf=i=>Math.min(2,Math.floor(3*((i/FW)|0)/FH))*3+Math.min(2,Math.floor(3*(i%FW)/FW));
    const secL=new Array(9).fill(0), secT=new Array(9).fill(0); for(let i=0;i<NN;i++){ const k=secOf(i); secT[k]++; if(land(i)) secL[k]++; }
    const secOK=SEC.map((_,k)=>secL[k]>=0.08*secT[k]);
    const cityAt=[]; if(rp.geo) for(const [nm,la,lo] of CV_CITIES){ const X=Math.round(rp.ax+rp.bx*lo)-rp.fx0, Y=Math.round(rp.ay+rp.by*la)-rp.fy0; if(X<3||Y<3||X>=FW-3||Y>=FH-3) continue; const i=Y*FW+X; if(!land(i)) continue; cityAt.push({nm,i,sec:secOf(i)}); }
    const qtl=(a,q)=>a.length?a[Math.min(a.length-1,Math.floor(q*(a.length-1)))]:NaN;
    const tFields=types.map(t=>{ const fs=fields.filter(f=>f.m.type===t), lv=new Set(fs.map(f=>f.m.level)); return {m:{type:t, weight:cvIdxW(t,warm), level: lv.size===1?fs[0].m.level:null, model:null, times:null}, vals:typeMean[t], ext:typeExt[t], n:fs.length, hours:new Set(fs.map(f=>f.loc&&f.loc.key)).size}; });
    const idxStats=tFields.map((f,fi)=>{ const t=T[f.m.type], ix=CV_IDX[f.m.type], rr=t.occ||t.sev, sv=SEC.map(()=>[]), sf=new Float64Array(9), sn=new Float64Array(9), sea_=[];
      const nanL=new Float64Array(9); let pkF=-1, pkI=-1;
      for(let i=0;i<NN;i+=2){ const v=f.vals[i]; if(!(v===v)){ if(land(i)) nanL[secOf(i)]++; continue; } if(!land(i)){ sea_.push(v); continue; } const k=secOf(i); sv[k].push(v); const a=cvRamp(v,rr); if(a===a){ sf[k]+=a; sn[k]++; } const ae=cvRamp(f.ext?f.ext[i]:v,rr); if(ae>pkF){ pkF=ae; pkI=i; } }
      const secs=SEC.map((nm,k)=>{ const a=sv[k].sort((x,y)=>x-y); const nf=(a.length+nanL[k])?nanL[k]/(a.length+nanL[k]):0; return {nm, ok:secOK[k]&&a.length>5, nan:nf, okSec:secOK[k], med:qtl(a,0.5), p25:qtl(a,0.25), p75:qtl(a,0.75), fav: (sn[k] && nf<=0.6)?100*sf[k]/sn[k]:NaN}; });
      let peak=null; if(pkI>=0){ const near=[]; for(const c of cityAt){ const dx=c.i%FW-pkI%FW, dy=((c.i/FW)|0)-((pkI/FW)|0); near.push([c.nm, Math.hypot(dx,dy)]); }
        near.sort((a,b)=>a[1]-b[1]); peak={v:(f.ext||f.vals)[pkI], fav:100*pkF, sec:SEC[secOf(pkI)], near:near.filter(q=>q[1]<0.12*Math.max(FW,FH)).slice(0,2).map(q=>q[0])}; }
      sea_.sort((x,y)=>x-y);
      const cities=cityAt.map(c=>({nm:c.nm, sec:c.sec, v:f.vals[c.i], fav:100*cvRamp(f.vals[c.i],rr)})).filter(c=>c.fav===c.fav);
      const same_=tFields.filter(g=>g.m.type===f.m.type), dup=same_.length>1;
      let tag=""; if(dup){ const mods=new Set(same_.map(g=>g.m.model)); const tt=f.m.times&&f.m.times.end;
        const lvls=new Set(same_.map(g=>g.m.level));
        if(f.m.level && lvls.size===same_.length) tag=` (${f.m.level})`;
        else if(f.m.model && mods.size===same_.length) tag=` (${f.m.model})`;
        else if(tt) tag=` (${persianDT(tt,f.m.times.offset||0).replace(/^.*?[،,]\s*/,"")})`;
        else tag=` — نقشهٔ ${FA(same_.indexOf(f)+1)}`; }
      return {key:f.m.type, ix, name: ix.n+tag, short: ix.n.replace(/\s*\(.*?\)/,"")+tag, secs, seaMed: sea_.length>50 && sea ? qtl(sea_,0.5) : NaN, seaFrac:sea_.length/(NN/2), cities, peak, weight:f.m.weight, n:f.n, hours:f.hours}; });
    const pSec=SEC.map((nm,k)=>{ let s_=0,n_=0; for(let i=0;i<NN;i+=2) if(land(i)&&secOf(i)===k){ s_+=P2[i]; n_++; } return n_?s_/n_:NaN; });
    // ۳) زمان و عنوان
    const ts=fields.map(f=>f.m.times).filter(t=>t&&t.end);
    let from="", to="";
    if(ts.length){ const t=ts.reduce((a,b)=>+b.end>+a.end?b:a), off=t.offset||0; from="معتبر برای "+persianDT(t.end,off)+tzSuffix(off); }
    const names=types.map(t=>CV_IDX[t].n.replace(/\s*\(.*\)/,"")), mlab={ing:"مؤلفه‌ای", mean:"میانگین وزنی", min:"سخت‌گیرانه"}[method];
    const S={from, to, region:"", init:"", thr:[], sigma:sig, cap:Infinity, barMode:"full", borders:wbBorders(), grid:true, showBorders:$("cvBorders").checked, brand:$("brand").value.trim(), handle:$("handle").value.trim(), logoImg:state.logoImg};
    await document.fonts.ready;
    await Promise.all(["21px Titr","14px Ketab","14px Lalezar","27px Nastaliq"].map(f=>document.fonts.load(f,"آبAa1")));
    const info2=`شاخص‌ها: ${names.join("، ")}  |  روش: ${mlab}${sea&&seaFrac>0.01?`  |  CAPE/CIN روی دریا ×${FA(seaF)}`:""}`;
    let pmx=0, imx=0; for(let i=0;i<N;i++){ if(P2[i]>pmx) pmx=P2[i]; if(I2[i]>imx) imx=I2[i]; }

    let a50=0, a20=0, cls=[0,0,0,0]; for(let i=0;i<N;i++){ if(P2[i]>=50) a50++; if(P2[i]>=20) a20++; const c=INT_SCHEME.cls(I2[i]); if(c>=0) cls[c]++; }
    const rgs=fields.map(f=>f.m.region).concat(cmpMaps.map(m=>m.region)).filter(Boolean), rgCount={}; for(const r_ of rgs) rgCount[r_]=(rgCount[r_]||0)+1;
    const rgKey=ref.region || Object.keys(rgCount).sort((a,b)=>rgCount[b]-rgCount[a])[0], regionFa=(ref.region&&CV_REGIONS[ref.region]) || ref.regionFa || cvRegionFromGeo(rp) || (rgKey?CV_REGIONS[rgKey]:"");
    const tE=fields.map(f=>f.m.times&&f.m.times.end).filter(Boolean).map(d=>+d), tSpread = tE.length>1 ? (Math.max(...tE)-Math.min(...tE))/3600000 : 0;
    WUZ.autoCv = WU_ZOOMS[regionFa] ? regionFa : null; try{ wuzSync(); }catch(e){}
    const report=cvReport({P:P2, I:I2, GF, sea, seaFrac, seaF, rp, from, pmin, idxStats, comps, regionFa, tSpread, nIdx:types.length, SEC, secOK});
    cvReportExtra(report, {warm, slots, perModel, fields, sea, regionFa});
    const chart=cvChart(idxStats, pSec, SEC, secOK, regionFa);
    const RC={S, info2, pmin, refData:ref.data, zoom:WUZ.autoCv, rpKey:rp.key, cache:{}};
    const PI={ "all":{P:P2, I:I2, label:models.length>1?"همهٔ مدل‌ها":(models[0]||"")} }; for(const pm of perModel) PI[pm.model]={P:pm.P2, I:pm.I2, label:pm.model, n:pm.n, names:pm.names};
    const {cvP, cvI}=cvRenderPI(RC, PI, "all");
    let cvH=null; if(HAIL){ CUR_SCHEME=PROB_SCHEME; const hinf=`احتمال تگرگ = احتمال همرفت × مساعدت تگرگ${hailInfo.clim?" (تراز صفر از اقلیم)":""}  |  ${hailInfo.used.map(k=>CV_IDX[k].n.replace(/\s*\(.*\)/,"")).join("، ")}`;
      cvH=renderMap({field:HAIL, kind:"prob", title:"احتمال بارش تگرگ"+(regionFa?" — "+regionFa:""), info1:hinf, info2:hinf, info:hinf, S, max:hailInfo.max, ref:ref.data, zoom:WUZ.autoCv}); CUR_SCHEME=null; }
    cv.res={HAIL, hailInfo, cvH, report, chart, idxStats, pSec, SEC, secOK, comps, regionFa, P:P2, I:I2, cvP, cvI, fields, warns, RC, PI, models, stats, warm, slots, method, pmin, pmx, imx, a50:a50/N, a20:a20/N, cls:cls.map(c=>c/N), refKey:rp.key, S, names};
    cvShow();
    cvStatus(`احتمال وقوع و شدت همرفت آماده است: ${FA(fields.length)} از ${FA(cv.maps.filter(m=>m.role!=="cmp").length)} نقشهٔ شاخص در تحلیل آمد`+(warns.length?" · "+FA(warns.length)+" هشدار":""), 1);
  }catch(e){ console.error(e); cvStatus("خطا: "+e.message, 0); }
  CUR_SCHEME=null;
  if(prev && PROFILES[prev]) await useProfile(prev); else P=undefined;
  cv.busy=false; $("cvRun").disabled=false;
  if(cv.pending){ cv.pending=false; cvSchedule(10); }
}
function cvCard(title, sub, wide){
  const card=document.createElement("article"); card.className="card"+(wide?" wide":"");
  const hd=document.createElement("header"); hd.innerHTML=`<h3></h3><div class="sub"></div>`; hd.querySelector("h3").textContent=title; hd.querySelector(".sub").textContent=sub;
  const img=new Image(); img.onclick=()=>{ const d=$("zoom"); d.querySelector("img").src=img.src; d.showModal(); };
  const sx=document.createElement("div"); sx.className="stats"; const dl=document.createElement("div"); dl.className="dl";
  card.append(hd, img, sx, dl); return {card, hd, img, sx, dl};
}

// ZIP بدون فشرده‌سازی (برای دانلود گروهی، بدون کتابخانهٔ بیرونی)
function zipStore(files){
  const crcT=new Uint32Array(256); for(let n=0;n<256;n++){ let c=n; for(let k=0;k<8;k++) c = c&1 ? 0xEDB88320^(c>>>1) : c>>>1; crcT[n]=c>>>0; }
  const crc=a=>{ let c=0xFFFFFFFF; for(let i=0;i<a.length;i++) c=crcT[(c^a[i])&255]^(c>>>8); return (c^0xFFFFFFFF)>>>0; };
  const enc=new TextEncoder(), parts=[], cen=[]; let off=0;
  for(const [name,data] of files){ const nb=enc.encode(name), c=crc(data), h=new DataView(new ArrayBuffer(30));
    h.setUint32(0,0x04034b50,true); h.setUint16(4,20,true); h.setUint16(6,0x0800,true); h.setUint32(14,c,true); h.setUint32(18,data.length,true); h.setUint32(22,data.length,true); h.setUint16(26,nb.length,true);
    parts.push(new Uint8Array(h.buffer), nb, data);
    const e=new DataView(new ArrayBuffer(46)); e.setUint32(0,0x02014b50,true); e.setUint16(4,20,true); e.setUint16(6,20,true); e.setUint16(8,0x0800,true); e.setUint32(16,c,true); e.setUint32(20,data.length,true); e.setUint32(24,data.length,true); e.setUint16(28,nb.length,true); e.setUint32(42,off,true);
    cen.push(new Uint8Array(e.buffer), nb); off+=30+nb.length+data.length; }
  const cs=cen.reduce((a,b)=>a+b.length,0), end=new DataView(new ArrayBuffer(22)); end.setUint32(0,0x06054b50,true); end.setUint16(8,files.length,true); end.setUint16(10,files.length,true); end.setUint32(12,cs,true); end.setUint32(16,off,true);
  return new Blob([...parts, ...cen, new Uint8Array(end.buffer)], {type:"application/zip"});
}
function cvShow(){
  const r=cv.res, box=$("cvCards"); box.replaceChildren();
  if(!cv.maps.some(m=>m.bad||!m.v)) $("cvInBox").open=false;
  const mkdl=(label, name, make)=>{ const b=document.createElement("button"); b.className="btn"; b.type="button"; b.textContent=label;
    b.onclick=async()=>{ b.disabled=true; await tick(); const prev=P?P.key:null; try{ await useProfile(r.refKey); const blob=await make(); const u=URL.createObjectURL(blob), a=document.createElement("a"); a.href=u; a.download=name; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),4000); }catch(e){ console.error(e); } if(prev&&PROFILES[prev]) await useProfile(prev); b.disabled=false; };
    return b; };
  const png=cv_=>exportPNG(cv_);
  const attrs=t=>[["title",t],["valid",r.S.from],["indices",r.names.join(", ")],["method",r.method],["note","index-based (fuzzy-logic ingredients) estimate; not a calibrated climatological probability"]];
  // گزارش فارسی
  const rep=document.createElement("article"); rep.className="card wide cvrep";
  const repTxt=(r.report||[]).join("\n\n");
  rep.innerHTML=`<header><h3>گزارش شرایط همرفت${r.regionFa?" — "+r.regionFa:""}</h3></header><div class="paras"></div><div class="dl"></div>`;
  for(const t of (r.report||[])){ const pp=document.createElement("p"); pp.textContent=t; rep.querySelector(".paras").append(pp); }
  if(r.comps && r.comps.length){ const tb=document.createElement("table"); tb.className="cvref cvcmp";
    tb.innerHTML=`<thead><tr><th>مدل</th><th>هم‌خوانی کلی</th><th>بارش در نواحی مساعد</th><th>پوشش نواحی مساعد</th><th>همبستگی</th></tr></thead><tbody>`+
      r.comps.map((c,k)=>`<tr${k===0?' class="best"':""}><td>${k===0?"★ ":""}${c.model}</td><td>${FA(Math.round(c.score*100))}٪</td><td>${FA(Math.round(c.hit*100))}٪</td><td>${FA(Math.round(c.cover*100))}٪</td><td>${FA(c.r.toFixed(2))}</td></tr>`).join("")+`</tbody>`;
    rep.querySelector(".paras").append(tb); }
  const cp=document.createElement("button"); cp.className="btn"; cp.type="button"; cp.textContent="کپی متن";
  cp.onclick=async()=>{ try{ await navigator.clipboard.writeText(trText(repTxt)); cp.textContent="کپی شد ✓"; }catch(e){ const t=document.createElement("textarea"); t.value=trText(repTxt); document.body.append(t); t.select(); document.execCommand("copy"); t.remove(); cp.textContent="کپی شد ✓"; } setTimeout(()=>cp.textContent="کپی متن",1500); };
  const tx=document.createElement("button"); tx.className="btn"; tx.type="button"; tx.textContent="TXT";
  tx.onclick=()=>{ const u=URL.createObjectURL(new Blob(["\ufeff"+trText(repTxt)],{type:"text/plain;charset=utf-8"})), a=document.createElement("a"); a.href=u; a.download="convection_report.txt"; a.click(); setTimeout(()=>URL.revokeObjectURL(u),2000); };
  rep.querySelector(".dl").append(cp, tx); box.append(rep);
  // نمودار مقایسهٔ شاخص‌ها در بخش‌های منطقه + جدول مقادیر
  if(r.chart){ const ch=document.createElement("article"); ch.className="card wide cvchart";
    ch.innerHTML=`<header><h3>نمودار تحلیلی شاخص‌ها</h3><div class="sub">هر خط یک شاخص است: مطلوبیت آن برای همرفت (۰ تا ۱۰۰٪) در هر بخش از منطقه؛ خط‌چین خاکستری احتمال ترکیبی است</div></header>`;
    const im=document.createElement("img"); im.src=r.chart.toDataURL("image/png"); im.alt="نمودار مطلوبیت شاخص‌ها در بخش‌های منطقه"; ch.append(im);
    const cats=r.SEC.map((n,k)=>k).filter(k=>r.secOK[k]), tb=document.createElement("table"); tb.className="cvref";
    tb.innerHTML=`<thead><tr><th>شاخص</th>${cats.map(k=>`<th>${r.SEC[k]}</th>`).join("")}</tr></thead><tbody>`+
      r.idxStats.map(st=>`<tr><td>${st.name}</td>${cats.map(k=>{ const c=st.secs[k]; return `<td>${c.fav===c.fav?FA(Math.round(c.fav))+"٪":"—"}<small> (${cvFmtV(c.med,st.ix)})</small></td>`; }).join("")}</tr>`).join("")+
      `<tr><td><b>احتمال ترکیبی</b></td>${cats.map(k=>`<td><b>${r.pSec[k]===r.pSec[k]?FA(Math.round(r.pSec[k]))+"٪":"—"}</b></td>`).join("")}</tr></tbody>`;
    const wrap=document.createElement("div"); wrap.className="tblwrap"; wrap.append(tb); ch.append(wrap);
    const dl=document.createElement("div"); dl.className="dl"; dl.append(mkdl("PNG","convection_indices_chart.png",()=>png(r.chart))); ch.append(dl); box.append(ch); }
  // نقشه‌های احتمال و شدت: همهٔ مدل‌ها با هم + هر مدل جداگانه
  const keys=Object.keys(r.PI), tabs=document.createElement("div"); tabs.className="cvtabs wide"; tabs.setAttribute("role","tablist");
  const c1=cvCard("احتمال وقوع همرفت", "شانس شکل‌گیری همرفت از ترکیب مؤلفه‌های ناپایداری، رطوبت و عامل صعود");
  const c2=cvCard("شدت بالقوهٔ همرفت", `توان همرفت در صورت وقوع (ناپایداری قوی، چینش باد، بارش شدید)؛ فقط جایی که احتمال ≥ ${FA(r.pmin)}٪`);
  const setPI=async key=>{ const prev=P?P.key:null; await useProfile(r.RC.rpKey); const R=cvRenderPI(r.RC, r.PI, key), d=r.PI[key]; if(prev&&PROFILES[prev]) await useProfile(prev);
    tabs.querySelectorAll("button").forEach(b=>b.setAttribute("aria-selected", b.dataset.k===key?"true":"false"));
    const nm=key==="all"?"all":key.replace(/[^A-Za-z0-9]+/g,"_");
    let a50=0,a20=0,cls=[0,0,0,0]; for(let i=0;i<N;i++){ if(d.P[i]>=50) a50++; if(d.P[i]>=20) a20++; const c=INT_SCHEME.cls(d.I[i]); if(c>=0) cls[c]++; }
    c1.img.src=R.cvP.toDataURL("image/png"); c1.img.alt="نقشهٔ احتمال وقوع همرفت — "+d.label;
    c1.sx.innerHTML=`<span>بیشینهٔ احتمال<b>${FA(Math.round(R.pmx))}٪</b></span><span>مساحت بالای ۵۰٪<b>${FA(Math.round(a50/N*100))}٪</b></span><span>مساحت بالای ۲۰٪<b>${FA(Math.round(a20/N*100))}٪</b></span>`;
    c1.dl.replaceChildren(mkdl("PNG",`convection_probability_${nm}.png`,()=>png(R.cvP)), mkdl("CSV",`convection_probability_${nm}.csv`,()=>toCSV(d.P,"probability_percent")), mkdl("NetCDF",`convection_probability_${nm}.nc`,()=>toNetCDF(d.P,"convection_probability","percent","probability of convection (index-based)",attrs("احتمال وقوع همرفت — "+d.label))));
    c2.img.src=R.cvI.toDataURL("image/png"); c2.img.alt="نقشهٔ شدت بالقوهٔ همرفت — "+d.label;
    c2.sx.innerHTML=INT_SCHEME.labs.slice(1).map((l,k)=>`<span>${l}<b>${FA(Math.round(cls[k]/N*100))}٪</b></span>`).join("");
    c2.dl.replaceChildren(mkdl("PNG",`convection_intensity_${nm}.png`,()=>png(R.cvI)), mkdl("CSV",`convection_intensity_${nm}.csv`,()=>toCSV(d.I,"intensity_index")), mkdl("NetCDF",`convection_intensity_${nm}.nc`,()=>toNetCDF(d.I,"convection_intensity","0-100","potential convective intensity index",attrs("شدت بالقوهٔ همرفت — "+d.label)))); };
  if(keys.length>1){ for(const k of keys){ const b=document.createElement("button"); b.type="button"; b.className="btn sm"; b.dataset.k=k; b.setAttribute("role","tab"); b.textContent=k==="all"?"همهٔ مدل‌ها با هم":k+(r.PI[k].n?` (${FA(r.PI[k].n)} نقشه)`:""); b.onclick=()=>setPI(k); tabs.append(b); }
    const lb=document.createElement("span"); lb.className="hint"; lb.textContent="نقشه‌های همرفت:"; tabs.prepend(lb); }
  setPI("all");
  // نقشه‌های آماری هر شاخص: میانگین و بیشینهٔ همهٔ ساعت‌ها، برای هر مدل و همهٔ مدل‌ها
  const sv=document.createElement("article"); sv.className="card wide cvstat";
  sv.innerHTML=`<header><h3>نقشه‌های آماری شاخص‌ها</h3><div class="sub">برای هر شاخص: میانگین و بیشینهٔ همهٔ ساعت‌ها (برای شاخص‌هایی که مقدار کمترشان مساعدتر است، مثل LI و CIN، کمینه)، برای هر مدل و همهٔ مدل‌ها با هم؛ با نوار رنگ خودِ همان شاخص</div></header>
    <div class="cvsel"><label>شاخص<select class="sT"></select></label><label>مدل<select class="sM"></select></label><label>آماره<select class="sK"><option value="mean">میانگین همهٔ ساعت‌ها</option><option value="ext">بیشینه/کمینهٔ همهٔ ساعت‌ها</option></select></label></div>
    <img alt="" class="sImg"><div class="stats sStat"></div><div class="dl"></div>`;
  const sT=sv.querySelector(".sT"), sM=sv.querySelector(".sM"), sK=sv.querySelector(".sK"), sImg=sv.querySelector(".sImg"), sDl=sv.querySelector(".dl");
  const tps=[...new Set(r.stats.map(x=>x.type))];
  sT.innerHTML=tps.map(t=>`<option value="${t}">${CV_IDX[t].n}</option>`).join("");
  const fillM=()=>{ const ms=r.stats.filter(x=>x.type===sT.value); sM.innerHTML=ms.map((x,i)=>`<option value="${i}">${x.all?(x.model==="همهٔ مدل‌ها"?"همهٔ مدل‌ها":x.model+" (تنها مدل)"):x.model} — ${FA(x.n)} نقشه</option>`).join("");
    const st=ms[0]; sK.options[1].textContent = st&&st.low ? "کمینهٔ همهٔ ساعت‌ها (مساعدترین)" : "بیشینهٔ همهٔ ساعت‌ها"; };
  const curSt=()=>r.stats.filter(x=>x.type===sT.value)[+sM.value||0];
  const showSt=async()=>{ const st=curSt(); if(!st) return; const prev=P?P.key:null; await useProfile(r.RC.rpKey); const c=cvRenderStat(r.RC, st, sK.value); if(prev&&PROFILES[prev]) await useProfile(prev);
    sImg.src=c.toDataURL("image/png"); sImg.alt=`${sK.value==="mean"?"میانگین":"بیشینه"} ${CV_IDX[st.type].n} — ${st.model}`;
    const fld=st[sK.value==="mean"?"mean":"ext"], nm=`${st.type}_${st.model==="همهٔ مدل‌ها"?"all":st.model.replace(/[^A-Za-z0-9]+/g,"_")}_${sK.value==="mean"?"mean":(st.low?"min":"max")}`;
    sDl.replaceChildren(mkdl("PNG", nm+".png", ()=>png(c)), mkdl("CSV", nm+".csv", ()=>toCSV(fld, st.type)), mkdl("ZIP همهٔ نقشه‌های آماری (PNG)", "convection_index_stats.zip", async()=>{ const files=[]; const prev2=P?P.key:null; await useProfile(r.RC.rpKey);
        for(const x of r.stats) for(const k of ["mean","ext"]){ const cc=cvRenderStat(r.RC, x, k); const nm2=`${x.type}_${x.model==="همهٔ مدل‌ها"?"all":x.model.replace(/[^A-Za-z0-9]+/g,"_")}_${k==="mean"?"mean":(x.low?"min":"max")}.png`; files.push([nm2, new Uint8Array(await (await exportPNG(cc)).arrayBuffer())]); }
        if(prev2&&PROFILES[prev2]) await useProfile(prev2); return zipStore(files); })); };
  sT.onchange=()=>{ fillM(); showSt(); }; sM.onchange=showSt; sK.onchange=showSt;
  fillM(); showSt();
  // سهم هر شاخص: مطلوبیت همان شاخص روی کادر مرجع
  const c3=document.createElement("article"); c3.className="card wide";
  c3.innerHTML=`<header><h3>مطلوبیت هر شاخص</h3><div class="sub">هر شاخص بعد از رقومی‌سازی و تبدیل به ۰ تا ۱۰۰٪ مطلوبیت برای همرفت؛ برای بررسی درستی اعداد نوار رنگ</div></header>`;
  const mini=document.createElement("div"); mini.className="cvmini"; const T=cvThr();
  const RW=FW, RH=FH, sc=Math.min(1, 300/RW), pc=PROB_COLORS.map(hexRGB);
  for(const f of r.fields){ const t=T[f.m.type], rng=t.occ||t.sev, c=document.createElement("canvas"); c.width=Math.round(RW*sc); c.height=Math.round(RH*sc);
    const cx=c.getContext("2d"), im=cx.createImageData(c.width,c.height); let mnv=Infinity, mxv=-Infinity;
    for(let i=0;i<f.vals.length;i++){ const v=f.vals[i]; if(v===v){ if(v<mnv) mnv=v; if(v>mxv) mxv=v; } }
    for(let y=0;y<c.height;y++) for(let x=0;x<c.width;x++){ const v=f.vals[Math.min(RH-1,Math.floor(y/sc))*RW+Math.min(RW-1,Math.floor(x/sc))], q=(y*c.width+x)*4;
      let rgb=[235,235,235]; if(v===v){ const a=cvRamp(v,rng)*100, k=probClass(a); rgb = k<0 ? [255,255,255] : pc[k]; } im.data[q]=rgb[0]; im.data[q+1]=rgb[1]; im.data[q+2]=rgb[2]; im.data[q+3]=255; }
    cx.putImageData(im,0,0);
    const fg=document.createElement("figure"); const cap=document.createElement("figcaption");
    cap.textContent=`${CV_IDX[f.m.type].n}${f.m.model?" — "+f.m.model:""}${f.loc?" — ساعت "+FA(String(Math.floor(f.loc.h)).padStart(2,"0"))+":"+FA(String(Math.round((f.loc.h%1)*60)).padStart(2,"0")):""} · وزن ${FA(+(f.w||0).toFixed(2))} · مقادیر ${isFinite(mnv)?fmt(mnv,1):"—"} تا ${isFinite(mxv)?fmt(mxv,1):"—"}`;
    fg.append(c, cap); mini.append(fg); }
  c3.append(mini);
  if(r.warns.length){ const w=document.createElement("p"); w.className="hint"; w.style.cssText="color:var(--warn);padding:0 14px 12px;margin:0"; w.innerHTML=r.warns.join("<br>"); c3.append(w); }
  if(keys.length>1) box.append(tabs);
  box.append(c1.card, c2.card);
  if(r.cvH){ const h=r.hailInfo, ch=cvCard("احتمال بارش تگرگ", "احتمال همرفت × مساعدت تگرگ: ناپایداری (CAPE/LI)، چینش باد لایهٔ عمیق، تراز صفر درجه، دمای ۵۰۰ هکتوپاسکال، آهنگ کاهش دما و بازتاب رادار مدل (هر کدام که داده شده باشد)"+(r.hailInfo&&r.hailInfo.clim?"؛ تراز صفر درجه نقشه نداشت و از اقلیم ماه و ارتفاع زمین (DEM) برآورد شد":""));
    ch.img.src=r.cvH.toDataURL("image/png"); ch.img.alt="نقشهٔ احتمال بارش تگرگ";
    ch.sx.innerHTML=`<span>بیشینهٔ احتمال<b>${FA(Math.round(h.max))}٪</b></span><span>مساحت بالای ۱۰٪<b>${FA(Math.round(h.a10*100))}٪</b></span>`+(h.miss.length?`<span>برای دقت بیشتر<b>${h.miss.map(k=>CV_IDX[k].n.replace(/\s*\(.*\)/,"")).join("، ")}</b></span>`:"");
    ch.dl.append(mkdl("PNG","hail_probability.png",()=>png(r.cvH)), mkdl("CSV","hail_probability.csv",()=>toCSV(r.HAIL,"hail_probability_percent")), mkdl("NetCDF","hail_probability.nc",()=>toNetCDF(r.HAIL,"hail_probability","percent","index-based hail probability",attrs("احتمال بارش تگرگ"))));
    box.append(ch.card); }
  box.append(sv, c3);
}
function openCV(){
  $("landing").hidden=true; $("app").hidden=true; $("dsApp").hidden=true; $("ltApp").hidden=true; $("wnApp").hidden=true; $("cqcApp").hidden=true; if($("caApp")) $("caApp").hidden=true; $("cvApp").hidden=false;
  $("srcName").textContent="همرفت"; $("srcBtn").hidden=false;
  ribbon($("ribbon"), [[0,0,0],[255,255,255],[63,142,232],[255,225,40],[255,140,20],[215,25,28],[255,105,180]]); cvDrawList(); cvThrPanel();
  store.set("mode","cv");
}
$("cvFiles").onchange=()=>{ cvAdd($("cvFiles").files).then(cvThrPanel); $("cvFiles").value=""; };
$("cvPFiles").onchange=()=>{ cvAdd($("cvPFiles").files,"cmp"); $("cvPFiles").value=""; };
{ const el=$("cvPDrop"); el.addEventListener("dragover", e=>{ e.preventDefault(); el.classList.add("over"); }); el.addEventListener("dragleave", ()=>el.classList.remove("over"));
  el.addEventListener("drop", e=>{ e.preventDefault(); el.classList.remove("over"); cvAdd(e.dataTransfer.files,"cmp"); }); }
$("cvWEq").onclick=()=>{ store.set("cv.wman",{}); store.set("cv.wmode","eq"); cvWeightsPanel(); cvSchedule(50); };
for(const el of [$("cvDrop"), $("cvEmpty")]){
  el.addEventListener("dragover", e=>{ e.preventDefault(); el.classList.add("over"); });
  el.addEventListener("dragleave", ()=>el.classList.remove("over"));
  el.addEventListener("drop", e=>{ e.preventDefault(); el.classList.remove("over"); cvAdd(e.dataTransfer.files).then(cvThrPanel); });
}
$("cvEmpty").onclick=()=>$("cvFiles").click();

